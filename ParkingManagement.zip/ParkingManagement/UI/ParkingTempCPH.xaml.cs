﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ParkingModel;
using ParkingInterface;

namespace UI
{
    /// <summary>
    /// ParkingTempCPH.xaml 的交互逻辑
    /// </summary>
    public partial class ParkingTempCPH : SFMControls.WindowBase
    {
        /// <summary>
        /// 访问服务对象
        /// </summary>
        GetServiceData gsd = new GetServiceData();

        /// <summary>
        /// 传入参数
        /// </summary>
        Dictionary<string, object> dicAfferentParameter = new Dictionary<string, object>();


        /// <summary>
        /// 更新车牌
        /// </summary>
        private ParkingMonitoring.UpdateCPHDataHandler CPHDataHandler;

        /// <summary>
        /// 用于定时关闭确定窗口
        /// </summary>
        private System.Windows.Threading.DispatcherTimer dTimer = new System.Windows.Threading.DispatcherTimer();


        ParkingCommunication.VoiceSend cmd;

        string localImagePath = "";
        List<string> frmCPHList = new List<string>();

        int m_hLPRClient = 0;
        int m_nSerialHandle = 0;
        //int modulus = 0;

        int laneIndex = 0;

        private string sTitle = "";   //2016-11-17

        public ParkingTempCPH()
        {
            InitializeComponent();
        }

        public ParkingTempCPH(List<string> _frmCPHList, ParkingMonitoring.UpdateCPHDataHandler _CPHDataHandler, string _sTitle = "")
        {
            InitializeComponent();
            sTitle = _sTitle;
            frmCPHList = _frmCPHList;
            CPHDataHandler = _CPHDataHandler;
        }

        public ParkingTempCPH(Dictionary<string, object> _dicAfferentParameter, ParkingMonitoring.UpdateCPHDataHandler _CPHDataHandler,string _localImagePath)
        {
            InitializeComponent();
            CPHDataHandler = _CPHDataHandler;
            dicAfferentParameter = _dicAfferentParameter;
            localImagePath = _localImagePath;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                //ImageBrush berriesBrush = new ImageBrush();
                //berriesBrush.ImageSource = new BitmapImage(new Uri(System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, @"Resources\Main0.jpg"), UriKind.Absolute));

                //this.Background = berriesBrush;

                //if (sTitle != "")
                //{
                //    this.Title = sTitle;
                //}

                //modulus = Convert.ToInt32(frmCPHList[0]);
                //m_hLPRClient = ParkingMonitoring.m_hLPRClient[modulus];
                //m_nSerialHandle = ParkingMonitoring.m_nSerialHandle[modulus];

                //voicesend = new ParkingCommunication.VoiceSend(ParkingMonitoring.m_hLPRClient, ParkingMonitoring.m_nSerialHandle, 1007, 1005);

                //cboHeader0.Text = Model.LocalProvince;
                //cboHeader1.Text = Model.LocalProvince;
                //if (frmCPHList.Count > 4)
                //{
                //    if (frmCPHList[2].Length == 7)
                //    {
                //        cboHeader0.Text = frmCPHList[2].Substring(0, 1);
                //        txtCPH0.Text = frmCPHList[2].Substring(1, 6);
                //    }
                //    if (frmCPHList[3].Length == 7)
                //    {
                //        cboHeader1.Text = frmCPHList[3].Substring(0, 1);
                //        txtCPH1.Text = frmCPHList[3].Substring(1, 6);
                //    }
                //    cboInName.SelectedValue = Model.Channels[Convert.ToInt32(frmCPHList[0])].sInOutName;
                //    cboInName.Text = Model.Channels[Convert.ToInt32(frmCPHList[0])].sInOutName;
                //}

                if (null != dicAfferentParameter)
                {
                    if (dicAfferentParameter.ContainsKey("title"))
                    {
                        this.Title = dicAfferentParameter["title"].ToString();
                    }

                    if (dicAfferentParameter.ContainsKey("laneIndex"))
                    {
                        laneIndex = Convert.ToInt32(dicAfferentParameter["laneIndex"]);
                        m_hLPRClient = ParkingMonitoring.m_hLPRClient[laneIndex];
                        m_nSerialHandle = ParkingMonitoring.m_nSerialHandle[laneIndex];
                        cmd = new ParkingCommunication.VoiceSend(ParkingMonitoring.m_hLPRClient, ParkingMonitoring.m_nSerialHandle, 1007, 1005);

                        cboInName.Items.Add(Model.Channels[laneIndex].sInOutName);
                        cboInName.SelectedIndex = 0;
                        //cboInName.Text = Model.Channels[laneIndex].sInOutName;
                        //cboInName.Text = Model.Channels[laneIndex].sInOutName;
                    }

                    cboHeader0.Text = Model.LocalProvince;
                    cboHeader1.Text = Model.LocalProvince;

                    if (dicAfferentParameter.ContainsKey("plateNumber"))
                    {
                        if (dicAfferentParameter["plateNumber"].ToString().Length == 7)
                        {
                            cboHeader0.Text = dicAfferentParameter["plateNumber"].ToString().Substring(0, 1);
                            txtCPH0.Text = dicAfferentParameter["plateNumber"].ToString().Substring(1);
                        }
                    }

                    if (dicAfferentParameter.ContainsKey("newPlateNumber"))
                    {
                        if (dicAfferentParameter["newPlateNumber"].ToString().Length == 7)
                        {
                            cboHeader0.Text = dicAfferentParameter["newPlateNumber"].ToString().Substring(0, 1);
                            txtCPH0.Text = dicAfferentParameter["newPlateNumber"].ToString().Substring(1);
                        }
                    }
                }

                if (Model.iAutoMinutes == 1)
                {
                    dTimer.Tick += new EventHandler(dTimer_Tick);
                    dTimer.Interval = new TimeSpan(0, 0, Model.iAutoSetMinutes);
                    dTimer.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\r\nParKingTempCPH_Load");
            }
        }

        private void dTimer_Tick(object sender, EventArgs e)
        {
            dTimer.Stop();
            this.Close();
        }


        string sInputCPH = "";

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (optCPH0.IsChecked == true)
            {
                sInputCPH = cboHeader0.Text + txtCPH0.Text;
            }
            else
            {
                sInputCPH = cboHeader1.Text + txtCPH1.Text;
            }

            if (!CR.CheckUpCPH(sInputCPH))
            {
                MessageBox.Show("输入的车牌号不对，请校验！", "提示");
                return;
            }

            Request request = new Request();
            Result<ApproachRecord> approachResult;
            approachResult = request.SetCarInConfirmed<ApproachRecord>(Model.token, dicAfferentParameter["plateNumber"].ToString(), sInputCPH, Model.Channels[laneIndex].iCtrlID, Model.stationID, (PlateColor)dicAfferentParameter["cPColoar"]);


            switch (approachResult.rcode)
            {
                case Rcode.RepeatAdmission:
                case Rcode.OK:
                    {
                        cmd.SendOpen(laneIndex);
                        if (null != approachResult.Model)
                        {
                            cmd.VoiceDisplay(ParkingCommunication.VoiceType.InGateVoice, laneIndex, approachResult.Model.CardType ?? "TmpA", approachResult.Model.CPH ?? "", approachResult.Model.RemainingDays, approachResult.Model.CarPlace ?? "", approachResult.Model.RemainingPlaceCount);
                            CPHDataHandler(approachResult.Model, laneIndex, localImagePath);
                        }
                        this.Close();
                    }
                    break;
                default:
                    {
                        MessageBox.Show(approachResult.msg);
                        break;
                    } 
            }

        

           
           

            //if (sInputCPH.Length > 6)
            //{
            //    if (sInputCPH.Length == 7 || (sInputCPH.Substring(0, 2) == "WJ" && sInputCPH.Length == 8))
            //    {
            //        if (Model.Channels[Convert.ToInt32(frmCPHList[0])].iOpenType == 7)
            //        {
            //            List<CardIssue> lstCI = gsd.SelectFaXing(sInputCPH);
            //            if (lstCI.Count > 0)
            //            {
            //                dtStop = lstCI[0].CarValidEndDate;

            //                tmpCardType = lstCI[0].CarCardType;

            //                tmpCardNO = lstCI[0].CardNO;
            //            }
            //        }
            //    }
            //    if (sInputCPH.Length < 7)
            //    {
            //        sInputCPH = "";
            //    }


            //    CarIn ci = new CarIn();
            //    ci.CardNO = tmpCardNO == "" ? frmCPHList[1] : tmpCardNO;
            //    ci.CPH = sInputCPH;
            //    ci.CardType = tmpCardType;
            //    ci.InTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            //    ci.OutTime = DateTime.Now;
            //    ci.InGateName = cboInName.Text;
            //    ci.InOperator = Model.sUserName;
            //    ci.InOperatorCard = Model.sUserCard;
            //    ci.OutOperatorCard = "";
            //    ci.OutOperator = "";
            //    ci.SFJE = 0;
            //    //ci.SFTime = DateTime.Now;
            //    //ci.OvertimeSFTime = DateTime.Now;
            //    ci.InPic = frmCPHList[5];
            //    ci.BigSmall = Model.Channels[modulus].iBigSmall;
            //    ci.InUser = "";
            //    ci.SFOperatorCard = "";
            //    ci.StationID = Model.stationID;
            //    ci.CarparkNO = Model.iParkingNo;
            //    ci.CardType = frmCPHList[6];
            //    gsd.AddAdmission(ci, 20);


            //    //int Count = gsd.UpdateComerecord(tmpCardNO, tmpCardType, sInputCPH, frmCPHList[5], frmCPHList[1], Convert.ToDateTime(frmCPHList[4]));

            //    CPHDataHandler(sInputCPH, Convert.ToInt32(frmCPHList[0]), ci.InTime);

            //    voicesend.SendOpen(modulus);

            //    //CR.SendVoice.SendOpen(axznykt_1, Model.PubVal.Channels[modulus].iCtrlID, Model.PubVal.Channels[modulus].sIP, 0x0C, 5, m_hLPRClient, Model.PubVal.Channels[modulus].iXieYi);//开闸

                

            //    if (frmCPHList[6].Length > 3 && frmCPHList[6].Substring(0, 3) == "Mth")
            //    {
            //        if (Model.bOut485)
            //        {
            //            System.Threading.Thread.Sleep(50);
            //        }
            //    }
            //    else
            //    {
            //        if (Model.bOut485)
            //        {
            //            System.Threading.Thread.Sleep(50);
            //        }
                   
            //    }

            //    voicesend.VoiceDisplay(ParkingCommunication.VoiceType.InGateVoice, modulus, frmCPHList[6], sInputCPH, Convert.ToInt32(frmCPHList[8]), frmCPHList[9], Convert.ToInt32(frmCPHList[7]));

            //    if (frmCPHList[5] != "")
            //    {
            //        string path = gsd.UpLoadPic(frmCPHList[5]);
            //        gsd.UpdateCarIn(frmCPHList[1], path);
            //    }
                    

                //this.Close();
            
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            cmd.LoadLsNoX2010znykt(laneIndex, "D2");
            this.Close();
        }

        private void WindowBase_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.OriginalSource == this)
            {
                if (e.Key == Key.E)
                {
                    btnOK_Click(null, null);
                }
                else if (e.Key == Key.Q)
                {
                    btnCancel_Click(null, null);
                }
            }
        }
    }
}
