﻿using ParkingInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UI
{
    /// <summary>
    /// ParkingMthCPH.xaml 的交互逻辑
    /// </summary>
    public partial class ParkingMthCPH : SFMControls.WindowBase
    {
        GetServiceData gsd = new GetServiceData();
        List<string> frmCPHList = new List<string>();
        int m_hLPRClient = 0;
        int m_nSerialHandle = 0;
        int laneIndex = 0;
        ParkingCommunication.VoiceSend cmd;

        Dictionary<string, object> dicAfferentParameter = new Dictionary<string, object>();

        public ParkingMthCPH()
        {
            InitializeComponent();
        }

        public ParkingMthCPH(List<string> _listStr)
        {
            InitializeComponent();
            frmCPHList = _listStr;
        }


        public ParkingMthCPH(Dictionary<string,object>_dicAfferentParameter)
        {
            InitializeComponent();
            dicAfferentParameter = _dicAfferentParameter;
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ImageBrush berriesBrush = new ImageBrush();
                berriesBrush.ImageSource = new BitmapImage(new Uri(System.IO.Path.Combine(System.Windows.Forms.Application.StartupPath, @"Resources\Main0.jpg"), UriKind.Absolute));
                this.Background = berriesBrush;

                //modulus = Convert.ToInt32(frmCPHList[0]);
                //m_hLPRClient = ParkingMonitoring.m_hLPRClient[modulus];
                //m_nSerialHandle = ParkingMonitoring.m_nSerialHandle[modulus];
                //lblCPH.Content = frmCPHList[3];
                //lblGateName.Content = ParkingModel.Model.Channels[Convert.ToInt32(frmCPHList[0])].sInOutName;

                laneIndex = Convert.ToInt32(dicAfferentParameter["laneIndex"]);
                m_hLPRClient = ParkingMonitoring.m_hLPRClient[laneIndex];
                m_nSerialHandle = ParkingMonitoring.m_nSerialHandle[laneIndex];
                lblCPH.Content = dicAfferentParameter["CPH"];
                lblGateName.Content = dicAfferentParameter["InOutName"].ToString();

                cmd = new ParkingCommunication.VoiceSend(ParkingMonitoring.m_hLPRClient, ParkingMonitoring.m_nSerialHandle, 1007, 1005);
            }
            catch (Exception ex)
            {
                gsd.AddLog(this.Title + ":Window_Loaded", ex.Message + "\r\n" + ex.StackTrace);
                MessageBox.Show(ex.Message + "\r\n" + "Window_Loaded", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                cmd.SendOpen(laneIndex);
                if (ParkingModel.Model.bOut485)
                {
                    System.Threading.Thread.Sleep(50);
                }

                //TimeSpan stime = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) - Convert.ToDateTime(frmCPHList[4]);


               // TimeSpan stime = Convert.ToDateTime(dicAfferentParameter["OutTime"].ToString()) - Convert.ToDateTime(dicAfferentParameter["InTime"].ToString());

                //string strTime = stime.Days.ToString("X4") + stime.Hours.ToString("X2") + stime.Minutes.ToString("00");

                cmd.VoiceDisplay(ParkingCommunication.VoiceType.OutGateVoice, laneIndex, dicAfferentParameter["CardType"].ToString(), lblCPH.Content.ToString(), Convert.ToInt32(dicAfferentParameter["RemainingDays"]), "FFFF", Convert.ToInt32(dicAfferentParameter["RemainingPlaceCount"]));


                //if ("" != frmCPHList[5])
                //{
                //    string path = gsd.UpLoadPic(frmCPHList[5]);
                //    gsd.UpdateCarOut(frmCPHList[1], path);
                //}

                this.Close();
            }
            catch (Exception ex)
            {
                gsd.AddLog(this.Title + ":btnOK_Click", ex.Message + "\r\n" + ex.StackTrace);
                MessageBox.Show(ex.Message + "\r\n" + "btnOK_Click", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string strsLoad = "D4";
                cmd.LoadLsNoX2010znykt(laneIndex, strsLoad);

                Request req = new Request();
                int ret = req.CancelCharge(ParkingModel.Model.token, dicAfferentParameter["CardNO"].ToString(), dicAfferentParameter["CardType"].ToString(), Convert.ToDateTime(dicAfferentParameter["OutTime"]));
                if (ret <= 0)
                {
                    MessageBox.Show("取消收费失败！" + "\r\n" + "btnOK_Click", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                this.Close();
            }
            catch (Exception ex)
            {
                gsd.AddLog(this.Title + ":btnCancel_Click", ex.Message + "\r\n" + ex.StackTrace);
                MessageBox.Show(ex.Message + "\r\n" + "btnCancel_Click", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void WindowBase_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.OriginalSource == this)
            {
                if (e.Key == Key.E)
                {
                    btnOK_Click(null, null);
                }
                else if (e.Key == Key.F)
                {
                    btnCancel_Click(null, null);
                }
            }
        }


    }
}
