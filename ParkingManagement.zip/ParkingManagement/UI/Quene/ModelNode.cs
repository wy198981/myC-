﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UI.Quene
{
    public class ModelNode
    {
        public int iDzIndex { get; set; }
        public string sDzScan { get; set; }
        public string strFile { get; set; }
        public string strFileJpg { get; set; }
        public string strCPH { get; set; }
    }
}
