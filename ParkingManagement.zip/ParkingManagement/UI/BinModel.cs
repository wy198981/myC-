﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace UI
{
    public class BinModel
    {
        public static List<string> lstOpenType = new List<string>();
        public static List<string> lstInOut = new List<string>();
        public static List<string> lstBigSmall = new List<string>();
        public static List<int> lstCtrlNumber = new List<int>();
        public static List<string> lstXieYi = new List<string>();
        public static List<string> lstCameraIP = new List<string>();
        public static List<string> lstPersonVideo = new List<string>();
        public static List<string> lstOP = new List<string>();
        public static List<string> lstVideoType = new List<string>();
    }
}
