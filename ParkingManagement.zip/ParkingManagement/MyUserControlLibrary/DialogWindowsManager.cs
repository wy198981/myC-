﻿/*
 本源码版权归博客园--我丫的是条鱼 
 * 用户所有
 * 转载及复用请注明出处
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;

namespace MyUserControlLibrary
{
    public static class DialogWindowsManager
    {
        #region 属性

        /// <summary>
        /// 等待窗体处理线程
        /// </summary>
        static Thread WaitingFormThread;
        /// <summary>
        /// 进度条进程
        /// </summary>
        static Thread CircleProgressFormThread;

        /// <summary>
        /// 等待进度条进程
        /// </summary>
        static Thread WaitingAndProgressFormThread;

        /// <summary>
        /// 进度条窗体
        /// </summary>
        static CircleProgressForm cf;
        /// <summary>
        /// 等待进度条
        /// </summary>
        static WaitingAndProgressForm wpf;
        #endregion

        #region 私有方法

        /// <summary>
        /// 打开等待窗体方法
        /// </summary>
        private static void showWaitingForm(object o)
        {
            double[] d = (double[])o;
            WaitingForm wf = new WaitingForm();
            wf.WindowStartupLocation = WindowStartupLocation.Manual;
            wf.Top = d[0];
            wf.Left = d[1];
            wf.ShowDialog();
        }

        /// <summary>
        /// 打开进度条窗体方法
        /// </summary>
        /// <param name="o">显示位置集合 double[] 0-Top 1-Left</param>
        private static void showCircleProgressForm(object o)
        {
            double[] d = (double[])o;
            cf = new CircleProgressForm();
            cf.WindowStartupLocation = WindowStartupLocation.Manual;
            cf.Top = d[0];
            cf.Left = d[1];
            cf.ShowDialog();
        }

        /// <summary>
        /// 打开进度条窗体方法
        /// </summary>
        /// <param name="o">显示位置集合 double[] 0-Top 1-Left</param>
        private static void showWaitingAndProgressForm(object o)
        {
            object[] m = (object[])o;
            double[] d = (double[])m[0];
            wpf = new WaitingAndProgressForm();
            wpf.MainControl.ShowType = (WaitAndProgressType)m[1];
            wpf.WindowStartupLocation = WindowStartupLocation.Manual;
            wpf.Top = d[0];
            wpf.Left = d[1];
            wpf.ShowDialog();
        }

        #endregion

        #region 公有方法

        /// <summary>
        /// 打开等待窗体线程
        /// </summary>
        public static void ShowWaitingForm(Window onwer) {
            double[] d = new double[2];
            d[0] = onwer.Top + onwer.Height / 2 - 50;
            d[1] = onwer.Left + onwer.Width / 2 - 50;
            if (WaitingFormThread == null)
            {
                WaitingFormThread = new Thread(new ParameterizedThreadStart(showWaitingForm));
                WaitingFormThread.SetApartmentState(ApartmentState.STA);
                WaitingFormThread.Start(d);
            }
            else {
                CloseWaitingForm();
                ShowWaitingForm(onwer);
            }
        }

        /// <summary>
        /// 关闭等待窗体线程
        /// </summary>
        public static void CloseWaitingForm()
        {
            WaitingFormThread.Abort();
            WaitingFormThread.Join();
            WaitingFormThread.DisableComObjectEagerCleanup();
            WaitingFormThread = null;
        }

        /// <summary>
        /// 打开进度条窗体线程
        /// </summary>
        public static void ShowCircleProgressForm(Window onwer)
        {
            double[] d = new double[2];
            d[0] = onwer.Top + onwer.Height / 2 - 50;
            d[1] = onwer.Left + onwer.Width / 2 - 50;
            if (CircleProgressFormThread == null)
            {
                CircleProgressFormThread = new Thread(new ParameterizedThreadStart(showCircleProgressForm));
                CircleProgressFormThread.SetApartmentState(ApartmentState.STA);
                CircleProgressFormThread.Start(d);
                Thread.Sleep(100);
            }
            else
            {
                CloseCircleProgressForm();
                ShowCircleProgressForm(onwer);
            }
        }

        /// <summary>
        /// 设置进度条百分比
        /// </summary>
        /// <param name="d">百分比</param>
        public static void setProgrssFormPercent(double d) {
            if (cf != null) {
                cf.Dispatcher.BeginInvoke(new Action(() => { if (cf != null) { cf.setPercent(d); } }));
                Thread.Sleep(50);
            }
        }

        /// <summary>
        /// 关闭进度条窗体线程
        /// </summary>
        public static void CloseCircleProgressForm()
        {
            CircleProgressFormThread.Abort();
            CircleProgressFormThread.Join();
            CircleProgressFormThread.DisableComObjectEagerCleanup();
            CircleProgressFormThread = null;
            cf = null;
        }

        /// <summary>
        /// 打开等待进度条窗体线程
        /// </summary>
        public static void ShowWaitingAndProgressForm(Window onwer,WaitAndProgressType t)
        {
            object[] o = new object[2];
            double[] d = new double[2];
            d[0] = onwer.Top + onwer.Height / 2 - 50;
            d[1] = onwer.Left + onwer.Width / 2 - 50;
            o[0] = d;
            o[1] = t;
            if (WaitingAndProgressFormThread == null)
            {
                WaitingAndProgressFormThread = new Thread(new ParameterizedThreadStart(showWaitingAndProgressForm));
                WaitingAndProgressFormThread.SetApartmentState(ApartmentState.STA);
                WaitingAndProgressFormThread.Start(o);
                Thread.Sleep(100);
            }
            else
            {
                CloseWaitingAndProgressForm();
                ShowWaitingAndProgressForm(onwer,t);
            }
        }

        /// <summary>
        /// 设置进度条百分比
        /// </summary>
        /// <param name="d">百分比</param>
        public static void setWaitingAndProgressFormPercent(double d)
        {
            if (wpf != null)
            {
                wpf.Dispatcher.BeginInvoke(new Action(() => { if (wpf != null) { wpf.setPercent(d); } }));
                Thread.Sleep(50);
            }
        }

        /// <summary>
        /// 关闭等待进度条窗体线程
        /// </summary>
        public static void CloseWaitingAndProgressForm()
        {
            WaitingAndProgressFormThread.Abort();
            WaitingAndProgressFormThread.Join();
            WaitingAndProgressFormThread.DisableComObjectEagerCleanup();
            WaitingAndProgressFormThread = null;
            wpf = null;
        }

        #endregion
    }
}
