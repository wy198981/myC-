﻿/*
 本源码版权归博客园--我丫的是条鱼 
 * 用户所有
 * 转载及复用请注明出处
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyUserControlLibrary
{
    /// <summary>
    /// WaitAdnProgress组件样式列表
    /// </summary>
    public enum WaitAndProgressType
    {
        /// <summary>
        /// 等待
        /// </summary>
        Waiting,
        /// <summary>
        /// 进度条
        /// </summary>
        Progress,
        /// <summary>
        /// 等待和进度条
        /// </summary>
        WaitingAndProgress
    }
}
