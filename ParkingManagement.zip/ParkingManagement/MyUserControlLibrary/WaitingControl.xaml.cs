﻿/*
 本源码版权归博客园--我丫的是条鱼 
 * 用户所有
 * 转载及复用请注明出处
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyUserControlLibrary
{
    /// <summary>
    /// WaitingControl.xaml 的交互逻辑
    /// </summary>
    public partial class WaitingControl : UserControl
    {
        #region 属性

        private int arcWeight = 30;
        /// <summary>
        /// 扇形面积
        /// </summary>
        [System.ComponentModel.Browsable(true), System.ComponentModel.Category("Appearance"), System.ComponentModel.Description("设置或获取动画扇形面积")]
        public int ArcWeight {
            get {
                return arcWeight;
            }
            set {
                if (value >= 0 && value <= 360)
                {
                    arcWeight = value;
                    arc.EndAngle = value;
                }
            }
        }

        private TimeSpan durationTime = new TimeSpan(0,0,0,1,600);
        /// <summary>
        /// 动画周期时间
        /// </summary>
        [System.ComponentModel.Browsable(true), System.ComponentModel.Category("Appearance"), System.ComponentModel.Description("设置或获取动画周期时间")]
        public TimeSpan DurationTime
        {
            get {
                return durationTime;
            }
            set {
                durationTime = value;
                Storyboard b = (Storyboard)this.Resources["MainStoryBoard"];
                b.Stop();
                DoubleAnimationUsingKeyFrames d = (DoubleAnimationUsingKeyFrames)b.Children[1];
                d.KeyFrames[0].KeyTime = KeyTime.FromTimeSpan(value);
                b.Duration = value;
                b.Begin();
            }
        }

        #endregion

        public WaitingControl()
        {
            InitializeComponent();
        }

        #region 事件

        //界面调整
        private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (Double.IsNaN(Width))
            {
                if (ActualWidth >= ActualHeight)
                {
                    double t = (ActualWidth - ActualHeight) / 2;
                    MainBorder.Margin = new Thickness(t + 8, 8, t + 8, 8);
                    arc.Margin = new Thickness(t + 10, 10, t + 10, 10);
                }
                else
                {
                    double t = (ActualHeight - ActualWidth) / 2;
                    MainBorder.Margin = new Thickness(8, t + 8, 8, t + 8);
                    arc.Margin = new Thickness(10, t + 10, 10, t + 10);
                }
            }
            else {
                if (Width >= Height)
                {
                    double t = (Width - Height) / 2;
                    MainBorder.Margin = new Thickness(t + 8, 8, t + 8, 8);
                    arc.Margin = new Thickness(t + 10, 10, t + 10, 10);
                }
                else
                {
                    double t = (Height - Width) / 2;
                    MainBorder.Margin = new Thickness(8, t + 8, 8, t + 8);
                    arc.Margin = new Thickness(10, t + 10, 10, t + 10);
                }
            }
        }

        #endregion
    }
}
