﻿/*
 本源码版权归博客园--我丫的是条鱼 
 * 用户所有
 * 转载及复用请注明出处
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyUserControlLibrary
{
    /// <summary>
    /// WaitingAndProgressForm.xaml 的交互逻辑
    /// </summary>
    public partial class WaitingAndProgressForm : Window
    {
        #region 属性

        private bool allowDragMove = false;
        /// <summary>
        /// 是否允许窗体拖拽移动
        /// </summary>
        public bool AllowDragMove
        {
            get { return allowDragMove; }
            set { allowDragMove = value; }
        }

        #endregion

        public WaitingAndProgressForm()
        {
            InitializeComponent();
        }

        #region 方法

        /// <summary>
        /// 设置百分比
        /// </summary>
        /// <param name="d">百分比</param>
        public void setPercent(double d)
        {
            MainControl.setPrecent(d);
        }

        #endregion

        #region 事件

        //拖拽移动
        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (allowDragMove)
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    this.DragMove();
                }
            }
        }

        #endregion
    }
}
