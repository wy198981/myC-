﻿/*
 本源码版权归博客园--我丫的是条鱼 
 * 用户所有
 * 转载及复用请注明出处
 */
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace MyUserControlLibrary
{
    /// <summary>
    /// 将角度转化成百分比
    /// </summary>
    public class ConverterCircleToPercent:IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (int)(double.Parse(value.ToString()) * 10 / 36);
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NullReferenceException();
        }
    }
}
