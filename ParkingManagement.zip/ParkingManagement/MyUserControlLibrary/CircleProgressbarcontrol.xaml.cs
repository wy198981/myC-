﻿/*
 本源码版权归博客园--我丫的是条鱼 
 * 用户所有
 * 转载及复用请注明出处
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyUserControlLibrary
{
    /// <summary>
    /// CircleProgressbarcontrol.xaml 的交互逻辑
    /// </summary>
    public partial class CircleProgressbarcontrol : UserControl
    {
        #region 属性

        private bool isShowPercent = true;
        /// <summary>
        /// 是否显示百分比
        /// </summary>
        [System.ComponentModel.Browsable(true),System.ComponentModel.Category("Appearance"),System.ComponentModel.Description("获取或设置是否显示百分比")]
        public bool IsShowPercent {
            get {
                return isShowPercent;
            }
            set {
                isShowPercent = value;
                if (isShowPercent)
                {
                    AreaShow.Visibility = System.Windows.Visibility.Visible;
                }
                else {
                    AreaShow.Visibility = System.Windows.Visibility.Hidden;
                }
            }
        }
        
        private TimeSpan percentTimeSpan = new TimeSpan(0, 0, 1);
        /// <summary>
        /// 每次更新百分比时的经过时间
        /// </summary>
        [System.ComponentModel.Browsable(true),System.ComponentModel.Category("Appearance"),System.ComponentModel.Description("获取或设置每次更新百分比时的经过时间")]
        public TimeSpan PercentTimeSpan {
            get {
                return percentTimeSpan;
            }
            set {
                percentTimeSpan = value;
                Storyboard sb = (Storyboard)this.Resources["MainStoryboard"];
                ((DoubleAnimationUsingKeyFrames)sb.Children[0]).KeyFrames[1].KeyTime = KeyTime.FromTimeSpan(value);
            }
        }

        #endregion

        public CircleProgressbarcontrol()
        {
            InitializeComponent();
        }

        #region 方法

        /// <summary>
        /// 设置当前百分比
        /// </summary>
        /// <param name="d">百分比</param>
        public void setPercent(double d) {
            Storyboard sb = (Storyboard)this.Resources["MainStoryboard"];
            ((DoubleAnimationUsingKeyFrames)sb.Children[0]).KeyFrames[0].Value = ProgressArea.EndAngle;
            ((DoubleAnimationUsingKeyFrames)sb.Children[0]).KeyFrames[1].Value = d*3.6;
            sb.Begin();
        }

        #endregion

        #region 事件

        //界面调整
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (Double.IsNaN(Width))
            {
                if (ActualWidth >= ActualHeight)
                {
                    double t = (ActualWidth - ActualHeight) / 2;
                    MainBorder.Margin = new Thickness(t, 0, t, 0);
                    ProgressArea.Margin = new Thickness(t + 5, 5, t + 5, 5);
                    AreaShow.Margin = new Thickness(t + 10, 10, t + 10, 10);
                }
                else
                {
                    double t = (ActualHeight - ActualWidth) / 2;
                    MainBorder.Margin = new Thickness(0, t + 0, 0, t + 0);
                    ProgressArea.Margin = new Thickness(5, t + 5, 5, t + 5);
                    AreaShow.Margin = new Thickness(10, t + 10, 10, t + 10);
                }
                AreaShow.FontSize = AreaShow.ActualWidth / 2;
            }
            else
            {
                if (Width >= Height)
                {
                    double t = (Width - Height) / 2;
                    MainBorder.Margin = new Thickness(t, 0, t, 0);
                    ProgressArea.Margin = new Thickness(t + 5, 5, t + 5, 5);
                    AreaShow.Margin = new Thickness(t + 10, 10, t + 10, 10);
                }
                else
                {
                    double t = (Height - Width) / 2;
                    MainBorder.Margin = new Thickness(0, t, 0, t);
                    ProgressArea.Margin = new Thickness(5, t + 5, 5, t + 5);
                    AreaShow.Margin = new Thickness(10, t + 10, 10, t + 10);
                }
                AreaShow.FontSize = AreaShow.ActualWidth / 2;
            }
        }

        #endregion
    }
}
