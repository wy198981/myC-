﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Xml;

namespace SFMControls
{
    public class ControlHelper
    {
        public static System.Windows.Media.ImageSource ImageToSource(System.Drawing.Image img, int? newWidth = null, int? newHeight = null)
        {
            IntPtr ptrBmp;
            Bitmap srcBmp;
            BitmapSource bmpSource;
            WriteableBitmap wtbleBmp;

            srcBmp = (null == newHeight || null == newWidth ? (Bitmap)img : new Bitmap(img, newWidth.Value, newHeight.Value));
            ptrBmp = srcBmp.GetHbitmap();
            bmpSource = Imaging.CreateBitmapSourceFromHBitmap(ptrBmp, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            bmpSource.Freeze();
            wtbleBmp = new WriteableBitmap(bmpSource);

            srcBmp.Dispose();

            return wtbleBmp;
        }

        public static System.Windows.Media.ImageSource HbitmapToSource(IntPtr bmpPtr)
        {
            BitmapSource bmpSource;
            WriteableBitmap wtbleBmp;

            bmpSource = Imaging.CreateBitmapSourceFromHBitmap(bmpPtr, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            bmpSource.Freeze();
            wtbleBmp = new WriteableBitmap(bmpSource);

            return wtbleBmp;
        }
    }
}