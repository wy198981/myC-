﻿using ParkingInterface;
using ParkingModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SFMControls
{
    public class WindowBase : System.Windows.Window, ILocalizer
    {
        public WindowBase()
            : base()
        {
            this.Loaded += Window_Loaded;
        }

        #region 权限处理需要用到的变量
        [System.ComponentModel.Category("RightsSetting")]
        protected virtual string _Category { get; set; }
        [System.ComponentModel.Category("RightsSetting")]
        protected virtual string _FromName { get; set; }
        [System.ComponentModel.Category("RightsSetting")]
        protected virtual string _ItemName { get; set; }
        [System.ComponentModel.Category("RightsSetting")]
        protected virtual string _Description { get; set; }

        public string Category { get { return _Category; } }
        public string FormName { get { return _FromName; } }
        public string ItemName { get { return _ItemName; } }
        public string Description { get { return _Description; } }


        [System.ComponentModel.Category("RightsSetting")]
        protected string ParentFormName { get; set; }
        [System.ComponentModel.Category("RightsSetting")]
        protected string ParentItemName { get; set; }
        [System.ComponentModel.Category("RightsSetting")]
        protected string ParentDescription { get; set; }
        #endregion

        #region 权限处理/本地化
        protected void GenerateRightsItem()
        {
            long ID;
            RightsItem ri;
            Rights rgt;
            Rights rgtParent = null;
            Request req;

            if (null == Category || null == FormName)
            {
                return;
            }

            //生成菜单项
            rgt = Model.GetRight(Category, FormName, ItemName);
            if (null == rgt)
            {
                //生成父级菜单项
                if (null != ParentFormName)
                {
                    rgtParent = Model.GetRight(Category, ParentFormName, ParentItemName);
                    if (null == rgtParent)
                    {
                        ri = new RightsItem();
                        ri.PID = 0;
                        ri.Category = Category;
                        ri.FormName = ParentFormName;
                        ri.ItemName = ParentItemName ?? "";
                        ri.Description = ParentDescription;

                        req = new Request();
                        ID = req.AddData("AddRightsItem", ri);
                        if (ID > 0)
                        {
                            ri.ID = ID;

                            rgt = new Rights();
                            rgt.CanOperate = false;
                            rgt.CanView = false;
                            rgt.Category = ri.Category;
                            rgt.Description = ri.Description;
                            rgt.FormName = ri.FormName;
                            rgt.GroupID = Model.sGroupNo;
                            rgt.ItemName = ri.ItemName;
                            rgt.PID = ri.PID;
                            rgt.RightsItemID = ri.ID;

                            Model.LoadRights(new List<Rights> { rgt }, false);
                        }
                    }
                }

                ri = new RightsItem();
                ri.PID = 0;
                ri.Category = Category;
                ri.FormName = FormName;
                ri.ItemName = ItemName ?? "";
                ri.Description = Description;

                req = new Request();
                ID = req.AddData("AddRightsItem", ri);
                if (ID > 0)
                {
                    ri.ID = ID;

                    rgt = new Rights();
                    rgt.CanOperate = false;
                    rgt.CanView = false;
                    rgt.Category = ri.Category;
                    rgt.Description = ri.Description;
                    rgt.FormName = ri.FormName;
                    rgt.GroupID = Model.sGroupNo;
                    rgt.ItemName = ri.ItemName;
                    rgt.PID = ri.PID;
                    rgt.RightsItemID = ri.ID;

                    Model.LoadRights(new List<Rights> { rgt }, false);
                }
            }

            if (null == rgt)
            {
                return;
            }
        }

        public string LocalTextCategoryKey { get; set; }

        public string LocalTextKey { get; set; }

        public virtual void Localize(string LocalTextCategoryKey, ResourceDictionary rd)
        {
            string LocalTextVale;
            Hashtable ht = null;

            rd = ParkingModel.Model.LanguageResource;
            if (null == rd || null == LocalTextCategoryKey || null == LocalTextKey)
            {
                return;
            }

            if (rd.Contains(LocalTextCategoryKey))
            {
                ht = rd[LocalTextCategoryKey] as Hashtable;
                if (null == ht)
                {
                    rd[LocalTextCategoryKey] = ht;
                }
            }
            else
            {
                ht = new Hashtable();
                rd.Add(LocalTextCategoryKey, ht);
            }

            if (ht.Contains(LocalTextKey))
            {
                LocalTextVale = ht[LocalTextKey] as string;
                this.Title = LocalTextVale ?? this.Title;
            }
            else
            {
                ht.Add(LocalTextKey, this.Title);
            }
        }

        public void Localize(Hashtable ht)
        {
            string LocalTextVale;

            if (null == ht || null == LocalTextKey)
            {
                return;
            }

            if (ht.Contains(LocalTextKey))
            {
                LocalTextVale = ht[LocalTextKey] as string;
                this.Title = LocalTextVale ?? this.Title;
            }
            else
            {
                ht.Add(LocalTextKey, this.Title);
            }
        }
        #endregion

        public static readonly DependencyProperty CornerRadiusProperty =
            DependencyProperty.Register("CornerRadius", typeof(CornerRadius), typeof(WindowBase), new PropertyMetadata(new CornerRadius(2)));
        public CornerRadius CornerRadius { get; set; }


        #region 标题栏样式属性
        public static readonly DependencyProperty HeaderBorderThicknessProperty =
            DependencyProperty.Register("HearderBorderThickness", typeof(Thickness), typeof(WindowBase), new PropertyMetadata(new Thickness(0)));
        public Thickness HearderBorderThickness { get; set; }

        public static readonly DependencyProperty HeaderBorderBrushProperty =
            DependencyProperty.Register("HeaderBorderBrush", typeof(Brush), typeof(WindowBase), new PropertyMetadata(null));
        public Brush HeaderBorderBrush { get; set; }

        public static readonly DependencyProperty HearderCornerRadiusProperty =
            DependencyProperty.Register("HearderCornerRadius", typeof(CornerRadius), typeof(WindowBase), new PropertyMetadata(new CornerRadius(0)));
        public CornerRadius HearderCornerRadius { get; set; }

        public static readonly DependencyProperty HeaderBackgroundProperty =
            DependencyProperty.Register("HeaderBackground", typeof(Brush), typeof(WindowBase), new PropertyMetadata(new SolidColorBrush(Color.FromRgb(0x0D, 0x76, 0xF3))));
        public Brush HeaderBackground { get; set; }

        public static readonly DependencyProperty HeaderForegroundProperty =
            DependencyProperty.Register("HeaderForeground", typeof(Brush), typeof(WindowBase), new PropertyMetadata(new SolidColorBrush(Colors.White)));
        public Brush HeaderForeground { get; set; }

        public static readonly DependencyProperty HeaderFontFamilyProperty =
            DependencyProperty.Register("HeaderFontFamily", typeof(FontFamily), typeof(WindowBase), new PropertyMetadata(new FontFamily("Microsoft YaHei")));
        public FontFamily HeaderFontFamily { get; set; }

        public static readonly DependencyProperty HeaderFontSizeProperty =
            DependencyProperty.Register("HeaderFontSize", typeof(double), typeof(WindowBase), new PropertyMetadata((double)24));
        public double HeaderFontSize { get; set; }

        public static readonly DependencyProperty HeaderHeightProperty =
            DependencyProperty.Register("HeaderHeight", typeof(double), typeof(WindowBase), new PropertyMetadata((double)60));
        public double HeaderHeight { get; set; }
        #endregion

        #region 自定义窗口事件处理
        public enum ResizeDirection
        {
            Left = 1,
            Right = 2,
            Top = 3,
            TopLeft = 4,
            TopRight = 5,
            Bottom = 6,
            BottomLeft = 7,
            BottomRight = 8,
        }

        private Button _minimizeButton;

        private Button _restoreButton;

        private Button _closeButton;

        private Button _skinButton;

        private HwndSource _hwndSource;

        #region 初始化
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (null != this.Template && Template.TargetType == typeof(WindowBase))
                {
                    InitializeControl();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void InitializeControl()
        {
            //ControlTemplate template = App.Current.FindResource("MetroWindowControlTemplate") as ControlTemplate;
            ControlTemplate template = Application.Current.Resources["MetroWindowControlTemplate"] as ControlTemplate;

            if (template != null)
            {
                Grid moveableRect = template.FindName("MoveableRectangle", this) as Grid;

                moveableRect.PreviewMouseDown += MoveableRect_PreviewMouseDown;

                _minimizeButton = template.FindName("MinimizeButton", this) as Button;

                _restoreButton = template.FindName("RestoreButton", this) as Button;

                _closeButton = template.FindName("CloseButton", this) as Button;

                _skinButton = template.FindName("SkinButton", this) as Button;

                _minimizeButton.Click += MinimizeButton_Click;

                _restoreButton.Click += RestoreButton_Click;

                _closeButton.Click += CloseButton_Click;

                _skinButton.Click += SkinButton_Click;

                Grid resizeGrid = template.FindName("ResizeGrid", this) as Grid;

                if (resizeGrid != null)
                {
                    foreach (UIElement element in resizeGrid.Children)
                    {
                        Rectangle resizeRectangle = element as Rectangle;
                        if (resizeRectangle != null)
                        {
                            resizeRectangle.PreviewMouseDown += ResizeRectangle_PreviewMouseDown;
                            resizeRectangle.MouseMove += ResizeRectangle_MouseMove;
                        }
                    }
                }
            }
        }

        protected override void OnInitialized(EventArgs e)
        {
            SourceInitialized += MainWindow_SourceInitialized;

            base.OnInitialized(e);
        }

        protected override void OnPreviewMouseMove(MouseEventArgs e)
        {
            if (Mouse.LeftButton != MouseButtonState.Pressed)
                Cursor = Cursors.Arrow;
        }

        private void MainWindow_SourceInitialized(object sender, EventArgs e)
        {
            _hwndSource = (HwndSource)PresentationSource.FromVisual(this);
        }
        #endregion

        protected virtual void MoveableRect_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        #region 改变窗口大小
        private void ResizeRectangle_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Rectangle rectangle;

            if (this.ResizeMode != System.Windows.ResizeMode.CanResize && this.ResizeMode != System.Windows.ResizeMode.CanResizeWithGrip)
            {
                return;
            }

            rectangle = sender as Rectangle;
            if (rectangle == null)
            {
                return;
            }

            switch (rectangle.Name)
            {
                case "Top":
                    Cursor = Cursors.SizeNS;
                    ResizeWindow(ResizeDirection.Top);
                    break;
                case "Bottom":
                    Cursor = Cursors.SizeNS;
                    ResizeWindow(ResizeDirection.Bottom);
                    break;
                case "Left":
                    Cursor = Cursors.SizeWE;
                    ResizeWindow(ResizeDirection.Left);
                    break;
                case "Right":
                    Cursor = Cursors.SizeWE;
                    ResizeWindow(ResizeDirection.Right);
                    break;
                case "TopLeft":
                    Cursor = Cursors.SizeNWSE;
                    ResizeWindow(ResizeDirection.TopLeft);
                    break;
                case "TopRight":
                    Cursor = Cursors.SizeNESW;
                    ResizeWindow(ResizeDirection.TopRight);
                    break;
                case "BottomLeft":
                    Cursor = Cursors.SizeNESW;
                    ResizeWindow(ResizeDirection.BottomLeft);
                    break;
                case "BottomRight":
                    Cursor = Cursors.SizeNWSE;
                    ResizeWindow(ResizeDirection.BottomRight);
                    break;
                default:
                    break;
            }
        }

        private void ResizeRectangle_MouseMove(object sender, MouseEventArgs e)
        {
            Rectangle rectangle;

            if (this.ResizeMode != System.Windows.ResizeMode.CanResize && this.ResizeMode != System.Windows.ResizeMode.CanResizeWithGrip)
            {
                return;
            }

            rectangle = sender as Rectangle;
            if (rectangle == null)
            {
                return;
            }

            switch (rectangle.Name)
            {
                case "Top":
                    Cursor = Cursors.SizeNS;
                    break;
                case "Bottom":
                    Cursor = Cursors.SizeNS;
                    break;
                case "Left":
                    Cursor = Cursors.SizeWE;
                    break;
                case "Right":
                    Cursor = Cursors.SizeWE;
                    break;
                case "TopLeft":
                    Cursor = Cursors.SizeNWSE;
                    break;
                case "TopRight":
                    Cursor = Cursors.SizeNESW;
                    break;
                case "BottomLeft":
                    Cursor = Cursors.SizeNESW;
                    break;
                case "BottomRight":
                    Cursor = Cursors.SizeNWSE;
                    break;
                default:
                    break;
            }
        }

        private void ResizeWindow(ResizeDirection direction)
        {
            if (this.ResizeMode != System.Windows.ResizeMode.CanResize && this.ResizeMode != System.Windows.ResizeMode.CanResizeWithGrip)
            {
                return;
            }

            SendMessage(_hwndSource.Handle, 0x112, (IntPtr)(61440 + direction), IntPtr.Zero);
        }
        #endregion

        #region 最大化/最小化/关闭/换肤
        protected virtual void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        protected virtual void RestoreButton_Click(object sender, RoutedEventArgs e)
        {
            this.MaxWidth = System.Windows.Forms.Screen.FromHandle(_hwndSource.Handle).WorkingArea.Width;
            this.MaxHeight = System.Windows.Forms.Screen.FromHandle(_hwndSource.Handle).WorkingArea.Height;
            this.WindowState = (WindowState == WindowState.Normal) ? WindowState.Maximized : WindowState.Normal;
        }

        protected virtual void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        protected virtual void SkinButton_Click(object sender, RoutedEventArgs e)
        {

        }
        #endregion

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, UInt32 msg, IntPtr wParam, IntPtr lParam);
        #endregion
    }

}