﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace SFMControls
{
    public class ButtonSfm : System.Windows.Controls.Button
    {
        #region 权限属性
		/// <summary>
        /// 权限项目所属类目
        /// </summary>
        [Category("RightsSetting")]
        public string Category { get; set; }

        /// <summary>
        /// 权限项目所属窗体
        /// </summary>
        [Category("RightsSetting")]
        public string FormName { get; set; }

        /// <summary>
        /// 权限项目名称
        /// </summary>
        [Category("RightsSetting")]
        public string ItemName { get; set; }

        /// <summary>
        /// 权限项目描述
        /// </summary>
        [Category("RightsSetting")]
        public string Description { get; set; } 
	#endregion


        public static readonly DependencyProperty CornerRadiusProperty =
            DependencyProperty.Register("CornerRadius", typeof(CornerRadius), typeof(ButtonSfm), new PropertyMetadata(new CornerRadius(2)));
        public CornerRadius CornerRadius { get; set; }

        protected override void OnClick()
        {
            base.OnClick();

            this.InvalidateVisual();
        }
    }
}