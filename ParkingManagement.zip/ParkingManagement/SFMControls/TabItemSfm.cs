﻿using ParkingModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace SFMControls
{
    public class TabItemSfm : TabItem, ILocalizer
    {

        public string LocalTextKey { get; set; }

        public virtual void Localize(string LocalTextCategoryKey, ResourceDictionary rd)
        {
            string LocalTextVale;
            Hashtable ht = null;

            rd = ParkingModel.Model.LanguageResource;
            if (null == rd || null == LocalTextCategoryKey || null == LocalTextKey)
            {
                return;
            }

            if (rd.Contains(LocalTextCategoryKey))
            {
                ht = rd[LocalTextCategoryKey] as Hashtable;
                if (null == ht)
                {
                    rd[LocalTextCategoryKey] = ht;
                }
            }
            else
            {
                ht = new Hashtable();
                rd.Add(LocalTextCategoryKey, ht);
            }

            if (ht.Contains(LocalTextKey))
            {
                LocalTextVale = ht[LocalTextKey] as string;
                this.Header = LocalTextVale ?? this.Header;
            }
            else
            {
                ht.Add(LocalTextKey, this.Header);
            }
        }


        public void Localize(Hashtable ht)
        {
            string LocalTextVale;

            if (null == ht || null == LocalTextKey)
            {
                return;
            }

            if (ht.Contains(LocalTextKey))
            {
                LocalTextVale = ht[LocalTextKey] as string;
                this.Header = LocalTextVale ?? this.Header;
            }
            else
            {
                ht.Add(LocalTextKey, this.Header);
            }
        }
    }
}
