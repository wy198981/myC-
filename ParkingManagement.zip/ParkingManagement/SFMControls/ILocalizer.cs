﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SFMControls
{
    public interface ILocalizer
    {
        string LocalTextKey { get; set; }

        void Localize(string LocalTextCategoryKey, ResourceDictionary rd);

        void Localize(Hashtable ht);

    }
}