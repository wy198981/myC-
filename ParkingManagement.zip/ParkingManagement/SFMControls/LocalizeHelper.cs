﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml;

namespace SFMControls
{
    public class LocalizeHelper
    {

        public static void LocalizeWindow(WindowBase win)
        {
            Hashtable ht = null;
            ResourceDictionary rd;

            rd = ParkingModel.Model.LanguageResource;
            if (null == rd || null == win || null == win.LocalTextCategoryKey)
            {
                return;
            }

            if (rd.Contains(win.LocalTextCategoryKey))
            {
                ht = rd[win.LocalTextCategoryKey] as Hashtable;
                if (null == ht)
                {
                    rd[win.LocalTextCategoryKey] = ht;
                }
            }
            else
            {
                ht = new Hashtable();
                rd.Add(win.LocalTextCategoryKey, ht);
            }

            LocalizeDependencyObject(win, ht);
        }

        protected static void LocalizeDependencyObject(DependencyObject obj, Hashtable ht)
        {
            DependencyObject child = null;

            if (obj is TabItem) //TabItem需要特殊处理才能遍历其内部的控件
            {
                TabItem ti = obj as TabItem;
                if (null != ti.Content && ti.Content is DependencyObject)
                {
                    LocalizeDependencyObject(ti.Content as DependencyObject, ht);
                }
            }
            else
            {
                for (int i = 0; i <= VisualTreeHelper.GetChildrenCount(obj) - 1; i++)
                {
                    child = VisualTreeHelper.GetChild(obj, i);

                    if (child is ILocalizer)
                    {
                        (child as ILocalizer).Localize(ht);
                    }
                    LocalizeDependencyObject(child, ht);
                }
            }
        }

        public static void SaveResourceDictionary(ResourceDictionary rd, string FilePath)
        {
            XmlWriterSettings xws;

            xws = new XmlWriterSettings();
            xws.Encoding = new UTF8Encoding(false); //设置编码,不能用Encoding.UTF8,会导致带有BOM标记
            xws.Indent = true;  //是否格式化文档。

            System.Xml.XmlWriter xmlWriter = System.Xml.XmlWriter.Create(FilePath, xws);
            System.Windows.Markup.XamlWriter.Save(rd, xmlWriter);
            xmlWriter.Close();
        }
    }
}