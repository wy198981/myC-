﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;


namespace ParkingInterface
{
    /// <summary>
    /// 类型转换(Model->DataSet)
    /// </summary>
    public class TypeCovert
    {
        /// <summary>  
        /// 将泛型集合转换成DataSet数据集  
        /// </summary>  
        /// <typeparam name="T">T类型</typeparam>  
        /// <param name="list">泛型集合</param>  
        /// <returns>DataSet数据集</returns>  
        public static DataSet ToDataSet<T>(IList<T> list)
        {
            if (list == null)
            {
                return null;
            }
            Type elementType = typeof(T);
            var ds = new DataSet();
            var t = new DataTable();
            ds.Tables.Add(t);
            elementType.GetProperties().ToList().ForEach(propInfo => t.Columns.Add(propInfo.Name, Nullable.GetUnderlyingType(propInfo.PropertyType) ?? propInfo.PropertyType));
            foreach (T item in list)
            {
                var row = t.NewRow();
                elementType.GetProperties().ToList().ForEach(propInfo => row[propInfo.Name] = propInfo.GetValue(item, null) ?? DBNull.Value);
                t.Rows.Add(row);
            }
            return ds;
        }


        public static DataTable ToDataTable(DataRow[] rows)
        {
            if (rows == null || rows.Length == 0) return null;
            DataTable tmp = rows[0].Table.Clone(); // 复制DataRow的表结构
            foreach (DataRow row in rows)
                tmp.Rows.Add(row); // 将DataRow添加到DataTable中
            return tmp;
        }


        public static DataTable ObjectToDataTable(object o)
        {
            string jsonString = JsonConvert.SerializeObject(o, Formatting.Indented, new IsoDateTimeConverter { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" });
            return JsonConvert.DeserializeObject<DataTable>(jsonString);
        }
    }
}
