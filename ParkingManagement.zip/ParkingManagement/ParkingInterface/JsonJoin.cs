﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Reflection;
using Newtonsoft.Json.Converters;

namespace ParkingInterface
{
    /// <summary>
    /// 将不同类型装换为Json字符串
    /// </summary>
    public class JsonJoin
    {
        /// <summary>
        /// 查询带条件的
        /// </summary>
        /// <param name="dic"></param>
        /// <param name="isExclude">默认为and,为true时</param>
        /// <returns></returns>
        public static string ToJson(Dictionary<string, object> dic, bool isExclude = false, bool isLike = false)
        {
            if (dic == null)
            {
                return null;
            }
            SelectModel content = new SelectModel();
            foreach (var d in dic)
            {
                content.Conditions.Add(new SelectModel.conditions()
                {
                    FieldName = d.Key,
                    Operator = isLike ? (isExclude ? "not like" : "like") : (isExclude ? "<>" : "="),
                    FieldValue = d.Value,
                    Combinator = "and"
                }
                );
            }
            content.Combinator = "and";
            List<SelectModel> lstContent = new List<SelectModel>();
            lstContent.Add(content);
            string jsonString = JsonConvert.SerializeObject(lstContent);
            string tmpStr = System.Web.HttpUtility.UrlEncode(jsonString);
            return tmpStr;
        }

        /// <summary>
        /// 直接将mode转为json字符串
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static string ModelToJson(object mode)
        {
            string jsonString = JsonConvert.SerializeObject(mode, Formatting.Indented, new IsoDateTimeConverter { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" });
            string tmpStr = System.Web.HttpUtility.UrlEncode(jsonString);
            return tmpStr;
        }

        public static string ObjectToJson(object model)
        {
            string jsonString = JsonConvert.SerializeObject(model, Formatting.Indented, new IsoDateTimeConverter { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" });
            string tmpStr = System.Web.HttpUtility.UrlEncode(jsonString);
            return tmpStr;
        }

        public static T ToModel<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }

    }
}
