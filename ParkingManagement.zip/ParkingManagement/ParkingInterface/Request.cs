﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Web;
using System.Configuration;
using System.Reflection;
using System.IO;
using ParkingModel;
using System.Net.Http;
using System.Net.Http.Headers;

namespace ParkingInterface
{
    /// <summary>
    /// 请求接口类(用于对接服务端的接口)
    /// </summary>
    public class Request
    {
        //存放服务地址
        static string address = "";
        public Request()
        {
            //NOTE: 这个时候读取的路径是应用程序/网站下面的bin目录, 或者应用程序/网站编译运行dll的目录(自定义输出路径的情况)
            //而不是类库的生成dll的输出路径! 
            //所以, 如果采用引用项目的方式引用, 要将配置文件一同复制到和dll同个目录(bin目录), 否则读取不到配置信息; 修改配置
            //文件后同样记得此目录下覆盖原文件
            //string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, MethodBase.GetCurrentMethod().DeclaringType.Namespace + ".dll");
            //System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(path);

            //Model.serverIP = config.AppSettings.Settings["ServiceIP"].Value;
            //Model.serverPort = config.AppSettings.Settings["ServicePort"].Value;

            address = "http://" + Model.serverIP + ":" + Model.serverPort + "/";
        }


        /// <summary>
        /// 忽略为空的字段
        /// </summary>
        JsonSerializerSettings setting = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore
        };


        public static T InvokeInterface<T>(string interfaceName, string param, out Exception exception)
        {
            string data;
            T result;
            API http;

            exception = null;

            try
            {
                http = new API();
                data = http.HttpPost(string.Format("{0}ParkAPI/{1}{2}{3}", address, interfaceName, (null == param || "" == param.Trim() ? "" : "?"), param), "");
                result = JsonConvert.DeserializeObject<T>(data);
            }
            catch (Exception ex)
            {
                exception = ex;
                result = default(T);
            }

            return result;
        }


        #region 获取token值请求
        /// <summary>
        /// 获取Token值
        /// </summary>
        /// <param name="userName">登陆名</param>
        /// <param name="pwd">密码</param>
        /// <returns></returns>
        public string GetToken(string userName, string pwd)
        {
            ResponseToken result;
            Exception ex;
            string token = "";

            //result = InvokeInterface<ResponseToken>("LoginUser", string.Format("UserNo={0}&password={1}&ForceLogin={2}", userName, pwd, isForceLogin), out ex);

            result = InvokeInterface<ResponseToken>("LoginUser", string.Format("UserNo={0}&password={1}&StationId={2}", userName, pwd, Model.stationID), out ex);
            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                string err = (result.rcode == "40000" ? "token已失效,请重新获取" : (result.rcode == "40001" ? "输入参数或异常" : (result.rcode == "40003" ? "token已失效" : (result.rcode == "40004" ? "重复登录" : "未知错误,请联系管理员!"))));
                throw new InvalidOperationException(result.msg);
            }

            //if (null == result)
            //{
            //    result = new ResponseToken();
            //    result.rcode = "40001";
            //    result.msg = null == ex ? "" : ex.Message;
            //    result.data = null;
            //    throw new InvalidOperationException(ex.Message);
            //}
            //else
            //{
            //    //将获取的token值赋值给全局变量
            //    token = ;
            //}
            return result.data.token;
        }

        public int CheckPwd(string token, string pwd)
        {

            Response result;
            Exception ex;
       
            //result = InvokeInterface<ResponseToken>("LoginUser", string.Format("UserNo={0}&password={1}&ForceLogin={2}", userName, pwd, isForceLogin), out ex);

            result = InvokeInterface<Response>("CheckPwd", string.Format("token={0}&pwd={1}", token, pwd), out ex);
            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                string err = (result.rcode == "40000" ? "token已失效,请重新获取" : (result.rcode == "40001" ? "输入参数或异常" : (result.rcode == "40003" ? "token已失效" : (result.rcode == "40004" ? "重复登录" : "未知错误,请联系管理员!"))));
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt32(result.data);
        }

        #endregion


        #region 查找数据请求
        /// <summary>
        /// 根据指定的条件获取指定的数据
        /// </summary>
        /// <typeparam name="T">泛型</typeparam>
        /// <param name="TableName">表名</param>
        /// <param name="condition">条件（json格式的字符串）为空则为无条件判断</param>
        /// <returns>实体类对象</returns>
        public T FindData<T>(string token, string TableName, string condition = null)
        {
            T temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(T);
            }

            if (condition == "")
            {
                condition = null;
            }

            Response result = InvokeInterface<Response>("Get" + TableName.Remove(0, 1)/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonSearchParam={1}", token, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }

        public List<CardIssue> GetCardIssueByCarPlateNumberLike(string CarPlateNumber, int Precision = 6, List<ParkingModel.QueryConditionGroup> lstConditionGroup = null)
        {
            Exception ex;
            Response result;
            List<CardIssue> lst;

            result = InvokeInterface<Response>("GetCardIssueByCarPlateNumberLike", string.Format("token={0}&CarPlateNumber={1}&Precision={2}{3}",
                ParkingModel.Model.token, CarPlateNumber, Precision,
                (null == lstConditionGroup || lstConditionGroup.Count <= 0 ? "" : "&jsonSearchParam=" + JsonJoin.ObjectToJson(lstConditionGroup))),
                out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            lst = JsonConvert.DeserializeObject<List<CardIssue>>(result.data.ToString(), setting);

            return lst;
        }

        public List<CarIn> GetCarInByCarPlateNumberLike(string CarPlateNumber, int Precision = 6, List<ParkingModel.QueryConditionGroup> lstConditionGroup = null)
        {
            Exception ex;
            Response result;
            List<CarIn> lst;

            result = InvokeInterface<Response>("GetCarInByCarPlateNumberLike", string.Format("token={0}&CarPlateNumber={1}&Precision={2}{3}",
                ParkingModel.Model.token, CarPlateNumber, Precision,
                (null == lstConditionGroup || lstConditionGroup.Count <= 0 ? "" : "&jsonSearchParam=" + JsonJoin.ObjectToJson(lstConditionGroup))),
                out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            lst = JsonConvert.DeserializeObject<List<CarIn>>(result.data.ToString(), setting);

            return lst;
        }

        /// <summary>
        /// 通过指定的接口获取数据
        /// </summary>
        /// <typeparam name="T">返回的数据的类型</typeparam>
        /// <param name="InterfaceName">接口名称</param>
        /// <param name="dicConditions">字典型条件列表。此列表为 字段名 - 字段值 的列表，各个条件间是且关系；字符型字段进行模糊查询，其它类型为等号查询</param>
        /// <param name="lstConditionGroup">列表型条件组。此列表中的条件可指定各个条件间的逻辑关系，也可指定各个字段的查询方式，是比较灵活的查询条件指定方式。</param>
        /// <returns></returns>
        public T GetData<T>(string InterfaceName, dynamic dicConditions = null, List<ParkingModel.QueryConditionGroup> lstConditionGroup = null, string orderField = null, string exParam = null)
        {
            T temp;
            Exception ex;
            Response result;

            if (null == InterfaceName || InterfaceName.Trim().Length <= 0)
            {
                return default(T);
            }

            result = InvokeInterface<Response>(InterfaceName,
                string.Format("token={0}{1}{2}{3}{4}",
                ParkingModel.Model.token,
                null == lstConditionGroup ? "" : "&jsonSearchParam=" + JsonJoin.ObjectToJson(lstConditionGroup),
                null == dicConditions ? "" : "&jsonModel=" + JsonJoin.ObjectToJson(dicConditions),
                null == orderField ? "" : "&OrderField=" + orderField,
                (null == exParam || exParam.Trim().Length <= 0 ? "" : (exParam.Trim().StartsWith("&") ? "" : "&") + exParam)
                ), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            temp = JsonConvert.DeserializeObject<T>(result.data.ToString(), setting);

            return temp;
        }

        public T GetDataByID<T>(string InterfaceName, long ID)
        {
            T temp;
            Exception ex;
            Response result;

            if (null == InterfaceName || InterfaceName.Trim().Length <= 0)
            {
                return default(T);
            }

            result = InvokeInterface<Response>(InterfaceName, string.Format("token={0}&ID={1}", ParkingModel.Model.token, ID), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            temp = JsonConvert.DeserializeObject<T>((result.data ?? "").ToString(), setting);

            return temp;
        }


        public T FindData<T>(string token, string TableName, string fields, bool orderWay, string condition = null)
        {
            T temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(T);
            }

            Response result = InvokeInterface<Response>("Get" + TableName.Remove(0, 1)/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonSearchParam={1}&OrderField={2}", token, condition, fields + " " + (orderWay ? "desc" : "asc")), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }


        public T FindData<T>(string token, string TableName, Dictionary<string, string> dic, string condition = null)
        {
            T temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(T);
            }
            string order = "";
            int count = 0;
            foreach (var dc in dic)
            {
                count++;
                if (count == 1)
                {
                    order = dc.Key + " " + dc.Value;
                }
                else
                {
                    order += "," + dc.Key + " " + dc.Value;
                }
            }
            if ("" == order)
            {
                return default(T);
            }

            ResponseLimit result = InvokeInterface<ResponseLimit>("Get" + TableName.Remove(0, 1)/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonSearchParam={1}&OrderField={2}", token, condition, order), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }


        public T FindData<T>(string token, string TableName, Dictionary<string, string> dic, int PageSize, string condition = null, int Page = 1)
        {
            T temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(T);
            }
            string order = "";
            int count = 0;
            foreach (var dc in dic)
            {
                count++;
                if (count == 1)
                {
                    order = dc.Key + " " + dc.Value;
                }
                else
                {
                    order += "," + dc.Key + " " + dc.Value;
                }
            }
            if ("" == order)
            {
                return default(T);
            }

            ResponseLimit result = InvokeInterface<ResponseLimit>("Get" + TableName.Remove(0, 1)/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonSearchParam={1}&PageSize={2}&Page={3}&OrderField={4}", token, condition, PageSize, Page, order), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString();

            //temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);
            return temp;
        }
        #endregion


        #region 查找不重复字段
        public T FindDistinctFields<T>(string token, string TableName, string fieldNames, Dictionary<string, string> dic = null, string condition = "", string conditionMode = "", string exportFields = "")
        {
            T temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(T);
            }
            string order = "";
            int count = 0;
            if (dic != null)
            {
                foreach (var dc in dic)
                {
                    count++;
                    if (count == 1)
                    {
                        order = dc.Key + " " + dc.Value;
                    }
                    else
                    {
                        order += "," + dc.Key + " " + dc.Value;
                    }
                }
            }
            ResponseLimit result = InvokeInterface<ResponseLimit>("Get" + TableName.Remove(0, 1) + "Distinct"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&FieldNames={1}&jsonModel={2}&jsonSearchParam={3}&OrderField={4}&ExportFields={5}", token, fieldNames, conditionMode, condition, order, exportFields), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString();
            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);
            return temp;
        }
        #endregion


        #region 增加数据请求
        public int AddData(string token, string TableName, string condition)
        {
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(int);
            }


            Response result = InvokeInterface<Response>("Add" + TableName.Remove(0, 1)/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonModel={1}", token, condition), out ex);

            if (null != ex)
            {
                if (TableName == "tOptLog")
                {
                    return default(int);
                }
                //return default(int);
                throw ex;
            }
            if (result.rcode != "200")
            {
                if (TableName == "tOptLog")
                {
                    return default(int);
                }
                //return default(int);
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return Convert.ToInt32(result.data);
        }

        public int AddDataList(string token, string TableName, string condition)
        {
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>("Add" + TableName.Remove(0, 1) + "List"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonModelList={1}", token, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return Convert.ToInt32(result.data);
        }

        public long AddData(string InterfaceName, object data)
        {
            Exception ex;
            if (null == InterfaceName || "" == InterfaceName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>(InterfaceName, string.Format("token={0}&jsonModel={1}", ParkingModel.Model.token, JsonJoin.ObjectToJson(data)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }
        public long AddList<T>(string InterfaceName, List<T> lst)
        {
            Exception ex;
            if (null == InterfaceName || "" == InterfaceName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>(InterfaceName, string.Format("token={0}&jsonModelList={1}",
                ParkingModel.Model.token, JsonJoin.ObjectToJson(lst)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }

        /// <summary>
        /// 车辆进场处理
        /// </summary>
        /// <param name="InRecord"></param>
        /// <returns></returns>
        public long SetCarIn(ParkingModel.CarIn InRecord)
        {
            Exception ex;

            Response result = InvokeInterface<Response>("SetCarIn", string.Format("token={0}&jsonCarIn={1}", ParkingModel.Model.token, JsonJoin.ObjectToJson(InRecord)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }

        /// <summary>
        /// 车辆出场处理
        /// </summary>
        /// <param name="OutRecord"></param>
        /// <returns></returns>
        public long SetCarOut(ParkingModel.CarOut OutRecord)
        {
            Exception ex;

            Response result = InvokeInterface<Response>("SetCarOut", string.Format("token={0}&jsonCarOut={1}", ParkingModel.Model.token, JsonJoin.ObjectToJson(OutRecord)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }
        #endregion


        #region 修改数据请求
        public int UpdateData(string token, string TableName, string condition, string where = null)
        {
            //T temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(int);
            }

            string tableName = "";

            Response result;

            if (null == where)
            {
                tableName = "Update" + TableName.Remove(0, 1);
                result = InvokeInterface<Response>(tableName/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonModel={1}", token, condition), out ex);
            }
            else
            {
                tableName = "Update" + TableName.Remove(0, 1) + "Fields";
                result = InvokeInterface<Response>(tableName/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonFieldValues={1}&jsonConditions={2}", token, condition, where), out ex);
            }



            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");
            //temp = JsonConvert.DeserializeObject<T>(jsonStr);
            return Convert.ToInt32(result.data);
        }

        public long UpdateData(string InterfaceName, object data)
        {
            Exception ex;
            if (null == InterfaceName || "" == InterfaceName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>(InterfaceName, string.Format("token={0}&jsonModel={1}",
                ParkingModel.Model.token, JsonJoin.ObjectToJson(data)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }

        public long UpdateField(string InterfaceName, object data, List<ParkingModel.QueryConditionGroup> lstCondition = null)
        {
            Exception ex;
            if (null == InterfaceName || "" == InterfaceName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>(InterfaceName, string.Format("token={0}&jsonFieldValues={1}&jsonConditions={2}",
                ParkingModel.Model.token, JsonJoin.ObjectToJson(data), JsonJoin.ObjectToJson(lstCondition)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }

        public long UpdateDataList(string token, string TableName, string where)
        {
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>("Update" + TableName.Remove(0, 1) + "List", string.Format("token={0}&jsonModelList={1}",
                ParkingModel.Model.token, where), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }
        #endregion


        #region 删除数据请求
        public int DeleteData(string token, string TableName, string condition)
        {
            //T temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>("Delete" + TableName.Remove(0, 1)/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonModel={1}", token, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<T>(jsonStr);

            return Convert.ToInt32(result.data);
        }


        public int DeleteDataBy(string token, string TableName, string condition = null)
        {
            //int temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>("Delete" + TableName.Remove(0, 1) + "By"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonConditions={1}", token, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<T>(jsonStr);

            return Convert.ToInt32(result.data);
        }

        public long DeleteDataBy(string InterfaceName, List<ParkingModel.QueryConditionGroup> lstConditionGroup)
        {
            Exception ex;
            if (null == InterfaceName || "" == InterfaceName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>(InterfaceName, string.Format("token={0}&jsonConditions={1}",
                ParkingModel.Model.token, JsonJoin.ObjectToJson(lstConditionGroup)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToInt64(result.data);
        }
        #endregion


        #region 权限记录获取
        public T GetRightsTree<T>(string token, int GroupNO)
        {
            T temp;
            Exception ex;
            Response result = InvokeInterface<Response>("GetRightsTreeByGroupNo" /*接口名比表名少前面的字母t*/,
                string.Format("token={0}&GroupNO={1}", token, GroupNO), out ex);
            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }


        public T GetRights<T>(string token, int GroupNO)
        {
            T temp;
            Exception ex;
            Response result = InvokeInterface<Response>("GetRightsByGroupID" /*接口名比表名少前面的字母t*/,
                string.Format("token={0}&GroupID={1}", token, GroupNO), out ex);
            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }
        #endregion


        #region 标准计算收费
        public CaclMoneyResult CaclMoney(string CardNO,string CardType, DateTime InTime, DateTime? OutTime = null, string CPH = null, long? DiscountSetId = null)
        {
            string Params;
            CaclMoneyResult temp;
            Exception ex;

            //Params = string.Format("token={0}&ParkID={1}&CardType={2}&InTime={3}&OutTime={4}",
            //    ParkingModel.Model.token, ParkingModel.Model.iParkingNo, CardType, InTime.ToString("yyyyMMddHHmmss"), OutTime.ToString("yyyyMMddHHmmss"));

            Params = string.Format("token={0}&StationId={1}&CardNO={2}&CardType={3}&InTime={4}&OutTime={5}",
                ParkingModel.Model.token, ParkingModel.Model.stationID, CardNO, CardType, InTime.ToString("yyyyMMddHHmmss"), (null == OutTime) ? null : OutTime.Value.ToString("yyyyMMddHHmmss"));
            if (null != CPH)
            {
                Params += string.Format("&CPH={0}", CPH);
            }
            if (null != DiscountSetId && DiscountSetId.Value > 0)
            {
                Params += string.Format("&DiscountSetId={0}", DiscountSetId);
            }
            Response result = InvokeInterface<Response>("CaclChargeAmount", Params, out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<CaclMoneyResult>(jsonStr, setting);

            //小数点处理
            //if (null != temp)
            //{
            //    if (Model.iChargeType == 3) //北京收费标准有小数点(1位或2位)
            //    {
            //        switch (Model.iXsdNum)
            //        {
            //            case 2:
            //                temp.YSJE /= 100M;
            //                temp.SFJE /= 100M;
            //                break;
            //            default:
            //                temp.YSJE /= 10M;
            //                temp.SFJE /= 10M;
            //                break;
            //        }
            //    }
            //    else if (Model.iXsd > 0)    //其它收费标准如果有小数则固定1位小数
            //    {
            //        temp.YSJE /= 10M;
            //        temp.SFJE /= 10M;
            //    }
            //}

            return temp;
        }
        #endregion


        #region 车牌号模糊对比
        public T GetCardIssueByCarPlateNumberLike<T>(string token, string cph, int count = 6, string condition = null)
        {
            T temp;
            Exception ex;

            if (condition == "")
            {
                condition = null;
            }

            Response result = InvokeInterface<Response>("GetCardIssueByCarPlateNumberLike"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CarPlateNumber={1}&Precision={2}&jsonSearchParam={3}", token, cph, count, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }


        public T GetCarInByCarPlateNumberLike<T>(string token, string cph, int count = 6, string condition = null)
        {
            T temp;
            Exception ex;

            if (condition == "")
            {
                condition = null;
            }

            Response result = InvokeInterface<Response>("GetCarInByCarPlateNumberLike"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CarPlateNumber={1}&Precision={2}&jsonSearchParam={3}", token, cph, count, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }
        #endregion


        #region 照片处理
        public int UpdateCarPhoto(string token, string cardNo = "", string cph = "", byte[] photo = null)
        {
            //T temp;
            Exception ex;

            if (null == photo)
            {
                return default(int);
            }

            //先编码传输
            string encode = Convert.ToBase64String(photo);

            Response result = InvokeInterface<Response>("UpdateCarPhoto"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CardNo={1}&CPH={2}&photo={3}", token, cardNo, cph, HttpUtility.UrlEncode(encode)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return Convert.ToInt32(result.data);
        }


        public int DeleteCarPhoto(string token, string cardNo = "", string cph = "")
        {
            //T temp;
            Exception ex;

            Response result = InvokeInterface<Response>("DeleteCarPhoto"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CardNo={1}&CPH={2}", token, cardNo, cph), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return Convert.ToInt32(result.data);
        }


        public byte[] GetCarPhoto<T>(string token, string cardNo = "", string cph = "")
        {
            Exception ex;

            Response result = InvokeInterface<Response>("GetCarPhoto"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CardNo={1}&CPH={2}", token, cardNo, cph), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<string>(jsonStr, setting);

            //解码
            byte[] decode = Convert.FromBase64String(jsonStr);

            return decode;
        }


        public int UpdateUserPhoto(string token, string cardNo = "", byte[] photo = null)
        {
            //T temp;
            Exception ex;

            if (null == photo)
            {
                return default(int);
            }

            //先编码传输
            string encode = Convert.ToBase64String(photo);

            Response result = InvokeInterface<Response>("UpdateUserPhoto"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&UserNo={1}&photo={2}", token, cardNo, System.Web.HttpUtility.UrlEncode(encode)), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            //return temp;

            return Convert.ToInt32(result.data);
        }


        public int DeleteUserPhoto(string token, string cardNo = "")
        {
            //T temp;
            Exception ex;

            Response result = InvokeInterface<Response>("DeleteUserPhoto"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&UserNo={1}", token, cardNo), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            //return temp;
            return Convert.ToInt32(result.data);
        }


        public byte[] GetUserPhoto(string token, string cardNo = "")
        {
            Exception ex;

            Response result = InvokeInterface<Response>("GetUserPhoto"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&UserNo={1}", token, cardNo), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            if (null == result.data)
            {
                return null;
            }
            string jsonStr = result.data.ToString();

            //string temp = JsonConvert.DeserializeObject<string>(jsonStr, setting);

            //解码
            byte[] decode = Convert.FromBase64String(jsonStr);

            return decode;
        }
        #endregion


        #region 统计
        public T GetParkingInfo<T>(string token, string startTime, int stationID )
        {
            T temp;
            Exception ex;
            Response result = InvokeInterface<Response>("GetParkingInfo"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&StartTime={1}&StationId={2}", token, startTime, stationID), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }

        public T GetCarInsummaryInfo<T>(string token, Dictionary<string, string> dic, string condition = "", int PageSize = 0, int Page = 1, string jsonModel = "")
        {
            T temp;
            Exception ex;

            string order = "";
            int count = 0;
            foreach (var dc in dic)
            {
                count++;
                if (count == 1)
                {
                    order = dc.Key + " " + dc.Value;
                }
                else
                {
                    order += "," + dc.Key + " " + dc.Value;
                }
            }

            Response result = InvokeInterface<Response>("GetCarInSummaryInfo"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonModel={1}&jsonSearchParam={2}&PageSize={3}&Page={4}&OrderField={5}", token, jsonModel, condition, PageSize == 0 ? "" : PageSize.ToString(), Page, order), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }

        public T GetCarOutsummaryInfo<T>(string token, Dictionary<string, string> dic, string condition = "", int PageSize = 0, int Page = 1, string jsonModel = "")
        {
            T temp;
            Exception ex;

            string order = "";
            int count = 0;
            foreach (var dc in dic)
            {
                count++;
                if (count == 1)
                {
                    order = dc.Key + " " + dc.Value;
                }
                else
                {
                    order += "," + dc.Key + " " + dc.Value;
                }
            }

            Response result = InvokeInterface<Response>("GetCarOutsummaryInfo"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&jsonModel={1}&jsonSearchParam={2}&PageSize={3}&Page={4}&OrderField={5}", token, jsonModel, condition, PageSize == 0 ? "" : PageSize.ToString(), Page, order), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }
        #endregion


        #region 获取和设置车场全局变量
        public Dictionary<string, string> GetSysSettingObject(string token, int staionId)
        {
            Dictionary<string, string> temp;
            Exception ex;
            Response result = InvokeInterface<Response>("GetSysSettingObject"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&StationID={1}", token, staionId), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<Dictionary<string, string>>(jsonStr, setting);

            return temp;
        }

        public int SetSysSettingObject(string token, int staionId, string condition)
        {
            int temp;
            Exception ex;
            Response result = InvokeInterface<Response>("SetSysSettingObject"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&StationID={1}&jsonModel={2}", token, staionId, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return temp;
        }
        #endregion


        #region 入出场业务处理
        public int SetCarIn(string token, string condition)
        {
            Exception ex;

            Response result = InvokeInterface<Response>("SetCarIn"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonCarIn={1}", token, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            return Convert.ToInt32(result.data);
        }

        public int SetCarOut(string token, string condition)
        {
            Exception ex;

            Response result = InvokeInterface<Response>("SetCarOut"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonCarOut={1}", token, condition), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            return Convert.ToInt32(result.data);
        }

        public Result<T> SetCarIn<T>(string token, string cph, int ctrlNumber, int stationID, PlateColor cpColor = PlateColor.Unknown, string reserved = "")
        {
            Exception ex;

            Response response = InvokeInterface<Response>("SetCarIn"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CPH={1}&CtrlNumber={2}&StationId={3}&CPColor={4}&Reserved={5}", token, cph, ctrlNumber, stationID, (int)cpColor, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }

            Result<T> result = new Result<T>();
            result.rcode = (Rcode)Convert.ToInt32(response.rcode);
            result.msg = response.msg;

            if (null == response.data)
            {
                result.Model = default(T);
            }
            else
            {
                result.Model = JsonConvert.DeserializeObject<T>(response.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", ""));
                //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");
                //approachModel = JsonConvert.DeserializeObject<T>(jsonStr, setting);
            }

            return result;
        }

        public Result<T> SetCarInWithoutCPH<T>(string token, int ctrlNumber, int stationID, string cph = "", string carBrand = "", string carColor = "", string reserved = "")
        {
            Exception ex;

            Response response = InvokeInterface<Response>("SetCarInWithoutCPH"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CtrlNumber={1}&StationId={2}&CPH={3}&CarBrand={4}&CarColor={5}&Reserved={6}", token, ctrlNumber, stationID, cph, carBrand, carColor, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }


            Result<T> result = new Result<T>();
            result.rcode = (Rcode)Convert.ToInt32(response.rcode);
            result.msg = response.msg;

            if (null == response.data)
            {
                result.Model = default(T);
            }
            else
            {
                result.Model = JsonConvert.DeserializeObject<T>(response.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", ""));
                //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");
                //approachModel = JsonConvert.DeserializeObject<T>(jsonStr, setting);
            }

            return result;
        }

        public Result<T> SetCarOut<T>(string token, string cph, int ctrNumber, int stationID, PlateColor cpColor = PlateColor.Unknown, string reserved = "")
        {
            Exception ex;

            Response response = InvokeInterface<Response>("SetCarOut"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CPH={1}&CtrlNumber={2}&StationId={3}&CPColor={4}&Reserved={5}", token, cph, ctrNumber, stationID, (int)cpColor, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }

            Result<T> result = new Result<T>();
            result.rcode = (Rcode)Convert.ToInt32(response.rcode);
            result.msg = response.msg;

            if (null == response.data)
            {
                result.Model = default(T);
            }
            else
            {
                result.Model = JsonConvert.DeserializeObject<T>(response.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", ""));
                //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");
                //approachModel = JsonConvert.DeserializeObject<T>(jsonStr, setting);
            }

            return result;
        }

        public Result<T> SetCarOutWithoutCPH<T>(string token, string cph, int ctrlNumber, int stationID, string cardNO, string cardType, DateTime dtIn, string NewCardType, decimal YSJE, decimal SFJE, int PayType = 0, string PayCode = "", int DiscountSetId = 0, string reserved = "")
        {
            Exception ex;

            Response response = InvokeInterface<Response>("SetCarOutWithoutCPH"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CPH={1}&CtrlNumber={2}&StationId={3}&CardNO={4}&CardType={5}&InTime={6}&NewCardTYpe={7}&YSJE={8}&SFJE={9}&PayType={10}&PayCode={11}&DiscountSetId={12}&Reserved={13}", token, cph, ctrlNumber, stationID, cardNO, cardType, dtIn.ToString("yyyyMMddHHmmss"), NewCardType, YSJE, SFJE, PayType, PayCode, DiscountSetId, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }

            Result<T> result = new Result<T>();
            result.rcode = (Rcode)Convert.ToInt32(response.rcode);
            result.msg = response.msg;

            if (null == response.data)
            {
                result.Model = default(T);
            }
            else
            {
                result.Model = JsonConvert.DeserializeObject<T>(response.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", ""));
            }

            return result;
        }


        public Result<T> SetCarFreeOutWithoutCPH<T>(string token, int ctrlNumber,int stationId, string cardNO, string cardType, DateTime dtIn, string freeReason, string reserved = "")
        {
            Exception ex;

            Response response = InvokeInterface<Response>("SetCarFreeOutWithoutCPH"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CtrlNumber={1}&StationId={2}&CardNO={3}&CardType={4}&InTime={5}&FreeReason={6}&Reserved={7}", token, ctrlNumber, stationId, cardNO, cardType, dtIn.ToString("yyyyMMddHHmmss"), freeReason, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }

            Result<T> result = new Result<T>();
            result.rcode = (Rcode)Convert.ToInt32(response.rcode);
            result.msg = response.msg;

            if (null == response.data)
            {
                result.Model = default(T);
            }
            else
            {
                result.Model = JsonConvert.DeserializeObject<T>(response.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", ""));
            }

            return result;
        }

        public Result<T> SetCarInConfirmed<T>(string token, string cph, string cphConfirmed, int ctrlNumber, int stationId, PlateColor cpColor = PlateColor.Unknown, string reserved = "")
        {
            Exception ex;

            Response response = InvokeInterface<Response>("SetCarInConfirmed"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&CPH={1}&CPHConfirmed={2}&CtrlNumber={3}&StationId={4}&CPColor={5}&Reserved={6}", token, cph, cphConfirmed, ctrlNumber, stationId, (int)cpColor, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }

            Result<T> result = new Result<T>();
            result.rcode = (Rcode)Convert.ToInt32(response.rcode);
            result.msg = response.msg;

            if (null == response.data)
            {
                result.Model = default(T);
            }
            else
            {
                result.Model = JsonConvert.DeserializeObject<T>(response.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", ""));
                //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");
                //approachModel = JsonConvert.DeserializeObject<T>(jsonStr, setting);
            }

            return result;
        }

        public int UpdateChargeInfo(string token, string cardNO, string cardType, DateTime outTime, string newCardType, string NewPayType, string NewYSJE, string NewSFJE, long DiscountSetId = 0, long FreeSetId = 0, string reserved = "")
        {
            int temp;
            Exception ex;

            Response result = InvokeInterface<Response>("UpdateChargeInfo", string.Format("token={0}&CardNO={1}&CardType={2}&OutTime={3}&NewCardType={4}&NewPayType={5}&YSJE={6}&SFJE={7}&DiscountSetId={8}&FreeSetId={9}&Reserved={10}", token,
                cardNO, cardType, outTime.ToString("yyyyMMddHHmmss"), newCardType, NewPayType, NewYSJE, NewSFJE, DiscountSetId, FreeSetId, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return temp;
        }

        public int UpdateChargeAmount(string token, string cardNO, string cardType, DateTime outTime, string NewPayType, string NewYSJE, string NewSFJE, string reserved = "")
        {
            int temp;
            Exception ex;

            Response result = InvokeInterface<Response>("UpdateChargeAmount", string.Format("token={0}&CardNO={1}&CardType={2}&OutTime={3}&NewPayType={4}&NewYSJE={5}&NewSFJE={6}&Reserved={7}", token,
                cardNO, cardType, outTime.ToString("yyyyMMddHHmmss"), NewPayType, NewYSJE, NewSFJE, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return temp;
        }

        public int UpdateChargeAsFree(string token, string cardNO, string cardType, DateTime outTime, string freeReason, string reserved = "")
        {
            int temp;
            Exception ex;

            Response result = InvokeInterface<Response>("UpdateChargeAsFree", string.Format("token={0}&CardNO={1}&CardType={2}&OutTime={3}&FreeReason={4}&Reserved={5}", token,
                cardNO, cardType, outTime.ToString("yyyyMMddHHmmss"), freeReason, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return temp;
        }

        public int CancelCharge(string token, string cardNO, string cardType, DateTime outTime, string reserved = "")
        {
            int temp;
            Exception ex;

            Response result = InvokeInterface<Response>("CancelCharge", string.Format("token={0}&CardNO={1}&CardType={2}&OutTime={3}&Reserved={4}", token,
                cardNO, cardType, outTime.ToString("yyyyMMddHHmmss"), reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return temp;
        }

        public Result<T> SetCarOutWithoutEntryRecord<T>(string token, string cph, int ctrlNumber, int stationId, PlateColor cpColor = PlateColor.Unknown, string reserved = "")
        {
            Exception ex;

            Response response = InvokeInterface<Response>("SetCarOutWithoutEntryRecord", string.Format("token={0}&CPH={1}&CtrlNumber={2}&StationId={3}&CPColor={4}&Reserved={5}", token,
                cph, ctrlNumber, stationId, (int)cpColor, reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }

            Result<T> result = new Result<T>();
            result.rcode = (Rcode)Convert.ToInt32(response.rcode);
            result.msg = response.msg;

            if (null == response.data)
            {
                result.Model = default(T);
            }
            else
            {
                result.Model = JsonConvert.DeserializeObject<T>(response.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", ""));
                //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");
                //approachModel = JsonConvert.DeserializeObject<T>(jsonStr, setting);
            }

            return result;
        }

        public int UpdateChargeWithCaptureImage(string token, string cardNO, string cardType, DateTime outTime, string reserved = "")
        {
            int temp;
            Exception ex;

            Response result = InvokeInterface<Response>("UpdateChargeWithCaptureImage", string.Format("token={0}&CardNO={1}&CardType={2}&OutTime={3}&Reserved={4}", token,
                cardNO, cardType, outTime.ToString("yyyyMMddHHmmss"), reserved), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return temp;
        }

        
        #endregion


        #region 取消收费(出场记录移到入场表)
        public long MoveCarOutToCarIn(List<ParkingModel.QueryConditionGroup> lstCondtion = null, dynamic ConditionModel = null)
        {
            long temp;
            Exception ex;

            Response result = InvokeInterface<Response>("MoveCarOutToCarIn", string.Format("token={0}&jsonSearchParam={1}&jsonModel={2}", ParkingModel.Model.token,
                (null == lstCondtion ? "" : JsonJoin.ObjectToJson(lstCondtion)), (null == ConditionModel ? "" : JsonJoin.ObjectToJson(ConditionModel))), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<long>(jsonStr, setting);

            return temp;
        }
        #endregion


        #region 添加操作日志
        public long AddLog(string OptMenu, string OptContent)
        {
            long temp;
            ParkingModel.OptLog log;

            log = new ParkingModel.OptLog();
            log.OptContent = OptContent;
            log.OptMenu = OptMenu;
            log.UserName = ParkingModel.Model.sUserName;

            temp = AddData("AddOptLog", log);

            return temp;
        }
        #endregion


        #region 获取服务器时间
        protected static DateTime? _svrTimeGot;
        protected static DateTime? _locTimeGot;

        /// <summary>
        /// 获取服务器时间。此函数会缓存服务器时间，但是为了保证时间的准确性应隔一段时间强制从服务器获取时间。如果人为修改了本地电脑的时间，也需要强制从服务器获取时间。
        /// </summary>
        /// <param name="ForceFromServer">是否强制从服务器获取。
        /// 如果此参数为True，则返回值表明是否成功从服务器获取到时间，返回值为空表示获取失败。
        /// 如果此参数为False，并且本地未曾从服务器获取过时间则先从服务器获取时间；如果有缓存则使用缓存的时间。
        /// </param>
        /// <returns></returns>
        public static DateTime? GetServerTime(bool ForceFromServer = false)
        {
            DateTime tm;
            TimeSpan ts;
            Exception ex;
            Response result;
            Dictionary<string, string> dic;

            if (null == _svrTimeGot || ForceFromServer)
            {
                result = InvokeInterface<Response>("getServerTime", "token=" + ParkingModel.Model.token, out ex);
                if (null == result || result.rcode != "200")
                {
                    return null;
                }

                dic = JsonJoin.ToModel<Dictionary<string, string>>((result.data ?? "").ToString());
                if (null != dic && dic.ContainsKey("serverTime"))
                {
                    if (DateTime.TryParse((dic["serverTime"] ?? "").ToString(), out tm))
                    {
                        _svrTimeGot = tm;
                        _locTimeGot = DateTime.Now;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
            }

            if (null == _svrTimeGot)
            {
                return null;
            }

            ts = DateTime.Now - (_locTimeGot ?? DateTime.Now);
            tm = DateTime.Parse(_svrTimeGot.Value.AddMilliseconds(ts.TotalMilliseconds).ToString("yyyy-MM-dd HH:mm:ss"));

            return tm;
        }


        public DateTime GetServerTime(string token)
        {
            DateTime temp;
            Exception ex;
            Response result = InvokeInterface<Response>("getServerTime"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}", token), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            Dictionary<string, string> dic = JsonConvert.DeserializeObject<Dictionary<string, string>>(jsonStr, setting);

            //DateTime.TryParse((result.data ?? "").ToString(), out temp);
            return Convert.ToDateTime(dic["serverTime"]);
        }
        #endregion


        #region 在线支付
        public Response OnlinePay(string AuthCode, int PayType, decimal Money, string Message, string CPH)
        {
            Exception ex;
            Response result;

            result = InvokeInterface<Response>("OnlinePay", string.Format("token={0}&AuthCode={1}&PayType={2}&Money={3}&Message={4}&CPH={5}&StationID={6}", Model.token,
                System.Web.HttpUtility.UrlEncode(AuthCode), PayType, Money, System.Web.HttpUtility.UrlEncode(Message), System.Web.HttpUtility.UrlEncode(CPH),Model.stationID), out ex);

            return result;
        }
        #endregion


        #region 换班记录
        public int SetHandover(string token, int StationId, string offDutyNo, string takeOverNo, string lastTakeOverTime, string thisTakeOverTime)
        {
            int temp;
            Exception ex;
            Response result = InvokeInterface<Response>("SetHandover"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&StationId={1}&OffDutyOperatorNo={2}&TakeOverOperatorNo={3}&LastTakeOverTime={4}&ThisTakeOverTime={5}", token, StationId, offDutyNo, takeOverNo, lastTakeOverTime, thisTakeOverTime), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return temp;
        }

        public T GetHandoverPrint<T>(string token, int StationID, string jiaoCardNO, string jiaoTime, string jieTime,string jieCardNO)
        {
            T temp;
            Exception ex;
            Response result = InvokeInterface<Response>("GetHandoverPrint"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&StationId={1}&OffDutyOperatorNo={2}&LastTakeOverTime={3}&ThisTakeOverTime={4}&TakeOverOperatorNo={5}", token, StationID, jiaoCardNO, jiaoTime, jieTime, jieCardNO), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

            return temp;
        }
        #endregion


        #region 二合一（新增数据和修改数据）
        public int SaveData(string token, string TableName, string jsonModelList)
        {
            int temp;
            Exception ex;
            if (null == TableName || "" == TableName.Trim())
            {
                return default(int);
            }

            Response result = InvokeInterface<Response>("Save" + TableName.Remove(0, 1)/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonModelList={1}", token, jsonModelList), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            temp = Convert.ToInt32(result.data);
            return temp;
        }

        public int SaveUserAndCardIssue(string token, string jsonModelList, bool AutoUserNo = false, bool AutoCardNo = false)
        {
            int temp;
            Exception ex;

            Response result = InvokeInterface<Response>("SaveUserAndCardIssue" /*接口名比表名少前面的字母t*/,
                string.Format("token={0}&jsonModelList={1}&AutoUserNo={2}&AutoCardNo={3}", token, jsonModelList, AutoUserNo, AutoCardNo), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            temp = Convert.ToInt32(result.data);
            return temp;
        }
        #endregion


        #region  图片上传和下载
        public string SendFiles(string token, int stationId, string FilePath)
        {
            byte[] buffer;
            string Result;

            if (!System.IO.File.Exists(FilePath))
            {
                return null;
            }

            using (var client = new HttpClient())
            using (var content = new MultipartFormDataContent())
            {
                client.BaseAddress = new Uri(address);

                buffer = File.ReadAllBytes(FilePath);
                var fc = new ByteArrayContent(buffer);
                fc.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") { FileName = Path.GetFileName(FilePath) };
                fc.Headers.ContentDisposition.Size = buffer.Length; //传Size值方便服务器在传输文件内容之前检查文件大小
                content.Add(fc);

                var result = client.PostAsync(string.Format(
                    "/ParkAPI/UploadCaptureImage?token={0}&StationId={1}&Date={2}",
                    token, stationId, DateTime.Now.ToString("yyyyMMdd")), content).Result;

                Response res = JsonConvert.DeserializeObject<Response>(result.Content.ReadAsStringAsync().Result);
                string jsonStr = res.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

                string[] temp = JsonConvert.DeserializeObject<string[]>(jsonStr, setting);

                if (null != temp && temp.GetLength(0) > 0)
                {
                    return temp[0];
                }
                else
                    return "";
            }
        }


        public int SendIDPhoto(string token, System.Drawing.Bitmap bit, string cardNO, string cardType, DateTime dtOut, string reserved = "")
        {
            byte[] buffer;

            if (null != bit)
            {
                return 0;
            }

            using (var client = new HttpClient())
            using (var content = new MultipartFormDataContent())
            {
                client.BaseAddress = new Uri(address);

                MemoryStream mstream = new MemoryStream();
                bit.Save(mstream, System.Drawing.Imaging.ImageFormat.Bmp);
                buffer = new Byte[mstream.Length];
                //buffer = File.ReadAllBytes(bit);
                var fc = new ByteArrayContent(buffer);
                fc.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") { FileName = Path.GetFileName("123.jpg") };
                fc.Headers.ContentDisposition.Size = buffer.Length; //传Size值方便服务器在传输文件内容之前检查文件大小
                content.Add(fc);

                var result = client.PostAsync(string.Format(
                    "/ParkAPI/UpdateChargeWithCaptureImage?token={0}&CardNO={1}&CardType={2}&OutTime={3}&Reserved={4}",
                    token, cardNO, cardType, dtOut.ToString("yyyyMMddHHmmss"), reserved), content).Result;

                Response res = JsonConvert.DeserializeObject<Response>(result.Content.ReadAsStringAsync().Result);
                string jsonStr = res.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

                int temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

                return temp;
            }
        }

        public bool DownLoadFile(string token, string FileUrl, string SaveFileName)
        {
            string dir;
            Uri svrUrl;
            HttpClient httpClient;
            HttpResponseMessage responseMessage;

            dir = Path.GetDirectoryName(SaveFileName);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            FileUrl = address + string.Format(
                   "ParkAPI/GetCaptureImage?token={0}&FileName={1}",
                   token, FileUrl);

            svrUrl = new Uri(FileUrl);
            httpClient = new HttpClient();
            responseMessage = httpClient.GetAsync(svrUrl).Result;

            if (!responseMessage.IsSuccessStatusCode)
            {
                return false;
            }

            using (FileStream fs = File.Create(SaveFileName))
            {
                Stream streamFromService = responseMessage.Content.ReadAsStreamAsync().Result;
                streamFromService.CopyTo(fs);
                return true;
            }
        }


        #endregion


        #region 秘钥文件上传
        public bool UploadOnlinePayCredentialFile(string token, string FilePath)
        {
            byte[] buffer;
         
            if (!System.IO.File.Exists(FilePath))
            {
                return false;
            }

            using (var client = new HttpClient())
            using (var content = new MultipartFormDataContent())
            {
                client.BaseAddress = new Uri(address);

                buffer = File.ReadAllBytes(FilePath);
                var fc = new ByteArrayContent(buffer);
                fc.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") { FileName = Path.GetFileName(FilePath) };
                fc.Headers.ContentDisposition.Size = buffer.Length; //传Size值方便服务器在传输文件内容之前检查文件大小
                content.Add(fc);

                var result = client.PostAsync(string.Format(
                    "/ParkAPI/UploadOnlinePayCredentialFile?token={0}",
                    token), content).Result;

                Response res = JsonConvert.DeserializeObject<Response>(result.Content.ReadAsStringAsync().Result);

                if (res.rcode == "200")
                {
                    return true;
                }
                else
                {
                    throw new InvalidOperationException(res.msg);
                }
            }
        }
        #endregion


        #region 无token验证(用于登陆界面显示)
        public T GetStationWithoutLogin<T>(string condition = "", Dictionary<string, string> dic = null)
        {
            T temp;
            Exception ex;

            string order = "";
            int count = 0;
            if (null != dic && dic.Count > 0)
            {
                foreach (var dc in dic)
                {
                    count++;
                    if (count == 1)
                    {
                        order = dc.Key + " " + dc.Value;
                    }
                    else
                    {
                        order += "," + dc.Key + " " + dc.Value;
                    }
                }
            }

            Response result = InvokeInterface<Response>("GetStationSetWithoutLogin"/*接口名比表名少前面的字母t*/,
                string.Format("JsonSearchParam={0}&OrderField={1}", condition, order), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            temp = JsonConvert.DeserializeObject<T>(result.data.ToString(), setting);

            return temp;
        }

        public T GetOperatorsWithoutLogin<T>(string condition = "", Dictionary<string, string> dic = null)
        {
            T temp;
            Exception ex;

            string order = "";
            int count = 0;
            if (null != dic && dic.Count > 0)
            {
                foreach (var dc in dic)
                {
                    count++;
                    if (count == 1)
                    {
                        order = dc.Key + " " + dc.Value;
                    }
                    else
                    {
                        order += "," + dc.Key + " " + dc.Value;
                    }
                }
            }

            Response result = InvokeInterface<Response>("GetOperatorsWithoutLogin"/*接口名比表名少前面的字母t*/,
                string.Format("JsonSearchParam={0}&OrderField={1}", condition, order), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            temp = JsonConvert.DeserializeObject<T>(result.data.ToString(), setting);

            return temp;
        }
        #endregion


        #region 心跳接口
        public int KeppAlive(string token)
        {
            Exception ex;

            Response result = InvokeInterface<Response>("KeepAlive"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}", token), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);

            return Convert.ToInt32(result.data);
        }

        public void LogOut(string token)
        {
            Exception ex;

            Response result = InvokeInterface<Response>("LogOut"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}", token), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            //string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            //temp = JsonConvert.DeserializeObject<int>(jsonStr, setting);  
        }


        #endregion


        #region 在某一时段有最高收费限额
        public Decimal CaclDayMoneyLimit(string token, int StationId, string CardNO, string CardType, string CPH, DateTime InTime, DateTime OutTime, string Decimals, Decimal ChargeAmount, int type)
        {
            Exception ex;
            Response result;
            if (type == 0)
            {
               // result = InvokeInterface<Response>("CaclDayMoneyLimit_0to0"/*接口名比表名少前面的字母t*/,
               //string.Format("token={0}&ParkID={1}&CardNO={2}&CardType={3}&CPH={4}&InTime={5}&OutTime={6}&Decimals={7}&ChargeAmount={8}", token, ParkID, CardNO, CardType, CPH, InTime.ToString("yyyyMMddHHmmss"), OutTime.ToString("yyyyMMddHHmmss"), Decimals, ChargeAmount), out ex);

                 result = InvokeInterface<Response>("CaclDayMoneyLimit_0to0"/*接口名比表名少前面的字母t*/,
                 string.Format("token={0}&StationId={1}&CardNO={2}&CardType={3}&CPH={4}&InTime={5}&OutTime={6}&Decimals={7}&ChargeAmount={8}", token, StationId, CardNO, CardType, CPH, InTime.ToString("yyyyMMddHHmmss"), OutTime.ToString("yyyyMMddHHmmss"), Decimals, ChargeAmount), out ex);
            }
            else
            {
                result = InvokeInterface<Response>("CaclDayMoneyLimit_24H"/*接口名比表名少前面的字母t*/,
               string.Format("token={0}&StationId={1}&CardNO={2}&CardType={3}&CPH={4}&InTime={5}&OutTime={6}&Decimals={7}&ChargeAmount={8}", token, StationId, CardNO, CardType, CPH, InTime.ToString("yyyyMMddHHmmss"), OutTime.ToString("yyyyMMddHHmmss"), Decimals, ChargeAmount), out ex);
            }
            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }

            return Convert.ToDecimal(result.data);
        }
        #endregion


        #region  设备参数的设置
        public int SetDeviceParameter(string token, int StationID, int CtrlNumber, string IP, string ParamValues)
        {
            Exception ex;

            Response result = InvokeInterface<Response>("SetDeviceParameter"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&StationId={1}&CtrlNumber={2}&IP={3}&ParamValues={4}", token, StationID, CtrlNumber, IP, ParamValues), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            return Convert.ToInt32(result.data);
        }

        public Dictionary<string, object> GetDeviceParameter(string token, int StationID, int CtrlNumber, string IP)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();

            Exception ex;

            Response result = InvokeInterface<Response>("GetDeviceParameter"/*接口名比表名少前面的字母t*/,
                string.Format("token={0}&StationId={1}&CtrlNumber={2}&IP={3}", token, StationID, CtrlNumber, IP), out ex);

            if (null != ex)
            {
                throw ex;
            }
            if (result.rcode != "200")
            {
                throw new InvalidOperationException(result.msg);
            }
            string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

            dic = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonStr, setting);

            return dic;
        }

        #endregion

     

        //#region 照片处理
        //public T UpdateCarPhoto<T>(string cardNo = "", string cph = "", byte[] photo = null)
        //{
        //    T temp;
        //    Exception ex;

        //    if (null == photo)
        //    {
        //        return default(T);
        //    }

        //    //先编码传输
        //    string encode = Convert.ToBase64String(photo);

        //    Response result = InvokeInterface<Response>("UpdateCarPhoto"/*接口名比表名少前面的字母t*/,
        //        string.Format("token={0}&CardNo={1}&CPH={2}&photo={3}", Model.token, cardNo, cph, System.Web.HttpUtility.UrlEncode(encode)), out ex);

        //    if (null != ex)
        //    {
        //        throw ex;
        //    }
        //    if (result.rcode != "200")
        //    {
        //        throw new InvalidOperationException(result.msg);
        //    }
        //    string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

        //    temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

        //    return temp;
        //}

        //public T DeleteCarPhoto<T>(string cardNo = "", string cph = "")
        //{
        //    T temp;
        //    Exception ex;

        //    Response result = InvokeInterface<Response>("DeleteCarPhoto"/*接口名比表名少前面的字母t*/,
        //        string.Format("token={0}&CardNo={1}&CPH={2}", Model.token, cardNo, cph), out ex);

        //    if (null != ex)
        //    {
        //        return default(T);
        //    }
        //    if (result.rcode != "200")
        //    {
        //        throw new InvalidOperationException(result.msg);
        //    }
        //    string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

        //    temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

        //    return temp;
        //}

        //public byte[] GetCarPhoto<T>(string cardNo = "", string cph = "")
        //{
        //    Exception ex;

        //    Response result = InvokeInterface<Response>("GetCarPhoto"/*接口名比表名少前面的字母t*/,
        //        string.Format("token={0}&CardNo={1}&CPH={2}", Model.token, cardNo, cph), out ex);

        //    if (null != ex)
        //    {
        //        return default(byte[]);
        //    }
        //    if (result.rcode != "200")
        //    {
        //        throw new InvalidOperationException(result.msg);
        //    }
        //    string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

        //    //temp = JsonConvert.DeserializeObject<string>(jsonStr, setting);

        //    //解码
        //    byte[] decode = Convert.FromBase64String(jsonStr);

        //    return decode;
        //}



        //public T UpdateUserPhoto<T>(string cardNo = "", byte[] photo = null)
        //{
        //    T temp;
        //    Exception ex;

        //    if (null == photo)
        //    {
        //        return default(T);
        //    }

        //    //先编码传输
        //    string encode = Convert.ToBase64String(photo);

        //    Response result = InvokeInterface<Response>("UpdateUserPhoto"/*接口名比表名少前面的字母t*/,
        //        string.Format("token={0}&UserNo={1}&photo={2}", Model.token, cardNo, System.Web.HttpUtility.UrlEncode(encode)), out ex);

        //    if (null != ex)
        //    {
        //        return default(T);
        //    }
        //    if (result.rcode != "200")
        //    {
        //        throw new InvalidOperationException(result.msg);
        //    }
        //    string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

        //    temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

        //    return temp;
        //}

        //public T DeleteUserPhoto<T>(string cardNo = "")
        //{
        //    T temp;
        //    Exception ex;

        //    Response result = InvokeInterface<Response>("DeleteUserPhoto"/*接口名比表名少前面的字母t*/,
        //        string.Format("token={0}&UserNo={1}", Model.token, cardNo), out ex);

        //    if (null != ex)
        //    {
        //        return default(T);
        //    }
        //    if (result.rcode != "200")
        //    {
        //        throw new InvalidOperationException(result.msg);
        //    }
        //    string jsonStr = result.data.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "");

        //    temp = JsonConvert.DeserializeObject<T>(jsonStr, setting);

        //    return temp;
        //}

        //public byte[] GetUserPhoto(string cardNo = "")
        //{
        //    Exception ex;

        //    Response result = InvokeInterface<Response>("GetUserPhoto"/*接口名比表名少前面的字母t*/,
        //        string.Format("token={0}&UserNo={1}", Model.token, cardNo), out ex);

        //    if (null != ex)
        //    {
        //        return default(byte[]);
        //    }
        //    if (result.rcode != "200")
        //    {
        //        throw new InvalidOperationException(result.msg);
        //    }

        //    if (null == result.data)
        //    {
        //        return null;
        //    }
        //    string jsonStr = result.data.ToString();

        //    //string temp = JsonConvert.DeserializeObject<string>(jsonStr, setting);

        //    //解码
        //    byte[] decode = Convert.FromBase64String(jsonStr);

        //    return decode;
        //}
    }
}
