﻿using ParkingModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Drawing;
using System.Threading;
using System.Drawing.Imaging;
using System.Security.Permissions;
using System.Text.RegularExpressions;

namespace ParkingInterface
{
    public class CR
    {
        private static Dictionary<string, string> dicCardType = new Dictionary<string, string>();
        private static Dictionary<string, string> dicCardTypeValue = new Dictionary<string, string>();

        #region WinApi
        [DllImport("kernel32.dll")]
        public static extern IntPtr _lopen(string lpPathName, int iReadWrite);

        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr hObject);

        public const int OF_READWRITE = 2;
        public const int OF_SHARE_DENY_NONE = 0x40;
        public static readonly IntPtr HFILE_ERROR = new IntPtr(-1);

        //消息发送API
        [DllImport("User32.dll", EntryPoint = "PostMessage")]
        public static extern int PostMessage(
            IntPtr hWnd,        // 信息发往的窗口的句柄
           int Msg,            // 消息ID
            int wParam,         // 参数1
            int lParam            // 参数2
        );

        [DllImport("kernel32")]
        public static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        /// <summary>
        /// 自定义的结构
        /// </summary>
        public struct My_lParam
        {
            public int i;
            public string s;
        }

        //消息发送API
        [DllImport("User32.dll", EntryPoint = "PostMessage")]
        public static extern int PostMessage(
            IntPtr hWnd,        // 信息发往的窗口的句柄
           int Msg,            // 消息ID
            int wParam,         // 参数1
            ref My_lParam lParam //参数2
        );


        /// <summary>
        /// 使用COPYDATASTRUCT来传递字符串
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct COPYDATASTRUCT
        {
            public IntPtr dwData;
            public int cbData;
            [MarshalAs(UnmanagedType.LPStr)]
            public string lpData;
        }

        //异步消息发送API
        [DllImport("User32.dll", EntryPoint = "PostMessage")]
        public static extern int PostMessage(
            IntPtr hWnd,        // 信息发往的窗口的句柄
           int Msg,            // 消息ID
            int wParam,         // 参数1
            ref  COPYDATASTRUCT lParam  // 参数2
        );


        [DllImport("kernel32.dll", EntryPoint = "GetSystemDefaultLCID")]
        public static extern int GetSystemDefaultLCID();
        [DllImport("kernel32.dll", EntryPoint = "SetLocaleInfoA")]
        public static extern int SetLocaleInfo(int Locale, int LCType, string lpLCData);
        public const int LOCALE_SLONGDATE = 0x20;
        public const int LOCALE_SSHORTDATE = 0x1F;
        public const int LOCALE_STIME = 0x1003;

        public static void SetDateTimeFormat()
        {
            try
            {
                int x = GetSystemDefaultLCID(); SetLocaleInfo(x, LOCALE_STIME, "HH:mm:ss");
                //时间格式 
                SetLocaleInfo(x, LOCALE_SSHORTDATE, "yyyy-MM-dd"); //短日期格式 
                SetLocaleInfo(x, LOCALE_SLONGDATE, "yyyy-MM-dd"); //长日期格式
            }
            catch (Exception ex)
            {

            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SystemTime
        {
            public ushort wYear;
            public ushort wMonth;
            public ushort wDayOfWeek;
            public ushort wDay;
            public ushort wHour;
            public ushort wMinute;
            public ushort wSecond;
            public ushort wMiliseconds;
        }
        [DllImport("Kernel32.dll")]
        private static extern bool SetLocalTime(ref SystemTime sysTime);


        public static void SetSysTime(string sysTime)
        {
            SystemTime mySysTime = new SystemTime();
            mySysTime.wYear = Convert.ToUInt16(sysTime.Substring(0, 4));
            mySysTime.wMonth = Convert.ToUInt16(sysTime.Substring(4, 2));
            mySysTime.wDay = Convert.ToUInt16(sysTime.Substring(6, 2));
            mySysTime.wHour = Convert.ToUInt16(sysTime.Substring(8, 2));
            mySysTime.wMinute = Convert.ToUInt16(sysTime.Substring(10, 2));
            mySysTime.wSecond = Convert.ToUInt16(sysTime.Substring(12, 2));
            SetLocalTime(ref mySysTime);
        }


        public const int GWL_STYLE = -16;
        public const int WS_SYSMENU = 0x80000;
        [DllImport("user32.dll", SetLastError = true)]
        public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll")]
        public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        #endregion

        /// <summary>
        /// 更新卡片种类
        /// </summary>
        /// <param name="dt"></param>
        public static void BinDic(List<CardTypeDef> lstCTD)
        {
            if (dicCardType != null)
            {
                dicCardType.Clear();
                dicCardType = null;
            }

            if (dicCardTypeValue != null)
            {
                dicCardTypeValue.Clear();
                dicCardTypeValue = null;
            }

            dicCardType = new Dictionary<string, string>();
            dicCardTypeValue = new Dictionary<string, string>();

            for (int i = 0; i < lstCTD.Count; i++)
            {
                dicCardType[lstCTD[i].Identifying] = lstCTD[i].CardType;
                dicCardTypeValue[lstCTD[i].CardType] = lstCTD[i].Identifying;
            }
        }

        public static string GetCardType(string type, int Flag)
        {
            string strRet = "无效卡";
            if (Flag == 0)
            {
                foreach (string m in dicCardTypeValue.Keys)
                {
                    if (m == type)
                    {
                        strRet = dicCardTypeValue[m];
                    }
                }
            }
            else if (Flag == 1)
            {
                foreach (string m in dicCardType.Keys)
                {
                    if (m == type)
                    {
                        strRet = dicCardType[m];
                    }
                }
            }
            return strRet;
        }


        [DllImport("kernel32.dll")]
        static extern uint GetTickCount();

        /// <summary>
        /// 图片转换为二进制流
        /// </summary>
        /// <param name="imgPath">图片路径</param>
        /// <returns></returns>
        public static byte[] GetImgToBinary(string imgPath)
        {
            if (imgPath != "")
            {
                FileStream fs = new FileStream(imgPath, FileMode.Open, FileAccess.Read);
                byte[] byteData = new byte[fs.Length];
                fs.Read(byteData, 0, byteData.Length);
                fs.Close();
                fs.Dispose();
                return byteData;
            }
            else
            {
                byte[] byteData = new byte[0];
                return byteData;
            }
        }
        /// <summary>
        /// 检查权限是否存在
        /// </summary>
        /// <param name="strList"></param>
        /// <param name="Name"></param>
        /// <returns></returns>
        public static bool BLevel(string strList, string Name)
        {
            bool rtn = false;
            string[] ListStr = strList.Split(',');
            foreach (string s in ListStr)
            {
                if (s == Name)
                {
                    rtn = true;
                }
            }
            return rtn;
        }
        /// <summary>
        /// 删除权限操作
        /// </summary>
        /// <param name="strList"></param>
        /// <param name="Name"></param>
        /// <returns></returns>
        public static string GetString(string strList, string Name)
        {
            string strSum = "";
            string[] ListStr = strList.Split(',');
            for (int i = 0; i < ListStr.Length; i++)
            {
                if (ListStr[i] == Name)
                {
                    ListStr[i] = "";
                }
            }
            foreach (string s in ListStr)
            {
                if (s != "")
                {
                    if (strSum == "")
                    {
                        strSum = s;
                    }
                    else
                    {
                        strSum += "," + s;
                    }
                }
            }
            return strSum;
        }

        /// <summary>
        /// 延时XX毫秒
        /// </summary>
        /// <param name="ms">毫秒</param>
        public static void DelaySec(uint ms)
        {
            uint start = GetTickCount();
            while (GetTickCount() - start < ms)
            {
                System.Windows.Forms.Application.DoEvents();
            }
        }

        public static string RightS(string sSource, int iLength)
        {
            return sSource.Substring(iLength > sSource.Length ? 0 : sSource.Length - iLength);
        }
        public static string LeftS(string sSource, int iLength)
        {
            return sSource.Substring(0, iLength > sSource.Length ? sSource.Length : iLength);
        }
        /// mid截取字符串
        ///
        public static string MidS(string sSource, int iStart, int iLength)
        {
            int iStartPoint = iStart > sSource.Length ? sSource.Length : iStart;
            return sSource.Substring(iStartPoint, iStartPoint + iLength > sSource.Length ? sSource.Length - iStartPoint : iLength);
        }

        //字符串MD5加密 不可逆 用于密码
        public static string UserMd5(string str1)
        {
            string cl1 = str1;
            string pwd = "";

            MD5 md5 = MD5.Create();
            // 加密后是一个字节类型的数组 
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl1));
            // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得 
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
                pwd = pwd + s[i].ToString("x2");
            }
            return pwd;
        }


        /// <summary>
        ///字符串转换为Byte数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static byte[] GetByteArray(string str)
        {
            string[] HexStr = GetStringArray(str);
            byte[] Hexbyte = new byte[HexStr.Length];
            for (int j = 0; j < HexStr.Length; j++)
            {
                Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            }

            return Hexbyte;
        }

        /// <summary>
        /// 字符串转换为字符串数组
        /// 如12345678,每取两位转换为12 34 56 78的四个数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string[] GetStringArray(string str)
        {
            List<String> al = new List<String>();
            for (int i = 0; i < str.Length / 2; i++)
            {
                string strJihao = str.Substring(i * 2, 2);
                al.Add(strJihao);
            }
            string s = string.Join(",", al.ToArray());
            string[] HexStr = s.Split(',');
            return HexStr;
        }


        /// <summary>
        ///异或效验 
        /// </summary>
        /// <param name="strList"></param>
        /// <returns></returns>
        public static byte YHXY(string str)
        {
            string[] strList = GetStringArray(str);
            byte[] Hexbyte = new byte[strList.Length];
            byte check = 0;

            //2015-08-15
            if (strList.Length == 1)
            {
                return Convert.ToByte(strList[0], 16);
            }

            check = (byte)(Convert.ToByte(strList[0], 16) ^ Convert.ToByte(strList[1], 16));
            for (int i = 2; i < strList.Length; i++)
            {
                check = (byte)(check ^ Convert.ToByte(strList[i], 16));
            }
            string CheckSumHex = Convert.ToString(check, 16);
            if (CheckSumHex.Length == 1)
            {
                CheckSumHex = "0" + CheckSumHex;
            }
            return Convert.ToByte(CheckSumHex.ToUpper(), 16);
        }


        /// <summary>
        /// 写文本操作日志
        /// </summary>
        /// <param name="text"></param>
        public static void WriteToTxtFile(string text)
        {
            try
            {
                //string filePath = System.Windows.Forms.Application.StartupPath;
                string filePath = System.AppDomain.CurrentDomain.BaseDirectory;

                FileStream fs = new FileStream(filePath + (filePath.EndsWith("\\") ? "LogList.txt" : "\\LogList.txt"), FileMode.Append);

                if (fs.Length > 1048576)
                {
                    fs.Close();
                    File.Move(filePath + "\\LogList.txt", filePath + "\\LogList-" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt");
                    fs = new FileStream(filePath + "\\LogList.txt", FileMode.Append);
                }

                StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                sw.Write(text + "\r\n");
                sw.Close();
                fs.Close();
            }
            catch (System.Exception ex)
            {

            }
        }


        /// <summary>
        /// 下载卡号Data
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static string GetDownLoadToCPH(DataRow dr)
        {
            string sendData = "";
            string CarNO = GetCPHtoCardNO(dr["CPH"].ToString());
            string StatType = "";

            //2016-04-26
            if (dr["CarCardType"].ToString().Substring(0, 3) == "Str")
            {
                StatType = "E6";
            }
            else
            {
                StatType = "E0";//判断为储值卡 该值为E6 其他时为E0
            }


            string CarNumber = CarNO;
            DateTime dtEndTime = Convert.ToDateTime(dr["CarValidEndDate"].ToString());//2016-06-28 th 处理下载时间大于2036-12-31日  按照2036-12-31下载
            if (dtEndTime > Convert.ToDateTime("2036-12-31 23:59:59"))
            {
                dtEndTime = Convert.ToDateTime("2036-12-31 23:59:59");
            }
            string strDateTime = Convert.ToDateTime(dr["CarValidStartDate"].ToString()).ToShortDateString().Replace("-", "").Substring(2, 6);
            string strDateTime1 = dtEndTime.ToShortDateString().Replace("-", "").Substring(2, 6);
            //IC卡的操作 默认是ID的操作
            if (CarNO.Length < 8)
            {
                StatType = "C0";
                if (Model.iICCardDownLoad == 0)
                {
                    strDateTime = "000000";
                    strDateTime1 = "000000";
                }
                CarNumber = Convert.ToString(Convert.ToInt32(CarNO), 16);
            }
            int lenth = CarNumber.Length;
            for (int i = 0; i < 14 - lenth; i++)
            {
                CarNumber = "0" + CarNumber;
            }
            if (CarNO.Length >= 8)
            {
                if (Model.iIdPlateDownLoad == 1)
                {
                    //string strCPH = strPlateZIP(dr["CPH"].ToString(), true);
                    string strCPH = strPlateZIPNew(dr["CPH"].ToString(), true);
                    if (strCPH.Length == 12)
                    {
                        sendData = StatType + strCPH.Substring(0, 6) + CarNO.Substring(0, 8) + strCPH.Substring(6, 6) + strDateTime1 + "0000";
                    }
                    else
                    {
                        sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                    }
                }
                else
                {
                    sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                }
            }
            else
            {
                sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
            }
            return sendData;
        }
        public static string GetDownLoadToCPH(CardIssue ci)
        {
            string sendData = "";
            string CarNO = GetCPHtoCardNO(ci.CPH);
            string StatType = "";

            //2016-04-26
            if (ci.CarCardType.StartsWith("Str", StringComparison.OrdinalIgnoreCase))
            {
                StatType = "E6";
            }
            else
            {
                StatType = "E0";//判断为储值卡 该值为E6 其他时为E0
            }


            string CarNumber = CarNO;
            DateTime dtEndTime = ci.CarValidEndDate;//2016-06-28 th 处理下载时间大于2036-12-31日  按照2036-12-31下载
            if (dtEndTime > Convert.ToDateTime("2036-12-31 23:59:59"))
            {
                dtEndTime = Convert.ToDateTime("2036-12-31 23:59:59");
            }
            string strDateTime = ci.CarValidStartDate.ToShortDateString().Replace("-", "").Substring(2, 6);
            string strDateTime1 = dtEndTime.ToShortDateString().Replace("-", "").Substring(2, 6);
            //IC卡的操作 默认是ID的操作
            if (CarNO.Length < 8)
            {
                StatType = "C0";
                if (Model.iICCardDownLoad == 0)
                {
                    strDateTime = "000000";
                    strDateTime1 = "000000";
                }
                CarNumber = Convert.ToString(Convert.ToInt32(CarNO), 16);
            }
            int lenth = CarNumber.Length;
            for (int i = 0; i < 14 - lenth; i++)
            {
                CarNumber = "0" + CarNumber;
            }
            if (CarNO.Length >= 8)
            {
                if (Model.iIdPlateDownLoad == 1)
                {
                    //string strCPH = strPlateZIP(dr["CPH"].ToString(), true);
                    string strCPH = strPlateZIPNew(ci.CPH, true);
                    if (strCPH.Length == 12)
                    {
                        sendData = StatType + strCPH.Substring(0, 6) + CarNO.Substring(0, 8) + strCPH.Substring(6, 6) + strDateTime1 + "0000";
                    }
                    else
                    {
                        sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                    }
                }
                else
                {
                    sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                }
            }
            else
            {
                sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
            }
            return sendData;
        }


        public static string strPlateZIPNew(string strPlate, bool bZIP)
        {
            int Ii, jj;
            int iTmp = 0;
            byte[] byte7 = new byte[7];
            bool[] bit48 = new bool[48];
            string[] strTmp7 = new string[7];
            byte[] byteMode = new byte[12];
            byte[] byteBitMode = new byte[8];
            byteBitMode = Model.byteBitMode;

            string strPlateZIP = "";

            if (strPlate.Length == 8 && strPlate.Substring(0, 2) == "WJ")
            {
                strPlate = "武" + strPlate.Substring(2);
            }

            string strTmpX = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成甲乙丙午未申庚巳辛壬临武使ABCDEFGHIJKLMNOPQRSTUVWXYZ";//武 WJ川12345
            string strTmpX1 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学";


            if (strPlate.Length != 7 || strPlate == "0000000" || strPlate == "6666666" || strPlate == "8888888")
            {
                return "";
            }

            for (Ii = 0; Ii < strTmpX.Length; Ii++)
            {
                if (strTmpX.Substring(Ii, 1) == strPlate.Substring(0, 1))
                {
                    iTmp = Ii;
                    break;
                }
            }

            string str2Sum = "";
            string str2SumFrist = Convert.ToString(iTmp, 2);
            str2Sum = Convert.ToString(iTmp, 2).PadLeft(6, '0');

            if (str2Sum.Length > 6)
            {
                str2Sum = str2Sum.Substring(str2Sum.Length - 6, 6);
            }
            else
            {
                str2Sum = str2Sum.PadLeft(6, '0');
            }

            for (jj = 1; jj < 7; jj++)
            {
                for (Ii = 0; Ii < strTmpX1.Length; Ii++)
                {
                    if (strTmpX1.Substring(Ii, 1) == strPlate.Substring(jj, 1))
                    {
                        string str2TO = Convert.ToString(Ii, 2);
                        if (str2TO.Length > 6)
                        {
                            str2Sum = str2Sum + str2TO.Substring(str2TO.Length - 6, 6);
                        }
                        else
                        {
                            str2Sum = str2Sum + str2TO.PadLeft(6, '0');
                        }

                        if (jj == 1 && str2TO.Length > 6 && str2TO.Substring(0, 1) == "1")
                        {
                            str2Sum = "10" + str2Sum;
                        }
                        if (str2Sum.Length == 42 && str2TO.Length > 6 && str2TO.Substring(0, 1) == "1")
                        {
                            str2Sum = "1" + str2Sum;
                        }
                        else if (str2Sum.Length == 44 && str2TO.Length > 6 && str2TO.Substring(0, 1) == "1")
                        {
                            str2Sum = str2Sum.Substring(0, 1) + "1" + str2Sum.Substring(2);
                        }
                        break;
                    }
                }
            }
            str2Sum = str2Sum.PadLeft(44, '0');
            if (str2SumFrist.Length > 6)
            {
                str2Sum = "1" + str2Sum;
            }
            str2Sum = str2Sum.PadLeft(48, '0');


            for (jj = 0; jj < 12; jj++)
            {
                strPlateZIP = strPlateZIP + string.Format("{0:x}", Convert.ToInt32(str2Sum.Substring(4 * jj, 4), 2)).ToUpper();
            }
            return strPlateZIP;
        }


        /// <summary>
        /// 脱机车牌识别下载
        /// </summary>
        /// <param name="strCPH"></param>
        /// <returns></returns>
        public static string GetCPHtoCardNO(string strCPH)
        {
            string strSum = "";

            if (strCPH.Length > 6)
            {
                string strCardE = "";
                string CPH = strCPH.Substring(strCPH.Length - 5, 5);
                for (int i = 0; i < CPH.Length; i++)
                {
                    string str1 = CPH.Substring(i, 1);
                    string str = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ港澳台警领学";
                    int iTmp = 0;
                    for (int Ii = 0; Ii < str.Length; Ii++)
                    {
                        if (str.Substring(Ii, 1) == str1)
                        {
                            iTmp = Ii;
                            break;
                        }
                    }

                    strCardE += Convert.ToString(iTmp, 2).PadLeft(6, '0');
                }

                strCardE = strCardE.PadLeft(32, '0');

                for (int y = 0; y < strCardE.Length / 4; y++)
                {
                    strSum += string.Format("{0:x}", Convert.ToInt32(strCardE.Substring(y * 4, 4), 2));
                }
                strSum = strSum.ToUpper();
            }
            return strSum.ToUpper();
        }


        /// <summary>
        /// 下载卡号Data
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static string GetDownLoad(DataRow dr)
        {
            string sendData = "";
            string CarNO = dr["CardNO"].ToString();
            string StatType = GetLoadHead(GetCardType(dr["CarCardType"].ToString(), 0));
            string CarNumber = CarNO;
            string strDateTime = Convert.ToDateTime(dr["CarValidStartDate"].ToString()).ToShortDateString().Replace("-", "").Substring(2, 6);
            string strDateTime1 = Convert.ToDateTime(dr["CarValidEndDate"].ToString()).ToShortDateString().Replace("-", "").Substring(2, 6);
            //IC卡的操作 默认是ID的操作
            if (CarNO.Length < 8)
            {
                StatType = "C0";
                if (Model.iICCardDownLoad == 0)
                {
                    strDateTime = "000000";
                    strDateTime1 = "000000";
                }
                CarNumber = Convert.ToString(Convert.ToInt32(CarNO), 16);
            }
            int lenth = CarNumber.Length;
            for (int i = 0; i < 14 - lenth; i++)
            {
                CarNumber = "0" + CarNumber;
            }
            if (CarNO.Length >= 8)
            {
                if (Model.iIdPlateDownLoad == 1)
                {
                    //string strCPH = strPlateZIP(dr["CPH"].ToString(), true);
                    string strCPH = strPlateZIPNew(dr["CPH"].ToString(), true);
                    if (strCPH.Length == 12)
                    {
                        sendData = StatType + strCPH.Substring(0, 6) + CarNO.Substring(0, 8) + strCPH.Substring(6, 6) + strDateTime1 + "0000";
                    }
                    else
                    {
                        sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                    }
                }
                else
                {
                    sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                }
            }
            else
            {
                sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
            }
            return sendData;
        }
        public static string GetDownLoad(CardIssue ci)
        {
            string sendData = "";
            string CarNO = ci.CardNO;
            string StatType = GetLoadHead(GetCardType(ci.CarCardType, 0));
            string CarNumber = CarNO;
            string strDateTime = Convert.ToDateTime(ci.CarValidStartDate.ToString("yyyy-MM-dd HH:mm:ss")).ToShortDateString().Replace("-", "").Substring(2, 6);
            string strDateTime1 = Convert.ToDateTime(ci.CarValidEndDate.ToString("yyyy-MM-dd HH:mm:ss")).ToShortDateString().Replace("-", "").Substring(2, 6);
            //IC卡的操作 默认是ID的操作
            if (CarNO.Length < 8)
            {
                StatType = "C0";
                if (Model.iICCardDownLoad == 0)
                {
                    strDateTime = "000000";
                    strDateTime1 = "000000";
                }
                CarNumber = Convert.ToString(Convert.ToInt32(CarNO), 16);
            }
            int lenth = CarNumber.Length;
            for (int i = 0; i < 14 - lenth; i++)
            {
                CarNumber = "0" + CarNumber;
            }
            if (CarNO.Length >= 8)
            {
                if (Model.iIdPlateDownLoad == 1)
                {
                    //string strCPH = strPlateZIP(dr["CPH"].ToString(), true);
                    string strCPH = strPlateZIPNew(ci.CPH, true);
                    if (strCPH.Length == 12)
                    {
                        sendData = StatType + strCPH.Substring(0, 6) + CarNO.Substring(0, 8) + strCPH.Substring(6, 6) + strDateTime1 + "0000";
                    }
                    else
                    {
                        sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                    }
                }
                else
                {
                    sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                }
            }
            else
            {
                sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
            }
            return sendData;
        }


        /// <summary>
        /// 获取下载卡号的头字符
        /// </summary>
        /// <param name="sCardType"></param>
        /// <returns></returns>
        public static string GetLoadHead(string sCardType)
        {
            switch (sCardType.Substring(0, 3))
            {
                case "Mth":
                    return "D0";
                case "Tmp":
                    return "D1";
                case "Fre":
                    return "D2";   //2015-10-10
                case "Cnt":
                    return "D3";
                case "Str":
                    return "D4";
                case "Opt":
                    return "D9";
                default:
                    return "D0";
            }
        }


        /// <summary>
        /// 下载卡号Data
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static string GetDownBlacklistCPH(Blacklist dr)
        {
            string sendData = "";
            string CarNO = GetCPHtoCardNO(dr.CPH);
            string StatType = "E7";
            string CarNumber = CarNO;

            string strDateTime = dr.StartTime.ToShortDateString().Replace("-", "").Substring(2, 6);
            string strDateTime1 = dr.EndTime.ToShortDateString().Replace("-", "").Substring(2, 6);
            //IC卡的操作 默认是ID的操作
            if (CarNO.Length < 8)
            {
                StatType = "C0";
                if (Model.iICCardDownLoad == 0)
                {
                    strDateTime = "000000";
                    strDateTime1 = "000000";
                }
                CarNumber = Convert.ToString(Convert.ToInt32(CarNO), 16);
            }
            int lenth = CarNumber.Length;
            for (int i = 0; i < 14 - lenth; i++)
            {
                CarNumber = "0" + CarNumber;
            }
            if (CarNO.Length >= 8)
            {
                if (Model.iIdPlateDownLoad == 1)
                {
                    //string strCPH = strPlateZIP(dr["CPH"].ToString(), true);
                    string strCPH = strPlateZIPNew(dr.CPH, true);
                    if (strCPH.Length == 12)
                    {
                        sendData = StatType + strCPH.Substring(0, 6) + CarNO.Substring(0, 8) + strCPH.Substring(6, 6) + strDateTime1 + "0000";
                    }
                    else
                    {
                        sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                    }
                }
                else
                {
                    sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
                }
            }
            else
            {
                sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";
            }
            return sendData;
        }


        /// <summary>
        /// 16进制转换为车牌号
        /// </summary>
        /// <param name="CPH"></param>
        /// <returns></returns>
        public static string GetHexToCPH(string CPH)
        {
            try
            {
                string str1 = CPH.Substring(0, 2);
                string diqu = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成甲乙丙午未申庚巳辛壬临武使ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                string strNum = "";
                strNum = diqu.Substring(Convert.ToInt32(str1, 16), 1);
                if (strNum == "武")
                {
                    strNum = "WJ";
                }
                return strNum;
            }
            catch
            {
                return "";
            }
        }


        /// <summary>
        /// 卡类型转换
        /// </summary>
        /// <param name="cardType"></param>
        /// <returns></returns>
        public static string GetCardType(string cardType)
        {
            string retCard = "无效卡";
            switch (cardType)
            {
                case "30":
                    retCard = "Ath";
                    break;
                case "31":
                    retCard = "Opt";
                    break;
                case "32":
                    retCard = "MthA";
                    break;
                case "3B":
                    retCard = "MthB";
                    break;
                case "3C":
                    retCard = "MthC";
                    break;
                case "3D":
                    retCard = "MthD";
                    break;
                case "47":
                    retCard = "MthE";
                    break;
                case "48":
                    retCard = "MthF";
                    break;
                case "49":
                    retCard = "MthG";
                    break;
                case "4A":
                    retCard = "MthH";
                    break;
                case "52":
                    retCard = "MtpA";
                    break;
                case "5B":
                    retCard = "MtpB";
                    break;
                case "5C":
                    retCard = "MtpC";
                    break;
                case "5D":
                    retCard = "MtpD";
                    break;
                case "5E":
                    retCard = "MtpE";
                    break;
                case "5F":
                    retCard = "MtpF";
                    break;
                case "60":
                    retCard = "MtpG";
                    break;
                case "61":
                    retCard = "MtpH";
                    break;
                case "33":
                    retCard = "StrA";
                    break;
                case "34":
                    retCard = "StrB";
                    break;
                case "35":
                    retCard = "StrC";
                    break;
                case "3A":
                    retCard = "StrD";
                    break;
                case "36":
                    retCard = "TmpA";
                    break;
                case "37":
                    retCard = "TmpB";
                    break;
                case "38":
                    retCard = "TmpC";
                    break;
                case "39":
                    retCard = "TmpD";
                    break;
                case "43":
                    retCard = "TmpE";
                    break;
                case "44":
                    retCard = "TmpF";
                    break;
                case "45":
                    retCard = "TmpG";
                    break;
                case "46":
                    retCard = "TmpH";
                    break;
                case "77":
                    retCard = "TmpJ";
                    break;
                case "41":
                    retCard = "FreA";
                    break;
                case "3E":
                    retCard = "FreB";
                    break;
                case "AA":
                    retCard = "Person";
                    break;
                case "AB":
                    retCard = "刷非法卡";
                    break;
                case "AC":
                    retCard = "刷卡闸未关";
                    break;
                case "3F":
                    retCard = "ID卡记录";
                    break;
                case "DD":
                    retCard = "车辆感应";
                    break;
                case "DE":
                    retCard = "车辆感应";
                    break;

            }
            return retCard;
        }

        //判断是否为日期类型
        public static bool IsTime(string time)
        {
            try
            {
                Convert.ToDateTime(time);
                return true;
            }
            catch
            {
                return false;
            }
        }

        ///<summary> 
        ///返回＊.exe.config文件中appSettings配置节的value项  
        ///</summary> 
        ///<param name="strKey"></param> 
        ///<returns></returns> 
        public static string GetAppConfig(string strKey)
        {
            foreach (string key in ConfigurationManager.AppSettings)
            {
                if (key == strKey)
                {
                    return ConfigurationManager.AppSettings[strKey];
                }
            }
            return null;
        }

        ///<summary>  
        ///在＊.exe.config文件中appSettings配置节增加一对键、值对  
        ///</summary>  
        ///<param name="newKey"></param>  
        ///<param name="newValue"></param>  
        public static void UpdateAppConfig(string newKey, string newValue)
        {
            bool isModified = false;
            foreach (string key in ConfigurationManager.AppSettings)
            {
                if (key == newKey)
                {
                    isModified = true;
                    break;
                }
            }

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            if (isModified)
            {
                config.AppSettings.Settings.Remove(newKey);
            }

            config.AppSettings.Settings.Add(newKey, newValue);
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        /// <summary>
        /// 同步服务器时间
        /// </summary>
        public static void SetSysTime()
        {
            //BLL.SystemSetBLL bll = new BLL.SystemSetBLL();
            //SystemTime mySysTime = new SystemTime();

            //try
            //{
            //    //DataTable dt = bll.GetServerSysTime();  //获取服务器时间

            //    string SysTime = Convert.ToDateTime(dt.Rows[0][0].ToString()).ToString("yyyyMMddHHmmss");

            //    mySysTime.wYear = Convert.ToUInt16(SysTime.Substring(0, 4));
            //    mySysTime.wMonth = Convert.ToUInt16(SysTime.Substring(4, 2));
            //    mySysTime.wDay = Convert.ToUInt16(SysTime.Substring(6, 2));
            //    mySysTime.wHour = Convert.ToUInt16(SysTime.Substring(8, 2));
            //    mySysTime.wMinute = Convert.ToUInt16(SysTime.Substring(10, 2));
            //    mySysTime.wSecond = Convert.ToUInt16(SysTime.Substring(12, 2));
            //    SetLocalTime(ref mySysTime);
            //}
            //catch
            //{

            //}
        }

        /// <summary>
        /// 字符串转换为16进制
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string GetStrTo16(string str)
        {
            string strSum = "";
            if (str != "")
            {

                byte[] array = System.Text.Encoding.Default.GetBytes(str);
                if (array != null)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        strSum += array[i].ToString("X2");
                    }
                }
            }
            return strSum;
        }

        /// <summary>
        /// 写文本日志
        /// </summary>
        /// <param name="text"></param>
        public static void WriteToTxtFileRead(string text)
        {
            try
            {
                string filePath = System.Windows.Forms.Application.StartupPath;

                FileStream fs = new FileStream(filePath + "\\LogRead.txt", FileMode.Append);

                if (fs.Length > 1048576)
                {
                    fs.Close();
                    File.Move(filePath + "\\LogRead.txt", filePath + "\\LogRead-" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt");
                    fs = new FileStream(filePath + "\\LogRead.txt", FileMode.Append);
                }

                StreamWriter sw = new StreamWriter(fs, Encoding.Default);
                sw.Write(text + "\r\n");
                sw.Close();
                fs.Close();
            }
            catch (System.Exception ex)
            {

            }
        }

        /// <summary>
        /// 返回添加水印后的Image对象
        /// </summary>
        /// <returns></returns>
        public static void AddShuiYin(string filename, string SavePath, string InOutName, string CardNO)
        {
            try
            {
                for (int i = 0; i < 50; i++)
                {
                    //if (!System.IO.File.Exists(filename))
                    //{
                    //    break;
                    //}
                    if (Occupy(filename))
                    {
                        break;
                    }
                    Thread.Sleep(20);
                }
                // Thread.Sleep(100);
                if (System.IO.File.Exists(filename))
                {
                    //                     string fileName1 = "";
                    // 
                    //                     if (Model.PubVal.sImageSavePath.Substring(Model.PubVal.sImageSavePath.Length - 1) != @"\")
                    //                     {
                    //                         fileName1 = Model.PubVal.sImageSavePath + @"\cin.jpg";
                    //                     }
                    //                     else
                    //                     {
                    //                         fileName1 = Model.PubVal.sImageSavePath + @"cin.jpg";
                    //                     }
                    //                     if (System.IO.File.Exists(fileName1))
                    //                     {
                    //                         System.IO.File.Delete(fileName1);
                    //                     }
                    //                     CompressPicture(filename, fileName1);
                    Image image = Image.FromFile(filename);
                    Graphics g = Graphics.FromImage(image);
                    g.DrawImage(image, 0, 0, image.Width, image.Height);
                    Color bcol = Color.FromArgb(255, Color.White);
                    Brush b = new SolidBrush(bcol);
                    Color bcol1 = Color.FromArgb(255, Color.Black);
                    Brush b1 = new SolidBrush(bcol1);
                    // Pen p = new Pen(b);

                    Font _selectedFont = new Font("宋体", 10.0f);
                    //g.DrawRectangle(p, 1, 1, 50, 15);
                    g.FillRectangle(b1, 1, 1, 170, 15);
                    g.DrawString("抓拍:" + DateTime.Now.ToString(), _selectedFont, b, 1, 1);
                    g.FillRectangle(b1, 1, 15, 150, 15);
                    g.DrawString("出口名称:" + InOutName, _selectedFont, b, 1, 15);
                    g.FillRectangle(b1, 1, 29, 150, 15);
                    g.DrawString("操作员:" + Model.sUserName, _selectedFont, b, 1, 29);
                    g.FillRectangle(b1, 1, 43, 100, 15);
                    g.DrawString("卡号:" + CardNO, _selectedFont, b, 1, 43);

                    g.Dispose();

                    image.Save(SavePath);


                    // Console.Write(SavePath);
                    image.Dispose();
                    //System.IO.File.Delete(filename);
                    if (Model.iAutoDeleteImg == 1)
                    {
                        DeleteImg(filename);
                    }
                    //System.IO.File.Delete(fileName1);
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + "\r\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// 返回添加水印后的Image对象
        /// </summary>
        /// <returns></returns>
        public static void AddShuiYin(string filename, string SavePath, string InOutName, string CardNO, int moudus, string CPH, string AutoCPH = "")
        {
            try
            {
                for (int i = 0; i < 50; i++)
                {

                    if (Occupy(filename))
                    {
                        break;
                    }
                    Thread.Sleep(20);
                }
                Thread.Sleep(100);
                if (System.IO.File.Exists(filename))
                {

                    //DateTime dtstart = DateTime.Now;
                    string fileName1 = "";
                    if (Model.sImageSavePath.Substring(Model.sImageSavePath.Length - 1) != @"\")
                    {
                        fileName1 = Model.sImageSavePath + @"\" + Guid.NewGuid().ToString() + ".jpg";
                    }
                    else
                    {
                        fileName1 = Model.sImageSavePath + @"" + Guid.NewGuid().ToString() + ".jpg";
                    }
                    if (System.IO.File.Exists(fileName1))
                    {
                        System.IO.File.Delete(fileName1);
                    }

                    CompressPicture(filename, fileName1);
                    Image image = Image.FromFile(fileName1);
                    Graphics g = Graphics.FromImage(image);
                    g.DrawImage(image, 0, 0, image.Width, image.Height);
                    Color bcol = Color.FromArgb(255, Color.White);
                    Brush b = new SolidBrush(bcol);
                    Color bcol1 = Color.FromArgb(255, Color.Black);
                    Brush b1 = new SolidBrush(bcol1);
                    Color bcol2 = Color.FromArgb(255, Color.Red);
                    Brush b2 = new SolidBrush(bcol2);

                    if (Model.iAutoLeft != 0)
                    {
                        g.FillRectangle(b2, Model.iAutoLeft, Model.iAutoTop, 2, (Model.iAutoBottom - Model.iAutoTop) + 2);
                        g.FillRectangle(b2, Model.iAutoLeft, Model.iAutoTop, (Model.iAutoRight - Model.iAutoLeft), 2);
                        int ileftX = Model.iAutoLeft + (Model.iAutoRight - Model.iAutoLeft);
                        g.FillRectangle(b2, ileftX, Model.iAutoTop, 2, (Model.iAutoBottom - Model.iAutoTop) + 2);

                        int ileftY = Model.iAutoTop + (Model.iAutoBottom - Model.iAutoTop) + 2;

                        g.FillRectangle(b2, Model.iAutoLeft, ileftY, (Model.iAutoRight - Model.iAutoLeft), 2);
                    }
                    Model.iAutoTop = 0;
                    Model.iAutoLeft = 0;
                    Model.iAutoRight = 0;
                    Model.iAutoBottom = 0;

                    Font _selectedFont = new Font("黑体", 36.0f);

                    g.FillRectangle(b1, 1, 1, 480, 50);
                    g.DrawString(DateTime.Now.ToString(), _selectedFont, b, 1, 1);
                    g.FillRectangle(b1, 1, 50, 260, 50);
                    g.DrawString(InOutName, _selectedFont, b, 1, 50);
                    g.FillRectangle(b1, 1, 100, 250, 50);
                    g.DrawString(CPH, _selectedFont, b, 1, 100);
                    g.FillRectangle(b1, 1, 150, 220, 50);

                    if (AutoCPH != "")
                    {
                        g.DrawString(AutoCPH, _selectedFont, b2, 1, 150);
                        g.FillRectangle(b1, 1, 200, 220, 50);
                    }
                    g.DrawString(CardNO, _selectedFont, b, 1, 150);
                    g.Dispose();
                    image.Save(SavePath);

                    image.Dispose();

                    DeleteImg(fileName1);

                    if (Model.iAutoDeleteImg == 0)
                    {
                        CHPAddShuiYing(filename, CPH);
                    }
                    if (Model.iAutoDeleteImg == 1)
                    {
                        DeleteImg(filename);
                    }

                }
            }
            catch (Exception ex)
            {
                string ssss = ex.Message + "\r\n" + ex.StackTrace;


                //gsd.AddLog("图片操作", ex.Message);
            }
        }


        public static bool Occupy(string FileName)
        {
            IntPtr vHandle = _lopen(FileName, OF_READWRITE | OF_SHARE_DENY_NONE);
            if (vHandle == HFILE_ERROR)
            {
                return false;
            }
            else
            {
                CloseHandle(vHandle);
                return true;
            }
        }


        public static bool CompressPicture(string sourcePath, string targetPath)
        {
            try
            {
                // 大小比率
                double sizeRate = double.Parse("100") / 100;
                // 品质比率
                int qualityRate = int.Parse("100");

                Image sourceImage = Image.FromFile(sourcePath);
                // 调整图片大小
                Bitmap bmp = new Bitmap(
                sourceImage,
                new Size(
                (int)(sourceImage.Width * sizeRate),
                (int)(sourceImage.Height * sizeRate)));
                // 压缩图片
                SaveAsJPEG(bmp, targetPath, qualityRate);

                GC.Collect();
                sourceImage.Dispose();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool SaveAsJPEG(Bitmap bmp, string FileName, int Qty)
        {
            try
            {
                EncoderParameter p;
                EncoderParameters ps;
                ps = new EncoderParameters(1);
                p = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, Qty);
                ps.Param[0] = p;
                bmp.Save(FileName, GetCodecInfo("image/jpeg"), ps);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static ImageCodecInfo GetCodecInfo(string mimeType)
        {
            ImageCodecInfo[] CodecInfo = ImageCodecInfo.GetImageEncoders();
            foreach (ImageCodecInfo ici in CodecInfo)
            {
                if (ici.MimeType == mimeType) return ici;
            }
            return null;
        }

        /// <summary>
        /// 删除图片
        /// </summary>
        /// <param name="File"></param>
        public static void DeleteImg(string File)
        {

            try
            {
                for (int i = 0; i < 10; i++)
                {
                    if (Occupy(File))
                    {
                        break;
                    }
                    Thread.Sleep(100);
                }
                System.IO.File.Delete(File);
            }
            catch (System.Exception ex)
            {
                //  DeleteImg(File);
            }
        }


        /// <summary>
        /// 原图加载车牌号
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="CPH"></param>
        public static void CHPAddShuiYing(string fileName, string CPH)
        {
            try
            {
                if (CPH != "")
                {

                    string strFile = fileName.Substring(0, fileName.Length - 4) + CPH.Substring(0, 7) + ".bmp";
                    System.IO.File.Move(fileName, strFile);
                }
            }
            catch
            {

            }
        }

        //  序号            7654 3210
        //  月HEX（1-12 4位 0000 1111）M
        //  日HEX（1-31 5位 0001 1111）D
        //  时HEX（0-23 5位 0001 1111）H
        //  分HEX（0-59 6位 0011 1111）m
        //  秒HEX（0-59 6位 0011 1111）S
        //机号HEX（1-63 6位 0011 1111）d
        //4+5+5+6+6+6＝32位
        //以上通过移位达到4个字节
        //第一字节 M3M2M1M0 D4D3D2D1 (高)
        //第二字节 D0H4H3H2 H1H0m5m4
        //第三字节 m3m2m1m0 S5S4S3S2
        //第四字节 S1S0d5d4 d3d2d1d0 (低)}
        //机号超过64  入口都设置为1-63，出口设置为 64-127
        public static string GetAutoCPHCardNO(int iJiHao)
        {
            string strCardNO = "";

            DateTime dtCardNO = DateTime.Now;
            string strM = Convert.ToString(dtCardNO.Month, 2);
            strM = strM.PadLeft(4, '0');

            string strD = Convert.ToString(dtCardNO.Day, 2);
            strD = strD.PadLeft(5, '0');

            string strH = Convert.ToString(dtCardNO.Hour, 2);
            strH = strH.PadLeft(5, '0');

            string strMi = Convert.ToString(dtCardNO.Minute, 2);
            strMi = strMi.PadLeft(6, '0');

            string strS = Convert.ToString(dtCardNO.Second, 2);
            strS = strS.PadLeft(6, '0');
            if (iJiHao > 63)
            {
                iJiHao = iJiHao - 62;
            }
            string strJi = Convert.ToString(iJiHao, 2);
            strJi = strJi.PadLeft(6, '0');

            strCardNO = strM + strD + strH + strMi + strS + strJi;
            string strSum = "";
            for (int i = 0; i < strCardNO.Length / 4; i++)
            {
                strSum = strSum + string.Format("{0:x}", Convert.ToInt32(strCardNO.Substring(4 * i, 4), 2)).ToUpper();
            }

            strCardNO = strSum;

            return strCardNO;

        }


        //// <summary>
        /// 枚举，比对时间的类型
        /// </summary>
        public enum DateInterval
        {
            Second, Minute, Hour, Day, Week, Month, Quarter, Year
        }

        /// <summary>
        /// 时间比对函数
        /// </summary>
        /// <param name="Interval">时间比对类型</param>
        /// <param name="StartDate">开始时间</param>
        /// <param name="EndDate">结束时间</param>
        /// <returns>两个事件的比对差值</returns>
        public static long DateDiff(DateInterval Interval, System.DateTime StartDate, System.DateTime EndDate)
        {
            long lngDateDiffValue = 0;
            System.TimeSpan TS = new System.TimeSpan(EndDate.Ticks - StartDate.Ticks);
            switch (Interval)
            {
                case DateInterval.Second:
                    lngDateDiffValue = (long)TS.TotalSeconds;
                    break;
                case DateInterval.Minute:
                    lngDateDiffValue = (long)TS.TotalMinutes;
                    break;
                case DateInterval.Hour:
                    lngDateDiffValue = (long)TS.TotalHours;
                    break;
                case DateInterval.Day:
                    lngDateDiffValue = (long)TS.Days;
                    break;
                case DateInterval.Week:
                    lngDateDiffValue = (long)(TS.Days / 7);
                    break;
                case DateInterval.Month:
                    lngDateDiffValue = (long)(TS.Days / 30);
                    break;
                case DateInterval.Quarter:
                    lngDateDiffValue = (long)((TS.Days / 30) / 3);
                    break;
                case DateInterval.Year:
                    lngDateDiffValue = (long)(TS.Days / 365);
                    break;
            }
            return (lngDateDiffValue);
        }//end of DateDiff 


        /// <summary>
        ///字符串转换为数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static byte[] GetArray(string str)
        {
            string[] HexStr = Getstring(str);
            byte[] Hexbyte = new byte[HexStr.Length];
            for (int j = 0; j < HexStr.Length; j++)
            {
                Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            }

            return Hexbyte;
        }

        public static string[] Getstring(string str)
        {
            List<String> al = new List<String>();
            for (int i = 0; i < str.Length / 2; i++)
            {
                string strJihao = str.Substring(i * 2, 2);
                al.Add(strJihao);
            }
            string s = string.Join(",", al.ToArray());
            string[] HexStr = s.Split(',');
            return HexStr;
        }

        public static string UserMd5new(string str1)
        {
            string cl1 = str1;
            string pwd = "";

            if (str1 == "")
            {
                return pwd;
            }

            MD5 md5 = MD5.Create();
            // 加密后是一个字节类型的数组 
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl1));
            // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得 
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
                pwd = pwd + s[i].ToString("x");
            }
            return pwd;
        }


        /// <summary>
        /// 16进制转换为2进制
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        public static string ConvertToBin(char c)
        {
            switch (c)
            {
                case '0':
                    return "0000";
                case '1':
                    return "0001";
                case '2':
                    return "0010";
                case '3':
                    return "0011";
                case '4':
                    return "0100";
                case '5':
                    return "0101";
                case '6':
                    return "0110";
                case '7':
                    return "0111";
                case '8':
                    return "1000";
                case '9':
                    return "1001";
                case 'A':
                case 'a':
                    return "1010";
                case 'B':
                case 'b':
                    return "1011";
                case 'C':
                case 'c':
                    return "1100";
                case 'D':
                case 'd':
                    return "1101";
                case 'E':
                case 'e':
                    return "1110";
                case 'F':
                case 'f':
                    return "1111";
                default:
                    throw new Exception();
            }
        }

        /// <summary>
        /// 判断是否为数字
        /// </summary>
        /// <param name="message"></param>
        /// <returns>是数字型返回true, 否则为false</returns>
        public static bool IsNumberic(string message)
        {
            Double result = 0;

            try
            {
                result = Convert.ToDouble(message);
                return true;
            }
            catch
            {
                return false;
            }
        }


        private static string CutedStr;
        private static Encoding myEncoding = Encoding.GetEncoding("GB2312");
        /// <summary>
        /// 转换内容
        /// </summary>
        /// <param name="strContent"></param>
        /// <returns></returns>
        public static byte[] ChinatoAscII(string strContent)
        {
            byte[] array2;
            array2 = System.Text.Encoding.Default.GetBytes(strContent);//把字符串转换为byte数组
            int Bytes_Count = 0;
            byte[] array1 = new byte[Bytes_Count];
            if (Bytes_Count > 200)
            {
                Bytes_Count = 200;
                Array.Copy(array2, 0, array1, 0, 200);
                CutedStr = myEncoding.GetString(array1);
                CutedStr = CutedStr.Substring(0, CutedStr.Length);
            }
            else
            {
                array1 = array2;
            }
            return array1;
        }


        public static string GetChineseCPH(string strCPH)
        {
            string strRst = "";

            for (int i = 0; i < strCPH.Length; i++)
            {
                string strW = strCPH.Substring(i, 1);
                switch (strW)
                {
                    case "0":
                        strRst += "00";
                        break;
                    case "1":
                        strRst += "01";
                        break;
                    case "2":
                        strRst += "02";
                        break;
                    case "3":
                        strRst += "03";
                        break;
                    case "4":
                        strRst += "04";
                        break;
                    case "5":
                        strRst += "05";
                        break;
                    case "6":
                        strRst += "06";
                        break;
                    case "7":
                        strRst += "07";
                        break;
                    case "8":
                        strRst += "08";
                        break;
                    case "9":
                        strRst += "09";
                        break;
                    case "A":
                        strRst += "0F";
                        break;
                    case "B":
                        strRst += "10";
                        break;
                    case "C":
                        strRst += "11";
                        break;
                    case "D":
                        strRst += "12";
                        break;
                    case "E":
                        strRst += "13";
                        break;
                    case "F":
                        strRst += "14";
                        break;
                    case "G":
                        strRst += "15";
                        break;
                    case "H":
                        strRst += "16";
                        break;
                    case "I":
                        strRst += "17";
                        break;
                    case "J":
                        strRst += "18";
                        break;
                    case "K":
                        strRst += "19";
                        break;
                    case "L":
                        strRst += "1A";
                        break;
                    case "M":
                        strRst += "1B";
                        break;
                    case "N":
                        strRst += "1C";
                        break;
                    case "O":
                        strRst += "1D";
                        break;
                    case "P":
                        strRst += "1E";
                        break;
                    case "Q":
                        strRst += "1F";
                        break;
                    case "R":
                        strRst += "20";
                        break;
                    case "S":
                        strRst += "21";
                        break;
                    case "T":
                        strRst += "22";
                        break;
                    case "U":
                        strRst += "23";
                        break;
                    case "V":
                        strRst += "24";
                        break;
                    case "W":
                        strRst += "25";
                        break;
                    case "X":
                        strRst += "26";
                        break;
                    case "Y":
                        strRst += "27";
                        break;
                    case "Z":
                        strRst += "28";
                        break;
                    case "京":
                        strRst += "29";
                        break;
                    case "津":
                        strRst += "2A";
                        break;
                    case "冀":
                        strRst += "2B";
                        break;
                    case "晋":
                        strRst += "2C";
                        break;
                    case "蒙":
                        strRst += "2D";
                        break;
                    case "辽":
                        strRst += "2E";
                        break;
                    case "吉":
                        strRst += "3F";
                        break;
                    case "黑":
                        strRst += "30";
                        break;
                    case "沪":
                        strRst += "31";
                        break;
                    case "苏":
                        strRst += "32";
                        break;
                    case "浙":
                        strRst += "33";
                        break;
                    case "皖":
                        strRst += "34";
                        break;
                    case "闽":
                        strRst += "35";
                        break;
                    case "赣":
                        strRst += "36";
                        break;
                    case "鲁":
                        strRst += "37";
                        break;
                    case "豫":
                        strRst += "38";
                        break;
                    case "鄂":
                        strRst += "39";
                        break;
                    case "湘":
                        strRst += "3A";
                        break;
                    case "粤":
                        strRst += "3B";
                        break;
                    case "桂":
                        strRst += "3C";
                        break;
                    case "琼":
                        strRst += "3D";
                        break;
                    case "渝":
                        strRst += "3E";
                        break;
                    case "川":
                        strRst += "3F";
                        break;
                    case "贵":
                        strRst += "40";
                        break;
                    case "云":
                        strRst += "41";
                        break;
                    case "藏":
                        strRst += "42";
                        break;
                    case "陕":
                        strRst += "43";
                        break;
                    case "甘":
                        strRst += "44";
                        break;
                    case "青":
                        strRst += "45";
                        break;
                    case "宁":
                        strRst += "46";
                        break;
                    case "新":
                        strRst += "47";
                        break;
                    case "港":
                        strRst += "48";
                        break;
                    case "澳":
                        strRst += "49";
                        break;
                    case "台":
                        strRst += "4A";
                        break;
                    case "警":
                        strRst += "4B";
                        break;
                    case "领":
                        strRst += "5C";
                        break;
                    case "学":
                        strRst += "5D";
                        break;
                    case "武":
                        strRst += "61";
                        break;
                    case "使":
                        strRst += "62";
                        break;
                }

            }


            return strRst;
        }


        /// <summary>
        /// 判断车牌是否全是字母
        /// </summary>
        /// <param name="sCPH"></param>
        /// <returns>true全是字母，false不全是</returns>
        public static bool IsCphAllEn(string sCPH)
        {
            //if (ValidText(Convert.ToChar("B"), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", true) == false) 
            //    e.Handled = true;
            string sEn = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string sWord = "";

            sCPH = sCPH.ToUpper();

            for (int i = 1; i < sCPH.Length; i++)
            {
                sWord = sCPH.Substring(i, 1);
                if (sEn.Contains(sWord) == false)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 判断车牌字符是否完全一样
        /// </summary>
        /// <param name="sCPH"></param>
        /// <returns>true完全一样，false不完全一样</returns>
        public static bool IsCphAllSame(string sCPH)
        {
            string sWord = "";
            sCPH = sCPH.ToUpper();

            for (int i = 1; i < sCPH.Length; i++)
            {
                sWord = sCPH.Substring(i, 1);
                if (sCPH.Substring(1, 1) != sWord)
                {
                    return false;
                }
            }

            return true;
        }


        /// <summary>
        /// 金额转为大写金额
        /// </summary>
        /// <param name="LowerMoney"></param>
        /// <returns></returns>
        public static string MoneyToChinese(string LowerMoney)
        {
            string functionReturnValue = null;
            bool IsNegative = false; // 是否是负数
            if (LowerMoney.Trim().Substring(0, 1) == "-")
            {
                // 是负数则先转为正数
                LowerMoney = LowerMoney.Trim().Remove(0, 1);
                IsNegative = true;
            }
            string strLower = null;
            string strUpart = null;
            string strUpper = null;
            int iTemp = 0;
            // 保留两位小数 123.489→123.49　　123.4→123.4
            LowerMoney = Math.Round(double.Parse(LowerMoney), 2).ToString();
            if (LowerMoney.IndexOf(".") > 0)
            {
                if (LowerMoney.IndexOf(".") == LowerMoney.Length - 2)
                {
                    LowerMoney = LowerMoney + "0";
                }
            }
            else
            {
                LowerMoney = LowerMoney + ".00";
            }
            strLower = LowerMoney;
            iTemp = 1;
            strUpper = "";
            while (iTemp <= strLower.Length)
            {
                switch (strLower.Substring(strLower.Length - iTemp, 1))
                {
                    case ".":
                        strUpart = "元";
                        break;
                    case "0":
                        strUpart = "零";
                        break;
                    case "1":
                        strUpart = "壹";
                        break;
                    case "2":
                        strUpart = "贰";
                        break;
                    case "3":
                        strUpart = "叁";
                        break;
                    case "4":
                        strUpart = "肆";
                        break;
                    case "5":
                        strUpart = "伍";
                        break;
                    case "6":
                        strUpart = "陆";
                        break;
                    case "7":
                        strUpart = "柒";
                        break;
                    case "8":
                        strUpart = "捌";
                        break;
                    case "9":
                        strUpart = "玖";
                        break;
                }

                switch (iTemp)
                {
                    case 1:
                        strUpart = strUpart + "分";
                        break;
                    case 2:
                        strUpart = strUpart + "角";
                        break;
                    case 3:
                        strUpart = strUpart + "";
                        break;
                    case 4:
                        strUpart = strUpart + "";
                        break;
                    case 5:
                        strUpart = strUpart + "拾";
                        break;
                    case 6:
                        strUpart = strUpart + "佰";
                        break;
                    case 7:
                        strUpart = strUpart + "仟";
                        break;
                    case 8:
                        strUpart = strUpart + "万";
                        break;
                    case 9:
                        strUpart = strUpart + "拾";
                        break;
                    case 10:
                        strUpart = strUpart + "佰";
                        break;
                    case 11:
                        strUpart = strUpart + "仟";
                        break;
                    case 12:
                        strUpart = strUpart + "亿";
                        break;
                    case 13:
                        strUpart = strUpart + "拾";
                        break;
                    case 14:
                        strUpart = strUpart + "佰";
                        break;
                    case 15:
                        strUpart = strUpart + "仟";
                        break;
                    case 16:
                        strUpart = strUpart + "万";
                        break;
                    default:
                        strUpart = strUpart + "";
                        break;
                }

                strUpper = strUpart + strUpper;
                iTemp = iTemp + 1;
            }

            strUpper = strUpper.Replace("零拾", "零");
            strUpper = strUpper.Replace("零佰", "零");
            strUpper = strUpper.Replace("零仟", "零");
            strUpper = strUpper.Replace("零零零", "零");
            strUpper = strUpper.Replace("零零", "零");
            strUpper = strUpper.Replace("零角零分", "整");
            strUpper = strUpper.Replace("零分", "整");
            strUpper = strUpper.Replace("零角", "零");
            strUpper = strUpper.Replace("零亿零万零元", "亿元");
            strUpper = strUpper.Replace("亿零万零元", "亿元");
            strUpper = strUpper.Replace("零亿零万", "亿");
            strUpper = strUpper.Replace("零万零元", "万元");
            strUpper = strUpper.Replace("零亿", "亿");
            strUpper = strUpper.Replace("零万", "万");
            strUpper = strUpper.Replace("零元", "元");
            strUpper = strUpper.Replace("零零", "零");
            //strUpper = strUpper.Replace("零元", "元");
            // 对壹圆以下的金额的处理
            if (strUpper.Substring(0, 1) == "元")
            {
                strUpper = strUpper.Substring(1, strUpper.Length - 1);
            }
            if (strUpper.Substring(0, 1) == "零")
            {
                strUpper = strUpper.Substring(1, strUpper.Length - 1);
            }
            if (strUpper.Substring(0, 1) == "角")
            {
                strUpper = strUpper.Substring(1, strUpper.Length - 1);
            }
            if (strUpper.Substring(0, 1) == "分")
            {
                strUpper = strUpper.Substring(1, strUpper.Length - 1);
            }
            if (strUpper.Substring(0, 1) == "整")
            {
                strUpper = "零元整";
            }
            functionReturnValue = strUpper;

            if (IsNegative == true)
            {
                return "负" + functionReturnValue;
            }
            else
            {
                return functionReturnValue;
            }
        }

        public static string GetChineseMoney(string strMoney)
        {
            string strRst = "";

            for (int i = 0; i < strMoney.Length; i++)
            {
                string strW = strMoney.Substring(i, 1);
                switch (strW)
                {
                    case "零":
                        strRst += "00";
                        break;
                    case "壹":
                        strRst += "01";
                        break;
                    case "贰":
                        strRst += "02";
                        break;
                    case "叁":
                        strRst += "03";
                        break;
                    case "肆":
                        strRst += "04";
                        break;
                    case "伍":
                        strRst += "05";
                        break;
                    case "陆":
                        strRst += "06";
                        break;
                    case "柒":
                        strRst += "07";
                        break;
                    case "捌":
                        strRst += "08";
                        break;
                    case "玖":
                        strRst += "09";
                        break;
                    case "拾":
                        strRst += "0A";
                        break;
                    case "佰":
                        strRst += "0B";
                        break;
                    case "仟":
                        strRst += "0C";
                        break;
                    case "万":
                        strRst += "0D";
                        break;
                    case "分":
                        strRst += "8A";
                        break;
                    case "角":
                        strRst += "64";
                        break;
                    case "元":
                        strRst += "63";
                        break;
                }
            }

            return strRst;
        }

        /// <summary>
        /// 检查车牌号长度是否合法
        /// </summary>
        /// <param name="plateNumber"></param>
        /// <returns></returns>
        public static bool CheckCarPlateNumberLength(string plateNumber)
        {
            string number;

            if (null == plateNumber)
            {
                return false;
            }

            number = plateNumber.Trim();
            switch (number.Length)
            {
                case 7:     //普通车牌
                    return true;
                case 8:     //警用车牌
                    return number.Substring(0, 2).ToUpper() == "WJ";
                default:
                    return false;
            }
        }



        #region 新增
        /// <summary>
        /// 判断字符串是否为中文字符
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsChineseCharacters(string str)
        {
            return Regex.IsMatch(str, @"[\u4e00-\u9fa5]");
        }


        /// <summary>
        /// 验证字符串是否为数字(包括小数点)
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsNum(string str)
        {
            return Regex.IsMatch(str, @"^[-]?\d+[.]?\d*$");
        }

        /// <summary>
        /// 判断字符串是否为数字
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsInteger(string str)
        {
            if (str == "") return false;
            return Regex.IsMatch(str, "^[0-9]*$");
        }

        /// <summary>
        /// 判断字符串是否为电话号码
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsPhone(string str)
        {
            return Regex.IsMatch(str, @"\d{3,4}-\d{7,8}");
        }

        /// <summary>
        /// 判断字符串是否为IP
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsIP(string str)
        {
            //return Regex.IsMatch(str, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$");

            bool blnTest = false;
            Regex regex = new Regex("^[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}$");
            blnTest = regex.IsMatch(str);
            if (blnTest == true)
            {
                string[] strTemp = str.Split(new char[] { '.' }); // textBox1.Text.Split(new char[] { '.' });
                if (strTemp.Length == 4)
                {
                    for (int i = 0; i < strTemp.Length; i++)
                    {
                        if (Convert.ToInt32(strTemp[i]) > 255)
                        {
                            //大于255
                            return false;
                        }
                    }
                    return true;
                }
                {
                    return false;
                }
            }
            else
            {
                //输入非数字
                return false;
            }
        }

        /// <summary>
        /// 判断字符串是否为Email
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsEmail(string str)
        {
            return Regex.IsMatch(str, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }

        /// <summary>
        /// 判读字符串是否为Url地址
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsUrl(string str)
        {
            return Regex.IsMatch(str, @"^(http|https|ftp)\://[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(:[a-zA-Z0-9]*)?/?([a-zA-Z0-9\-\._\?\,\'/\\\+&$%\$#\=~])*$");
        }

        public static bool IsLetterOrFigure(string str)
        {
            return Regex.IsMatch(str, @"^[a-zA-Z0-9]+$");
        }

        public static bool IsLetter(string str)
        {
            return Regex.IsMatch(str, @"^[a-zA-Z]+$");
        }

        public static bool IsLetterNotIO(string str)
        {
            return Regex.IsMatch(str, @"[a-hj-np-zA-HJ-NP-Z0]+$");
        }

        public static bool IsLetterOrFigureNotIO(string str)
        {
            return Regex.IsMatch(str, @"^[a-hj-np-zA-HJ-NP-Z0-9]+$");
        }
        #endregion

        /// <summary>
        /// ASCII处理
        /// </summary>
        /// <param name="strAscii"></param>
        /// <returns></returns>
        public static string GetAscii(string strAscii)
        {
            string sum = "";
            for (int i = 0; i < strAscii.Length / 2; i++)
            {
                string strJihao = strAscii.Substring(i * 2, 2);
                int ac = Convert.ToInt32(strJihao, 16);

                if (ac < 40)
                {
                    string diqu1 = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学";
                    sum += diqu1.Substring(ac, 1);
                }
                else
                {
                    char chr = Convert.ToChar(ac);
                    sum += chr.ToString();
                }


            }
            return sum;

        }


        /// <summary>
        /// 判断字符串是否为合法车牌号，
        /// </summary>
        /// <param name="strCPH"></param>
        /// <returns></returns>
        public static bool CheckUpCPH(string strCPH)
        {
            if (null == strCPH || (strCPH.Length != 7 && strCPH.Length != 8))
            {
                return false;
            }
            else if (strCPH.Length == 8)
            {
                if (strCPH.Substring(0, 2).ToUpper() != "WJ")
                {
                    return false;
                }
                else
                {
                    string cphHead = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成";
                    if (cphHead.Contains(strCPH.Substring(2, 1)))
                    {
                        if (CR.IsLetterOrFigureNotIO(strCPH.Substring(3)))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                string cphHead = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成临";
                if (cphHead.Contains(strCPH.Substring(0, 1)))
                {
                    //if (CR.IsLetterNotIO(strCPH.Substring(1, 1)))
                    {
                        if (CR.IsLetterOrFigureNotIO(strCPH.Substring(2, 4)))
                        {
                            string strCphHead = "港澳警学领ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjklmnpqrstuvwxyz0123456789";
                            if (strCphHead.Contains(strCPH.Substring(6, 1)))
                            {
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                    //else
                    //{
                    //    return false;
                    //}
                }
                else
                {
                    return false;
                }
            } 
        }

        #region 加载权限到缓存
        public static void LoadRights(bool ForceLoadFromServer = false)
        {
            Request req;
            List<Rights> lstRight;

            if (!ForceLoadFromServer && Model.RightsHasLoaded)
            {
                return;
            }

            req = new Request();
            lstRight = req.GetData<List<Rights>>("GetRightsByGroupID", null, null, null, "&GroupID=" + Model.sGroupNo);

            Model.LoadRights(lstRight, true);
        }
        #endregion

        /// <summary>
        /// 下载临时卡脱机卡号Data
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static string GetDownLoadToTempCPH(AutoTempDownLoad dr)
        {
            string sendData = "";
            string CarNO = GetCPHtoCardNO(dr.CPH);
            string StatType = "E8";
            string CarNumber = CarNO;
            string strInTime = dr.InTime.ToString("HHmmss");
            string strDateTime = dr.InTime.ToShortDateString().Replace("-", "").Substring(2, 6);
            string strDateTime1 = strInTime;

            CarNumber = CarNumber.PadLeft(8, '0');
            //2015-11-07 TH
            string strCPH = strPlateZIPNew(dr.CPH, true);
            if (strCPH.Length == 12)
            {
                CarNumber = strCPH.Substring(0, 6) + CarNumber;
            }
            else
            {
                CarNumber = CarNumber.PadLeft(14, '0');
            }
            sendData = StatType + CarNumber + strDateTime + strDateTime1 + "0000";

            return sendData;
        }


        public static string ReplaceAppointString(string str, string oldstr, string newstr, int startIndex)
        {
            Regex r = new Regex(oldstr);
            str = r.Replace(str, newstr, 1, startIndex);
            return str;
        }

        public static System.Drawing.Bitmap ReadImageFile(string path)
        {
            System.IO.FileStream fs = System.IO.File.OpenRead(path); //OpenRead
            int filelength = 0;
            filelength = (int)fs.Length; //获得文件长度 
            Byte[] image = new Byte[filelength]; //建立一个字节数组 
            fs.Read(image, 0, filelength); //按字节流读取 
            System.Drawing.Image result = System.Drawing.Image.FromStream(fs);
            fs.Close();
            System.Drawing.Bitmap bit = new System.Drawing.Bitmap(result);
            return bit;
        }

    }
}