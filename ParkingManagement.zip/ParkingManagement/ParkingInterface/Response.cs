﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParkingInterface
{
    /// <summary>
    /// 用于接收服务端返回值
    /// </summary>
    public class Response
    {
        public object data { get; set; }
        public string msg { get; set; }
        public string rcode { get; set; }
    }


    public class Result<T>
    {
        public T Model { get; set; }
        public string msg { get; set; }
        public Rcode rcode { get; set; }
    }

    public enum Rcode
    {
        /// <summary>
        /// 重复入场
        /// </summary>
        RepeatAdmission = -3,
        /// <summary>
        /// 月租车过期按临时车计费
        /// </summary>
        MthBeOverdueToTmpCharge,
        /// <summary>
        /// 月租车满位按临时车计费
        /// </summary>
        MthFullToTmpCharge,
        /// <summary>
        /// 成功
        /// </summary>
        OK = 200,
        /// <summary>
        /// token 已经失效
        /// </summary>
        TokenInvalid = 40000,
        /// <summary>
        /// 未知异常，请联系管理员查看异常日志
        /// </summary>
        UnknownError,
        /// <summary>
        /// 输入参数缺失
        /// </summary>
        ParameterMissing,
        /// <summary>
        /// token已过期
        /// </summary>
        TokenBeOverdue,
        /// <summary>
        /// 用户重复登录
        /// </summary>
        UserRepeatLogin,
        /// <summary>
        /// 工作站重复
        /// </summary>
        StationRepeat,
        /// <summary>
        /// 无权限
        /// </summary>
        NoPermission,
        /// <summary>
        /// 已过有效期
        /// </summary>
        BeOverdue,
        /// <summary>
        /// 没有通过此车道的权限
        /// </summary>
        NoThisLanePermission,
        /// <summary>
        /// 个人车位已满
        /// </summary>
        PersonalFull = 40010,
        /// <summary>
        /// 禁止通行
        /// </summary>
        ProhibitCurrent,
        /// <summary>
        /// 余额不足
        /// </summary>
        BalanceNotEnough,
        /// <summary>
        /// 黑名单车辆
        /// </summary>
        BlackList,
        /// <summary>
        /// 禁止开闸模式
        /// </summary>
        ProhibitCutOff,
        /// <summary>
        /// 月租车车位已满
        /// </summary>
        MonthCarFull,
        /// <summary>
        ///临时车车位已满
        /// </summary>
        TemporaryCarFull,
        /// <summary>
        /// 储值车车位已满
        /// </summary>
        PrepaidCarFull,
        /// <summary>
        /// 总车位已满位
        /// </summary>
        SummaryCarFull,
        /// <summary>
        /// 全字母车牌不处理
        /// </summary>
        AllLetterPlateNoHandle = 40020,
        /// <summary>
        /// 全字符相同车牌不处理
        /// </summary>
        AllCharacterSamePlateNoHandle,
        /// <summary>
        /// 临时车禁止入小车场
        /// </summary>
        TemporaryCarNotInSmall = 40026,
        /// <summary>
        /// 确认开闸模式
        /// </summary>
        ConfirmCutOff,
        /// <summary>
        /// 月租车车位已满确认开闸
        /// </summary>
        MonthCarFullConfirmCutOff = 40030,
        /// <summary>
        /// 临时车车位已满确认开闸
        /// </summary>
        TemporaryCarFulllConfirmCutOff,
        /// <summary>
        /// 储值车车位已满确认开闸
        /// </summary>
        PrepaidCarFullConfirmCutOff,
        /// <summary>
        /// 所有车车位已满确认开闸
        /// </summary>
        SummaryCarFullConfirmCutOff,
        /// <summary>
        /// 未找到入场记录
        /// </summary>
        NotFoundApproachRecord = 40040
    }


    /// <summary>
    /// 用于接收分页结果集
    /// </summary>
    public class ResponseLimit
    {
        public object data { get; set; }
        public string msg { get; set; }
        public string rcode { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int TotalRows { get; set; }
    }


    public class ResponseToken
    {
        public class Data
        {
            public string token { get; set; }
        }
        public Data data { get; set; }
        public string msg { get; set; }
        public string rcode { get; set; }
    }
}
