﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingInterface
{
    public class DeviceCommanderManager
    {
        static readonly object objLock = new object();
        static readonly Dictionary<string, DeviceCommander> dicDevFlag_DevCmder = new Dictionary<string, DeviceCommander>();

        public static DeviceCommander GetCommander(ParkingModel.CheDaoSet channel, int localPort = 1007, int serverPort = 1005)
        {
            string Flag;
            DeviceCommander cmder;

            if (null == channel)
            {
                return null;
            }

            Flag = string.Format("{0}_{1}", channel.CtrlNumber, channel.IP);    //以机号和IP组成标识

            lock (objLock)
            {
                if (dicDevFlag_DevCmder.ContainsKey(Flag))
                {
                    cmder = dicDevFlag_DevCmder[Flag];
                }
                else
                {
                    cmder = new DeviceCommander(channel, serverPort, localPort);
                    dicDevFlag_DevCmder.Add(Flag, cmder);
                }
            }

            return cmder;
        }

        public static void UpdateCommander(ParkingModel.CheDaoSet channel)
        {
            string Flag;

            if (null == channel)
            {
                return;
            }

            Flag = string.Format("{0}_{1}", channel.CtrlNumber, channel.IP);    //以机号和IP组成标识

            lock (objLock)
            {
                if (dicDevFlag_DevCmder.ContainsKey(Flag))
                {
                    dicDevFlag_DevCmder[Flag] = new DeviceCommander(channel);
                }
            }
        }

        public static void DeleteCommander(ParkingModel.CheDaoSet channel)
        {
            if (null == channel)
            {
                return;
            }

            DeleteCommander(channel.CtrlNumber, channel.IP);
        }

        public static void DeleteCommander(int CtrlNumber, string IP)
        {
            string Flag;

            Flag = string.Format("{0}_{1}", CtrlNumber, IP);    //以机号和IP组成标识

            lock (objLock)
            {
                if (dicDevFlag_DevCmder.ContainsKey(Flag))
                {
                    dicDevFlag_DevCmder.Remove(Flag);
                }
            }
        }
    }
}