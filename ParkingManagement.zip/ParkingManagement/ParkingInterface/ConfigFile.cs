﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Xml;

namespace ParkingInterface
{
    public class ConfigFile
    {  
        ///<summary> 
        ///返回＊.exe.config文件中appSettings配置节的value项  
        ///</summary> 
        ///<param name="strKey"></param> 
        ///<returns></returns> 
        public static string GetAppConfig(string strKey)
        {
            foreach (string key in ConfigurationManager.AppSettings)
            {
                if (key == strKey)
                {
                    return ConfigurationManager.AppSettings[strKey];
                }
            }
            return null;
        }


        public static bool UpdateAppConfig(Configuration config, Dictionary<string, object> dic)
        {
            foreach (var v in dic)
            {
                config.AppSettings.Settings[v.Key].Value = v.Value.ToString();
            }
            config.Save();
            return true;
        }
    }
}
