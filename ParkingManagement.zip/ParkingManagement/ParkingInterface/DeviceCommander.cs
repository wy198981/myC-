﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ParkingInterface
{
    public class DeviceCommander
    {
        protected int LocalPort = 1007;
        protected int ServerPort = 1005;
        ParkingModel.CheDaoSet Channel;

        public static DeviceCommander GetCommander(ParkingModel.CheDaoSet channel, int localPort = 1007, int serverPort = 1005)
        {
            return DeviceCommanderManager.GetCommander(channel, localPort, serverPort);
        }

        public static int DeviceProtocol { get { return ParkingModel.PubVal.DeviceProtocol; } }
        public static byte[] DeviceProtocolCode = { 0xA5, 0xDA, 0xA6, 0xAD, 0xAA, 0xAB, 0x00, 0xA7, 0xA8, 0xA9, 0xAC, 0xAE, 0xA4, 0xA3, 0xA2, 0xA1, 0xA0, 0xAF, 0xD0, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDB, 0xDC };

        internal DeviceCommander(ParkingModel.CheDaoSet channel, int serverPort = 1005, int localPort = 1007)
        {
            if (null == channel)
            {
                throw new ArgumentNullException("channel");
            }

            Channel = channel;
            LocalPort = localPort;
            ServerPort = serverPort;
        }

        public static void SearchDevice(Action<byte[]> SolveDeviceData = null, Action SearchFinished = null)
        {
            byte[] cmdData;

            cmdData = new byte[] { 0xAA, 0xBB, 0xCC, 0x88 };

            Task t1 = Task.Factory.StartNew(delegate
            {
                UdpCommander.SendDataAndReceiveUntillTimeOut(new IPEndPoint(IPAddress.Broadcast, 1005), cmdData, new IPEndPoint(IPAddress.Any, 1007), SolveDeviceData, SearchFinished);
            });
            Task t2 = Task.Factory.StartNew(delegate
            {
                UdpCommander.SendDataAndReceiveUntillTimeOut(new IPEndPoint(IPAddress.Broadcast, 9801), cmdData, new IPEndPoint(IPAddress.Any, 9802), SolveDeviceData, SearchFinished);
            });

            Task.WaitAll(new Task[] { t1, t2 });
        }

        public DateTime? GetTime()
        {
            string time;
            string week;
            string data;
            int result;
            byte[] cmdData;
            byte[] backData = null;
            byte[] buffer;
            IPEndPoint epSend;
            IPEndPoint epReceive;
            DateTime tmTmp;
            DateTime? DeviceTime = null;

            cmdData = new byte[5];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = (byte)0x32;
            cmdData[4] = (byte)0x32;

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out backData, epReceive);
                    break;
            }

            if (null == backData)
            {
                throw new ArgumentException("没有返回数据");
            }
            if (backData.Length < 10)
            {
                throw new ArgumentException("返回的数据有误: 长度不足");
            }

            buffer = new byte[backData.Length - 4];
            Array.Copy(backData, 3, buffer, 0, buffer.Length);
            if (backData[backData.Length - 1] != GetXorChecksum(buffer))
            {
                throw new Exception("返回的数据有误: 数据检验失败");
            }

            //data格式16081812010204 即yyMMddHHmmss，最后两位表示星期几(1到7，7表示星期日)
            data = ByteToHexString(backData);
            if (data == "00000000000000")
            {
                throw new Exception("返回的数据有误: 请先加载时间");
            }

            time = string.Format("20{0}-{1}-{2} {3}:{4}:{5}", data.Substring(6, 2), data.Substring(8, 2), data.Substring(10, 2),
                data.Substring(12, 2), data.Substring(14, 2), data.Substring(16, 2));

            week = "";
            switch (backData[6])
            {
                case 1:
                    week = "星期一";
                    break;
                case 2:
                    week = "星期二";
                    break;
                case 3:
                    week = "星期三";
                    break;
                case 4:
                    week = "星期四";
                    break;
                case 5:
                    week = "星期五";
                    break;
                case 6:
                    week = "星期六";
                    break;
                case 7:
                    week = "星期日";
                    break;
            }

            if (DateTime.TryParse(time, out tmTmp))
            {
                DeviceTime = tmTmp;
            }

            return DeviceTime;
        }

        public int SetTime(DateTime? time)
        {
            int week;
            int result = 0;
            string tmHex;
            byte[] cmdData;
            byte[] timeData;
            byte[] buffer = null;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            time = time ?? DateTime.Now;
            week = (int)time.Value.DayOfWeek;
            tmHex = time.Value.ToString("yyMMddHHmmss") + (week == 0 ? "07" : week.ToString("00"));

            timeData = HexStringToByte(tmHex);
            cmdData = new byte[timeData.Length + 6];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = 0x31;
            cmdData[4] = 0x31;
            Array.Copy(timeData, 0, cmdData, 5, timeData.Length);
            cmdData[cmdData.Length - 1] = GetXorChecksum(timeData);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out buffer, epReceive);
                    break;
            }

            if (null == buffer)
            {
                throw new ArgumentException("没有返回数据");
            }

            return result;
        }

        public int SetPublishMessage(string msg, DateTime validStar, DateTime validEnd)
        {
            int result = 0;
            byte[] cmdData;
            byte[] timeData;
            byte[] buffer = null;
            byte[] msgData;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            msgData = Encoding.Default.GetBytes(msg);
            timeData = HexStringToByte(validStar.ToString("yyMMdd") + validEnd.ToString("yyMMdd"));

            if (msgData.Length > 80)   //最多一次发送80个字节的消息
            {
                buffer = new byte[80];
                Array.Copy(msgData, buffer, buffer.Length);
                msgData = buffer;
            }

            cmdData = new byte[msgData.Length + timeData.Length + 8];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = 0x41;
            cmdData[4] = 0x41;
            cmdData[5] = (byte)msgData.Length;
            Array.Copy(msgData, 0, cmdData, 6, msgData.Length);
            cmdData[6 + msgData.Length] = GetXorChecksum(msgData);
            Array.Copy(timeData, 0, cmdData, 7 + msgData.Length, timeData.Length);
            cmdData[cmdData.Length - 1] = GetXorChecksum(timeData);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out buffer, epReceive);
                    break;
            }

            if (null == buffer)
            {
                throw new ArgumentException("没有返回数据");
            }

            return result;
        }

        public int SetVolume(int HourStart, int HourEnd, int Volume, int VolumeOtherHour)
        {
            int result = 0;
            byte[] cmdData;
            byte[] buffer = null;
            byte[] msgData;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            msgData = HexStringToByte(HourStart.ToString("00") + HourEnd.ToString("00") + Volume.ToString("00") + VolumeOtherHour.ToString("00"));

            cmdData = new byte[msgData.Length + 6];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = 0x88;
            cmdData[4] = 0x88;
            Array.Copy(msgData, 0, cmdData, 5, msgData.Length);
            cmdData[cmdData.Length - 1] = GetXorChecksum(msgData);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out buffer, epReceive);
                    break;
            }

            if (null == buffer)
            {
                throw new ArgumentException("没有返回数据");
            }

            return result;
        }

        public int PlayCombinationVoice(string HexVoiceCode)
        {
            int result = 0;
            byte[] cmdData;
            byte[] buffer = null;
            byte[] msgData;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            if (null == HexVoiceCode || HexVoiceCode.Trim().Length <= 0)
            {
                return result;
            }

            HexVoiceCode = HexVoiceCode.Trim();
            if (HexVoiceCode.Length <= 2)   //因为计算校验码至少需要两个字节，因此如果只有一个字节的数据则组合一个不存在的语音代码
            {
                HexVoiceCode = (HexVoiceCode + "FF").PadLeft(4, '0');
            }

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            msgData = HexStringToByte(HexVoiceCode);

            cmdData = new byte[msgData.Length + 10];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = 0x3D;
            cmdData[4] = 0x3D;
            cmdData[5] = Convert.ToByte(msgData.Length + 3);
            cmdData[6] = Convert.ToByte(msgData.Length + 3);
            cmdData[7] = 0x72;
            cmdData[8] = (byte)msgData.Length;
            Array.Copy(msgData, 0, cmdData, 9, msgData.Length);
            cmdData[cmdData.Length - 1] = GetXorChecksum(msgData);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out buffer, epReceive);
                    break;
            }

            if (null == buffer)
            {
                throw new ArgumentException("没有返回数据");
            }

            return result;
        }

        public int ClearData()
        {
            int result = 0;
            byte[] cmdData;
            byte[] buffer = null;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            cmdData = new byte[7];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = 0x20;
            cmdData[4] = 0x20;
            cmdData[5] = 0x55;
            cmdData[6] = 0x55;

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out buffer, epReceive);
                    break;
            }

            if (null == buffer)
            {
                throw new ArgumentException("没有返回数据");
            }

            return result;
        }

        public ParkingModel.CardTypeChargeRules GetChargeRule(string CardType)
        {
            int SendCount = 0;
            string data;
            byte[] buffer;
            byte[] cmdData;
            byte[] backData = null;
            IPEndPoint epSend;
            IPEndPoint epReceive;
            ParkingModel.CardTypeChargeRules result = null;

            data = GetSendCardType(CardType);
            if (null == data || data.Trim().Length <= 0)
            {
                throw new NotSupportedException("不支持的卡类型");
            }

            result = new ParkingModel.CardTypeChargeRules(null);
            result.CardType = CardType;

            cmdData = new byte[7];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = (byte)0x37;
            cmdData[4] = (byte)0x37;
            cmdData[5] = HexStringToByte(data)[0];
            cmdData[6] = cmdData[5];

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    SendCount = SendDataTo(cmdData, epSend, out backData, epReceive);
                    break;
            }

            if (null == backData)
            {
                throw new ArgumentException("没有返回数据");
            }
            if (backData.Length < 5)
            {
                throw new ArgumentException("返回的数据有误: 长度不足");
            }

            buffer = new byte[backData.Length - 4];
            Array.Copy(backData, 3, buffer, 0, buffer.Length);
            if (backData[backData.Length - 1] != GetXorChecksum(buffer))
            {
                throw new Exception("返回的数据有误: 数据检验失败");
            }

            switch (buffer[buffer.Length - 4])  //收费模式
            {
                case 5: //北京收费标准
                    break;
                case 0:     //标准收费
                    result.ChangeChargeMode(0);
                    result.FreeMinutes = buffer[1];
                    result.TopSF = buffer[buffer.Length - 6] + buffer[buffer.Length - 2] * 256;
                    result.FreeMinutesNoCharge = buffer[buffer.Length - 5] != 0;

                    result.HoursRule.Hour1Money = buffer[2];
                    result.HoursRule.Hour2Money = buffer[3];
                    result.HoursRule.Hour3Money = buffer[4];
                    result.HoursRule.Hour4Money = buffer[5];
                    result.HoursRule.Hour5Money = buffer[6];
                    result.HoursRule.Hour6Money = buffer[7];
                    result.HoursRule.Hour7Money = buffer[8];
                    result.HoursRule.Hour8Money = buffer[9];
                    result.HoursRule.Hour9Money = buffer[10];
                    result.HoursRule.Hour10Money = buffer[11];
                    result.HoursRule.Hour11Money = buffer[12];
                    result.HoursRule.Hour12Money = buffer[13];
                    result.HoursRule.Hour13Money = buffer[14];
                    result.HoursRule.Hour14Money = buffer[15];
                    result.HoursRule.Hour15Money = buffer[16];
                    result.HoursRule.Hour16Money = buffer[17];
                    result.HoursRule.Hour17Money = buffer[18];
                    result.HoursRule.Hour18Money = buffer[19];
                    result.HoursRule.Hour19Money = buffer[20];
                    result.HoursRule.Hour20Money = buffer[21];
                    result.HoursRule.Hour21Money = buffer[22];
                    result.HoursRule.Hour22Money = buffer[23];
                    result.HoursRule.Hour23Money = buffer[24];
                    result.HoursRule.Hour24Money = buffer[25];
                    break;
                case 1:     //按设定时间收费
                    result.ChangeChargeMode(2);
                    result.FreeMinutes = buffer[1];
                    result.TopSF = buffer[buffer.Length - 6] + buffer[buffer.Length - 2] * 256;
                    result.FreeMinutesNoCharge = buffer[buffer.Length - 5] != 0;

                    result.TimeUnitRule.TimeUnit = buffer[2] + buffer[24] * 256;
                    result.TimeUnitRule.FirstUnit = buffer[4] + buffer[25] * 256;
                    result.TimeUnitRule.UnitMoney = buffer[3];
                    result.TimeUnitRule.FirstUnitMoney = buffer[5];
                    break;
                case 2:     //分白天夜间段
                    result.ChangeChargeMode(1);
                    result.FreeMinutes = buffer[1];
                    result.TopSF = buffer[buffer.Length - 6] + buffer[buffer.Length - 2] * 256;
                    result.FreeMinutesNoCharge = buffer[buffer.Length - 5] != 0;

                    result.DayNightRule.DayBeginHour = buffer[2];
                    result.DayNightRule.DayBeginMinute = buffer[3];
                    result.DayNightRule.NightBeginHour = buffer[4];
                    result.DayNightRule.NightBeginMinute = buffer[5];
                    result.DayNightRule.DayHourUnit = Convert.ToInt32(ByteToHexString(buffer, 6, 2), 16) / 60;
                    result.DayNightRule.DayMinuteUnit = Convert.ToInt32(ByteToHexString(buffer, 6, 2), 16) % 60;
                    result.DayNightRule.DayUnitMoney = buffer[8];
                    result.DayNightRule.NightHourUnit = Convert.ToInt32(ByteToHexString(buffer, 9, 2), 16) / 60;
                    result.DayNightRule.NightMinuteUnit = Convert.ToInt32(ByteToHexString(buffer, 9, 2), 16) % 60;
                    result.DayNightRule.NightUnitMoney = buffer[11];
                    result.DayNightRule.DayMaxMoney = buffer[12] + buffer[18] * 256;
                    result.DayNightRule.NightMaxMoney = buffer[13] + buffer[19] * 256;
                    //result.DayNightRule.DayMinMoney = buffer[14];
                    //result.DayNightRule.NightMinMoney = buffer[15];
                    result.DayNightRule.DayFirstUnitMoney = buffer[16] + buffer[20] * 256;
                    result.DayNightRule.NightFirstUnitMoney = buffer[17] + buffer[21] * 256;
                    result.DayNightRule.DayFirstUnitHour = Convert.ToInt32(ByteToHexString(buffer, 22, 2), 16) / 60;
                    result.DayNightRule.DayFirstUnitMinute = Convert.ToInt32(ByteToHexString(buffer, 22, 2), 16) % 60;
                    result.DayNightRule.NightFirstUnitHour = Convert.ToInt32(ByteToHexString(buffer, 24, 2), 16) / 60;
                    result.DayNightRule.NightFirstUnitMinute = Convert.ToInt32(ByteToHexString(buffer, 24, 2), 16) % 60;

                    result.DayNightRule.DayCutAtTheNextStartPoint = true;
                    result.DayNightRule.NightCutAtTheNextStartPoint = true;
                    break;
                case 0x0A:  //按次收费
                    result.ChangeChargeMode(3);
                    result.FreeMinutes = buffer[1];
                    result.TopSF = buffer[buffer.Length - 6] + buffer[buffer.Length - 2] * 256;
                    result.FreeMinutesNoCharge = buffer[buffer.Length - 5] != 0;
                    break;
                case 0xFF:  //标准收费(未定义)
                    result.ChangeChargeMode(0);
                    break;
            }

            return result;
        }

        public int SetChargeRule(ParkingModel.CardTypeChargeRules Rule)
        {
            string data;
            int result = 0;
            byte[] cmdData;
            byte[] buffer = null;
            byte[] msgData;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            data = GetSendCardType(Rule.CardType);
            if (null == data || data.Trim().Length <= 0)
            {
                throw new NotSupportedException("不支持的卡类型");
            }

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            switch (Rule.ChargeMode)
            {
                case 0:
                    msgData = GetHourRuleData(Rule);
                    break;
                case 1:
                    msgData = GetDayNightData(Rule);
                    break;
                case 2:
                    msgData = GetTimeUnitData(Rule);
                    break;
                case 3:
                    msgData = new byte[32];
                    msgData[0] = 1;
                    msgData[1] = (byte)Rule.FreeMinutes;
                    msgData[26] = (byte)(Rule.TopSF % 256);
                    msgData[27] = (byte)(Rule.FreeMinutesNoCharge ? 1 : 0);
                    msgData[28] = 10; //收费模式
                    msgData[29] = 0;
                    msgData[30] = (byte)(Rule.TopSF / 256);
                    msgData[31] = 0;
                    break;
                default:
                    Rule.ChargeMode = 0;
                    msgData = GetHourRuleData(Rule);
                    break;
            }

            cmdData = new byte[msgData.Length + 8];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = 0x36;
            cmdData[4] = 0x36;
            cmdData[5] = HexStringToByte(data)[0];
            cmdData[6] = cmdData[5];
            Array.Copy(msgData, 0, cmdData, 7, msgData.Length);
            cmdData[cmdData.Length - 1] = GetXorChecksum(msgData);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out buffer, epReceive);
                    break;
            }

            if (null == buffer)
            {
                throw new ArgumentException("没有返回数据");
            }

            return result;
        }

        public int SetLedSetting(ParkingModel.LedSetting setting, string ScreenText, bool ShowFullWidth, int CarPlaceNumber)
        {
            int sum = 0;
            int result = 0;
            byte[] buffer = null;
            StringBuilder strBldr;
            StringBuilder strBldrTmp;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            strBldr = new StringBuilder();
            strBldr.Append("AA");
            int.TryParse(setting.SurplusID, out result);
            strBldr.Append(result.ToString("00"));
            strBldr.Append("BB5154");

            strBldrTmp = new StringBuilder();
            int.TryParse(setting.Move, out result);
            strBldrTmp.Append(result.ToString("X2"));
            int.TryParse(setting.Speed, out result);
            strBldrTmp.Append(result.ToString("00"));
            int.TryParse(setting.StopTime, out result);
            strBldrTmp.Append(result.ToString("X2"));
            int.TryParse(setting.Color, out result);
            strBldrTmp.Append(result.ToString("00"));
            int.TryParse(setting.SumTime, out result);
            strBldrTmp.Append(result.ToString("X2"));
            strBldrTmp.Append(ByteToHexString(Encoding.Default.GetBytes(ScreenText)));
            strBldrTmp.Append(ByteToHexString(Encoding.Default.GetBytes(ShowFullWidth ? ToFullWidthString(CarPlaceNumber.ToString()) : ToHalfWidthString(CarPlaceNumber.ToString()))));
            buffer = HexStringToByte(strBldrTmp.ToString());
            foreach( byte b in buffer)
            {
                sum += b;
            }
            sum = sum % 256;

            strBldr.Append(sum.ToString("X2"));
            strBldr.Append(strBldrTmp);
            strBldr.Append("FF");

            return SetLedSetting(strBldr.ToString());
        }

        public int SetLedSetting(string set)
        {
            int result = 0;
            byte[] cmdData;
            byte[] buffer = null;
            byte[] msgData;
            IPEndPoint epSend;
            IPEndPoint epReceive;

            epSend = new IPEndPoint(IPAddress.Parse(Channel.IP), ServerPort);
            epReceive = new IPEndPoint(IPAddress.Parse(Channel.IP), LocalPort);

            msgData = HexStringToByte(set);

            buffer = new byte[msgData.Length + 1];
            buffer[0] = (byte)msgData.Length;
            Array.Copy(msgData, 0, buffer, 1, msgData.Length);

            cmdData = new byte[msgData.Length + 7];
            cmdData[0] = DeviceProtocolCode[DeviceProtocol];
            cmdData[1] = (byte)Channel.CtrlNumber;
            cmdData[2] = (byte)Channel.CtrlNumber;
            cmdData[3] = 0x64;
            cmdData[4] = 0x64;
            cmdData[5] = (byte)msgData.Length;
            Array.Copy(msgData, 0, cmdData, 6, msgData.Length);
            cmdData[cmdData.Length - 1] = GetXorChecksum(buffer);

            switch (Channel.XieYi)
            {
                case 0: //485
                    break;
                case 1: //Tcp/Ip
                    result = SendDataTo(cmdData, epSend, out buffer, epReceive);
                    break;
            }

            if (null == buffer)
            {
                throw new ArgumentException("没有返回数据");
            }

            return result;
        }

        #region 收费标准辅助函数
        protected byte[] GetHourRuleData(ParkingModel.CardTypeChargeRules Rule)
        {
            byte[] buffer;

            buffer = new byte[32];
            buffer[0] = 1;
            buffer[1] = (byte)Rule.FreeMinutes;

            buffer[2] = (byte)Rule.HoursRule.Hour1Money;
            buffer[3] = (byte)Rule.HoursRule.Hour2Money;
            buffer[4] = (byte)Rule.HoursRule.Hour3Money;
            buffer[5] = (byte)Rule.HoursRule.Hour4Money;
            buffer[6] = (byte)Rule.HoursRule.Hour5Money;
            buffer[7] = (byte)Rule.HoursRule.Hour6Money;
            buffer[8] = (byte)Rule.HoursRule.Hour7Money;
            buffer[9] = (byte)Rule.HoursRule.Hour8Money;
            buffer[10] = (byte)Rule.HoursRule.Hour9Money;
            buffer[11] = (byte)Rule.HoursRule.Hour10Money;
            buffer[12] = (byte)Rule.HoursRule.Hour11Money;
            buffer[13] = (byte)Rule.HoursRule.Hour12Money;
            buffer[14] = (byte)Rule.HoursRule.Hour13Money;
            buffer[15] = (byte)Rule.HoursRule.Hour14Money;
            buffer[16] = (byte)Rule.HoursRule.Hour15Money;
            buffer[17] = (byte)Rule.HoursRule.Hour16Money;
            buffer[18] = (byte)Rule.HoursRule.Hour17Money;
            buffer[19] = (byte)Rule.HoursRule.Hour18Money;
            buffer[20] = (byte)Rule.HoursRule.Hour19Money;
            buffer[21] = (byte)Rule.HoursRule.Hour20Money;
            buffer[22] = (byte)Rule.HoursRule.Hour21Money;
            buffer[23] = (byte)Rule.HoursRule.Hour22Money;
            buffer[24] = (byte)Rule.HoursRule.Hour23Money;
            buffer[25] = (byte)Rule.HoursRule.Hour24Money;

            buffer[26] = (byte)(Rule.TopSF % 256);
            buffer[27] = (byte)(Rule.FreeMinutesNoCharge ? 1 : 0);
            buffer[28] = 0; //收费模式
            buffer[29] = (byte)(Rule.HoursRule.OverNightCharge);
            buffer[30] = (byte)(Rule.TopSF / 256);
            buffer[31] = 0;

            return buffer;
        }
        protected byte[] GetDayNightData(ParkingModel.CardTypeChargeRules Rule)
        {
            byte[] buffer;

            buffer = new byte[32];
            buffer[0] = 1;
            buffer[1] = (byte)Rule.FreeMinutes;

            buffer[2] = (byte)Rule.DayNightRule.DayBeginHour;
            buffer[3] = (byte)Rule.DayNightRule.DayBeginMinute;
            buffer[4] = (byte)Rule.DayNightRule.NightBeginHour;
            buffer[5] = (byte)Rule.DayNightRule.NightBeginMinute;
            buffer[6] = HexStringToByte(((int)(Rule.DayNightRule.DayHourUnit * 60 + Rule.DayNightRule.DayMinuteUnit)).ToString("X4"))[0];
            buffer[7] = HexStringToByte(((int)(Rule.DayNightRule.DayHourUnit * 60 + Rule.DayNightRule.DayMinuteUnit)).ToString("X4"))[1];
            buffer[8] = (byte)Rule.DayNightRule.DayUnitMoney;
            buffer[9] = HexStringToByte(((int)(Rule.DayNightRule.NightHourUnit * 60 + Rule.DayNightRule.NightMinuteUnit)).ToString("X4"))[0];
            buffer[10] = HexStringToByte(((int)(Rule.DayNightRule.NightHourUnit * 60 + Rule.DayNightRule.NightMinuteUnit)).ToString("X4"))[1];
            buffer[11] = (byte)Rule.DayNightRule.NightUnitMoney;
            buffer[12] = (byte)(Rule.DayNightRule.DayMaxMoney % 256);
            buffer[13] = (byte)(Rule.DayNightRule.NightMaxMoney % 256);
            //buffer[14] = (byte)Rule.DayNightRule.DayMinMoney;
            //buffer[15] = (byte)Rule.DayNightRule.NightMinMoney;
            buffer[16] = (byte)(Rule.DayNightRule.DayFirstUnitMoney % 256);
            buffer[17] = (byte)(Rule.DayNightRule.NightFirstUnitMoney % 256);
            buffer[18] = (byte)(Rule.DayNightRule.DayMaxMoney / 256);
            buffer[19] = (byte)(Rule.DayNightRule.NightMaxMoney / 256);
            buffer[20] = (byte)(Rule.DayNightRule.DayFirstUnitMoney / 256);
            buffer[21] = (byte)(Rule.DayNightRule.NightFirstUnitMoney / 256);
            buffer[22] = HexStringToByte(((int)(Rule.DayNightRule.DayFirstUnitHour * 60 + Rule.DayNightRule.DayFirstUnitMinute)).ToString("X4"))[0];
            buffer[23] = HexStringToByte(((int)(Rule.DayNightRule.DayFirstUnitHour * 60 + Rule.DayNightRule.DayFirstUnitMinute)).ToString("X4"))[1];
            buffer[24] = HexStringToByte(((int)(Rule.DayNightRule.NightFirstUnitHour * 60 + Rule.DayNightRule.NightFirstUnitMinute)).ToString("X4"))[0];
            buffer[25] = HexStringToByte(((int)(Rule.DayNightRule.NightFirstUnitHour * 60 + Rule.DayNightRule.NightFirstUnitMinute)).ToString("X4"))[1];

            buffer[26] = (byte)(Rule.TopSF % 256);
            buffer[27] = (byte)(Rule.FreeMinutesNoCharge ? 1 : 0);
            buffer[28] = 2; //收费模式
            buffer[29] = 0;
            buffer[30] = (byte)(Rule.TopSF / 256);
            buffer[31] = 0;

            return buffer;
        }
        protected byte[] GetTimeUnitData(ParkingModel.CardTypeChargeRules Rule)
        {
            byte[] buffer;

            buffer = new byte[32];
            buffer[0] = 1;
            buffer[1] = (byte)Rule.FreeMinutes;

            buffer[2] = (byte)(Rule.TimeUnitRule.TimeUnit % 256);
            buffer[3] = (byte)Rule.TimeUnitRule.UnitMoney;
            buffer[4] = (byte)(Rule.TimeUnitRule.FirstUnit % 256);
            buffer[5] = (byte)Rule.TimeUnitRule.FirstUnitMoney;
            buffer[24] = (byte)(Rule.TimeUnitRule.TimeUnit / 256);
            buffer[25] = (byte)(Rule.TimeUnitRule.FirstUnit / 256);

            buffer[26] = (byte)(Rule.TopSF % 256);
            buffer[27] = (byte)(Rule.FreeMinutesNoCharge ? 1 : 0);
            buffer[28] = 1; //收费模式
            buffer[29] = (byte)(Rule.HoursRule.OverNightCharge);
            buffer[30] = (byte)(Rule.TopSF / 256);
            buffer[31] = 0;

            return buffer;
        }
        #endregion

        #region 全/半角转换
        /// <summary>
        /// 转全角的函数(SBC case)
        /// </summary>
        /// <param name="input">任意字符串</param>
        /// <returns>全角字符串</returns>
        ///<remarks>
        ///全角空格为12288，半角空格为32
        ///其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
        ///</remarks>        
        public static string ToFullWidthString(string input)
        {
            //半角转全角：
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 32)
                {
                    c[i] = (char)12288;
                    continue;
                }
                if (c[i] < 127)
                    c[i] = (char)(c[i] + 65248);
            }
            return new string(c);
        }

        /// <summary>
        /// 转半角的函数(DBC case)
        /// </summary>
        /// <param name="input">任意字符串</param>
        /// <returns>半角字符串</returns>
        ///<remarks>
        ///全角空格为12288，半角空格为32
        ///其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
        ///</remarks>
        public static string ToHalfWidthString(string input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288)
                {
                    c[i] = (char)32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375)
                    c[i] = (char)(c[i] - 65248);
            }
            return new string(c);
        }
        #endregion

        #region 十六进制数/字节数组转换
        /// <summary>
        /// 字节数组转换为十六进制数字符串
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string ByteToHexString(byte[] bytes, int idxStart = 0, int length = 0)
        {
            string str = string.Empty;
            if (bytes != null)
            {
                for (int i = idxStart; i < (length > 0 ? idxStart + length : bytes.Length); i++)
                {
                    str += bytes[i].ToString("X2");
                }
            }
            return str;
        }

        public static byte[] HexStringToByte(string Hex, int idxStart = 0, int length = 0)
        {
            string data;
            byte[] buffer;

            if (null == Hex || Hex.Trim().Length <= 0)
            {
                return null;
            }

            data = Hex.Trim();
            if (idxStart > 0 || length > 0)
            {
                data = data.Substring(idxStart, length > 0 ? idxStart + length : data.Length - idxStart);
            }

            if (data.Length % 2 != 0)
            {
                data.Insert(data.Length - 1, "0");
            }

            buffer = new byte[data.Length / 2];
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = Convert.ToByte(data.Substring(i * 2, 2), 16);
            }

            return buffer;
        }
        #endregion

        #region 计算异或结果
        /// <summary>
        /// 计算异或运算的结果
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static byte GetXorChecksum(byte[] data)
        {
            byte checksum = 0;

            checksum = (byte)(data[0] ^ data[1]);
            for (int i = 2; i < data.Length; i++)
            {
                checksum ^= data[i];
            }

            return checksum;
        }
        #endregion

        #region 根据软件上的卡类型获取机器上对应的卡类型的ID
        /// <summary>
        /// 获取卡类型在设备上对应的卡类代码
        /// </summary>
        /// <param name="cardType"></param>
        /// <returns></returns>
        public static string GetSendCardType(string cardType)
        {
            string retCard = "";
            switch (cardType)
            {
                case "Ath":
                    retCard = "30";
                    break;
                case "Opt":
                    retCard = "31";
                    break;
                case "MthA":
                    retCard = "32";
                    break;
                case "MthB":
                    retCard = "3B";
                    break;
                case "MthC":
                    retCard = "3C";
                    break;
                case "MthD":
                    retCard = "3D";
                    break;
                case "MthE":
                    retCard = "47";
                    break;
                case "MthF":
                    retCard = "48";
                    break;
                case "MthG":
                    retCard = "49";
                    break;
                case "MthH":
                    retCard = "4A";
                    break;
                case "MtpA":
                    retCard = "52";
                    break;
                case "MtpB":
                    retCard = "5B";
                    break;
                case "MtpC":
                    retCard = "5C";
                    break;
                case "MtpD":
                    retCard = "5D";
                    break;
                case "MtpE":
                    retCard = "5E";
                    break;
                case "MtpF":
                    retCard = "5F";
                    break;
                case "MtpG":
                    retCard = "60";
                    break;
                case "MtpH":
                    retCard = "61";
                    break;
                case "StrA":
                    retCard = "33";
                    break;
                case "StrB":
                    retCard = "34";
                    break;
                case "StrC":
                    retCard = "35";
                    break;
                case "StrD":
                    retCard = "3A";
                    break;
                case "TmpA":
                    retCard = "36";
                    break;
                case "TmpB":
                    retCard = "37";
                    break;
                case "TmpC":
                    retCard = "38";
                    break;
                case "TmpD":
                    retCard = "39";
                    break;
                case "TmpE":
                    retCard = "43";
                    break;
                case "TmpF":
                    retCard = "44";
                    break;
                case "TmpG":
                    retCard = "45";
                    break;
                case "TmpH":
                    retCard = "46";
                    break;
                case "TmpJ":
                    retCard = "77";
                    break;
                case "FreA":
                    retCard = "41";
                    break;
                case "FreB":
                    retCard = "3E";
                    break;
                case "手动开闸":
                    retCard = "AA";
                    break;
                case "刷非法卡":
                    retCard = "AB";
                    break;
                case "刷卡闸未关":
                    retCard = "AC";
                    break;
                case "ID卡记录":
                    retCard = "3F";
                    break;
                case "车辆感应":
                    retCard = "DD";
                    break;

            }
            return retCard;
        }
        #endregion

        #region 辅助发送函数
        protected static int SendDataTo(byte[] data, IPEndPoint epSendTo, out byte[] BackData, IPEndPoint epReceive = null, int SendTimeOut = 1000, int ReceiveTimeOut = 3000)
        {
            int SendCount = 0;

            SendCount = UdpCommander.SendDataTo(data, epSendTo, out BackData, epReceive, SendTimeOut, ReceiveTimeOut);

            if (null != epReceive)
            {
                if (null == BackData)
                {
                    throw new ArgumentException("没有返回数据");
                }

                if (BackData.Length > 2)
                {
                    if (BackData[0] != 0xB5 || BackData[1] != 0x30 || BackData[2] != 0x30)
                    {
                        throw new ArgumentException("命令执行出错: " + ByteToHexString(BackData));
                    }
                }
            }

            return SendCount;
        }
        #endregion
    }
}