﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;


namespace ParkingInterface
{
    /// <summary>
    /// 请求方式(Post,Get)
    /// </summary>
    public class API
    {
        public string HttpPost(string Url, string postDataStr, bool DecodeJson = false)
        
        {
            //System.GC.Collect();
            //System.Net.ServicePointManager.DefaultConnectionLimit = 1;
            Stream myRequestStream = null;
            Stream myResponseStream = null;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = Encoding.UTF8.GetByteCount(postDataStr);

            
                myRequestStream = request.GetRequestStream();
                StreamWriter myStreamWriter = new StreamWriter(myRequestStream, Encoding.GetEncoding("gb2312"));
                myStreamWriter.Write(postDataStr);
                //myStreamWriter.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                myResponseStream = response.GetResponseStream();
                StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
                string retString = myStreamReader.ReadToEnd();
                if (DecodeJson) //服务器返回的Json数据是多转了一次字符串的结果，所以先解析一次字符串以得到原始值
                {
                    retString = Newtonsoft.Json.JsonConvert.DeserializeObject<string>(retString);
                }
                myStreamReader.Close();
                //myResponseStream.Close();

                return retString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                myRequestStream.Close();
                myResponseStream.Close();
            }
        }

        public string HttpGet(string Url, string postDataStr, bool DecodeJson = true)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            if (DecodeJson) //服务器返回的Json数据是多转了一次字符串的结果，所以先解析一次字符串以得到原始值
            {
                retString = Newtonsoft.Json.JsonConvert.DeserializeObject<string>(retString);
            }
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }
    }
}
