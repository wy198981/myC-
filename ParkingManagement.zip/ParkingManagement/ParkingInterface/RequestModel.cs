﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParkingInterface
{
    public class SelectModel
    {
        public class conditions
        {
            string fieldName = "";
            string oper = "";
            object fieldvalue;
            string combinator = "";

            public string FieldName
            {
                get { return fieldName; }
                set { fieldName = value; }
            }
            public string Operator
            {
                get { return oper; }
                set { oper = value; }
            }
            public object FieldValue
            {
                get { return fieldvalue; }
                set { fieldvalue = value; }
            }
            public string Combinator
            {
                get { return combinator; }
                set { combinator = value; }
            }
            //public conditions(string FieldName, string Operator, object FieldValue, string Combinator)
            //{
            //    fieldName = FieldName;
            //    oper = Operator;
            //    fieldvalue = FieldValue;
            //    combinator = Combinator;
            //}
        }
        public List<conditions> Conditions = new List<conditions>();
        public string Combinator = "and";
    }

    public class UpdateModel
    {
        public string Name { get; set; }
        public object Value { get; set; }
        public UpdateModel(string name, object value)
        {
            Name = name;
            Value = value;
        }
    }
}
