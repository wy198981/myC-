﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ParkingInterface
{
    public class UdpCommander
    {
        public static int SendDataAndReceiveUntillTimeOut(IPEndPoint epSendTo, byte[] data, IPEndPoint epReceive = null, Action<byte[]> SolveData = null, Action SearchFinished = null, int SendTimeOut = 1000, int ReceiveTimeOut = 5000)
        {
            byte[] BackData;
            int CountSend = 0;
            UdpClient udp;

            BackData = null;
            udp = new UdpClient();
            udp.Client.SendTimeout = SendTimeOut;
            udp.Client.ReceiveTimeout = ReceiveTimeOut;

            if (null == data)
            {
                return CountSend;
            }

            CountSend = udp.Send(data, data.Length, epSendTo);

            if (null != SolveData && null != epReceive)
            {
                while (true)
                {
                    try
                    {
                        BackData = udp.Receive(ref epReceive);

                        SolveData(BackData);
                    }
                    catch (TimeoutException tmOut)
                    {
                        System.Diagnostics.Trace.WriteLine("SendDataAndWaitTimeOut timeout on Receive : " + tmOut.Message);
                        break;
                    }
                }
            }

            if (null != SearchFinished)
            {
                SearchFinished();
            }

            return CountSend;
        }
        public static int SendDataTo(byte[] data, IPEndPoint epSendTo, out byte[] BackData, IPEndPoint epReceive = null, int SendTimeOut = 1000, int ReceiveTimeOut = 3000)
        {
            int CountSend = 0;
            byte[] buffer = null;
            UdpClient udp;

            BackData = null;
            udp = new UdpClient();

            udp.Client.SendTimeout = SendTimeOut;
            udp.Client.ReceiveTimeout = ReceiveTimeOut;

            if (null == data)
            {
                return CountSend;
            }

            if (null != epReceive && udp.Available > 0)
            {
                buffer = udp.Receive(ref epReceive);
                System.Diagnostics.Trace.WriteLine("SendDataTo clear receive buffer: " + DeviceCommander.ByteToHexString(buffer));
            }

            CountSend = udp.Send(data, data.Length, epSendTo);

            if (null != epReceive)
            {
                try
                {
                    BackData = udp.Receive(ref epReceive);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Trace.WriteLine("SendDataTo exception on Receive: " + ex.Message);
                }
            }

            return CountSend;
        }
    }
}