﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.IO.Ports;
using System.Threading;
namespace ParkingCommunication
{
    public class UDPSend
    {
        //public static int sLocalPort;
        private static UdpClient udpClent = new UdpClient(new IPEndPoint(IPAddress.Any, SedBll.LPort));
        private static int ICount = 0;
        private static string str = "2";
        //public static UdpClient MJclent = new UdpClient(DoorSedBll.iLocalPort);//门禁 

        //public static UdpClient Dtclent = new UdpClient( Dt_SendBell.iLocalPort);//电梯
        //public static string DtSend(byte[] data, string IP, int LocalPort, int ServerPort,int OutTime=500)
        //{
        //    ICount++;
        //    string Relust = "";

        //    try
        //    {
        //        if (ICount < 6)
        //        {
        //            // sLocalPort = LocalPort;
        //            //udpClent = new UdpClient(LocalPort);//绑定发送端端口号 
        //            string st = ByteToHexString(data);
        //            List<string> slt = new List<string>();
        //            for (int i = 0; i < st.Length / 2; i++)
        //            {
        //                slt.Add(st.Substring(2 * i, 2));
        //            }
        //            string fsdfd = string.Join(" ", slt).ToString();
        //            IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(IP), ServerPort);//构建服务器IP和端口号
        //            Dtclent.Send(data, data.Length, ipep);//向服务器发送指令

        //            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);// new IPEndPoint(IPAddress.Parse(IP), ServerPort);//new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
        //            Dtclent.Client.ReceiveTimeout = OutTime;//设置超时
        //            byte[] rtndata = Dtclent.Receive(ref sender);//接收客户端发送的信息
        //            if (data.OrderBy(a => a).SequenceEqual(rtndata.OrderBy(a => a)))//第一次返回的和发送的一样的数据 重新发送
        //            {

        //                Dtclent.Send(data, data.Length, ipep);//向服务器发送指令


        //                sender = new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
        //                Dtclent.Client.ReceiveTimeout = OutTime;//设置超时
        //                rtndata = Dtclent.Receive(ref sender);//接收客户端发送的信息
        //            }


        //            //  MJclent.Close();//关闭UDP连接。
        //            if (rtndata.Length > 0)
        //            {
        //                ICount = 0;
        //                Relust = ByteToHexString(rtndata);
        //                return Relust;//返回服务器传回的指令。
        //            }
        //            else
        //            {
        //                ICount = 0;
        //                Relust = "2";
        //                return Relust;
        //            }

        //        }
        //        else
        //        {
        //            ICount = 0;
        //            return Relust = "2";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //throw ex;
        //        Relust = "2";
        //        // Send(data, IP, LocalPort, ServerPort);

        //        return Relust;
        //    }



        //}

        //public static string MJSend(byte[] data, string IP, int LocalPort, int ServerPort)
        //{
        //    ICount++;
        //    string Relust = "";
            
        //    try
        //    {
        //        if (ICount < 6)
        //        {
        //            // sLocalPort = LocalPort;
        //            //udpClent = new UdpClient(LocalPort);//绑定发送端端口号 
        //            string st = ByteToHexString(data);
        //            List<string> slt = new List<string>();
        //            for (int i = 0; i < st.Length / 2; i++)
        //            {
        //                slt.Add(st.Substring(2 * i, 2));
        //            }
        //            string fsdfd = string.Join(" ", slt).ToString();
        //            IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(IP), ServerPort);//构建服务器IP和端口号
        //            MJclent.Send(data, data.Length, ipep);//向服务器发送指令

        //            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);// new IPEndPoint(IPAddress.Parse(IP), ServerPort);//new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
        //            MJclent.Client.ReceiveTimeout = 500;//设置超时
        //            byte[] rtndata = MJclent.Receive(ref sender);//接收客户端发送的信息
        //            // data.OrderBy(a => a).SequenceEqual(rtndata.OrderBy(a => a));
        //            if (data.OrderBy(a => a).SequenceEqual(rtndata.OrderBy(a => a)))//第一次返回的和发送的一样的数据 重新发送
        //            {

        //                MJclent.Send(data, data.Length, ipep);//向服务器发送指令


        //                sender = new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
        //                MJclent.Client.ReceiveTimeout = 500;//设置超时
        //                rtndata = MJclent.Receive(ref sender);//接收客户端发送的信息
        //            }


        //            //  MJclent.Close();//关闭UDP连接。
        //            if (rtndata.Length > 0)
        //            {
        //                ICount = 0;
        //                Relust = ByteToHexString(rtndata);
        //                return Relust;//返回服务器传回的指令。
        //            }
        //            else
        //            {
        //                ICount = 0;
        //                Relust = "2";
        //                return Relust;
        //            }

        //        }
        //        else
        //        {
        //            ICount = 0;
        //            return Relust = "2";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //throw ex;
        //        Relust = "2";
        //        // Send(data, IP, LocalPort, ServerPort);

        //        return Relust;
        //    }
           
          

        //}



        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="data">指令数组</param>
        /// <param name="IP">服务器IP</param>
        /// <param name="LocalPort">本地端口号</param>
        /// <param name="ServerPort">服务器端口号</param>
        /// <returns>服务器返回的指令</returns>
        public static string Send(byte[] data, string IP, int LocalPort, int ServerPort)
        {
            ICount++;
            try
            {
                if (ICount < 6)
                {
                    // sLocalPort = LocalPort;
                    //udpClent = new UdpClient(LocalPort);//绑定发送端端口号 

                    IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(IP), ServerPort);//构建服务器IP和端口号
                    udpClent.Send(data, data.Length, ipep);//向服务器发送指令

                    IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
                    udpClent.Client.ReceiveTimeout = 500;//设置超时
                    byte[] rtndata = udpClent.Receive(ref sender);//接收客户端发送的信息
                    //udpClent.Close();//关闭UDP连接。

                    //while (true)
                    //{
                    //    byte[] buf = udpClent.Receive(ref sender);
                    //    string msg = Encoding.Default.GetString(buf);
                    //    Console.WriteLine(msg);
                    //}  

                    if (rtndata.Length > 0)
                    {
                        ICount = 0;
                        //2016-03-05
                        if (ipep.Address.ToString() != sender.Address.ToString())
                        {
                            //GCR.Hid.WriteToTxtFile("发送接收IP不符：" + ipep.Address.ToString() + " " + sender.Address.ToString() + " XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                            return "6";
                        }
                        str = ByteToHexString(rtndata);
                        return str;//返回服务器传回的指令。
                    }
                    else
                    {
                        ICount = 0;
                        str = "2";
                        return str;
                    }
                }
                else
                {
                    ICount = 0;
                    return str = "2";
                }
            }
            catch
            {
                //str= "2";
                Send(data, IP, LocalPort, ServerPort);

                return str;
            }

        }
        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="data">指令数组</param>
        /// <param name="IP">服务器IP</param>
        /// <param name="LocalPort">本地端口号</param>
        /// <param name="ServerPort">服务器端口号</param>
        /// <returns>服务器返回的指令</returns>
        public static string Sends(byte[] data, string IP, int LocalPort, int ServerPort)
        {
            ICount++;
            try
            {
                if (ICount < 6)
                {
                    // sLocalPort = LocalPort;
                    //udpClent = new UdpClient(LocalPort);//绑定发送端端口号 

                    IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(IP), ServerPort);//构建服务器IP和端口号
                    udpClent.Send(data, data.Length, ipep);//向服务器发送指令

                    IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
                    udpClent.Client.ReceiveTimeout = 500;//设置超时
                    byte[] rtndata = udpClent.Receive(ref sender);//接收客户端发送的信息
                    //udpClent.Close();//关闭UDP连接。

                    //while (true)
                    //{
                    //    byte[] buf = udpClent.Receive(ref sender);
                    //    string msg = Encoding.Default.GetString(buf);
                    //    Console.WriteLine(msg);
                    //}  

                    if (rtndata.Length > 0)
                    {
                        ICount = 0;
                        //2016-03-05
                        if (ipep.Address.ToString() != sender.Address.ToString())
                        {
                            //GCR.Hid.WriteToTxtFile("发送接收IP不符：" + ipep.Address.ToString() + " " + sender.Address.ToString() + " XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                            Send(data, IP, LocalPort, ServerPort);
                        }
                        else
                        {
                            str = ByteToHexString(rtndata);
                        }
                        return str;//返回服务器传回的指令。
                    }
                    else
                    {
                        ICount = 0;
                        str = "2";
                        return str;
                    }
                }
                else
                {
                    ICount = 0;
                    return str = "2";
                }
            }
            catch
            {
                //str= "2";
                Send(data, IP, LocalPort, ServerPort);

                return str;
            }

        }



        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="data">指令数组</param>
        /// <param name="IP">服务器IP</param>
        /// <param name="LocalPort">本地端口号</param>
        /// <param name="ServerPort">服务器端口号</param>
        /// <returns>服务器返回的指令</returns>
        public static string SendTest(byte[] data, string IP, int LocalPort, int ServerPort)
        {
            ICount++;
            try
            {
                if (ICount < 6)
                {
                    // sLocalPort = LocalPort;
                    //udpClent = new UdpClient(LocalPort);//绑定发送端端口号 

                    IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(IP), ServerPort);//构建服务器IP和端口号
                    udpClent.Send(data, data.Length, ipep);//向服务器发送指令

//                     IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
//                     udpClent.Client.ReceiveTimeout = 500;//设置超时
//                     byte[] rtndata = udpClent.Receive(ref sender);//接收客户端发送的信息
                    //udpClent.Close();//关闭UDP连接。

                    //while (true)
                    //{
                    //    byte[] buf = udpClent.Receive(ref sender);
                    //    string msg = Encoding.Default.GetString(buf);
                    //    Console.WriteLine(msg);
                    //}  
                    return "B53030";
//                     if (rtndata.Length > 0)
//                     {
//                         ICount = 0;
//                         str = ByteToHexString(rtndata);
//                         return str;//返回服务器传回的指令。
//                     }
//                     else
//                     {
//                         ICount = 0;
//                         str = "2";
//                         return str;
//                     }
                }
                else
                {
                    ICount = 0;
                    return str = "2";
                }
            }
            catch
            {
                //str= "2";
                Send(data, IP, LocalPort, ServerPort);

                return str;
            }

        }



        public static void SendSearch(byte[] data,IPEndPoint iep)
        {

            udpClent.Send(data, data.Length, iep);

        }

        public static byte[] RstSendSearch(IPEndPoint iep)
        {

            byte[] buf = udpClent.Receive(ref iep);
            return buf;

        }

        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="data">指令数组</param>
        /// <param name="IP">服务器IP</param>
        /// <param name="LocalPort">本地端口号</param>
        /// <param name="ServerPort">服务器端口号</param>
        /// <returns>服务器返回的指令</returns>
        public static string SendNoRst(byte[] data, string IP, int LocalPort, int ServerPort)
        {
            try
            {
                    // sLocalPort = LocalPort;
                    //udpClent = new UdpClient(LocalPort);//绑定发送端端口号 

                    IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(IP), ServerPort);//构建服务器IP和端口号
                    udpClent.Send(data, data.Length, ipep);//向服务器发送指令

//                     IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
//                     udpClent.Client.ReceiveTimeout = 500;//设置超时
//                     byte[] rtndata = udpClent.Receive(ref sender);//接收客户端发送的信息
//                     //udpClent.Close();//关闭UDP连接。
// 
//                     //while (true)
//                     //{
//                     //    byte[] buf = udpClent.Receive(ref sender);
//                     //    string msg = Encoding.Default.GetString(buf);
//                     //    Console.WriteLine(msg);
//                     //}  
// 
//                     if (rtndata.Length > 0)
//                     {
//                         ICount = 0;
//                         str = ByteToHexString(rtndata);
//                         return str;//返回服务器传回的指令。
//                     }
//                     else
//                     {
//                         ICount = 0;
//                         str = "2";
//                         return str;
//                     }
                    return str;
            }
            catch
            {
                return "2";
            }

        }



        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="data">指令数组</param>
        /// <param name="IP">服务器IP</param>
        /// <param name="LocalPort">本地端口号</param>
        /// <param name="ServerPort">服务器端口号</param>
        /// <returns>服务器返回的指令</returns>
        public static string ReadSend(byte[] data, string IP, int LocalPort, int ServerPort)
        {
            //string str = "";

            try
            {

                // sLocalPort = LocalPort;
                //udpClent = new UdpClient(LocalPort);//绑定发送端端口号
                IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(IP), ServerPort);//构建服务器IP和端口号                
                udpClent.Send(data, data.Length, ipep);//向服务器发送指令

                IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);//构建服务器端的IP端口号
                udpClent.Client.ReceiveTimeout = 500;//设置超时
                byte[] rtndata = udpClent.Receive(ref sender);//接收客户端发送的信息
                //udpClent.Close();//关闭UDP连接。

                if (rtndata.Length > 0)
                {

                    return ByteToHexString(rtndata);//返回服务器传回的指令。
                }
                else
                {
                    return "2";
                }
            }
            catch
            {
                return "2";
            }

        }

        private static CommPort_old Commport = new CommPort_old();

        /// <summary>
        /// 串口发送
        /// </summary>
        /// <param name="data">发送指令</param>
        /// <param name="ComPort">com口</param>
        /// <param name="Rate">串口通信波特率</param>
        /// <returns></returns>
        public static string Senddata(byte[] data, int ComPort, int Rate)
        {
            ICount++;
            try
            {
                if (ICount < 6)
                {
                    Commport.PortNum = ComPort; //端口号
                    Commport.Parity = (byte)1; //奇偶校验
                    Commport.BaudRate = Rate;//串口通信波特率
                    Commport.ByteSize = (byte)8; //数据位
                    Commport.StopBits = 0;//停止位
                    Commport.ReadTimeout = 500; //读超时
                    if (Commport.Opened)
                    {
                        Commport.Close();
                        Commport.Open(); //打开串口
                    }
                    else
                    {
                        //Sport.Close();
                        Commport.Open();//打开串口
                    }
                    Commport.Write(data);



                    byte[] bs = Commport.Read(1000);
                    Commport.Close();
                    if (bs.Length > 0)
                    {
                        ICount = 0;
                        str = ByteToHexString(bs);
                        return str;//返回服务器传回的指令。
                    }
                    else
                    {
                        str = "2";
                        if (data.Length > 1 && data[1] != 84)
                        //ICount = 0;
                        {
                            Senddata(data, ComPort, Rate);
                        }
                        return str;
                    }
                }
                else
                {
                    ICount = 0;
                    return str = "2";
                }
            }
            catch
            {
                if (str.Length > 6)
                {
                    if (Commport.Opened)
                    {
                        Commport.Close(); //关闭串口
                        // sp1.Close();
                    }
                    return str;
                }
                else
                {
                    if (Commport.Opened)
                    {
                        Commport.Close(); //关闭串口
                        // sp1.Close();
                    }
                    Senddata(data, ComPort, Rate);
                    return str;

                }
            }
        }
        private static bool IsSend=false;
        /// <summary>
        /// 串口发送
        /// </summary>
        /// <param name="data">发送指令</param>
        /// <param name="ComPort">com口</param>
        /// <param name="Rate">串口通信波特率</param>
        /// <returns></returns>
        public static string PKSenddata(byte[] data, int ComPort, int Rate)
        {
            //while (!IsSend)
            //{
                IsSend = true;

                try
                {
                    Commport.PortNum = ComPort; //端口号
                    Commport.Parity = (byte)1; //奇偶校验
                    Commport.BaudRate = Rate;//串口通信波特率
                    Commport.ByteSize = (byte)8; //数据位
                    Commport.StopBits = 0;//停止位
                    Commport.ReadTimeout = 200; //读超时
                    if (Commport.Opened)
                    {
                        Commport.Close();
                        Commport.Open(); //打开串口
                    }
                    else
                    {
                        //Sport.Close();
                        Commport.Open();//打开串口
                    }
                    Commport.Write(data);
                    byte[] bs = Commport.Read(1000);
                    Commport.Close();
                    IsSend = false;
                    if (bs.Length > 0)
                    {
                        str = ByteToHexString(bs);
                        return str;//返回服务器传回的指令。
                    }
                    else
                    {
                        str = "2";

                        return str;
                    }
                   
                }
                catch
                {
                    str = "2";
                    return str;
                }

                
           // }
            //return str;
        }



        public static bool ComStart(int ComPort, int Rate)
        {

            Commport.PortNum = ComPort; //端口号
            Commport.Parity = (byte)1; //奇偶校验
            Commport.BaudRate = Rate;//串口通信波特率
            Commport.ByteSize = (byte)8; //数据位
            Commport.StopBits = 0;//停止位
            Commport.ReadTimeout = 200; //读超时
            if (Commport.Opened)
            {
                Commport.Close();
                return Commport.Open(); //打开串口
            }
            else
            {
                //Sport.Close();
                return Commport.Open();//打开串口
            }
            // return true;
        }
        public static void ComClose(int ComPort, int Rate)
        {
            if (Commport.Opened)
            {
                Commport.Close();
            }
        }
        /// <summary>
        /// 串口发送
        /// </summary>
        /// <param name="data">发送指令</param>
        /// <param name="ComPort">com口</param>
        /// <param name="Rate">串口通信波特率</param>
        /// <returns></returns>
        public static string PSenddata(byte[] data, int ComPort, int Rate)
        {
            ICount++;
            try
            {
                if (ICount < 6)
                {

                    //Sport.Parity = (byte)1; //奇偶校验
                    //Sport.BaudRate = Rate;//串口通信波特率
                    //Sport.ByteSize = (byte)8; //数据位
                    //Sport.StopBits = 0;//停止位
                    //Sport.ReadTimeout = 200; //读超时
                    //if (Sport.Opened)
                    //{
                    //    Sport.Close();
                    //    Sport.Open(); //打开串口
                    //}
                    //else
                    //{
                    //    //Sport.Close();
                    //    Sport.Open();//打开串口
                    //}
                    Commport.Write(data);

                    byte[] bs = Commport.Read(1000);
                    //Sport.Close();
                    if (bs.Length > 0)
                    {
                        ICount = 0;
                        str = ByteToHexString(bs);
                        return str;//返回服务器传回的指令。
                    }
                    else
                    {
                        //ICount = 0;
                        str = "2";
                        PSenddata(data, ComPort, Rate);
                        return str;
                    }
                }
                else
                {
                    ICount = 0;
                    return str = "2";
                }
            }
            catch
            {
                if (Commport.Opened)
                {
                    Commport.Close(); //关闭串口
                    // sp1.Close();
                }
                PSenddata(data, ComPort, Rate);

                return str;
            }
        }



        /// <summary>
        /// btye数组转换为字符串
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string ByteToHexString(byte[] bytes)
        {
            string str = string.Empty;
            if (bytes != null)
            {
                for (int i = 0; i < bytes.Length; i++)
                {
                    str += bytes[i].ToString("X2");
                }
            }
            return str;
        }
    }
}
