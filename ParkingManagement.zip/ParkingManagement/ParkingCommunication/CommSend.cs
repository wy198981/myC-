﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ParkingCommunication
{
    public class CommSend
    {
        private static string strRet = "2";
        private static CommPort Commport = new CommPort();
        //private const int MAX_READ_BYTES = 100;
        //public static int iBytesToRead = MAX_READ_BYTES;  //读取多少个字节

        public static bool ComStart( int ComPort, int Rate )
        {

            Commport.PortNum = ComPort; //端口号
            Commport.Parity = 0; //奇偶校验
            Commport.BaudRate = Rate;//串口通信波特率
            Commport.ByteSize = 8; //数据位
            Commport.StopBits = 0;//停止位
            Commport.ReadTimeout = 1000; //读超时
            if (Commport.Opened)
            {
                Commport.Close();
                return Commport.Open(); //打开串口
            }
            else
            {
                //Sport.Close();
                return Commport.Open();//打开串口
            }
        }
        public static void ComClose()
        {
            if (Commport.Opened)
            {
                Commport.Close();
            }
        }

        /// <summary>
        /// 串口发送
        /// </summary>
        /// <param name="data">发送指令</param>
        /// <param name="ComPort">com口</param>
        /// <param name="Rate">串口通信波特率</param>
        /// <param name="bNoRead">不读取返回值，用于无返回的指令</param>
        /// <returns></returns>
        public static string SendData( byte[] data, int ComPort, int Rate, int iBytesToRead = 100, bool bNoRead = false )
        {
            int iCount = 0;
            strRet = "2";
            
            try
            {
                while (iCount < 5)
                {                    
                    if (!Commport.Opened)
                    {
                        //打开串口
                        if (ComStart(ComPort, Rate) == false)
                        {
                            strRet = "2";  //串口打开失败
                            return strRet;
                        }
                    }
                    Commport.Write(data);

                    if (bNoRead)
                    {                           
                        return "";
                    }

                    bool bSuccess = false;
                    Thread.Sleep(1000);

                    byte[] recvData = Commport.Read(iBytesToRead, ref bSuccess);
                                        
                    if (bSuccess)  //读取成功
                    {
                        strRet = ByteToHexString(recvData);
                        Commport.Close();
                        return strRet;//返回服务器传回的指令。

                        //byte[] recvData11 = Commport.Read(iBytesToRead, ref bSuccess);
                    }
                    else
                    {
                        strRet = "2";                        
                        iCount++;
                    }
                }
                return strRet;
                
            }
            catch
            {               
                return "2";
            }            
        }


        /// <summary>
        /// btye数组转换为字符串
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string ByteToHexString( byte[] bytes )
        {
            string str = string.Empty;
            if (bytes != null)
            {
                for (int i = 0; i < bytes.Length; i++)
                {
                    str += bytes[i].ToString("X2");
                }
            }
            return str;
        }
    }
}
