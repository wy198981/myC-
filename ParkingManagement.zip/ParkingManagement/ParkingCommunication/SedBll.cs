﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading;
using System.IO;
using ParkingModel;
using ParkingInterface;

namespace ParkingCommunication
{
    /// <summary>
    /// 处理发送指令
    /// </summary>
    public class SedBll
    {
        private static string LIP = "";
        public static int LPort = 0;
        public static int SPort = 0;
        //private Hid usbHid = new Hid();

        private static bool bUsbSending = false;  //2015-09-18

        public Hid UsbObj = null;   //2015-09-18

        public SedBll(string IP, int Localport, int ServerPort)
        {
            LIP = IP;
            LPort = Localport;
            SPort = ServerPort;

            if (Model.bAppEnable)
            {
                LPort = 9802;
                SPort = 9801;
            }
            else
            {
                LPort = 1007;
                SPort = 1005;
            }
        }

        public SedBll(string IP)
        {
            LIP = IP;
        }

        public SedBll()
        {
            // TODO: Complete member initialization
        }

        public void TCPSend(byte[] bSndData, string strIP, int strLPort, int strSPort)
        {

            string strrtn = UDPSend.Send(bSndData, strIP, strLPort, strSPort);

        }


        public void Test()
        {
            byte[] sendData = new byte[5];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = 0x01;
            sendData[2] = 0x01;
            sendData[3] = 0x32;
            sendData[4] = 0x32;
            string aaa = CommSend.SendData(sendData, 2, Model.BaudRate); //UDPSend.Senddata(sendData, 2, Model.BaudRate);
        }
        public bool ComStart(int Com)
        {
            try
            {
                return UDPSend.ComStart(Com, Model.BaudRate);
            }
            catch
            {
                return false;
            }

        }
        public string ComClose()
        {
            try
            {
                if (Model.iFXMachineType == 2)
                {
                    UDPSend.ComStart(Model.iParkCom, Model.BaudRate);
                }
                else
                {
                    UDPSend.ComStart(Model.iParkCom, Model.BaudRate);
                }
                return "0";
            }
            catch (System.Exception ex)
            {
                return "2";
            }

        }

        /// <summary>
        /// 加载时间
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="dt">当前时间</param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string LoadTime(int JiHao, DateTime dt, int Flag)
        {
            try
            {
                //byte[] strList = GetByteArray(JiHao);

                //#region  时间转换
                //string year = dt.Year.ToString().Substring(2, 2);
                //string month = "";
                //if (dt.Month < 10)
                //{
                //    month = "0" + dt.Month.ToString();
                //}
                //else
                //{
                //    month = dt.Month.ToString();
                //}
                //string day = "";
                //if (dt.Day < 10)
                //{
                //    day = "0" + dt.Day.ToString();
                //}
                //else
                //{
                //    day = dt.Day.ToString();
                //}
                //string hour = "";
                //if (dt.Hour < 10)
                //{
                //    hour = "0" + dt.Hour.ToString();
                //}
                //else
                //{
                //    hour = dt.Hour.ToString();
                //}
                //string minute = "";
                //if (dt.Minute < 10)
                //{
                //    minute = "0" + dt.Minute.ToString();
                //}
                //else
                //{
                //    minute = dt.Minute.ToString();
                //}
                //string second = "";
                //if (dt.Second < 10)
                //{
                //    second = "0" + dt.Second.ToString();
                //}
                //else
                //{
                //    second = dt.Second.ToString();
                //}

                //#endregion

                //int week = (int)dt.DayOfWeek;

                //string strDate;

                //if (week == 0)
                //{
                //    strDate = year + month + day + hour + minute + second + "07";
                //}
                //else
                //{
                //    strDate = year + month + day + hour + minute + second + "0" + week.ToString();
                //}

                //byte[] dateByte = GetArray(strDate);
                //byte dateJY = YHXY(strDate);

                //byte[] sendData = new byte[strList.Length + dateByte.Length + 4];
                //sendData[0] = Config.byteHead[Config.HeadIndex];
                //for (int i = 1; i <= strList.Length; i++)//机号处理
                //{
                //    sendData[i] = strList[i - 1];
                //}
                //sendData[strList.Length + 1] = 0x31;
                //sendData[strList.Length + 2] = 0x31;
                //for (int i = strList.Length + 3; i < strList.Length + 3 + dateByte.Length; i++)//时间处理
                //{
                //    sendData[i] = dateByte[i - (strList.Length + 3)];
                //}
                //sendData[strList.Length + dateByte.Length + 3] = dateJY;//验证处理

                byte[] sendData = AllCommand.LoadTime(JiHao, dt);

                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                else if (Flag == 2 || Flag == 3)
                {
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  usbHid.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 6);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                {
                    return "0";
                }
                else
                {
                    return "1";
                }
            }
            catch
            {
                return "3";
            }
            //return strrtn;
        }

        /// <summary>
        /// 读取时间
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <returns>正常时间字符串，2：超时，3：方法出错,9：验证出错</returns>
        public string ReadTime(int JiHao, int Flag)
        {
            try
            {
                //byte[] byteJihao = GetByteArray(JiHao);
                //byte[] sendData = new byte[byteJihao.Length + 3];
                //sendData[0] = Config.byteHead[Config.HeadIndex];
                //for (int i = 1; i <= byteJihao.Length; i++)
                //{
                //    sendData[i] = byteJihao[i - 1];
                //}
                //sendData[byteJihao.Length + 3 - 2] = 0x32;
                //sendData[byteJihao.Length + 3 - 1] = 0x32;

                byte[] sendData = AllCommand.ReadTime(JiHao);

                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  usbHid.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 22);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }

                if (strrtn != "2")
                {
                    string str = strrtn.Substring(6, 14);
                    if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str))
                    {
                        return str;
                    }
                    else
                    {
                        return "9";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 转换模式
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Mode">模式:0为正常工作模式   1为发卡模式</param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string SelectMode(int JiHao, int Mode, int Flag)
        {
            try
            {
                //int sMode = 0;
                //if (Mode == 1)
                //{
                //    sMode = 49;
                //}
                //else
                //{
                //    sMode = 48;
                //}
                //byte[] byteJihao = GetByteArray(JiHao);
                //byte[] byteMode = GetByteArray(sMode);

                //byte[] sendData = new byte[byteJihao.Length + byteMode.Length + 3];
                //sendData[0] = Config.byteHead[Config.HeadIndex];
                //for (int i = 1; i <= byteJihao.Length; i++)
                //{
                //    sendData[i] = byteJihao[i - 1];
                //}
                //sendData[byteJihao.Length + 1] = 0x33;
                //sendData[byteJihao.Length + 2] = 0x33;
                //for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteMode.Length; i++)//时间处理
                //{
                //    sendData[i] = byteMode[i - (byteJihao.Length + 3)];
                //}

                byte[] sendData = AllCommand.SelectMode(JiHao, Mode);

                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }

            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 写卡(写卡前必须先把下位机转换成发行模式)
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="SectorMode">扇区号</param>
        /// <param name="strData">命令</param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string WriteCard(int JiHao, int SectorMode, string strData, int Flag)
        {
            try
            {
                //byte[] byteJihao = GetByteArray(JiHao);
                //byte[] byteSectorMode = GetByteArray(SectorMode);
                //byte[] dateByte = GetArray(strData);
                //byte dateJY = YHXY(strData);

                //byte[] sendData = new byte[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 4];
                //sendData[0] = Config.byteHead[Config.HeadIndex];
                //for (int i = 1; i <= byteJihao.Length; i++)
                //{
                //    sendData[i] = byteJihao[i - 1];
                //}
                //sendData[byteJihao.Length + 1] = 0x3E;
                //sendData[byteJihao.Length + 2] = 0x3E;
                //for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteSectorMode.Length; i++)//时间处理
                //{
                //    sendData[i] = byteSectorMode[i - (byteJihao.Length + 3)];
                //}
                //for (int i = byteJihao.Length + 3 + byteSectorMode.Length; i < byteJihao.Length + dateByte.Length + 3 + byteSectorMode.Length; i++)//时间处理
                //{
                //    sendData[i] = dateByte[i - (byteJihao.Length + 3 + byteSectorMode.Length)];
                //}
                //sendData[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 3] = dateJY;//验证处理

                byte[] sendData = AllCommand.WriteCard(JiHao, SectorMode, strData);

                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 写卡 发行器不用转换模式(写卡前必须先把下位机转换成发行模式)
        /// </summary>
        /// <param name="SectorMode">扇区号</param>
        /// <param name="strData">命令</param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string WriteCardCom(int SectorMode, string strData, int com, int Rate)
        {
            try
            {
                byte[] byteSectorMode = GetByteArray(SectorMode);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);

                byte[] sendData = new byte[byteSectorMode.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];

                sendData[1] = 0x57;
                sendData[2] = 0x57;
                for (int i = 3; i < 3 + byteSectorMode.Length; i++)//时间处理
                {
                    sendData[i] = byteSectorMode[i - 3];
                }
                for (int i = 3 + byteSectorMode.Length; i < dateByte.Length + 3 + byteSectorMode.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (3 + byteSectorMode.Length)];
                }
                sendData[byteSectorMode.Length + dateByte.Length + 3] = dateJY;//验证处理

                string strrtn = CommSend.SendData(sendData, com, Rate);  //UDPSend.Senddata(sendData, com, Rate);
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return strrtn;
                }

            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 读卡
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="SectorMode">扇区号</param>
        /// <returns>正常时间字符串，2：超时，3：方法出错,4，发送错误，9：验证出错</returns>
        public string ReadCard(int JiHao, int SectorMode, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] byteSectorMode = GetByteArray(SectorMode);
                byte[] sendData = new byte[byteJihao.Length + byteSectorMode.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x3F;
                sendData[byteJihao.Length + 2] = 0x3F;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteSectorMode.Length; i++)//时间处理
                {
                    sendData[i] = byteSectorMode[i - (byteJihao.Length + 3)];
                }
                string strrtn = "";
                if (Flag == 1)  //TCP
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)  //串口
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); // UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length >= 6)
                {
                    if (strrtn.Substring(2, 4) == "3131")
                    {
                        return "4";
                    }
                    else if (strrtn != "2")
                    {
                        string sum = "";
                        string str1 = strrtn.Substring(6, 32);
                        string str2 = strrtn.Substring(strrtn.Length - 10, 8);
                        if (Convert.ToByte(strrtn.Substring(38, 2), 16) == YHXY(str1) && Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str2))
                        {
                            sum = str1 + str2;
                            return sum;
                        }
                        else
                        {
                            return "9";
                        }
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 发行器读卡
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="Data"></param>
        /// <returns></returns>
        public string ReadCardCom(byte cmd, string Data, int Com, int Rate)
        {
            try
            {

                string strrtn = "";
                if (Data == "")
                {
                    byte[] sendData = new byte[3];
                    sendData[0] = Config.byteHead[Config.HeadCom];
                    sendData[1] = cmd;
                    sendData[2] = cmd;
                    strrtn = CommSend.SendData(sendData, Com, Rate);   //UDPSend.Senddata(sendData, Com, Rate);
                    if (strrtn.Length > 2)
                    {
                        if (strrtn.Substring(2, 4) != "3131")
                        {
                            if (strrtn.Length == 6)
                            {
                                return "0";
                            }
                            else
                            {
                                return strrtn.Substring(6, 8);
                            }
                        }
                        else
                        {
                            return "";
                        }
                    }
                    else
                    {
                        return strrtn;
                    }
                }
                else
                {
                    byte[] dateByte = GetArray(Data);
                    byte[] sendData = new byte[dateByte.Length + 3];
                    sendData[0] = Config.byteHead[Config.HeadCom];
                    sendData[1] = cmd;
                    sendData[2] = cmd;
                    for (int i = 3; i < dateByte.Length + 3; i++)//时间处理
                    {
                        sendData[i] = dateByte[i - 3];
                    }
                    strrtn = CommSend.SendData(sendData, Com, Rate);   //UDPSend.Senddata(sendData, Com, Rate);


                    if (strrtn.Length > 2)
                    {
                        if (strrtn.Substring(2, 4) != "3131")
                        {
                            return strrtn.Substring(6, 32);
                        }
                        else
                        {
                            return "";
                        }
                    }
                    else
                    {
                        return strrtn;
                    }
                }
            }
            catch
            {
                return "3";
            }

        }

        /// <summary>
        /// 读取ID卡
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadIDCard(int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x40;
                sendData[byteJihao.Length + 2] = 0x40;

                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length >= 6)
                {
                    if (strrtn.Substring(2, 4) == "3131")
                    {
                        return "4";
                    }
                    else if (strrtn != "2")
                    {
                        string sum = "";
                        string str1 = strrtn.Substring(6, 16);
                        //string str2 = strrtn.Substring(strrtn.Length - 10, 8);
                        if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str1))
                        {
                            sum = str1.Substring(str1.Length - 10, 10);
                            return sum;
                        }
                        else
                        {
                            return "9";
                        }
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 发卡器读取ID卡
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadIDCardCom(int Com, int Rate)
        {
            try
            {
                byte[] sendData = new byte[5];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = 0x00;
                sendData[2] = 0x00;
                sendData[3] = 0x40;
                sendData[4] = 0x40;

                string strrtn = CommSend.SendData(sendData, Com, Rate); //UDPSend.Senddata(sendData, Com, Rate);
                if (strrtn.Length >= 6)
                {
                    if (strrtn.Substring(2, 4) == "3131")
                    {
                        return "4";
                    }
                    else if (strrtn != "2")
                    {
                        string sum = "";
                        string str1 = strrtn.Substring(6, 16);
                        //string str2 = strrtn.Substring(strrtn.Length - 10, 8);
                        if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str1))
                        {
                            sum = str1.Substring(str1.Length - 8, 8);
                            return sum;
                        }
                        else
                        {
                            return "9";
                        }
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="Ziling"></param>
        /// <param name="iZ"></param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string SendCommandCom(int Com, int Rate)
        {
            try
            {

                byte[] sendData = new byte[9];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = 0x00;
                sendData[2] = 0x00;
                sendData[3] = 0x34;
                sendData[4] = 0x34;
                sendData[5] = 0x80;
                sendData[6] = 0x80;
                sendData[7] = 0x01;
                sendData[8] = 0x01;
                string strrtn = CommSend.SendData(sendData, Com, Rate); //UDPSend.Senddata(sendData, Com, Rate);
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 读取收费标准
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="CardType">卡类</param>
        /// <returns>正常时间字符串，2：超时，3：方法出错,4，发送错误，9：验证出错</returns>
        public string ReadCharge(int JiHao, string CardType, int Flag)
        {
            try
            {
                //byte[] byteJihao = GetByteArray(JiHao);
                //byte[] byteCardType = GetByteArray(CardType);

                //byte[] sendData = new byte[byteJihao.Length + byteCardType.Length + 3];
                //sendData[0] = Config.byteHead[Config.HeadIndex];
                //for (int i = 1; i <= byteJihao.Length; i++)
                //{
                //    sendData[i] = byteJihao[i - 1];
                //}
                //sendData[byteJihao.Length + 1] = 0x37;
                //sendData[byteJihao.Length + 2] = 0x37;
                //for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteCardType.Length; i++)//时间处理
                //{
                //    sendData[i] = byteCardType[i - (byteJihao.Length + 3)];
                //}
                byte[] sendData = AllCommand.ReadCharge(JiHao, CardType);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 72);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length >= 6)
                {
                    if (strrtn.Substring(2, 4) == "3131")
                    {
                        return "4";
                    }
                    else if (strrtn != "2")
                    {
                        string str = strrtn.Substring(6, strrtn.Length - 8);
                        string str2 = strrtn.Substring(6, strrtn.Length - 6);
                        if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str))
                        {
                            return str;
                        }
                        else
                        {
                            return "9";
                        }
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 加载收费标准
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="CardType">卡类</param>
        /// <param name="strData">指令</param>
        /// <returns></returns>
        public string LoadCharge(int JiHao, string CardType, string strData, int Flag)
        {
            try
            {
                //byte[] byteJihao = GetByteArray(JiHao);
                //byte[] byteSectorMode = GetByteArray(CardType);
                //byte[] dateByte = GetArray(strData);
                //byte dateJY = YHXY(strData);

                //byte[] sendData = new byte[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 4];
                //sendData[0] = Config.byteHead[Config.HeadIndex];
                //for (int i = 1; i <= byteJihao.Length; i++)
                //{
                //    sendData[i] = byteJihao[i - 1];
                //}
                //sendData[byteJihao.Length + 1] = 0x36;
                //sendData[byteJihao.Length + 2] = 0x36;
                //for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteSectorMode.Length; i++)//时间处理
                //{
                //    sendData[i] = byteSectorMode[i - (byteJihao.Length + 3)];
                //}
                //for (int i = byteJihao.Length + 3 + byteSectorMode.Length; i < byteJihao.Length + dateByte.Length + 3 + byteSectorMode.Length; i++)//时间处理
                //{
                //    sendData[i] = dateByte[i - (byteJihao.Length + 3 + byteSectorMode.Length)];
                //}
                //sendData[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 3] = dateJY;//验证处理
                byte[] sendData = AllCommand.LoadCharge(JiHao, CardType, strData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 6);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 5)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 读取记录数
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadRecordCount(string IP, int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x35;
                sendData[byteJihao.Length + 3 - 1] = 0x35;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}

                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 14);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length >= 6)
                {
                    if (strrtn.Substring(2, 4) == "3131")
                    {
                        return "4";
                    }
                    else
                    {
                        string Count = (Convert.ToInt32(strrtn.Substring(10, 2), 16) + Convert.ToInt32(strrtn.Substring(6, 2), 16) * 256).ToString();
                        return Count;
                    }
                }
                else
                {
                    return "-2";
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 读取记录
        /// </summary>
        /// <param name="IP">IP</param>
        /// <param name="JiHao">机号</param>
        /// <returns>正常记录字符串，2：超时，3：方法出错,4，发送错误，5：数据错误 9：验证出错</returns>
        public string ReadRecord(string IP, int JiHao, int Flag)
        {
            string sRecordData = "";   //记录信息
            string sDZState = "";   //道闸状态
            string sCPH = "";       //车牌后6位

            string sRecv = "";   //接收到的原始数据
            string sRecv2 = "";

            string sXOR = "";
            byte byteXOR = 0;

            string sRet = "";    //返回的数据

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x3C;
                sendData[byteJihao.Length + 3 - 1] = 0x3C;

                //long beginTime = DateTime.Now.Ticks;

                if (Flag == 1)
                {
                    sRecv = UDPSend.ReadSend(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    sRecv = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 41); //UDPSend.PKSenddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //                     if (Flag == 2)
                    //                     {
                    //                         usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //                     }
                    //                     else
                    //                     {
                    //                         usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //                     }
                    //                     usbHid.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    sRecv = ReadStr.Substring(2, 82);
                                    if (sRecv.Substring(0, 6) == "000000")
                                    {
                                        sRecv = "2";
                                    }
                                }
                            }
                            else
                            {
                                sRecv = "2";
                            }
                        }

                    }
                    else
                    {
                        sRecv = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (sRecv.Length == 16 || sRecv.Length == 82)  //状态 或 记录
                {
                    if (sRecv.Length == 16)
                    {
                        if (sRecv.Substring(2, 4) == "3131")
                        {
                            //异或检查
                            sXOR = CR.RightS(sRecv, 2);
                            sDZState = sRecv.Substring(sRecv.Length - 10, 8);
                            byteXOR = YHXY(sDZState);

                            if (Convert.ToByte(sXOR, 16) != byteXOR)  //异或错误
                                return "9";

                            return sDZState;
                        }
                        else
                        {
                            Console.WriteLine("5:" + sRecv);
                            return "5";
                        }
                    }
                    else  //strrtn.Length == 82
                    {
                        //3036090856170000000042313233343542A85838                        
                        //B53030 C00000000000001B323609090200360909020000000000004231323334350000 9A DFFF027F 5D   //9A是前面从C0开始的32字节数据的异或    5D是8字节道闸状态的异或

                        //string sum = "";
                        //string str = strrtn.Substring(strrtn.Length - 28, 12);
                        //string strJY = strrtn.Substring(6, strrtn.Length - 20);
                        //string strJY1 = strrtn.Substring(strrtn.Length - 10, 8);

                        //数据异或检查
                        sXOR = CR.MidS(sRecv, 70, 2);
                        sRecordData = CR.MidS(sRecv, 6, 64);   //strJY                        
                        byteXOR = YHXY(sRecordData);

                        if (Convert.ToByte(sXOR, 16) != byteXOR)  //异或错误
                            return "9";

                        //道闸异或检查
                        sXOR = CR.RightS(sRecv, 2);
                        sDZState = sRecv.Substring(sRecv.Length - 10, 8);
                        byteXOR = YHXY(sDZState);

                        if (Convert.ToByte(sXOR, 16) != byteXOR)  //异或错误
                            return "9";

                        sCPH = sRecv.Substring(sRecv.Length - 28, 12);

                        //读成功后返回一个字节的机号，下位机无返回                                                
                        if (Flag == 1 || Flag == 3)
                        {
                            byte[] byteData = new byte[7];
                            byteData[0] = Config.byteHead[Config.HeadIndex];
                            byteData[1] = byteJihao[0];
                            byteData[2] = byteJihao[0];
                            byteData[3] = 0x74;
                            byteData[4] = 0x74;
                            byteData[5] = 0x55;
                            byteData[6] = 0x55;
                            if (Flag == 1)
                            {
                                sRecv2 = UDPSend.Send(byteData, IP, LPort, SPort);
                            }
                            else
                            {
                                //                                 if (Flag == 2)
                                //                                 {
                                //                                     usbHid = new Hid(Model.USBSProductID);//设备的ID
                                //                                 }
                                //                                 else
                                //                                 {
                                //                                     usbHid = new Hid(Model.USBLProductID);//设备的ID
                                //                                 }
                                //                                 usbHid.CheckDevicePresent();

                                byte[] sendByte = byteData;

                                string Returnstr = "";

                                //  usbHid.CheckDevicePresent();
                                if (UsbObj.deviceOpened)
                                {
                                    byte[] transferData = new byte[UsbObj.OutputReportLength - 1];
                                    for (int y = 0; y < sendByte.Length; y++)
                                    {
                                        transferData[y] = sendByte[y];
                                    }

                                    report myRP = new report(1, transferData);

                                    string ReadStr = "";
                                    ReadStr = UsbObj.Write(myRP);

                                    if (ReadStr != "")
                                    {
                                        if (ReadStr != "设备关闭")
                                        {
                                            if (ReadStr.Substring(4, 2) != "31")
                                            {
                                                sRecv2 = ReadStr.Substring(2, 6);
                                                if (sRecv2.Substring(0, 6) == "000000")
                                                {
                                                    sRecv2 = "2";
                                                }
                                            }
                                        }
                                    }

                                }
                                else
                                {
                                    sRecv = "2";
                                    // MessageBox.Show("连接失败", "提示");
                                }
                                // UsbObj.CloseDevice();//关闭USB 连接。。
                            }
                            //string Count = ReadRecordCount("192.168.1.199", 1, 0);
                            // string Count = ReadRecordCount("192.168.1.199", 1, 1);
                        }
                        else if (Flag == 0)
                        {
                            // string Countss = ReadRecordCount("192.168.1.198", 2,0);s
                            byte[] byteDataCom = new byte[1];
                            byteDataCom[0] = byteJihao[0];

                            sRecv2 = CommSend.SendData(byteDataCom, Model.iParkCom, Model.BaudRate, 1, true); //UDPSend.Senddata(byteDataCom, Model.iParkCom, Model.BaudRate);

                            //long endTime = DateTime.Now.Ticks;
                            //long lValue = (endTime - beginTime) / 10000;
                            //Console.WriteLine("所用时间：" + lValue.ToString());

                        }

                        //最终返回：C00000000000001B32360909025136091026000000000000 B12345 0000 DFFF837F
                        sRecordData = CR.LeftS(sRecordData, 48);
                        sCPH = GetAscii(sCPH);

                        sRet = sRecordData + sCPH + sRecv.Substring(sRecv.Length - 16, 4) + sDZState;
                        return sRet; // +" " + sRecv;
                    }
                }
                else
                {
                    return sRecv;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 读取记录
        /// </summary>
        /// <param name="IP">IP</param>
        /// <param name="JiHao">机号</param>
        /// <returns>正常记录字符串，2：超时，3：方法出错,4，发送错误，5：数据错误 9：验证出错</returns>
        public string ReadRecordOffLine(string IP, int JiHao, int Flag)
        {
            string sRecordData = "";   //记录信息
            string sDZState = "";   //道闸状态
            string sCPH = "";       //车牌后6位

            string sRecv = "";   //接收到的原始数据
            string sRecv2 = "";

            string sXOR = "";
            byte byteXOR = 0;

            string sRet = "";    //返回的数据

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x52;
                sendData[byteJihao.Length + 3 - 1] = 0x52;

                //long beginTime = DateTime.Now.Ticks;

                if (Flag == 1)
                {
                    sRecv = UDPSend.ReadSend(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    sRecv = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 41); //UDPSend.PKSenddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //                     if (Flag == 2)
                    //                     {
                    //                         usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //                     }
                    //                     else
                    //                     {
                    //                         usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //                     }
                    //                     usbHid.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  usbHid.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    sRecv = ReadStr.Substring(2, 82);
                                    if (sRecv.Substring(0, 6) == "000000")
                                    {
                                        sRecv = "2";
                                    }
                                }
                            }
                            else
                            {
                                sRecv = "2";
                            }
                        }

                    }
                    else
                    {
                        sRecv = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 链接。。
                }
                if (sRecv.Length == 16 || sRecv.Length == 82)  //状态 或 记录
                {
                    if (sRecv.Length == 16)
                    {
                        if (sRecv.Substring(2, 4) == "3131")
                        {
                            //异或检查
                            sXOR = CR.RightS(sRecv, 2);
                            sDZState = sRecv.Substring(sRecv.Length - 10, 8);
                            byteXOR = YHXY(sDZState);

                            if (Convert.ToByte(sXOR, 16) != byteXOR)  //异或错误
                                return "9";

                            return sDZState;
                        }
                        else
                        {
                            Console.WriteLine("5:" + sRecv);
                            return "5";
                        }
                    }
                    else  //strrtn.Length == 82
                    {
                        //3036090856170000000042313233343542A85838                        
                        //B53030 C00000000000001B323609090200360909020000000000004231323334350000 9A DFFF027F 5D   //9A是前面从C0开始的32字节数据的异或    5D是8字节道闸状态的异或

                        //string sum = "";
                        //string str = strrtn.Substring(strrtn.Length - 28, 12);
                        //string strJY = strrtn.Substring(6, strrtn.Length - 20);
                        //string strJY1 = strrtn.Substring(strrtn.Length - 10, 8);

                        //数据异或检查
                        sXOR = CR.MidS(sRecv, 70, 2);
                        sRecordData = CR.MidS(sRecv, 6, 64);   //strJY                        
                        byteXOR = YHXY(sRecordData);

                        if (Convert.ToByte(sXOR, 16) != byteXOR)  //异或错误
                            return "9";

                        //道闸异或检查
                        sXOR = CR.RightS(sRecv, 2);
                        sDZState = sRecv.Substring(sRecv.Length - 10, 8);
                        byteXOR = YHXY(sDZState);

                        if (Convert.ToByte(sXOR, 16) != byteXOR)  //异或错误
                            return "9";

                        sCPH = sRecv.Substring(sRecv.Length - 28, 12);

                        //读成功后返回一个字节的机号，下位机无返回                                                
                        if (Flag == 1 || Flag == 3)
                        {
                            byte[] byteData = new byte[7];
                            byteData[0] = Config.byteHead[Config.HeadIndex];
                            byteData[1] = byteJihao[0];
                            byteData[2] = byteJihao[0];
                            byteData[3] = 0x74;
                            byteData[4] = 0x74;
                            byteData[5] = 0x55;
                            byteData[6] = 0x55;
                            if (Flag == 1)
                            {
                                sRecv2 = UDPSend.Send(byteData, IP, LPort, SPort);
                            }
                            else
                            {
                                //                                 if (Flag == 2)
                                //                                 {
                                //                                     usbHid = new Hid(Model.USBSProductID);//设备的ID
                                //                                 }
                                //                                 else
                                //                                 {
                                //                                     usbHid = new Hid(Model.USBLProductID);//设备的ID
                                //                                 }
                                //                                 usbHid.CheckDevicePresent();

                                byte[] sendByte = byteData;

                                string Returnstr = "";

                                //  usbHid.CheckDevicePresent();
                                if (UsbObj.deviceOpened)
                                {
                                    byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                                    for (int y = 0; y < sendByte.Length; y++)
                                    {
                                        transferData[y] = sendByte[y];
                                    }

                                    report myRP = new report(1, transferData);

                                    string ReadStr = "";
                                    ReadStr = UsbObj.Write(myRP);

                                    if (ReadStr != "")
                                    {
                                        if (ReadStr != "设备关闭")
                                        {
                                            if (ReadStr.Substring(4, 2) != "31")
                                            {
                                                sRecv2 = ReadStr.Substring(2, 6);
                                                if (sRecv2.Substring(0, 6) == "000000")
                                                {
                                                    sRecv2 = "2";
                                                }
                                            }
                                        }
                                    }

                                }
                                else
                                {
                                    sRecv = "2";
                                    // MessageBox.Show("连接失败", "提示");
                                }
                                // usbHid.CloseDevice();//关闭USB 链接。。
                            }
                            //string Count = ReadRecordCount("192.168.1.199", 1, 0);
                            // string Count = ReadRecordCount("192.168.1.199", 1, 1);
                        }
                        else if (Flag == 0)
                        {
                            // string Countss = ReadRecordCount("192.168.1.198", 2,0);s
                            byte[] byteDataCom = new byte[1];
                            byteDataCom[0] = byteJihao[0];

                            sRecv2 = CommSend.SendData(byteDataCom, Model.iParkCom, Model.BaudRate, 1, true); //UDPSend.Senddata(byteDataCom, Model.iParkCom, Model.BaudRate);

                            //long endTime = DateTime.Now.Ticks;
                            //long lValue = (endTime - beginTime) / 10000;
                            //Console.WriteLine("所用时间：" + lValue.ToString());

                        }

                        //最终返回：C00000000000001B32360909025136091026000000000000 B12345 0000 DFFF837F
                        sRecordData = CR.LeftS(sRecordData, 48);
                        sCPH = GetAscii(sCPH);

                        sRet = sRecordData + sCPH + sRecv.Substring(sRecv.Length - 16, 4) + sDZState;
                        return sRet; // +" " + sRecv;
                    }
                }
                else
                {
                    return sRecv;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 读取记录，成功后不返回“01”，用于状态查询)
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <returns>正常记录字符串，2：超时，3：方法出错,4，发送错误，9：验证出错</returns>
        public string GetReadRecord(string IP, int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x3C;
                sendData[byteJihao.Length + 3 - 1] = 0x3C;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.ReadSend(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate);    //UDPSend.PKSenddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length >= 6)
                {
                    if (strrtn.Substring(2, 4) == "3131")
                    {
                        return strrtn.Substring(strrtn.Length - 10, 8);
                    }
                    else
                    {
                        string sum = "";
                        string str = strrtn.Substring(strrtn.Length - 28, 12);
                        string strJY = strrtn.Substring(6, strrtn.Length - 20);
                        string strJY1 = strrtn.Substring(strrtn.Length - 10, 8);
                        //string sss = strrtn.Substring(strrtn.Length - 12, 2);



                        if (strrtn == "B53131")
                        {
                            return "4";
                        }
                        else
                        {
                            //if (Convert.ToByte(strrtn.Substring(strrtn.Length - 12, 2), 16) == YHXY(strJY) && Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(strJY1))
                            //{

                            sum = strrtn.Substring(6, strrtn.Length - 34) + GetAscii(str) + strrtn.Substring(strrtn.Length - 16, 4) + strJY1;
                            return sum;
                            //}
                            //else
                            //{
                            //    return "9";
                            //}
                        }

                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="Ziling"></param>
        /// <param name="iZ"></param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string SearchUpdateIP(int JiHao, int Flag)
        {
            try
            {
                byte[] data = new byte[4];
                data[0] = 0xAA;//;
                data[1] = 0xBB;//;
                data[2] = 0xCC;//;
                data[3] = 0x88;//;


                string strrtn = "";
                if (Flag == 1)
                {
                    //GCR.Hid.WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "修改IP 发送IP：" + LIP + "端口号：" + LPort + SPort);
                    strrtn = UDPSend.Sends(data, LIP, LPort, SPort);

                    //GCR.Hid.WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 发送IP：" + LIP + "返回：" + strrtn);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(data, Model.iParkCom, Model.BaudRate, 100, true); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 8)
                {
                    if (strrtn.Substring(0, 8) == "AABBCC88")
                    {
                        return "0";
                    }
                    else
                    {
                        Console.Write(strrtn);
                        return "1";
                        //return strrtn + "指令" + CommSend.ByteToHexString(sendData);
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="Ziling"></param>
        /// <param name="iZ"></param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string SendCommand(int JiHao, int Ziling, int iZ, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] byteZhiling = GetByteArray(Ziling);
                byte[] byteiZ = GetByteArray(iZ.ToString());
                byte[] sendData = new byte[byteJihao.Length + byteZhiling.Length + byteiZ.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x34;
                sendData[byteJihao.Length + 2] = 0x34;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteZhiling.Length; i++)//时间处理
                {
                    sendData[i] = byteZhiling[i - (byteJihao.Length + 3)];
                }
                for (int i = byteJihao.Length + 3 + byteZhiling.Length; i < byteJihao.Length + byteZhiling.Length + 3 + byteiZ.Length; i++)//时间处理
                {
                    sendData[i] = byteiZ[i - (byteJihao.Length + 3 + byteZhiling.Length)];
                }
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, true); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 6);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                                else
                                {
                                    strrtn = "1";
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        Console.Write(strrtn);
                        return "1";
                        //return strrtn + "指令" + CommSend.ByteToHexString(sendData);
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 显示屏控制命令,报语音“请交费XXXX元”
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <param name="Flag">协议</param>
        /// <returns></returns>
        public string ShowLed55(int JiHao, string strData, int Flag)
        {

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                //byte[] dateByte = GetAsciiShow(strData);
                byte[] sendData = new byte[byteJihao.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x3D;
                sendData[byteJihao.Length + 2] = 0x3D;
                sendData[byteJihao.Length + 3] = 1;
                sendData[byteJihao.Length + 4] = 1;
                sendData[byteJihao.Length + 5] = 0x55;

                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 下载卡号
        /// </summary>
        /// <param name="IP"></param>
        /// <param name="JiHao"></param> 
        /// <param name="strData"></param>
        /// <param name="Flag">0，串口 1，TCP 3 USB临时卡计费器</param>
        /// <returns></returns>
        public string DownloadCard(string IP, int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x4D;
                sendData[byteJihao.Length + 2] = 0x4D;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + dateByte.Length + 3] = dateJY;//验证处理
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 6);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 删除下载卡号
        /// </summary>
        /// <param name="IP"></param>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <param name="Flag">0，串口 1，TCP 3 USB临时卡计费器</param>
        /// <returns></returns>
        public string DownLossloadCard(string IP, int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x3A;
                sendData[byteJihao.Length + 2] = 0x3A;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + dateByte.Length + 3] = dateJY;//验证处理
                string strrtn = "";

                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); // UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {
                                if (ReadStr.Substring(4, 2) != "31")
                                {
                                    strrtn = ReadStr.Substring(2, 6);
                                    if (strrtn.Substring(0, 6) == "000000")
                                    {
                                        strrtn = "2";
                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 校验下载的卡号
        /// </summary>
        /// <param name="IP"></param>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public string CheckDldCard(string IP, int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x3B;
                sendData[byteJihao.Length + 2] = 0x3B;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + dateByte.Length + 3] = dateJY;//验证处理
                string strrtn = "";

                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 40);
                                if (strrtn.Substring(0, 6) == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Length == 40)
                    {
                        if (strrtn.Substring(6, 32) == strData.ToUpper())
                        {
                            return "0";
                        }
                        else
                        {
                            return strData.Substring(2, 14);
                        }
                    }
                    else
                    {
                        return strData.Substring(2, 14);
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return strData.Substring(2, 14);
            }
        }
        /// <summary>
        /// 加载显示内容
        /// </summary>
        /// <param name="IP">IP地址</param>
        /// <param name="JiHao">机号</param>
        /// <param name="length">长度</param>
        /// <param name="data">byte[]</param>
        /// <param name="strData">起始到结束年月日</param>
        /// <returns></returns>
        public string LoadShow(string IP, int JiHao, byte length, byte[] data, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);

                //byte[] data = GetArray(UDPSend.ByteToHexString(data1));
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + data.Length + dateByte.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x41;
                sendData[byteJihao.Length + 2] = 0x41;
                sendData[byteJihao.Length + 3] = length;
                for (int i = byteJihao.Length + 4; i < byteJihao.Length + 4 + data.Length; i++)//时间处理
                {
                    sendData[i] = data[i - (byteJihao.Length + 4)];
                }

                sendData[byteJihao.Length + data.Length + 4] = YHXY(UDPSend.ByteToHexString(data));

                for (int i = data.Length + byteJihao.Length + 5; i < byteJihao.Length + 5 + data.Length + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + data.Length + 5)];
                }
                sendData[byteJihao.Length + 5 + data.Length + dateByte.Length] = dateJY;
                string strrtn = "";

                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }

                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 清空控制机
        /// </summary>
        /// <param name="IP"></param>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public string InitControl(string IP, int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);

                byte[] sendData = new byte[byteJihao.Length + 5];
                byte[] sendDataC = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendDataC[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                    sendDataC[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x20;
                sendData[byteJihao.Length + 2] = 0x20;
                sendData[byteJihao.Length + 3] = 0x55;
                sendData[byteJihao.Length + 4] = 0x55;
                sendDataC[byteJihao.Length + 1] = 0x20;
                sendDataC[byteJihao.Length + 2] = 0x20;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, IP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        strrtn = CommSend.SendData(sendDataC, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendDataC, Model.iParkCom, Model.BaudRate);
                    }
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //if (Flag == 2)
                    //{
                    //    usbHid = new Hid(Model.USBSProductID);//设备的ID
                    //}
                    //else
                    //{
                    //    usbHid = new Hid(Model.USBLProductID);//设备的ID
                    //}
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 6);
                                if (strrtn.Substring(0, 6) == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {

                    if (strrtn.Substring(2, 4) == "3030")
                    {

                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 预置卡类及车牌号
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public string PrecutcardType(int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x38;
                sendData[byteJihao.Length + 2] = 0x38;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + dateByte.Length + 3] = dateJY;//验证处理
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 显示屏控制命令,报语音“请交费XXXX元”
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <param name="Flag">协议</param>
        /// <returns></returns>
        public string ShowLed(int JiHao, string strData, int Flag)
        {

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetAsciiShow(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x3D;
                sendData[byteJihao.Length + 2] = 0x3D;
                sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
                sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
                sendData[byteJihao.Length + 5] = 0x4A;
                for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 6)];
                }
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 显示屏控制命令,报语音，可用日期XX日，储值卡收费和余额
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">数据</param>
        /// <param name="zhiling">子命令</param>
        /// <param name="Flag">协议</param>
        /// <returns></returns>
        public string ShowLed(int JiHao, string strData, byte zhiling, int Flag)
        {

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetAsciiShow(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x3D;
                sendData[byteJihao.Length + 2] = 0x3D;
                sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
                sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
                sendData[byteJihao.Length + 5] = zhiling;
                for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 6)];
                }
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 语音 
        /// 42：欢迎光临 
        /// 46：此卡过期  
        /// 48：此卡无效  
        /// 4C：此卡已入场 
        /// 4F：此卡禁止入场 
        /// 57：此卡已出场
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">指令</param>
        /// <returns></returns>
        public string VoiceLoad(int JiHao, string strData, int Flag)
        {

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 5];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x3D;
                sendData[byteJihao.Length + 2] = 0x3D;
                sendData[byteJihao.Length + 3] = 0x01;
                sendData[byteJihao.Length + 4] = 0x01;
                for (int i = byteJihao.Length + 5; i < byteJihao.Length + 5 + dateByte.Length; i++)
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 5)];
                }
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 加载时间段音量设置协议
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">时间段和音量</param>
        /// <returns></returns>
        public string LoadSound(int JiHao, string strData, int Flag)
        {

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x88;
                sendData[byteJihao.Length + 2] = 0x88;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + 3 + +dateByte.Length] = dateJY;
                string strrtn = "";

                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 公用发送。不带校验位，带长度
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="byteCmd">命令</param>
        /// <param name="Data">数组</param>
        /// <param name="length">数组长度</param>
        /// <returns></returns>
        public string SendCmdLS(byte JiHao, byte byteCmd, byte[] Data, int length, int Flag)
        {
            try
            {
                byte[] sendData = new byte[Data.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = Convert.ToByte(length + 1);
                sendData[4] = Convert.ToByte(length + 1);
                sendData[5] = byteCmd;
                for (int i = 6; i < Data.Length + 6; i++)//时间处理
                {
                    sendData[i] = Data[i - 6];
                }
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 公用发送。带校验位
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="byteCmd">命令</param>
        /// <param name="Data">数组</param>
        /// <returns></returns>
        public string DisplayCmdX2(byte JiHao, byte byteCmd, byte[] Data, int Flag)
        {

            try
            {
                byte[] sendData = new byte[Data.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = byteCmd;
                sendData[4] = byteCmd;

                for (int i = 5; i < Data.Length + 5; i++)//时间处理
                {
                    sendData[i] = Data[i - 5];
                }
                sendData[Data.Length + 5] = YHXY(UDPSend.ByteToHexString(Data));
                string strrtn = "";

                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //usbHid = new Hid(Model.USBLProductID);//设备的ID
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 6);
                                if (strrtn == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 公用发送。不带校验位
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="byteCmd">命令</param>
        /// <param name="Data">数组</param>
        /// <returns></returns>
        public string DisplayCmdX1(byte JiHao, byte byteCmd, byte[] Data, int Flag)
        {

            try
            {
                byte[] sendData = new byte[Data.Length + 5];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = byteCmd;
                sendData[4] = byteCmd;

                for (int i = 5; i < Data.Length + 5; i++)//时间处理
                {
                    sendData[i] = Data[i - 5];
                }
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //UsbObj = new Hid(Model.USBLProductID);//设备的ID
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 6);
                                if (strrtn == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 设置月卡有效期预警日期
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">剩余天数</param>
        /// <returns></returns>
        public string MouthEarlr(int JiHao, int strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetByteArray(strData);

                byte[] sendData = new byte[7];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = byteJihao[0];
                sendData[2] = byteJihao[1];
                sendData[3] = 0x84;
                sendData[4] = 0x84;
                sendData[5] = dateByte[0];
                sendData[6] = dateByte[1];
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 增加月卡禁止时间及时段数据
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public string ProhibitMouth(int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x79;
                sendData[byteJihao.Length + 2] = 0x79;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + 3 + +dateByte.Length] = dateJY;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //usbHid = new Hid(Model.USBLProductID);//设备的ID
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 6);
                                if (strrtn.Substring(0, 6) == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }

        /// <summary>
        /// 读取月卡禁止时间及时段数据
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadProhibitMouth(int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x7A;
                sendData[byteJihao.Length + 3 - 1] = 0x7A;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn != "2")
                {
                    string str = strrtn.Substring(6, strrtn.Length - 8);
                    if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str))
                    {
                        return str;
                    }
                    else
                    {
                        return "9";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 读取月卡禁止时间及时段数据
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadVoice(int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x89;
                sendData[byteJihao.Length + 3 - 1] = 0x89;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn != "2")
                {
                    string str = strrtn.Substring(6, strrtn.Length - 8);
                    if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str))
                    {
                        return str;
                    }
                    else
                    {
                        return "9";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 系统状态设置 
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public string LoadSystem(int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x43;
                sendData[byteJihao.Length + 2] = 0x43;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + 3 + +dateByte.Length] = dateJY;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 系统状态读取
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadSystem(int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x44;
                sendData[byteJihao.Length + 3 - 1] = 0x44;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //usbHid = new Hid(Model.USBLProductID);//设备的ID
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 16);
                                if (strrtn.Substring(0, 6) == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn != "2")
                {
                    string str = strrtn.Substring(6, 8);
                    if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str))
                    {
                        return str;
                    }
                    else
                    {
                        return "9";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 高峰开闸模式
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">0A0A设置车辆高峰模式，5555取消车辆高峰模式</param>
        /// <returns></returns>
        public string HeightCutoff(int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x8B;
                sendData[byteJihao.Length + 2] = 0x8B;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 修改TCPIP参数
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public string UpDateIP(int JiHao, string strData)
        {

            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x77;
                sendData[byteJihao.Length + 2] = 0x77;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + dateByte.Length + 3] = YHXY(strData);
                string strrtn = "";

                strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 语音发送
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string LoadLsNoX2010znykt(byte JiHao, byte Order, byte SonOrder, string StrData, int Flag)
        {
            int i;
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 8];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = Order;
                sendData[4] = Order;
                //                 if (Flag == 1 || Flag == 2|| Flag == 3)
                //                 {
                //                     sendData[5] = Convert.ToByte(sendData.Length + 1);
                //                     sendData[6] = Convert.ToByte(sendData.Length + 1);
                // 
                //                 }
                //                 else if (Flag == 0)
                //                 {
                sendData[5] = Convert.ToByte(dateByte.Length + 1);
                sendData[6] = Convert.ToByte(dateByte.Length + 1);
                // }
                sendData[7] = SonOrder;
                for (i = 8; i < dateByte.Length + 8; i++)//时间处理
                {
                    sendData[i] = dateByte[i - 8];
                }
                string strrtn = "";

                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                else if (Flag == 2 || Flag == 3)
                {

                    //usbHid = new Hid(Model.USBLProductID);//设备的ID
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }
                        // string strG = UDPSend.ByteToHexString(transferData);
                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 6);
                                if (strrtn == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 语音发送
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string LoadLsNoX2010znyktXor(byte JiHao, byte Order, byte SonOrder, string StrData, int Flag)
        {
            int i;
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 9];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = Order;
                sendData[4] = Order;
                if (Flag == 1 || Flag == 2 || Flag == 3)
                {
                    sendData[5] = Convert.ToByte(dateByte.Length + 1);
                    sendData[6] = Convert.ToByte(dateByte.Length + 1);
                }
                else if (Flag == 0)
                {
                    sendData[5] = Convert.ToByte(dateByte.Length + 1);
                    sendData[6] = Convert.ToByte(dateByte.Length + 1);
                }
                sendData[7] = SonOrder;
                for (i = 8; i < dateByte.Length + 8; i++)//时间处理
                {
                    sendData[i] = dateByte[i - 8];
                }
                sendData[dateByte.Length + 8] = YHXY(StrData);

                string strrtn = "";

                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //UsbObj = new Hid(Model.USBLProductID);//设备的ID
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 6);
                                if (strrtn == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 控制机显示屏
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string CtrlLedShow(byte JiHao, byte Order, byte SonOrder, string StrData, int Flag)
        {
            int i;
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 10];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = Order;
                sendData[4] = Order;
                sendData[5] = Convert.ToByte(dateByte.Length + 3);
                sendData[6] = Convert.ToByte(dateByte.Length + 3);
                sendData[7] = SonOrder;
                sendData[8] = Convert.ToByte(dateByte.Length);
                for (i = 9; i < dateByte.Length + 9; i++)//时间处理
                {
                    sendData[i] = dateByte[i - 9];
                }
                sendData[dateByte.Length + 9] = YHXY(StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 剩余车位屏控制命令 
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string SurplusCtrlLedShow(byte JiHao, string StrData, int Flag)
        {
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 7];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = 0x64;
                sendData[4] = 0x64;
                sendData[5] = Convert.ToByte(dateByte.Length);
                for (int i = 6; i < dateByte.Length + 6; i++)
                {
                    sendData[i] = dateByte[i - 6];
                }
                sendData[dateByte.Length + 6] = YHXY(dateByte.Length.ToString("X2") + StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, true); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                //strrtn=  UDPSend.Senddata(dateByte);//串口发送
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }
        /// <summary>
        /// 剩余车位屏控制命令 
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public void SurplusCtrlLedShowNORst(byte JiHao, string StrData, int Flag)
        {
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 7];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = 0x64;
                sendData[4] = 0x64;
                sendData[5] = Convert.ToByte(dateByte.Length);
                for (int i = 6; i < dateByte.Length + 6; i++)
                {
                    sendData[i] = dateByte[i - 6];
                }
                sendData[dateByte.Length + 6] = YHXY(dateByte.Length.ToString("X2") + StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.SendNoRst(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, true); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
            }
            catch
            {
                //return "3";
            }

        }
        /// <summary>
        /// 加载多功能自定义语音
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string SetVoice(byte JiHao, byte cmd, string StrData, int Flag)
        {
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = cmd;
                sendData[4] = cmd;
                for (int i = 5; i < dateByte.Length + 5; i++)
                {
                    sendData[i] = dateByte[i - 5];
                }
                sendData[dateByte.Length + 5] = YHXY(StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, false); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                //strrtn=  UDPSend.Senddata(dateByte);//串口发送
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }
        /// <summary>
        /// 加载多功能自定义语音
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string LoadReadByteNoX2010znykt_(byte JiHao, byte cmd, string StrData, int Flag)
        {
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = cmd;
                sendData[4] = cmd;
                for (int i = 5; i < dateByte.Length + 5; i++)
                {
                    sendData[i] = dateByte[i - 5];
                }
                sendData[dateByte.Length + 5] = YHXY(StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, false); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                //strrtn=  UDPSend.Senddata(dateByte);//串口发送
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(2, 4) == "3030")
                    {
                        return strrtn.Substring(strrtn.Length - 4, 4);
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }


        /// <summary>
        /// 打印机设置
        /// </summary>
        /// <param name="sendData"></param>
        /// <param name="Flag"></param>
        /// <returns></returns>
        public string BarCodePrint(byte[] sendData, int Flag)
        {
            try
            {
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                //string sss = UDPSend.ByteToHexString(sendData);
                //strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                //strrtn=  UDPSend.Senddata(dateByte);//串口发送
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }

        /// <summary>
        /// 读取多功能语音设置是否启用
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadDVoice(int JiHao, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 3];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 3 - 2] = 0x61;
                sendData[byteJihao.Length + 3 - 1] = 0x61;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn != "2")
                {
                    string str = strrtn.Substring(6, strrtn.Length - 8);
                    if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str))
                    {
                        return str;
                    }
                    else
                    {
                        return "9";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 加载多功能自定义语音
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string ReadSetVoice(byte JiHao, byte cmd, string StrData, int Flag)
        {
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = cmd;
                sendData[4] = cmd;
                for (int i = 5; i < dateByte.Length + 5; i++)
                {
                    sendData[i] = dateByte[i - 5];
                }
                sendData[dateByte.Length + 5] = YHXY(StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, false); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                //strrtn=  UDPSend.Senddata(dateByte);//串口发送
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(2, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }

        //         public string OffLineSet()
        //         {
        // 
        //         }

        /// <summary>
        /// 设置下位机脱机出口IP
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="strData"></param>
        /// <returns></returns>
        public string SetOffLineIP(int JiHao, string strData, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] dateByte = GetArray(strData);
                byte dateJY = YHXY(strData);
                byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 4];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 1] = 0x93;
                sendData[byteJihao.Length + 2] = 0x93;
                for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + dateByte.Length; i++)//时间处理
                {
                    sendData[i] = dateByte[i - (byteJihao.Length + 3)];
                }
                sendData[byteJihao.Length + dateByte.Length + 3] = dateJY;//验证处理
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 系统状态读取
        /// </summary>
        /// <param name="JiHao"></param>
        /// <returns></returns>
        public string ReadDinnerPrice(int JiHao, byte bType, int Flag)
        {
            try
            {
                byte[] byteJihao = GetByteArray(JiHao);
                byte[] sendData = new byte[byteJihao.Length + 5];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                for (int i = 1; i <= byteJihao.Length; i++)
                {
                    sendData[i] = byteJihao[i - 1];
                }
                sendData[byteJihao.Length + 5 - 4] = 0x37;
                sendData[byteJihao.Length + 5 - 3] = 0x37;
                sendData[byteJihao.Length + 5 - 2] = bType;
                sendData[byteJihao.Length + 5 - 1] = bType;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);
                }
                else if (Flag == 2 || Flag == 3)
                {
                    //usbHid = new Hid(Model.USBLProductID);//设备的ID
                    UsbObj.CheckDevicePresent();

                    byte[] sendByte = sendData;

                    string Returnstr = "";

                    //  UsbObj.CheckDevicePresent();
                    if (UsbObj.deviceOpened)
                    {
                        byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                        for (int y = 0; y < sendByte.Length; y++)
                        {
                            transferData[y] = sendByte[y];
                        }

                        report myRP = new report(1, transferData);

                        string ReadStr = "";
                        ReadStr = UsbObj.Write(myRP);

                        if (ReadStr != "")
                        {
                            if (ReadStr != "设备关闭")
                            {

                                //if (ReadStr.Substring(4, 2) != "31")
                                //{
                                strrtn = ReadStr.Substring(2, 16);
                                if (strrtn.Substring(0, 6) == "000000")
                                {
                                    strrtn = "2";
                                }
                                //}
                            }
                        }

                    }
                    else
                    {
                        strrtn = "2";
                        // MessageBox.Show("连接失败", "提示");
                    }
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn != "2")
                {
                    string str = strrtn.Substring(6, 64);
                    if (Convert.ToByte(strrtn.Substring(strrtn.Length - 2, 2), 16) == YHXY(str))
                    {
                        return str;
                    }
                    else
                    {
                        return "9";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }
        }


        /// <summary>
        /// 加载多功能自定义语音
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string LoadDinnerPrice(byte JiHao, byte bType, string StrData, int Flag)
        {
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 8];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = 0x36;
                sendData[4] = 0x36;
                sendData[5] = bType;
                sendData[6] = bType;
                for (int i = 7; i < dateByte.Length + 7; i++)
                {
                    sendData[i] = dateByte[i - 7];
                }
                sendData[dateByte.Length + 7] = YHXY(StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, LIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, false); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                //strrtn=  UDPSend.Senddata(dateByte);//串口发送
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(2, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string LoadOffLineSet(byte JiHao, int Flag, string strIP)
        {
            try
            {
                byte[] sendData = new byte[5];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = 0x7C;
                sendData[4] = 0x7C;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, strIP, LPort, SPort);
                }
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(2, 4) == "3030")
                    {
                        return strrtn.Substring(6, 26);
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }

            }
            catch
            {
                return "3";
            }
        }
        /// <summary>
        /// 加载车牌识别白牌车自动开闸
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string LoadDinnerPriceSet(byte JiHao, string StrData, int Flag, string strIP)
        {
            try
            {
                byte[] dateByte = GetArray(StrData);
                byte[] sendData = new byte[dateByte.Length + 6];
                sendData[0] = Config.byteHead[Config.HeadIndex];
                sendData[1] = JiHao;
                sendData[2] = JiHao;
                sendData[3] = 0x7B;
                sendData[4] = 0x7B;
                for (int i = 5; i < dateByte.Length + 5; i++)
                {
                    sendData[i] = dateByte[i - 5];
                }
                sendData[dateByte.Length + 5] = YHXY(StrData);
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, strIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate, 100, false); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                //strrtn=  UDPSend.Senddata(dateByte);//串口发送
                if (strrtn.Length > 1)
                {
                    if (strrtn.Substring(2, 4) == "3030")
                    {
                        return "0";
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }
            }
            catch
            {
                return "3";
            }

        }


        //2016-04-11 zsd
        /// <summary>
        /// 强制脱机指令
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public string ForceOffLine(string sIP, int JiHao, int Flag)
        {
            try
            {

                byte[] sendData = AllCommand.ForceOffLine(JiHao);

                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.ReadSend(sendData, sIP, LPort, SPort);
                }
                else if (Flag == 0)
                {
                    ////strrtn = CommSend.SendData(sendData, Model.iParkCom, Model.BaudRate); //UDPSend.Senddata(sendData, Model.iParkCom, Model.BaudRate);;
                }
                else if (Flag == 2 || Flag == 3)
                {
                    ////UsbObj.CheckDevicePresent();

                    ////byte[] sendByte = sendData;

                    ////string Returnstr = "";

                    //////  usbHid.CheckDevicePresent();
                    ////if (UsbObj.deviceOpened)
                    ////{
                    ////    byte[] transferData = new byte[this.UsbObj.OutputReportLength - 1];
                    ////    for (int y = 0; y < sendByte.Length; y++)
                    ////    {
                    ////        transferData[y] = sendByte[y];
                    ////    }

                    ////    report myRP = new report(1, transferData);

                    ////    string ReadStr = "";
                    ////    ReadStr = UsbObj.Write(myRP);

                    ////    if (ReadStr != "")
                    ////    {
                    ////        if (ReadStr != "设备关闭")
                    ////        {
                    ////            if (ReadStr.Substring(4, 2) != "31")
                    ////            {
                    ////                strrtn = ReadStr.Substring(2, 6);
                    ////                if (strrtn.Substring(0, 6) == "000000")
                    ////                {
                    ////                    strrtn = "2";
                    ////                }
                    ////            }
                    ////        }
                    ////    }

                    ////}
                    ////else
                    ////{
                    ////    strrtn = "2";
                    ////    // MessageBox.Show("连接失败", "提示");
                    ////}
                    //usbHid.CloseDevice();//关闭USB 连接。。
                }
                if (strrtn.Substring(strrtn.Length - 4, 4) == "3030")
                {
                    return "0";
                }
                else
                {
                    return "1";
                }
            }
            catch
            {
                return "3";
            }
            //return strrtn;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public string LoadVersionSet(byte JiHao, int Flag, string strIP)
        {
            try
            {
                byte[] sendData = new byte[5];
                sendData[0] = 0xAA;
                sendData[1] = 0xBB;
                sendData[2] = 0xCC;
                sendData[3] = 0x22;
                sendData[4] = 0x22;
                string strrtn = "";
                if (Flag == 1)
                {
                    strrtn = UDPSend.Send(sendData, strIP, LPort, SPort);
                }
                if (strrtn.Length > 8)
                {
                    if (strrtn.Substring(0, 8) == "AABBCC22")
                    {
                        return strrtn.Substring(8, 60);
                    }
                    else
                    {
                        return "1";
                    }
                }
                else
                {
                    return strrtn;
                }

            }
            catch
            {
                return "3";
            }
        }

        /// <summary>
        /// 机号和扇区号处理
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public byte[] GetByteArray(string number)
        {
            byte[] Nbtye = new byte[2];
            Nbtye[0] = Convert.ToByte(number.ToString(), 16);
            Nbtye[1] = Convert.ToByte(number.ToString(), 16);

            return Nbtye;
        }
        /// <summary>
        /// ASCII处理
        /// </summary>
        /// <param name="strAscii"></param>
        /// <returns></returns>
        public string GetAscii(string strAscii)
        {
            string sum = "";
            for (int i = 0; i < strAscii.Length / 2; i++)
            {
                string strJihao = strAscii.Substring(i * 2, 2);
                int ac = Convert.ToInt32(strJihao, 16);

                if (ac < 40)
                {
                    string diqu1 = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学";
                    sum += diqu1.Substring(ac, 1);
                }
                else
                {
                    char chr = Convert.ToChar(ac);
                    sum += chr.ToString();
                }


            }
            return sum;

        }

        /// <summary>
        /// ASCII处理
        /// </summary>
        /// <param name="strAscii"></param>
        /// <returns></returns>
        public byte[] GetAsciiShow(string strAscii)
        {

            byte[] byteDate = new byte[strAscii.Length];
            for (int i = 0; i < strAscii.Length; i++)
            {
                string sum = "";
                string strJihao = strAscii.Substring(i, 1);
                //int ac = Convert.ToInt32(strJihao, 16);
                // char chr = Convert.ToChar(ac);

                System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();

                byte[] aaa = asciiEncoding.GetBytes(strJihao);

                int intAsciiCode = (int)asciiEncoding.GetBytes(strJihao)[0];



                //return (intAsciiCode);

                //sum = chr.ToString();

                byteDate[i] = Convert.ToByte(Convert.ToString(intAsciiCode, 16), 16);
            }
            return byteDate;

        }
        /// <summary>
        /// 机号和扇区号处理
        /// </summary>
        /// <param name="number">int</param>
        /// <returns>返回byte[]类型</returns>
        public byte[] GetByteArray(int number)
        {
            byte[] Nbtye = new byte[2];
            Nbtye[0] = Convert.ToByte(number.ToString());
            Nbtye[1] = Convert.ToByte(number.ToString());

            return Nbtye;
        }


        /// <summary>
        ///字符串转换为数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public byte[] GetArray(string str)
        {
            string[] HexStr = Getstring(str);
            byte[] Hexbyte = new byte[HexStr.Length];
            for (int j = 0; j < HexStr.Length; j++)
            {
                Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            }

            return Hexbyte;
        }

        public string[] Getstring(string str)
        {
            List<String> al = new List<String>();
            for (int i = 0; i < str.Length / 2; i++)
            {
                string strJihao = str.Substring(i * 2, 2);
                al.Add(strJihao);
            }
            string s = string.Join(",", al.ToArray());
            string[] HexStr = s.Split(',');
            return HexStr;
        }

        /// <summary>
        ///字符串转换为数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public byte[] GetArray1(string str)
        {
            string[] HexStr = Getstring1(str);
            byte[] Hexbyte = new byte[HexStr.Length];
            for (int j = 0; j < HexStr.Length; j++)
            {
                Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            }

            return Hexbyte;
        }

        public string[] Getstring1(string str)
        {
            List<String> al = new List<String>();
            for (int i = 0; i < str.Length; i++)
            {
                string strJihao = str.Substring(i, 1);
                al.Add(strJihao);
            }
            string s = string.Join(",", al.ToArray());
            string[] HexStr = s.Split(',');
            return HexStr;
        }
        /// <summary>
        ///异或效验 
        /// </summary>
        /// <param name="strList"></param>
        /// <returns></returns>
        public byte YHXY(string str)
        {
            string[] strList = Getstring(str);
            byte[] Hexbyte = new byte[strList.Length];
            byte check = 0;
            check = (byte)(Convert.ToByte(strList[0], 16) ^ Convert.ToByte(strList[1], 16));
            for (int i = 2; i < strList.Length; i++)
            {
                check = (byte)(check ^ Convert.ToByte(strList[i], 16));
            }
            string CheckSumHex = Convert.ToString(check, 16);
            if (CheckSumHex.Length == 1)
            {
                CheckSumHex = "0" + CheckSumHex;
            }
            return Convert.ToByte(CheckSumHex.ToUpper(), 16);
        }

        public void SetUsbType(ref Hid myUsb, int iXieYi)
        {
            if (iXieYi == 1)
            {
                return;
            }
            UsbObj = myUsb;
            if (UsbObj.deviceOpened == false)
            {
                if (iXieYi == 2)//手持机
                {
                    UsbObj.PID = Model.USBSProductID;//设备的ID
                }
                else if (iXieYi == 3)//临时卡计费器
                {
                    UsbObj.PID = Model.USBLProductID;//设备的ID
                }
                UsbObj.CheckDevicePresent();
            }
        }






        /// <summary>
        /// 不同的设备
        /// </summary>
        /// <param name="Flag"></param>
        //public void OpenUsb(int Flag)
        //{
        //    if (usbHid.deviceOpened == false)
        //    {

        //        if (Flag == 2)//手持机
        //        {
        //            usbHid.PID = Model.USBSProductID;//设备的ID
        //        }
        //        else if (Flag == 3)//临时卡计费器
        //        {
        //            usbHid.PID = Model.USBLProductID;//设备的ID
        //        }
        //        usbHid.CheckDevicePresent();
        //    }
        //}
        //public void CloseUsb()
        //{
        //    usbHid.CloseDevice();
        //}
    }
}
