﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ParkingCommunication
{
    public class UdpCommander
    {
        public static int SendDataAndReceiveUntillTimeOut(IPEndPoint epSendTo, byte[] data, IPEndPoint epReceive = null, Action<byte[]> SolveData = null, int SendTimeOut = 1000, int ReceiveTimeOut = 5000)
        {
            byte[] BackData;
            int CountSend = 0;
            UdpClient udp;

            BackData = null;
            udp = new UdpClient();
            udp.Client.SendTimeout = SendTimeOut;
            udp.Client.ReceiveTimeout = ReceiveTimeOut;

            if (null == data)
            {
                return CountSend;
            }

            CountSend = udp.Send(data, data.Length, epSendTo);

            if (null != SolveData && null != epReceive)
            {
                while (true)
                {
                    try
                    {
                        BackData = udp.Receive(ref epReceive);

                        SolveData(BackData);
                    }
                    catch (SocketException ex)
                    {
                        if (ex.SocketErrorCode == SocketError.TimedOut)
                        {
                            System.Diagnostics.Trace.WriteLine("SendDataAndReceiveUntillTimeOut timeout on Receive : " + ex.Message);
                            break;
                        }
                        else
                        {
                            throw ex;
                        }
                    }
                }
            }

            udp.Close();

            return CountSend;
        }
        public static int SendDataTo(byte[] data, IPEndPoint epSendTo, out byte[] BackData, IPEndPoint epReceive = null, int SendTimeOut = 1000, int ReceiveTimeOut = 3000)
        {
            #region MyRegion
            //int CountSend = 0;
            //byte[] buffer = null;
            //UdpClient udp;

            //BackData = null;
            //udp = new UdpClient();

            //udp.Client.SendTimeout = SendTimeOut;
            //udp.Client.ReceiveTimeout = ReceiveTimeOut;

            //if (null == data)
            //{
            //    return CountSend;
            //}

            //if (null != epReceive && udp.Available > 0)
            //{
            //    buffer = udp.Receive(ref epReceive);
            //    System.Diagnostics.Trace.WriteLine("SendDataTo clear receive buffer: " + DeviceCommander.ByteToHexString(buffer));
            //}

            //CountSend = udp.Send(data, data.Length, epSendTo);

            //if (null != epReceive)
            //{
            //    try
            //    {
            //        BackData = udp.Receive(ref epReceive);
            //    }
            //    catch (Exception ex)
            //    {
            //        System.Diagnostics.Trace.WriteLine("SendDataTo exception on Receive: " + ex.Message);
            //    }
            //}

            //udp.Close();

            //return CountSend; 
            #endregion

            string strBack;

            BackData = null;
            strBack = UDPSend.Send(data, epSendTo.Address.ToString(), null == epReceive ? 1007 : epReceive.Port, epSendTo.Port);

            if (null != epReceive)
            {
                if (null == strBack || "2" == strBack)
                {
                    throw new Exception("没有返回数据");
                }
                if ("6" == strBack)
                {
                    throw new Exception("发送IP与接收IP不一致");
                }
                if (strBack.Length > 5)
                {
                    if (strBack.Substring(2, 4) != "3030")
                    {
                        throw new ArgumentException("命令执行出错: " + strBack);
                    }
                }

                BackData = DeviceCommander.HexStringToByte(strBack);
            }

            return data.Length;
        }
    }
}