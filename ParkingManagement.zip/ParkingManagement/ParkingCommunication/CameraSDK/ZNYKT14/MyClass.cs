﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace ParkingCommunication.CameraSDK.ZNYKT14
{
    public class MyClass
    {

        public const string dllname = @"ZNYKTY14\NetSDK.dll";

        //public const string dllname14 = @"ZNYKTY14\NetSDK.dll";

        public static int iFlag = 0;

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_Init();

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern void Net_UNinit();

        [DllImport(dllname, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_AddCamera(string ptIp);

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_DelCamera(int tHandle);

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_ConnCamera(int tHandle, ushort usPort, ushort usTimeout);

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_DisConnCamera(int tHandle);

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_StartVideo(int tHandle, int niStreamType, IntPtr hWnd);

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_StopVideo(int tHandle);

        [DllImport(dllname, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_GetSdkVersion([MarshalAs(UnmanagedType.LPStr)]StringBuilder szVersion, ref int ptLen);

        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_TransRS485Data(int tHandle, byte ucRs485Id, byte[] pRS485Data, byte ucDatalen);


        /**********************************************************************
* 函数名称：Net_SaveImageToJpeg
* 功能描述：截取当前图像，保存到指定路径
* 输入参数：tHandle 相机句柄
*			ucPathNmme 保存图像的路径
* 输出参数：无
* 返 回 值：状态码
***********************************************************************/
        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_SaveImageToJpeg(int tHandle, string ucPathNmme);


        [StructLayout(LayoutKind.Sequential)]
        public class T_ImageUserInfo
        {
            public ushort usWidth;   /*图片的宽度，单位:像素*/
            public ushort usHeight;  /*图片的高度，单位:像素*/
            public byte ucVehicleColor;/*车身颜色，E_ColorType*/
            public byte ucVehicleBrand;/*车标，E_VehicleFlag*/
            public byte ucVehicleSize;/*车型(大中小)，ITS_Tb_Vt*/
            public byte ucPlateColor;/*车牌颜色，E_ColorType*/
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public byte[] szLprResult;/*车牌，若为'\0'，表示无效GB2312编码*/
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public ushort[] usLpBox;  /*车牌位置，左上角(0, 1), 右下角(2,3)*/
            public byte ucLprType;/*车牌类型*/
            public uint uiSpeed;     /*单位km/h*/
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
            public byte[] acSnapTime;         /*图片抓拍时间:格式YYYYMMDDHHMMSSmmm(年月日时分秒毫秒)*/
            public byte ucViolateCode;    /*违法代码E_ViolationCode*/
            public byte ucLaneNo;          /*车道号,从0开始编码*/
            public uint uiVehicleId; 		/*检测到的车辆id，若为同一辆车，则id相同*/
            public byte ucScore;    		/*车牌识别可行度*/
            public byte ucDirection;       /*行车方向E_Direction*/
            public byte ucTotalNum;        /*该车辆抓拍总张数*/
            public byte ucSnapshotIndex;   /*当前抓拍第几张，从0开始编号*/
        };

        [StructLayout(LayoutKind.Sequential)]
        public class T_PicInfo
        {
            public uint uiPanoramaPicLen;  /*全景图片大小*/
            public uint uiVehiclePicLen;      /*车牌图片大小*/
            public IntPtr ptPanoramaPicBuff;   /*全景图片缓冲区*/
            public IntPtr ptVehiclePicBuff;  /*车牌图片缓冲区*/
        };

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)]
        public delegate int FGetImageCB(int tHandle, uint uiImageId, IntPtr ptImageInfo, IntPtr ptPicInfo);

        [DllImport(dllname, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_RegImageRecv(FGetImageCB fCb);

        [StructLayout(LayoutKind.Sequential)]
        public class T_FrameInfo
        {
            public uint uiFrameId;          //帧ID
            public uint uiTimeStamp;        //RTP时间戳
            public uint uiEncSize;          //帧大小
            public uint uiFrameType;        //1:i帧 0:其它
            public T_FrameInfo()
            {
                uiFrameId = 0;
                uiTimeStamp = 0;
                uiEncSize = 0;
                uiFrameType = 0;
            }
        };
        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_ImageSnap(int tHandle, IntPtr ptImageSnap);

        [StructLayout(LayoutKind.Sequential)]
        public class T_ControlGate
        {
            [MarshalAs(UnmanagedType.U1)]
            public byte ucState;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public byte[] ucReserved;
        };
        [DllImport(dllname, CallingConvention = CallingConvention.StdCall)]
        public static extern int Net_GateSetup(int tHandle, IntPtr ptControlGate);

        [StructLayout(LayoutKind.Sequential)]
        public class T_BlackWhiteList
        {
            public byte LprMode;  /* 0：黑名单；1：白名单*/
            public byte LprCode;      /* 0：车牌号码utf-8字符编码；1：车牌号码gb2312字符编码*/
            public byte Lprnew; /*0： 重新发送；1：续传；2:删除；*/
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public byte[] aucLplPath;
        };
        [DllImport(dllname, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
        public static extern int Net_BlackWhiteListSend(int tHandle, IntPtr ptBalckWhiteList);

        [StructLayout(LayoutKind.Sequential)]
        public class T_GetBlackWhiteList
        {
            public byte LprMode;  /* 0：黑名单；1：白名单*/
            public byte LprCode;      /* 0：车牌号码utf-8字符编码；1：车牌号码gb2312字符编码*/
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public byte[] aucLplPath;
        };
        [DllImport(dllname, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
        public static extern int Net_GetBlackWhiteList(int tHandle, IntPtr ptGetBalckWhiteList);

        [StructLayout(LayoutKind.Sequential)]
        public class T_LprResult
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public byte[] LprResult;/*车牌号码；单条消息最多80条车牌号码；其它分多条消息发送*/
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public byte[] StartTime;//eg:20151012190303 YYYYMMDDHHMMSS
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public byte[] EndTime;//eg:20151012190303 YYYYMMDDHHMMSS
        };
        [StructLayout(LayoutKind.Sequential)]
        public class T_BlackWhiteListCount
        {
            public int uiCount;  /* 0：黑名单；1：白名单*/
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public byte[] aucLplPath;
        };
        [DllImport(dllname, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
        public static extern int Net_BlackWhiteListSetup(IntPtr ptLprResult, IntPtr ptBlackWhiteListCount);

    }

}
