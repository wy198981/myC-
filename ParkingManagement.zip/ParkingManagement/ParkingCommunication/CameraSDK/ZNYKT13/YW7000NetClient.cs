﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Data;

namespace ParkingCommunication.CameraSDK.ZNYKT13
{
    public enum HHERR_CODE
    {
        HHERR_SUCCESS,					//操作成功
        HHERR_FAILURE,					//操作失败
        HHERR_REFUSE_REQ,				//请求被拒绝
        HHERR_USER_FULL,				//登录用户已满
        HHERR_PREVIEW_FULL,				//预览用户已满
        HHERR_TASK_FULL,				//系统任务繁忙，待会尝试连接
        HHERR_CHANNEL_NOT_EXIST,		//要打开的通道不存在或已满
        HHERR_DEVICE_NAME,				//打开的设备不存在
        HHERR_IS_TALKING,				//正在对讲
        HHERR_QUEUE_FAILUE,				//队列出错
        HHERR_USER_PASSWORD,			//用户名或密码和系统不匹配
        HHERR_SHARE_SOCKET,				//socket 错误
        HHERR_RELAY_NOT_OPEN,			//转发请求的服务还未打开
        HHERR_RELAY_MULTI_PORT,			//转发多播端口错误
        HHERR_VIEWPUSH_CHANNEL_USING,	//视频输入的通道已经被占用
        HHERR_VIEWPUSH_DECODE_TYPE,		//视频输入通道的解码格式错误，0通道(4cif,2cif,cif),1通道(2cif,cif),2通道(cif),3通道(cif)
        HHERR_AUTO_LINK_FAILURE,		//转发的自动连接失败
        HHERR_NOT_LOGON,				//设备还未登录
        HHERR_IS_SETTING,				//设备正在设置
        HHERR_COMMAND_FAILURE,			//命令失败
        HHERR_RESTRICT_ID,				//ID使用受限

        HHERR_INVALID_PARAMETER = 100,	//输入参数无效
        HHERR_LOGON_FAILURE,			//登录失败
        HHERR_TIME_OUT,					//操作超时
        HHERR_SOCKET_ERR,				//SOCKET错误
        HHERR_NOT_LINKSERVER,			//还未连接服务器
        HHERR_BUFFER_EXTCEED_LIMIT,		//使用缓冲超过限制	
        HHERR_LOW_PRIORITY,				//操作权限不足
        HHERR_BUFFER_SMALL,				//缓冲太小
        HHERR_IS_BUSY,					//系统任务正忙
        HHERR_UPDATE_FILE,				//升级文件错误
        HHERR_UPDATE_UNMATCH,			//升级文件和机器不匹配
        HHERR_PORT_INUSE,				//端口被占用
        HHERR_RELAY_DEVICE_EXIST,		//设备名已经存在
        HHERR_CONNECT_REFUSED,			//连接时被拒绝
        HHERR_PROT_NOT_SURPPORT,		//不支持该协议

        HHERR_FILE_OPEN_ERR,            //打开文件失败
        HHERR_FILE_SEEK_ERR,            //fseek失败 
        HHERR_FILE_WRITE_ERR,           //fwrite失败 
        HHERR_FILE_READ_ERR,            //fread失败 
        HHERR_FILE_CLOSING,             //正在关闭文件 

        HHERR_ALLOC_BUF_ERR
    }

    public enum DVS_MACHINE_TYPE
    {
        HH5001C = 0x00,				//一路CIF编码器
        HH5002H = 0x01,				//二路HalfD1编码器
        HH5001D = 0x02,				//一路D1编码器
        HH5004C = 0x03,				//四路CIF编码器
        HH5104 = 0x04,				//四路解码器
        HH5108 = 0x05,				//八路解码器
        HH6104 = 0x06,				//四路解码卡

        HH5200 = 0x10,				//保留
        HH5201 = 0x11,				//IPCam一路CCD,D1编码,HH9000系列
        HH5201DI = 0X11,
        HH5201CI = 0x12,				//IPCam一路CCD,CIF编码,HH9000系列
        HH5201MI = 0x13,				//IPCam一路CMOS,HH9000系列

        HH5201C = 0x20,				//DVS一路CIF
        HH5201D = 0x21,				//DVS一路D1
        HH5202C = 0x22,				//DVS两路CIF
        HH5202H = 0x23,				//DVS两路HD1
        HH5204C = 0x24,				//DVS四路CIF
        HH5204D = 0x25,				//DVS四路d1

        HH5301 = 0x30,				//H.264 单路解码器(IPCam,  HH52系列, HH56系列DVS)

        HH5700 = 0x35,				//HH57系列 解码器 (IPCam,  HH52系列, HH56系列DVS)

        HH9800CI = 0x40,				//HH98系列 IPCam一路CCD
        HH9800MI,						//HH98系列 IPCam一路CMOS
        HH9800MIX,						//HH98系列 IPCam一路CMOS(高清)
        HH9800CIX,						//HH98系列 IPCam一路CCD (高清)
        HH9800CIH,						//HH98系列 IPCam一路CCD (高清高速球)

        HH5801C = 0x45,				//HH58系列 DVS			
        HH5801D,
        HH5802C,
        HH5802H,
        HH5802D,
        HH5804C,
        HH5804H,
        HH5804D,

        HH7000 = 0x50,
    }
    public enum HHMSG_NOTIFY
    {
        HHMSG_CONNECT_CLOSE,			//登录连接关闭
        HHMSG_CHANNEL_CLOSE,			//通道连接关闭
        HHMSG_TALK_CLOSE,				//对讲连接关闭
        HHMSG_ALARM_OUTPUT,				//报警输出
        HHMSG_UPDATE_SEND_PERCENT,		//升级程序发送百分比
        HHMSG_UPDATE_SAVE_PERCENT,		//升级写入发送百分比
        HHMSG_BROADCAST_ADD_FAILURE,	//加入语音广播组失败
        HHMSG_BROADCAST_CLOSE,			//语音广播中一个断开
        HHMSG_SENSOR_CAPTURE,			//探头触发的抓拍
        HHMSG_COM_DATA,					//串口采集数据
        HHMSG_ALARM_LOST,				//报警消失
        HHMSG_ALARM_OUTPUT_NEW,			//报警输出(新)
        HHMSG_ALARM_LOST_NEW,			//报警消失(新)
        HHMSG_PICCHN_CLOSE,				//抓拍通道连接关闭
        HHMSG_LOGON_SUCCESS,			//登录连接成功
        HHMSG_CHANNEL_SUCCESS,			//通道连接成功
        HHMSG_TALK_SUCCESS,				//对讲连接成功
        HHMSG_BROADCAST_SUCCESS,		//加入语音广播组成功
        HHMSG_PICCHN_SUCCESS,			//抓拍通道连接成功
        HHMSG_VIEWPUSH_SUCCESS,			//打开解码器视频输入成功
        HHMSG_GPS_STATUS,				//GPS信息,add by huangtao
        HHMSG_NETREPLAY_CLOSE,			//远程回放通道关闭
        HHMSG_VIEWPUSH_CLOSE,			//解码通道关闭
        //ICE_MOD
        HHMSG_ICEMOD_RESULT,			//移动目标智能识别
    }
    public enum ICE_PLATETYPE_E
    {
        ICE_PLATE_UNCERTAIN = 0,	//!< 不确定的
        ICE_PLATE_BLUE = 1,	//!< 蓝牌车
        ICE_PLATE_YELLOW = 2,	//!< 单层黄牌车
        ICE_PLATE_POLICE = 4,    //!< 警车
        ICE_PLATE_WUJING = 8,	//!< 武警车辆
        ICE_PLATE_DBYELLOW = 16,	//!< 双层黄牌
        ICE_PLATE_MOTOR = 32,	//!< 摩托车
        ICE_PLATE_INSTRUCTIONCAR = 64,	//!< 教练车
        ICE_PLATE_MILITARY = 128,	//!< 军车
        ICE_PLATE_PERSONAL = 256,	//!< 个性化车
        ICE_PLATE_GANGAO = 512,	//!< 港澳车
    }

    public enum ICE_PLATECOLOR_E
    {
        ICE_PLATE_COLOR_UNKNOWN = 0,	//!<  未知
        ICE_PLATE_COLOR_BLUE = 1,	//!<  蓝底白字
        ICE_PLATE_COLOR_YELLOW = 2,	//!<  黄底黑字
        ICE_PLATE_COLOR_WHITE = 3,	//!<  白底黑字
        ICE_PLATE_COLOR_BLACK = 4,	//!<  黑底白字
        ICE_PLATE_COLOR_GREEN = 5		//!<  绿底白字
    }

    public enum ICE_VEHICLECOLOR_E
    {
        ICE_VEHICLE_COLOR_UNKOWN = 0,		//!<  未知
        ICE_VEHICLE_COLOR_RED = 1,			//!<  红色
        ICE_VEHICLE_COLOR_GREEN = 2,		//!<  绿色
        ICE_VEHICLE_COLOR_BLUE = 3,			//!<  蓝色
        ICE_VEHICLE_COLOR_YELLOW = 4,		//!<  黄色
        ICE_VEHICLE_COLOR_WHITE = 5,		//!<  白色
        ICE_VEHICLE_COLOR_GRAY = 6,			//!<  灰色
        ICE_VEHICLE_COLOR_BLACK = 7,		//!<  黑色
        ICE_VEHICLE_COLOR_PURPLE = 8,			//!<  紫色
        ICE_VEHICLE_COLOR_BROWN = 9,			//!<  棕色
        ICE_VEHICLE_COLOR_PINK = 10			//!<  粉色
    }

    public enum NET_PROTOCOL_TYPE
    {
        NET_PROTOCOL_TCP = 0,			//TCP协议
        NET_PROTOCOL_UDP = 1,			//UDP协议
        NET_PROTOCOL_MULTI = 2			//多播协议
    }

    public enum HHCMD_NET
    {
        //编码器命令
        HHCMD_GET_ALL_PARAMETER,		//0. 得到所有编码器参数
        HHCMD_SET_DEFAULT_PARAMETER,	//1. 恢复所有编码器默认参数
        HHCMD_SET_RESTART_DVS,			//2. 重启编码器
        HHCMD_GET_SYS_CONFIG,			//3. 获取系统设置
        HHCMD_SET_SYS_CONFIG,			//4. 设置系统设置
        HHCMD_GET_TIME,					//5. 获取编码器时间
        HHCMD_SET_TIME,					//6. 设置编码器时间
        HHCMD_GET_AUDIO_CONFIG,			//7. 获取音频设置
        HHCMD_SET_AUDIO_CONFIG,			//8. 设置音频设置
        HHCMD_GET_VIDEO_CONFIG,			//9. 获取视频设置
        HHCMD_SET_VIDEO_CONFIG,			//10.设置视频设置
        HHCMD_GET_VMOTION_CONFIG,		//11.获取移动侦测设置
        HHCMD_SET_VMOTION_CONFIG,		//12.设置移动侦测设置
        HHCMD_GET_VMASK_CONFIG,			//13.获取图像屏蔽设置
        HHCMD_SET_VMASK_CONFIG,			//14.设置图像屏蔽设置
        HHCMD_GET_VLOST_CONFIG,			//15.获取视频丢失设置
        HHCMD_SET_VLOST_CONFIG,			//16.设置视频丢失设置
        HHCMD_GET_SENSOR_ALARM,			//17.获取探头报警侦测设置
        HHCMD_SET_SENSOR_ALARM,			//18.设置探头报警侦测设置
        HHCMD_GET_USER_CONFIG,			//19.获取用户设置
        HHCMD_SET_USER_CONFIG,			//20.设置用户设置
        HHCMD_GET_NET_CONFIG,			//21.获取网络设置结构
        HHCMD_SET_NET_CONFIG,			//22.设置网络设置结构
        HHCMD_GET_COM_CONFIG,			//23.获取串口设置
        HHCMD_SET_COM_CONFIG,			//24.设置串口设置
        HHCMD_GET_YUNTAI_CONFIG,		//25.获取内置云台信息
        HHCMD_SET_YUNTAI_CONFIG,		//26.设置内置云台信息
        HHCMD_GET_VIDEO_SIGNAL_CONFIG,	//27.获取视频信号参数（亮度、色度、对比度、饱和度）
        HHCMD_SET_VIDEO_SIGNAL_CONFIG,	//28.设置视频信号参数（亮度、色度、对比度、饱和度）
        HHCMD_SET_PAN_CTRL,				//29.云台控制
        HHCMD_SET_COMM_SENDDATA,		//30.透明数据传输
        HHCMD_SET_COMM_START_GETDATA,	//31.开始采集透明数据
        HHCMD_SET_COMM_STOP_GETDATA,	//32.停止采集透明数据
        HHCMD_SET_OUTPUT_CTRL,			//33.继电器控制
        HHCMD_SET_PRINT_DEBUG,			//34.调试信息开关
        HHCMD_SET_ALARM_CLEAR,			//35.清除报警
        HHCMD_GET_ALARM_INFO,			//36.获取报警状态和继电器状态
        HHCMD_SET_TW2824,				//37.设置多画面芯片参数(保留)
        HHCMD_SET_SAVE_PARAM,			//38.设置保存参数
        HHCMD_GET_USERINFO,				//39.获取当前登陆的用户信息
        HHCMD_GET_DDNS,					//40.获取DDNS
        HHCMD_SET_DDNS,					//41.设置DDNS
        HHCMD_GET_CAPTURE_PIC,			//42.前端抓拍
        HHCMD_GET_SENSOR_CAP,			//43.获取触发抓拍设置
        HHCMD_SET_SENSOR_CAP,			//44.设置触发抓拍设置
        HHCMD_GET_EXTINFO,				//45.获取扩展配置
        HHCMD_SET_EXTINFO,				//46.设置扩展配置
        HHCMD_GET_USERDATA,				//47.获取用户配置
        HHCMD_SET_USERDATA,				//48.设置用户配置
        HHCMD_GET_NTP,					//49.获取NTP配置
        HHCMD_SET_NTP,					//50.设置NTP配置
        HHCMD_GET_UPNP,					//51.获取UPNP配置
        HHCMD_SET_UPNP,					//52.设置UPNP配置
        HHCMD_GET_MAIL,					//53.获取MAIL配置
        HHCMD_SET_MAIL,					//54.设置MAIL配置
        HHCMD_GET_ALARMNAME,			//55.获取报警名配置
        HHCMD_SET_ALARMNAME,			//56.设置报警名配置
        HHCMD_GET_WFNET,				//57.获取无线网络配置
        HHCMD_SET_WFNET,				//58.设置无线网络配置
        HHCMD_GET_SEND_DEST,			//59.设置视频定向发送目标机
        HHCMD_SET_SEND_DEST,			//60.设置视频定向发送目标机
        HHCMD_GET_AUTO_RESET,			//61.取得定时重新注册
        HHCMD_SET_AUTO_RESET,			//62.设置定时重新注册
        HHCMD_GET_REC_SCHEDULE,			//63.取得录像策略
        HHCMD_SET_REC_SCHEDULE,			//64.设置录像策略
        HHCMD_GET_DISK_INFO,			//65.取得磁盘信息
        HHCMD_SET_MANAGE,				//66.设置命令和操作
        HHCMD_GET_CMOS_REG,				//67.取得CMOS参数
        HHCMD_SET_CMOS_REG,				//68.设置CMOS参数
        HHCMD_SET_SYSTEM_CMD,			//69.设置执行命令
        HHCMD_SET_KEYFRAME_REQ,			//70.设置关键帧请求
        HHCMD_GET_CONFIGENCPAR,			//71.取得视频参数
        HHCMD_SET_CONFIGENCPAR,			//72.设置视频参数

        //--------------------------    HH58系列、HH98系列及以后的设备用(添加)
        HHCMD_GET_ALL_PARAMETER_NEW,	//73.获取所有参数
        HHCMD_FING_LOG,					//74.查找日志(查询方式:0－全部，1－按类型，2－按时间，3－按时间和类型 0xFF-关闭本次搜索)
        HHCMD_GET_LOG,					//75.读取查找到的日志	
        HHCMD_GET_SUPPORT_AV_FMT,		//76.获取设备支持的编码格式、宽高及音频格式
        HHCMD_GET_VIDEO_CONFIG_NEW,		//77.取得视频参数（新）
        HHCMD_SET_VIDEO_CONFIG_NEW,		//78.设置视频参数（新）
        HHCMD_GET_VMOTION_CONFIG_NEW,	//79.取得移动报警参数（新）
        HHCMD_SET_VMOTION_CONFIG_NEW,	//80.设置移动报警参数（新）
        HHCMD_GET_VLOST_CONFIG_NEW,		//81.取得视频丢失报警参数（新）
        HHCMD_SET_VLOST_CONFIG_NEW,		//82.设置视频丢失报警参数（新）
        HHCMD_GET_SENSOR_ALARM_NEW,		//83.取得探头报警参数（新）
        HHCMD_SET_SENSOR_ALARM_NEW,		//84.设置探头报警参数（新）
        HHCMD_GET_NET_ALARM_CONFIG,		//85.取得网络故障报警参数（新）
        HHCMD_SET_NET_ALARM_CONFIG,		//86.设置网络故障报警参数（新）
        HHCMD_GET_RECORD_CONFIG,		//87.取得定时录像参数
        HHCMD_SET_RECORD_CONFIG,		//88.设置定时录像参数
        HHCMD_GET_SHOOT_CONFIG,			//89.取得定时抓拍参数
        HHCMD_SET_SHOOT_CONFIG,			//90.设置定时抓拍参数
        HHCMD_GET_FTP_CONFIG,			//91.取得FTP参数
        HHCMD_SET_FTP_CONFIG,			//92.设置定时抓拍参数
        HHCMD_GET_RF_ALARM_CONFIG,		//93.取得无线报警参数
        HHCMD_SET_RF_ALARM_CONFIG,		//94.设置定时抓拍参数
        HHCMD_GET_EXT_DATA_CONFIG,		//95.取得其它扩展参数(如平台设置其它参数)
        HHCMD_SET_EXT_DATA_CONFIG,		//96.设置定时抓拍参数
        HHCMD_GET_FORMAT_PROCESS,		//97.取得获取硬盘格式化进度
        HHCMD_GET_PING_CONFIG,			//98.取得PING 设置获取
        HHCMD_SET_PING_CONFIG,			//99.设置PING 设置设置

        //解码器命令
        DDCMD_GET_ALL_PARAMETER = 100,	//获取解码器所有设置
        DDCMD_GET_TIME,					//获取系统时间
        DDCMD_SET_TIME,					//设置系统时间
        DDCMD_GET_SYS_CONFIG,			//获取系统配置
        DDCMD_SET_SYS_CONFIG,			//设置系统配置
        DDCMD_GET_NET_CONFIG,			//获取网络配置
        DDCMD_SET_NET_CONFIG,			//设置网络配置
        DDCMD_GET_COM_CONFIG,			//获取串口配置
        DDCMD_SET_COM_CONFIG,			//设置串口配置
        DDCMD_GET_VIDEO_CONFIG,			//获取视频配置
        DDCMD_SET_VIDEO_CONFIG,			//设置视频配置
        DDCMD_GET_ALARM_OPT,			//获取报警选项
        DDCMD_SET_ALARM_OPT,			//设置报警选项
        DDCMD_GET_USER_INFO,			//获取用户设置信息
        DDCMD_SET_USER_INFO,			//设置用户设置信息
        DDCMD_GET_ALARM_RECORD,			//获取报警记录信息
        DDCMD_GET_ADRRESS_BOOK,			//获取地址薄配置
        DDCMD_SET_ADRRESS_BOOK,			//设置地址薄配置
        DDCMD_SET_COMM,					//设置发送串口数据
        DDCMD_SET_CMD,					//设置透明的命令
        DDCMD_GET_YUNTAI_INFO,			//获取云台信息
        DDCMD_GET_YUNTAI_CONFIG,		//获取云台配置
        DDCMD_SET_YUNTAI_CONFIG,		//设置云台配置
        DDCMD_GET_ONELINK_ADDR,			//获取解码器单路连接的信息
        DDCMD_SET_ONELINK_ADDR,			//设置解码器单路连接的信息
        DDCMD_GET_CYCLELINK_ADDR,		//获取解码器循环连接的信息
        DDCMD_SET_CYCLELINK_ADDR,		//设置解码器循环连接的信息
        DDCMD_GET_EXTINFO,				//获取扩展配置
        DDCMD_SET_EXTINFO,				//设置扩展配置
        DDCMD_GET_NTP,					//获取NTP配置
        DDCMD_SET_NTP,					//设置NTP配置
        DDCMD_GET_UPNP,					//获取UPNP配置
        DDCMD_SET_UPNP,					//设置UPNP配置
        DDCMD_GET_MAIL,					//获取MAIL配置
        DDCMD_SET_MAIL,					//设置MAIL配置
        DDCMD_GET_ALARMNAME,			//获取报警名配置
        DDCMD_SET_ALARMNAME,			//设置报警名配置
        DDCMD_GET_WFNET,				//获取无线网络配置
        DDCMD_SET_WFNET,				//设置无线网络配置
        DDCMD_GET_SEND_DEST,			//设置视频定向发送目标机
        DDCMD_SET_SEND_DEST,			//设置视频定向发送目标机

        //by come 20101112
        HHCMD_GET_VPN_CONFIG = 200,		//200.获取VPN设置参数
        HHCMD_SET_VPN_CONFIG = 201,		//201.设置VPN参数
        HHCMD_GET_3G_CONFIG = 202,		//获取3G参数
        HHCMD_SET_3G_CONFIG = 203,        //设置3G参数
        HHCMD_GET_GPS_CONFIG = 204,
        HHCMD_SET_GPS_CONFIG = 205,
        HHCMD_GET_3G_DIALCTRL = 206,
        HHCMD_SET_3G_DIALCTRL = 207,

        HHCMD_SET_CAMERA_CONFIG = 208,

        HHCMD_GET_NETIPV6_CONFIG,      //ipv6网络设置
        HHCMD_SET_NETIPV6_CONFIG,


        HHCMD_SET_3DPTZ = 300,			//高清球云台3D点击放大等控制
        HHCMD_GET_PTZPOSITION,			//获取球位置信息
        HHCMD_SET_PTZPOSITION,			//设置球位置信息

        HHCMD_GET_MODPARAMS,			//获取MOD参数
        HHCMD_SET_MODPARAMS,			//设置MOD参数

        HHCMD_GET_COMMONPARAMS,			//获取公共接口数据()
        HHCMD_SET_COMMONPARAMS,			//获取公共接口数据()

        HHCMD_GET_TRAFFICSNAP = 307,		//交通抓拍参数
        HHCMD_SET_TRAFFICSNAP = 308,		//交通抓拍参数


        HHCMD_GET_WHITELIST = 311,		//交通卡口黑白名单
        HHCMD_SET_WHITELIST = 312,

        NETCMD_GET_VI_SENSOR = 1000,
        NETCMD_SET_VI_SENSOR,
        NETCMD_GET_VI_SCENE,
        NETCMD_SET_VI_SCENE,
        NETCMD_GET_VI_CFG,
        NETCMD_SET_VI_CFG,

        HHCMD_SET_COMM_SET_ATCMD = 1500,  //表示发数据包	
        HHCMD_SET_COMM_GET_ATRETURN,      //表示获取数据包
        HHCMD_SET_COMM_3G_CONTROL,        //用于3G模块的访问控制
    }

    public enum CONNECT_STATUS
    {
        CONNECT_STATUS_NONE,			//未连接
        CONNECT_STATUS_OK,				//已经连接
        CONNECT_STATUS_DATA,
        CONNECT_STATUS_EXIST,

    }

    //1，数字视频服务器机器类型
    public enum DVS_MACHINE_TYPE_
    {
        HH5001C = 0x00,				//一路CIF编码器
        HH5002H = 0x01,				//二路HalfD1编码器
        HH5001D = 0x02,				//一路D1编码器
        HH5004C = 0x03,				//四路CIF编码器
        HH5104 = 0x04,				//四路解码器
        HH5108 = 0x05,				//八路解码器
        HH6104 = 0x06,				//四路解码卡

        HH5200 = 0x10,				//保留
        HH5201 = 0x11,				//IPCam一路CCD,D1编码,HH9000系列
        HH5201DI = 0X11,
        HH5201CI = 0x12,				//IPCam一路CCD,CIF编码,HH9000系列
        HH5201MI = 0x13,				//IPCam一路CMOS,HH9000系列

        HH5201C = 0x20,				//DVS一路CIF
        HH5201D = 0x21,				//DVS一路D1
        HH5202C = 0x22,				//DVS两路CIF
        HH5202H = 0x23,				//DVS两路HD1
        HH5204C = 0x24,				//DVS四路CIF
        HH5204D = 0x25,				//DVS四路d1

        HH5301 = 0x30,				//H.264 单路解码器(IPCam,  HH52系列, HH56系列DVS)

        HH5700 = 0x35,				//HH57系列 解码器 (IPCam,  HH52系列, HH56系列DVS)

        HH9800CI = 0x40,				//HH98系列 IPCam一路CCD
        HH9800MI,						//HH98系列 IPCam一路CMOS
        HH9800MIX,						//HH98系列 IPCam一路CMOS(高清)
        HH9800CIX,						//HH98系列 IPCam一路CCD (高清)
        HH9800CIH,						//HH98系列 IPCam一路CCD (高清高速球)

        HH5801C = 0x45,				//HH58系列 DVS			
        HH5801D,
        HH5802C,
        HH5802H,
        HH5802D,
        HH5804C,
        HH5804H,
        HH5804D,

        HH7000 = 0x50,
    }

    public class YW7000NetClient
    {

        public const string dllname = @"ZNYKTY13\YW7000NetClient.dll";

        const int MAX_URL_IP_LEN = 64;
        const int MAX_ID_LEN = 32;
        const int ICE_MAX_TRAJECT_LEN = 40;
        const int MAX_IP_NAME_LEN = 128;
        const int DVS_NAME_LEN = 32;
        const int USER_NAME_LEN = 16;	//用户名的最大长度
        const int USER_PASSWD_LEN = 16;	//用户密码最大长度
        public const int MAX_VIDEO_NUM = 4;
        const int MAX_RF_SENSOR_NUM = 8;

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HH_SERVER_INFO
        {
            public IntPtr hServer;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = MAX_IP_NAME_LEN + 1)]
            public string szServerIP;
            public uint nServerPort;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DVS_NAME_LEN + 1)]
            public string szDeviceName;
            public uint nDeviceID;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_NAME_LEN + 1)]
            public string szUserName;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_PASSWD_LEN + 1)]
            public string szUserPassword;
            public uint dwClientID;
            public CONNECT_STATUS logonStatus;
            public uint nVersion;
            public uint nLogonID;
            public uint nPriority;
            public uint nServerChannelNum;
            public uint nLanguageNo;
            public DVS_MACHINE_TYPE nMachineType;
            public int bPalStandard;
            public uint nMulticastAddr;
            public uint nMulticastPort;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_VIDEO_NUM)]
            public YW7000AVDefine.HHAV_INFO[] avInformation;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HH_CHANNEL_INFO
        {
            public IntPtr hOpenChannel;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = MAX_IP_NAME_LEN + 1)]
            public string szServerIP;
            public uint nServerPort;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DVS_NAME_LEN + 1)]
            public string szDeviceName;

            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_NAME_LEN + 1)]
            public string szUserName;

            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_PASSWD_LEN + 1)]
            public string szUserPassword;

            public uint dwClientID;

            public CONNECT_STATUS openStatus;
            public uint nVersion;
            public uint nOpenID;
            public uint nPriority;
            public uint nOpenChannelNo;
            public uint nMulticastAddr;
            public uint nMulticastPort;
            public YW7000AVDefine.HHAV_INFO avInformation;
            public ENCODE_VIDEO_TYPE encodeVideoType;

            public NET_PROTOCOL_TYPE protocolType;
            public ChannelStreamCallback funcStreamCallback;
            public IntPtr pCallbackContext;

            public uint dwDeviceID;	//V4.0 add
        }
        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct USERDATA_CONFIG
        {
            public int nDataLen;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 252, ArraySubType = UnmanagedType.U1)]
            public byte[] userData;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ALARM_STATUS_OUTPUT_NEW
        {
            public byte year;
            public byte month;
            public byte day;
            public byte week;
            public byte hour;
            public byte minute;
            public byte second;
            public byte millsecond;

            public uint SensorAlarm;
            public uint MotionAlarm;
            public uint ViLoseAlarm;
            public uint RFSensorAlarm;
            public uint NetAlarm;

            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_SENSOR_NUM, ArraySubType = UnmanagedType.U4)]
            public uint[] SensorAlarmRec;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_VIDEO_NUM, ArraySubType = UnmanagedType.U4)]
            public uint[] MotionAlarmRec;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_VIDEO_NUM, ArraySubType = UnmanagedType.U4)]
            public uint[] ViLoseAlarmRec;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_RF_SENSOR_NUM, ArraySubType = UnmanagedType.U4)]
            public uint[] RFSensorAlarmRec;
            public uint NetAlarmRec;
            public uint OutputStatus;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 19, ArraySubType = UnmanagedType.U4)]
            public uint[] reserved;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ALARM_MSG_NOTIFY_NEW
        {
            public IntPtr hLogonServer;
            public uint dwClientID;
            public uint dwServerIP;
            public uint dwServerPort;
            public ALARM_STATUS_OUTPUT_NEW alarmStatus;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ALARM_STATUS_OUTPUT
        {
            public byte year;
            public byte month;
            public byte day;
            public byte week;
            public byte hour;
            public byte minute;
            public byte second;

            public byte statusSensorAlarm;
            public byte statusMotionAlarm;
            public byte statusViLoseAlarm;

            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_SENSOR_NUM, ArraySubType = UnmanagedType.U1)]
            public byte[] SensorAlarmRec;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_VIDEO_NUM, ArraySubType = UnmanagedType.U1)]
            public byte[] MotionAlarmRec;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_VIDEO_NUM, ArraySubType = UnmanagedType.U1)]
            public byte[] ViLoseAlarmRec;

            public byte statusAlarmOutput;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ALARM_MSG_NOTIFY
        {
            public IntPtr hLogonServer;
            public uint dwClientID;
            public uint dwServerIP;
            public uint dwServerPort;
            public ALARM_STATUS_OUTPUT alarmStatus;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct AREA_RECT_S
        {
            public short x; //X坐标
            public short y; //Y坐标
            public short w; //宽度
            public short h; //高度 
        }
        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct VEHICLE_INFO_S
        {
            public uint dwBgnFlag;			//0x12345678
            public uint dwSize;				//结构大小 sizeof(VEHICLE_INFO_S)	

            public ushort wImageWidth;		//图片宽度
            public ushort wImageHeight;		//图片高度	

            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 16)]
            public string szPlateNum;		//车牌号
            public ICE_RECT_S stPlateRect;		//车牌矩形框(位置)

            public ICE_PLATECOLOR_E ePlateColor;	//车牌颜色
            public ICE_PLATETYPE_E ePlateType;		//车牌类型
            public ICE_VEHICLECOLOR_E eVehicleColor;	//车身颜色\
            public byte byLaneNum;                      //车道号
            public byte byConfirm;                      //车牌置信度
            public byte byCarResume;                    //是否续传的文件 0xfe
            public byte byRes;                          //备用
            public uint dwPicLen;                       //图片长度
            public uint dwPicType;                      //图片类型
            public uint dwTimeStamp;                    //时间戳
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 256 - 68, ArraySubType = UnmanagedType.U1)]
            public byte[] dwReserved;//备用		

            public uint dwEndFlag;			//0x87654321
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct URL_PORT_S
        {
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = MAX_URL_IP_LEN)]
            string szAddr;				//IP地址 域名
            uint dwIPAddr;
            uint dwPort;								//端口
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct CROSS_SNAP_S
        {
            uint dwSize;
            byte bEnable;						//抓拍开关
            byte bySnapProtocol;					//上传协议
            byte bySnapQuality;					//抓拍质量
            byte bySnapNum;						//连拍张数
            ushort wSnapIntervalMode;				//连拍间隔模式
            ushort wSnapInterval;					//连拍间隔
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = MAX_ID_LEN)]
            string szCrossID;			//卡号编号
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = MAX_ID_LEN)]
            string szDeviceID;			//设备编号
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct LPR_PARAM_S
        {
            uint dwSize;
            byte byDayAlarmThreshold;			//白天报警阀值
            byte byNightAlarmThreshold;			//夜晚报警阀值
            byte bySensitivityThreshold;			//灵敏度阀值
            byte byRecognizeThreshold;			//识别阀值
            uint dwTriggerInterval;				//触发间隔
            ushort wMinPlate;						//最小车牌
            ushort wMaxPlate;						//最大车牌
            //BYTE				byCalibrationEnable;				//标定参数开启
            byte byPlateTypeSp;
            byte byManual;						//相机参数手动
            byte byAGain;						// 相机参数模拟增益
            byte byDGain;						// 相机参数数字增益
            uint dwExposure;						// 相机参数曝光时间
            //WORD				wHorDistance;						//标定参数水平距离
            //WORD				wVerDistance;						//标定参数垂直距离
            float fPlateAngle;					//车牌角度
            uint dwPriorCityType;				//优先城市类型
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 28, ArraySubType = UnmanagedType.U1)]
            byte[] Res;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct DRIVEWAY_CONFIG_S
        {
            public uint dwSize;
            public byte byCheckMode;					//检测模式
            public byte byFillterPlate;					//过滤无效车牌
            public byte byMeasureSpeed;					//测速
            public byte byRelationIO;					//闪光灯IO号
            public ushort wRealDistance;					//实际距离
            public byte byCorrection;					//校正系数
            public byte byTrigerMode;					//触发检测模式
            public AREA_RECT_S stTriglo1;						//线圈坐标1
            public AREA_RECT_S stTriglo2;						//线圈坐标2

            public byte byOsdEnable;					//字符叠加开关
            public byte byOsdMode;						//OSD方式
            public byte byOsdRed;						//OSD 红色
            public byte byOsdGreen;						//OSD 绿色

            public byte byOsdBlue;						//OSD蓝色
            public byte byOsdTimeMode;					//实际格式
            public byte byOsdAddress;					//地址
            public byte byOsdDirection;					//方向
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string szAddrTitle;				//地址信息
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string szDirecTitle;				//方向信息

            public ushort wOsdX;							//OSD X坐标
            public ushort wOsdY;							//OSD Y坐标

            public byte bySpeed;						//车速
            public byte byLimitSpeed;					//限速值
            public byte byOverSpeedRate;				//超速比率
            public byte byDriveWayInfo;					//车道信息

            public byte byPlateInfo;					//车牌信息
            public byte byDriveWay;						//车道
            public byte byCustom1;						//自定义开关1
            public byte byCustom2;						//自定义开关2
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 64, ArraySubType = UnmanagedType.U1)]
            public byte[] szCustom1;					//自定义信息1
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 64, ArraySubType = UnmanagedType.U1)]
            public byte[] szCustom2;					//自定义信息2
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32, ArraySubType = UnmanagedType.U1)]
            public byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct FLASH_PARAM_S
        {
            uint dwSize;
            byte byIONum;						//IO 输出号
            byte byFlashMode;					//闪光灯类型
            byte byIODefaultLevel;				//IO默认电平
            byte byIOStartValidLevel;			//IO起效电平
            byte byFrequencyDouble;				//倍频	
            byte byDutyCycle;					//占空比
            byte byWorkMode;						//工作模式
            byte byAutoModeThreshold;			//自动工作模式闪烁亮度阀值
            byte byTime1Hour;					//定时工作模式起始时间
            byte byTime1Min;						//定时工作模式起始时间
            byte byTime2Hour;					//定时工作模式结束时间
            byte byTime2Min;						//定时工作模式结束时间
            byte byIOValidTime;					//IO 起效持续时间
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 31, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct PARK_REMOTESERVER_S
        {
            uint dwSize;
            int bEnable;
            URL_PORT_S stUrlPort;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 31, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct IOINPUT_CONFIG_S
        {
            uint dwSize;
            byte byIOInputNum;					//IO输入选择
            byte byIOInputType;					//IO输入类型
            byte byTrigloStatus;					//抓拍线圈的触发状态
            byte byRedLightLevel;				//红灯有效电平
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct PARK_FTPCONFIG_S
        {
            uint dwSize;
            byte byEnable;						//
            byte byDirLevel;						//目录结构
            byte byTopDirMode;					//一级目录
            byte bySubDirMode;					//二级目录
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 16)]
            string szSeparator;				//分隔符
            byte byName1;						//命名项
            byte byName2;
            byte byName3;
            byte byName4;
            byte byName5;
            byte byName6;
            byte byRes1;
            byte byRes2;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct PARK_LED_S
        {
            uint dwSize;
            ushort wLightMode;						//控灯模式
            ushort wParkingNum;					//车位数

            byte byNoCarEnable;					//无车是否有效(内置灯)
            byte byHaveCarEnable;				//有车是否有效(内置灯)
            byte byGrooveEnable;					//压线是否有效(内置灯)
            byte bySpecialCarEnable;				//特殊车位是否有效(内置灯)

            byte byNoCarFlash;					//无车是否闪烁(内置灯)
            byte byHaveCarFlash;					//有车是否闪烁(内置灯)
            byte byGrooveFlash;					//压线是否闪烁(内置灯)
            byte bySpecialCarFlash;				//特殊车位是否闪烁(内置灯)

            byte byNoCarLightColor;				//无车灯的颜色(内置灯)
            byte byHaveCarLightColor;			//有车灯的颜色(内置灯)
            byte byGrooveLightColor;				//压线灯的颜色(内置灯)
            byte bySpecialCarLightColor;			//特殊车位灯的颜色(内置灯)

            byte byP1CYEnable;					//车位1普通车位有车是否起效
            byte byP1CNEnable;					//车位1普通车位无车是否起效
            byte byP1SYEnable;					//车位1特殊车位有车是否起效
            byte byP1SNEnable;					//车位1特殊车位无车是否起效

            byte byP1CYFlash;					//车位1普通车位有车是否闪烁
            byte byP1CNFlash;					//车位1普通车位无车是否闪烁
            byte byP1SYFlash;					//车位1特殊车位有车是否闪烁
            byte byP1SNFlash;					//车位1特殊车位无车是否闪烁

            byte byP1CYIOStatus;					//车位1普通车位有车IO电平状态
            byte byP1CNIOStatus;					//车位1普通车位无车IO电平状态
            byte byP1SYIOStatus;					//车位1特殊车位有车IO电平状态	
            byte byP1SNIOStatus;					//车位1特殊车位无车IO电平状态

            byte byP2CYEnable;
            byte byP2CNEnable;
            byte byP2SYEnable;
            byte byP2SNEnable;

            byte byP2CYFlash;
            byte byP2CNFlash;
            byte byP2SYFlash;
            byte byP2SNFlash;

            byte byP2CYIOStatus;
            byte byP2CNIOStatus;
            byte byP2SYIOStatus;
            byte byP2SNIOStatus;

            byte byP3CYEnable;
            byte byP3CNEnable;
            byte byP3SYEnable;
            byte byP3SNEnable;

            byte byP3CYFlash;
            byte byP3CNFlash;
            byte byP3SYFlash;
            byte byP3SNFlash;

            byte byP3CYIOStatus;
            byte byP3CNIOStatus;
            byte byP3SYIOStatus;
            byte byP3SNIOStatus;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct PLATE_PARAM_S
        {
            uint dwSize;
            byte byDefaultProvince;				//默认省份
            byte byBackRecognize;				//背向识别
            byte byBigPlate;						//大车牌
            byte byCarClor;						//车身颜色
            byte byFarmCar;						//农用车
            byte byFuzzyRecognize;				//模糊识别
            byte byRec1;
            byte byRec2;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct PARK_PARAM_S
        {
            uint dwSize;
            byte byRecognizeParking;				//识别的车位数
            byte byPark1Num;						//车位号
            byte byPark1Special;					//是否特殊车位
            byte byPark2Num;						//车位号
            byte byPark2Special;					//是否特殊车位
            byte byPark3Num;						//车位号
            byte byPark3Special;					//是否特殊车位
            byte byRec1;

            AREA_RECT_S stArea1;						//车位区域
            AREA_RECT_S stArea2;
            AREA_RECT_S stArea3;
            AREA_RECT_S stArea4;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 28, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct TRAFFIC_SNAP_S
        {
            public uint dwSize;

            public byte bEnable;
            public byte byPicFormat;					//0: YUV 420		1: YUV 422		2: JPG
            public byte byCapMode;						//0: 单张抓拍		1: 多张模式
            public byte bOpenLight;						//0: 不触发闪光灯	1: 触发闪光灯

            URL_PORT_S stUrlPort;						//服务器地址
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 2, ArraySubType = UnmanagedType.U2)]
            public ushort[] wPreTime;
            public ushort wDelayTime;						//延迟抓拍时间
            public ushort wDelayCap;						//延迟取照片时间 

            public ushort wLightDelayTime;				//延迟开灯时间
            public ushort wLightTime;						//亮灯时间

            public CROSS_SNAP_S stCrossSnap;
            public LPR_PARAM_S stLPRSetting;
            public DRIVEWAY_CONFIG_S stDriveWaySetting;
            public FLASH_PARAM_S stFlashSetting;
            public IOINPUT_CONFIG_S stIOInputSetting;
            public PARK_REMOTESERVER_S stRemoteServer;
            public PARK_FTPCONFIG_S stParkFtpSetting;
            public PARK_LED_S stParkLedSetting;
            public PLATE_PARAM_S stPlateSetting;
            public LPR_PARAM_S stParkLPRSetting;
            public PARK_PARAM_S stParkSetting;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 2048 - 92 - 968, ArraySubType = UnmanagedType.U1)]
            byte[] byRes;

        }

        /*        public struct ICE_TIME_S
                {
                    uint			reserved: 16;					//保留
                    uint			week : 6;						//星期
                    uint			millisec : 10;					//毫秒:0 ~ 999
                    uint			second : 6;						//秒:  0 ~ 59
                    uint			minute : 6;						//分:  0 ~ 59
                    uint			hour : 5;						//时:  0 ~ 23
                    uint			day : 5;						//日:  1 ~ 31
                    uint			month : 4;						//月:  1 ~ 12
                    uint			year : 6;						//年:  2000 ~ 2063
                }*/

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICE_TIME_S
        {
            uint dw1;
            uint dw2;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICE_POINT_S
        {
            public short s16X;               //!< x
            public short s16Y;               //!< y
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICE_RECT_S
        {
            public short s16Left;            //!< letf x
            public short s16Top;             //!< top y
            public short s16Right;           //!< right x
            public short s16Bottom;          //!< bottom y

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICE_TGT_TRAJECT
        {
            public int length;							//!< 轨迹长度
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = ICE_MAX_TRAJECT_LEN)]
            public ICE_POINT_S[] points;//!< 轨迹点数组

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICE_TARGET
        {
            public uint u32ID;                          //!< 目标ID
            public int u32Type;                        //!< 目标类型，参考\ref ICE_TGT_TYPE
            public ICE_POINT_S stPoint;                    //!< 目标位置
            public ICE_RECT_S stRect;                      //!< 目标矩形框
            public int s32AreaPix;                     //!< 目标面积(单位：像素)
            public int s32Area;                        //!< 目标面积(单位：平方厘米)
            public int s32Direct;                      //!< 运动方向(单位：角度)
            public float fSpeed;                       //!< 运动速度(单位：千米/小时)
            public ICE_TGT_TRAJECT stTraject;				//!< 目标轨迹

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICE_EVENT
        {
            uint u32Type;                        //!< 事件类型，参考\ref ICE_EVT_TYPE
            uint u32ID;                          //!< 事件标识
            uint u32Status;                      //!< 事件状态，参考\ref ICE_EVT_STATUS
            uint u32Zone;                        //!< 事件发生区域
            uint u32TgtID;                       //!< 目标标识
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = UnmanagedType.U1)]
            byte[] u8Data;                     //!< 事件私有数据

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICE_MOD_RESULT_S
        {
            public ICE_TIME_S stTime;					//时间

            public int s32TargetNum;           //!< 有效目标数目
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32)]
            public ICE_TARGET[] astTargets; 		//!< 目标数组

            public int s32EventNum;            //!< 有效事件数目
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 64)]
            public ICE_EVENT astEvents;   		//!< 事件数组

            public int dwAlgoWidth;			//dwAlgoWidth和dwAlgoHeight是算法处理的图像宽和高
            public int dwAlgoHeight;

            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 12 * 1024 - 128 - 8712 - 8 - 8, ArraySubType = UnmanagedType.U1)]
            public byte[] byRes;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct ICEMOD_MSG_NOTIFY
        {
            IntPtr hLogonServer;
            uint dwClientID;
            uint dwServerIP;
            uint dwServerPort;
            public ICE_MOD_RESULT_S stIceModResult;

        }

        /*       const int ICE_VANA_FUNC_MAXNUM = 32;

               [StructLayoutAttribute(LayoutKind.Sequential)]
               public struct ICE_VANA_FUNCTION
               {
                   ICE_VANA_PARAM_S defparam;          //!< 缺省功能参数
                   int num_used;                   //!< 有效功能数目
                   [MarshalAsAttribute(UnmanagedType.ByValArray,SizeConst = ICE_VANA_FUNC_MAXNUM)]
                   ICE_VANA_FUNC[] funcs;//!< 分析功能数组

               }

               [StructLayoutAttribute(LayoutKind.Sequential)]
               public struct ICE_DTCA_PARAM_APP
               {
                   int dim_w;                          //!< 配置图像的宽度
                   int dim_h;                          //!< 配置图像的高度
                   ICE_VANA_FUNCTION functions;            //!< 分析功能
                   ICE_PAPA_VEXCEPT para_vexcept;          //!< 视频异常检测参数
       // #ifdef SUPPORT_IES
                   ICE_PARA_IMGES para_imges;              //!< 图像电子稳定参数
       // #endif
                   ICE_PARA_TGTOUT para_tgtout;            //!< 目标输出参数

               }

               [StructLayoutAttribute(LayoutKind.Sequential)]
               public struct ICE_DTCA_PARAM_ADV
               {
       // #ifdef ADVPARAM_DTCA
           // 背景建模
                   int bgm_multiple;					//!< 是否启用复杂背景建模(取值范围：0(否)，1(是)；缺省值：1)
                   int bgm_period;						//!< 是否启用周期运动背景建模(取值范围：0(否)，1(是)；缺省值：0)
                   int bgm_period_time;				//!< 周期运动时间(取值范围：1～60秒；缺省值：15)
                   int bgm_period_noise;				//!< 周期运动噪声(取值范围：0(低)，1(高)；缺省值：0)
           // 检测灵敏度
                   int sensi_high_noise;				//!< 是否高噪声(取值范围：0(否)，1(是)；缺省值：0)
                   int sensi_low_contrast;				//!< 是否低对比度(取值范围：0(否)，1(是)；缺省值：0)
           // 跟踪灵敏度
                   int init_min_time;                  //!< 目标初始化最短时间(取值范围：100～4000毫秒；缺省值：1000)
                   int sensi_mtrend;                   //!< 目标运动趋势门限(0：高，1：中，2：低；缺省值：1)
           // 光影抑制
                   int supfg_light;			        //!< 启用光影前景抑制(取值范围：0(否)，1(是)；缺省值：1)
                   int supfglt_suppress;		        //!< 进行光影前景抑制(取值范围：0(否)，1(是)；缺省值：1)
                   int supfglt_determine;		        //!< 进行光照区域判断(取值范围：0(否)，1(是)；缺省值：0)
                   [MarshalAsAttribute(UnmanagedType.ByValArray,SizeConst = 9,ArraySubType = UnmanagedType.I4)]
                   int[] dtca_reserved;				//!< 保留字段
       // #endif

       // #ifdef ADVPARAM_MODH
           // MODH参数
                   int scene_mode;						//!< 场景模式(取值范围：0(室内)，1(室外)；缺省值：0)
                   int sensitivity;					//!< 灵敏度(0：高，1：中，2：低；缺省值：1)
                   int use_caminfo;					//!< 是否使用相机信息(取值范围：0(否)，1(是)；缺省值：1)
                   int use_posinfo;					//!< 是否使用位置信息(取值范围：0(否)，1(是)；缺省值：1)
                   int cam_fov_vert;					//!< 相机垂直视场角(取值范围：0～180度；缺省值：50)
                   int cam_height;						//!< 相机安装高度(取值范围：0～300厘米；缺省值：160)
                   int tolerance_rat;					//!< 参数容差比率(取值范围：0～50；缺省值：20)
                   int tgt_height_min;					//!< 目标最小高度(取值范围：0～400厘米；缺省值：150)
                   int view_dis_max;					//!< 视场最远距离(取值范围：0～2000厘米；缺省值：1000)
                   int reftgt_height;					//!< 参考目标高度(取值范围：0～400厘米；缺省值：0)
                   int reftgt_pos_hy;					//!< 参考目标头顶位置(取值范围：0～1000像素；缺省值：0)
                   int reftgt_pos_fy;					//!< 参考目标脚底位置(取值范围：0～1000像素；缺省值：0)
                   [MarshalAsAttribute(UnmanagedType.ByValArray,SizeConst = 8,ArraySubType = UnmanagedType.I4)]
                   int[] modh_reserved;				//!< 保留字段
       // #endif

           // 头部检测
                   int detect_head;                    //!< 是否检测头部(取值范围：0(否)，1(是)；缺省值：0)
                   int vote_mode;                      //!< 投票模式(取值范围：bit0(对黑区域投票) ，bit1(对白区域投票)；缺省值：1)
                   int vote_ratio;                     //!< 投票计数比率阈值(取值范围：0～500；缺省值：80)
                   int circonf_rat;                    //!< 圆置信度比率(取值范围：0～100；缺省值：20)
                   [MarshalAsAttribute(UnmanagedType.ByValArray,SizeConst = 16,ArraySubType = UnmanagedType.I4)]
                   int[] head_reserved;				//!< 保留字段

               }

               [StructLayoutAttribute(LayoutKind.Sequential)]
               public struct ICE_DTCA_PARAM_ALGO
               {
                   ICE_DTCA_PARAM_APP cParamApp;           //!< 应用参数
                   int s32UseAdvParam;                 //!< 是否使用高级参数
                   ICE_DTCA_PARAM_ADV cParamAdv;           //!< 高级参数

               }

               [StructLayoutAttribute(LayoutKind.Sequential)]
               public struct ICE_DTCA_PARAM_INOUT
               {
                   int s32Width;                       //!< 图像宽度
                   int s32Height;                      //!< 图像高度
                   uint u32FrameTime;                   //!< 图像帧的时间长度（单位：毫秒）

               }

               [StructLayoutAttribute(LayoutKind.Sequential)]
               public struct ICE_DTCA_PARAM
               {
                   ICE_DTCA_PARAM_INOUT cParamInout;       //!< 算法IO参数
                   ICE_DTCA_PARAM_ALGO cParamAlgo;         //!< 算法处理参数

               }

               [StructLayoutAttribute(LayoutKind.Sequential)]
               public struct ICE_MOD_PARAMS
               {
                   ICE_DTCA_PARAM stDtcaParam;		//周界参数	 
                   [MarshalAsAttribute(UnmanagedType.ByValArray,SizeConst = 10 * 1024 - 9356,ArraySubType = UnmanagedType.U1)]
                   byte[]		   szRes1;
	
                   ICE_CLBR_PARAM stClbrParam;		//标定参数	152
                   byte		   bModU;			//0: modp    1: modu(3516 modu)(3518 modu)
                   [MarshalAsAttribute(UnmanagedType.ByValArray,SizeConst = 2 * 1024 - 152 - 128 - 1,ArraySubType = UnmanagedType.U1)]
                   byte[]		   szRes2;

               }*/


        public delegate int ChannelStreamCallback(IntPtr hOpenChannel, IntPtr pStreamData, uint dwClientID, IntPtr pContext, ENCODE_VIDEO_TYPE encodeVideoType, ref YW7000AVDefine.HHAV_INFO pAVInfo);

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HHOPEN_CHANNEL_INFO
        {
            public uint dwClientID;
            public uint nOpenChannel;
            public NET_PROTOCOL_TYPE protocolType;
            public ChannelStreamCallback funcStreamCallback;
            public IntPtr pCallbackContext;

        }

        public delegate int PictureCallback(IntPtr hPictureChn, IntPtr pPicData, int nPicLen, uint dwClientID, IntPtr pContext);

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HHOPEN_PICTURE_INFO
        {
            public uint dwClientID;
            public uint nOpenChannel;
            public NET_PROTOCOL_TYPE protocolType;
            public PictureCallback funcPictureCallback;
            public IntPtr pCallbackContext;

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HH_PICTURE_INFO
        {
            public IntPtr hOpenChannel;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = MAX_IP_NAME_LEN + 1)]
            public string szServerIP;
            public uint nServerPort;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DVS_NAME_LEN + 1)]
            public string szDeviceName;

            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_NAME_LEN + 1)]
            public string szUserName;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_PASSWD_LEN + 1)]
            public string szUserPassword;

            public uint dwClientID;

            public CONNECT_STATUS openStatus;
            public uint nVersion;
            public uint nOpenID;
            public uint nPriority;
            public uint nOpenChannelNo;
            public uint nMulticastAddr;
            public uint nMulticastPort;
            public uint nPicWidth;
            public uint nPicHeight;
            public uint nPicBits;
            public int picFormatType;//0:JPEG,1:BMP

            public NET_PROTOCOL_TYPE protocolType;
            public PictureCallback funcStreamCallback;
            public IntPtr pCallbackContext;

            public uint dwDeviceID;

        }

        [StructLayoutAttribute(LayoutKind.Explicit)]
        public struct DNS_IP
        {
            [FieldOffset(0)]
            uint DdnsIP2;						//DDNS 2的IP,非网络字节次序
            [FieldOffset(0)]
            uint DNSHostIP2;						//DNS  2
        }

        const int PPPPOE_NAME_LEN = 32;
        const int PPPPOE_PASSWD_LEN = 16;
        const int DDNS_NAME_LEN = 32;
        const int DDNS_PASS_LEN = 16;
        const int DDNS_SERVER_NAME_LEN = 32;
        const int MAX_SENSOR_NUM = 4;
        public const int MAX_SDKLIST_COUNT = 432;

        const int WHITELIST_VALID_TIME_LEN = 10;

        const int ICE_VLPR_PLATE_CHAR_NUM = 7;				//!<  车牌字符数
        const int ICE_VLPR_PLATE_BUFLEN = 16;              //!<  车牌号最大值


        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct NET_CONFIG
        {
            public uint IPAddr;						//IP地址
            public uint SubNetMask;					//掩码
            public uint GateWay;						//网关

            public ushort ComPortNo;						//设置接收客户端命令端口号        UDP	
            public ushort WebPortNo;						//Webserver端口     			  TCP
            public uint MultiCastIPAddr;				//多播IP地址
            public ushort MultiCastPortNo;				//UDP传输起始端口<多播传输>
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.U1)]
            public byte[] RT8139MAC;      				//人工设置网卡的MAC地址		5---0有效
            public byte DHCP;							//DHCP 开关					0	关		1:开

            public byte PppoeOpen;						//PPPOE 开关     	
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = PPPPOE_NAME_LEN + 1)]
            public string PppoeName;	//拨号用户名
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = PPPPOE_PASSWD_LEN + 1)]
            public string PppoePass; //拨号密码	
            public uint PppoeTimes;   					//在线时间
            public uint PppoeIPAddr;					//PPPOEIP地址		报警回传IP	

            public uint DdnsOpen;						//DDNS开关
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DDNS_NAME_LEN + 1)]
            public string DdnsName;		//注册主机名称
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DDNS_PASS_LEN + 1)]
            public string DdnsPass;		//注册主机密码	

            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DDNS_SERVER_NAME_LEN + 1)]
            public string DdnsIP;	//DDNS服务器
            public byte DdnsRefreshMode;


            public ushort DdnsPortNo;						//DDNS服务器端口
            public ushort DdnsMapWebPort;					//本地WEB映射端口
            public ushort DdnsMapDataPort;				//本地数据映射端口

            public uint DNSHostIP;						//DNS的IP

            public int ConnectCenter;					//是否主动连接中心
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DDNS_SERVER_NAME_LEN + 1)]
            public string ConnectCenterIP;//中心IP
            public ushort ConnectCenterPort;						//中心端口

            public ushort appFunction;					//实现功能定义,以bit位表示:0-PPPOE,1-NTP,2-UPNP,3-WF,4-MAIL,5-定向发送，6:-无线探头 8-带存储功能
            public byte tcpSendInterval;
            public byte udpSendInterval;
            public ushort PacketMTU;

            public byte CaptureMode;					//抓拍模式
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_SENSOR_NUM, ArraySubType = UnmanagedType.U1)]
            public byte[] CapturePort;	//抓拍通道(0-3bit: 分别表示1 ~ 4号通道  1:开  0: 关)
            public DNS_IP DnsIP;

            public ushort DdnsPortNo2;					//DDNS 2的端口
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DVS_NAME_LEN + 1)]
            public string sysByname;		//域名
            public byte domainSetState;					//0－成功；1－名字存在，修改新域名；2－正在申请；3－失败

        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HH_TALK_INFO
        {
            public IntPtr hServer;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = MAX_IP_NAME_LEN + 1)]
            public string szServerIP;
            public uint nServerPort;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = DVS_NAME_LEN + 1)]
            public string szDeviceName;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_NAME_LEN + 1)]
            public string szUserName;
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = USER_PASSWD_LEN + 1)]
            public string szUserPassword;
            public IntPtr pTalkContext;
            public DVS_MACHINE_TYPE nMachineType;
            public CONNECT_STATUS logonStatus;
            public uint nAudioEncodeType;
            public uint nAudioChannels;
            public uint nAudioBits;
            public uint nAudioSamples;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct OUTPUT_CTRL
        {
            public byte ChannelNo;
            public byte Status;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct COM_CONFIG
        {
            public uint Baudrate;
            public byte Databit;
            public byte Stopbit;
            public byte CheckType;
            public byte Flowctrl;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct COMM_CTRL
        {
            public byte COMMNo;
            public COM_CONFIG COMConfig;
            public ushort DataLength;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 256, ArraySubType = UnmanagedType.U1)]
            public byte[] Data;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct COMM_DATA_NOTIFY
        {
            public IntPtr hLogonServer;
            public uint dwClientID;
            public uint dwServerIP;
            public uint dwServerPort;
            public COMM_CTRL commCtrl;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct WHITELIST_ITEM_S
        {
            [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = ICE_VLPR_PLATE_BUFLEN)]
            public string szPlateNumber;
            public uint stBgnTime;
            public uint stEndTime;
            public byte bEnable;
            public byte byLicenseType;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 2, ArraySubType = UnmanagedType.U1)]
            public byte[] byRes;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct CAR_WHITELIST_INFO_S
        {
            public ushort dwSize;
            public ushort bEnable;
            public uint wFrom;
            public uint dwCount;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = MAX_SDKLIST_COUNT)]
            public WHITELIST_ITEM_S[] stWhitelist;
            public byte bFinished;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 31, ArraySubType = UnmanagedType.U1)]
            public byte[] byRes;
        }

        public static DateTime GetDateTimeFromValue(uint dwValue)
        {
            int nYear, nMonth, nDay, nHour, nMinute, nSecond;
            nSecond = (int)(dwValue & 0x3F); //6bits
            nMinute = (int)(dwValue >> 6) & 0x3F; //6bits
            nHour = (int)(dwValue >> 12) & 0x1F;    //5bits
            nDay = (int)(dwValue >> 17) & 0x1F; //5bits
            nMonth = (int)(dwValue >> 22) & 0x0F; //4bits
            nYear = (int)((dwValue >> 26) & 0x3F) + 2000; //6bits
            return new DateTime(nYear, nMonth, nDay, nHour, nMinute, nSecond);
        }

        public static uint GetValueFromDateTime(DateTime stValue)
        {
            uint dwValue;
            dwValue = 0;
            dwValue = (uint)stValue.Second;
            dwValue |= (uint)(stValue.Minute << 6);
            dwValue |= (uint)(stValue.Hour << 12);
            dwValue |= (uint)(stValue.Day << 17);
            dwValue |= (uint)(stValue.Month << 22);
            dwValue |= (uint)((stValue.Year - 2000) << 26);
            return dwValue;
        }

        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_Startup(IntPtr hNotifyWnd, uint nCommandID, uint dwFrameBufNum, bool bReadyRelay, bool bReadyCenter, string pLocalAddr);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_Cleanup();
        public delegate int MessageNotifyCallback(IntPtr wParam, IntPtr lParam);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_MessageCallback(MessageNotifyCallback pCallback);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_LogonServer(string pServerIP, ushort wServerPort, string pDeviceName, string pUserName, string pUserPassword, uint dwClientID, out IntPtr hLogonServer, IntPtr hNotifyWindow);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_LogoffServer(IntPtr hServer);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_GetServerConfig(IntPtr hServer, HHCMD_NET nConfigCommand, IntPtr pConfigBuf, ref uint nConfigBufSize, ref uint pAppend);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_SetServerConfig(IntPtr hServer, HHCMD_NET nConfigCommand, IntPtr pConfigBuf, uint nConfigBufSize, uint dwAppend);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_OpenChannel(string pServerIP, ushort wServerPort, string pDeviceName, string pUserName, string pUserPassword, ref  HHOPEN_CHANNEL_INFO pOpenInfo, out IntPtr hOpenChannel, IntPtr hNotifyWindow);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_CloseChannel(IntPtr hOpenChannel);

        public delegate void CallbackServerFind(DVS_MACHINE_TYPE nDeviceType, string pDeviceName,
                                                          string pIP, IntPtr macAddr, ushort wPortWeb, ushort wPortListen, string pSubMask,
                                                          string pGateway, string pMultiAddr, string pDnsAddr, ushort wMultiPort, int nChannelNum, int nFindCount, uint dwDeviceID);


        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_SearchAllServer(uint nTimeWait, CallbackServerFind pCallback);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_OpenPicture(string pServerIP, ushort wServerPort, string pDeviceName, string pUserName, string pUserPassword, ref  HHOPEN_PICTURE_INFO pOpenInfo, out IntPtr hOpenChannel, IntPtr hNotifyWindow);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_ClosePicture(IntPtr hOpenPicture);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_CapturePicture(IntPtr hOpenPicture);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_ReadPictureInfo(IntPtr hOpenPicture, out  HH_PICTURE_INFO pictureInfo);

        public delegate int TalkStreamCallback(IntPtr hOpenChannel, IntPtr pTalkData, uint nTalkDataLen, IntPtr pContext);

        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_TalkRequsest(string pServerIP, ushort wServerPort, string pDeviceName, string pUserName, string pUserPassword, TalkStreamCallback funcTalkCallback, IntPtr pContext, out IntPtr hTalk, IntPtr hNotifyWindow);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_TalkStop(IntPtr hTalk);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_TalkReadInfo(IntPtr hTalk, ref HH_TALK_INFO talkInfo);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_TalkSend(IntPtr hTalk, IntPtr pTalkData, uint nDataLen);
        [DllImport(dllname)]
        public static extern HHERR_CODE YW7000NET_ReadServerInfo(IntPtr hServer, ref HH_SERVER_INFO pServerInfo);


        public static void Sen485(IntPtr hLogon, byte[] bSend)
        {
            YW7000NetClient.COMM_CTRL nCOMMCtrl = new YW7000NetClient.COMM_CTRL();
            nCOMMCtrl.Data = new byte[256];
            //byte[] strSend = new byte[1024];
            uint nLength, len, comPort;
            int nDataPos, nData;
            string strTmp;
            HHERR_CODE nRet;

            len = (uint)Marshal.SizeOf(typeof(YW7000NetClient.COM_CONFIG));
            comPort = 0;
            IntPtr ptrComConfig = Marshal.AllocHGlobal((int)len);
            nRet = YW7000NetClient.YW7000NET_GetServerConfig(hLogon, HHCMD_NET.HHCMD_GET_COM_CONFIG, ptrComConfig, ref len, ref comPort);
            nCOMMCtrl.COMConfig = (YW7000NetClient.COM_CONFIG)Marshal.PtrToStructure(ptrComConfig, typeof(YW7000NetClient.COM_CONFIG));
            Marshal.FreeHGlobal(ptrComConfig);
            nCOMMCtrl.COMMNo = 0;
            nCOMMCtrl.DataLength = (ushort)bSend.Length;
            Array.Copy(bSend, nCOMMCtrl.Data, bSend.Length);
            nCOMMCtrl.COMConfig.Baudrate = uint.Parse("9600");
            nCOMMCtrl.COMConfig.Databit = byte.Parse("8");
            nCOMMCtrl.COMConfig.Stopbit = byte.Parse("1");
            IntPtr ptrCommCtrl = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(YW7000NetClient.COMM_CTRL)));
            Marshal.StructureToPtr(nCOMMCtrl, ptrCommCtrl, false);
            nRet = YW7000NetClient.YW7000NET_SetServerConfig(hLogon, HHCMD_NET.HHCMD_SET_COMM_SENDDATA, ptrCommCtrl, (uint)Marshal.SizeOf(typeof(YW7000NetClient.COMM_CTRL)), 0);
            Marshal.FreeHGlobal(ptrCommCtrl);
        }


        public static int Whitelist(IntPtr hLogon, DataTable dt)
        {
            int i, j, Count, Index;
            YW7000NetClient.CAR_WHITELIST_INFO_S stWhiteListInfo = new YW7000NetClient.CAR_WHITELIST_INFO_S();
            stWhiteListInfo.stWhitelist = new YW7000NetClient.WHITELIST_ITEM_S[YW7000NetClient.MAX_SDKLIST_COUNT];
            IntPtr ptrWhiteList = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(YW7000NetClient.CAR_WHITELIST_INFO_S)));
            uint dwAppend, config_len;
            HHERR_CODE errCode;
            config_len = (uint)Marshal.SizeOf(typeof(YW7000NetClient.CAR_WHITELIST_INFO_S));
            Count = dt.Rows.Count / YW7000NetClient.MAX_SDKLIST_COUNT;
            if ((dt.Rows.Count % YW7000NetClient.MAX_SDKLIST_COUNT) != 0)
                Count++;
            if (Count == 0) //没有白名单
            {
                dwAppend = 0;
                stWhiteListInfo.bEnable = 1;
                stWhiteListInfo.dwCount = 0;
                stWhiteListInfo.dwSize = (ushort)Marshal.SizeOf(typeof(YW7000NetClient.CAR_WHITELIST_INFO_S));
                stWhiteListInfo.wFrom = 0;
                stWhiteListInfo.bFinished = 1;
                Marshal.StructureToPtr(stWhiteListInfo, ptrWhiteList, true);
                errCode = YW7000NetClient.YW7000NET_SetServerConfig(hLogon, HHCMD_NET.HHCMD_SET_WHITELIST, ptrWhiteList, config_len, dwAppend);
                if (errCode != HHERR_CODE.HHERR_SUCCESS)
                {
                    //MessageBox.Show(string.Format("上传白名单失败,序号:{0},错误码:{1}!", 0, (int)errCode), "提示");
                }
                return -1;
            }
            for (i = 0; i < Count; i++)
            {
                dwAppend = (uint)i;

                stWhiteListInfo.bEnable = 1;

                stWhiteListInfo.dwCount = 0;
                stWhiteListInfo.dwSize = (ushort)Marshal.SizeOf(typeof(YW7000NetClient.CAR_WHITELIST_INFO_S));
                stWhiteListInfo.wFrom = (uint)i * YW7000NetClient.MAX_SDKLIST_COUNT;
                for (j = 0; j < YW7000NetClient.MAX_SDKLIST_COUNT; j++)
                {
                    Index = (int)(stWhiteListInfo.wFrom + j);
                    if (Index >= dt.Rows.Count)
                        break;


                    stWhiteListInfo.stWhitelist[j].szPlateNumber = dt.Rows[Index]["CPH"].ToString();
                    stWhiteListInfo.stWhitelist[j].stBgnTime = GetValueFromDateTime(Convert.ToDateTime(dt.Rows[Index]["StartTime"].ToString()));
                    stWhiteListInfo.stWhitelist[j].stEndTime = GetValueFromDateTime(Convert.ToDateTime(dt.Rows[Index]["EndTime"].ToString()));
                    stWhiteListInfo.stWhitelist[j].bEnable = 1;
                    stWhiteListInfo.stWhitelist[j].byLicenseType = 0;
                    stWhiteListInfo.dwCount++;
                }
                if (i == Count - 1)
                    stWhiteListInfo.bFinished = 1;
                else
                    stWhiteListInfo.bFinished = 0;
                Marshal.StructureToPtr(stWhiteListInfo, ptrWhiteList, true);
                errCode = YW7000NetClient.YW7000NET_SetServerConfig(hLogon, HHCMD_NET.HHCMD_SET_WHITELIST, ptrWhiteList, config_len, dwAppend);
                if (errCode != HHERR_CODE.HHERR_SUCCESS)
                {
                    return -1;
                    //MessageBox.Show(string.Format("上传白名单失败,序号:{0},错误码:{1}!", i, (int)errCode), "提示");
                   // break;
                }
                else
                {
                   // return 0;
                }

            }
            Marshal.FreeHGlobal(ptrWhiteList);
            return 0;
        }
    }
}
