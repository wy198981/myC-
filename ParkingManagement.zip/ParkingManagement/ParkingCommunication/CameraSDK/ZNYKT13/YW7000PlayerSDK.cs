﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ParkingCommunication.CameraSDK.ZNYKT13
{
    public class YW7000PlayerSDK
    {
        public const string dllname = @"ZNYKTY13\YW7000PlayerSDK.dll";

        [StructLayoutAttribute(LayoutKind.Sequential, Pack = 1)]
        public struct WAVEFORMATEX
        {
            public ushort wFormatTag;
            public ushort nChannels;
            public uint nSamplesPerSec;
            public uint nAvgBytesPerSec;
            public ushort nBlockAlign;
            public ushort wBitsPerSample;
            public ushort cbSize;
        }

        [DllImport(dllname)]
        public static extern int YW7000PLAYER_InitSDK(IntPtr hHwnd);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_ReleaseSDK();
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_InitPlayer(ushort nPort, IntPtr hWnd);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_ReleasePlayer(ushort nPort);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_OpenStream(ushort nPort);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_PutDecStreamDataEx(ushort nPort, IntPtr pBuf, uint nSize, ENCODE_VIDEO_TYPE nDataType, ref YW7000AVDefine.HHAV_INFO pAVInfo);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_SetAudio(ushort nPort, bool bEnabled);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_SetDecoderQulity(bool bQulity);				//0: 高质量  1: 低质量
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_InitPlayer2(ushort nPort,IntPtr hWnd,bool bSupportDraw);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_SetDrawPen(ushort nPort, int nPenStyle, int nWidth, uint crColor);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_DrawLine(ushort nPort, int x1, int y1, int x2, int y2);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_DrawRect(ushort nPort, int x1, int y1, int x2, int y2);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_ClearDraw(ushort nPort,int nType);					//nType: 0 all, 1 image, 2 text, 3 line, rect
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_CaptureOnePicture(ushort nPort,out IntPtr bmpbuf,out int bmpsize);	//捕捉当前的图像

          //================================================================
//文件播放
//================================================================
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_OpenStreamFileM(ushort nPort,IntPtr[] filelist, int filenum, ref uint nTimeLength);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_GetStreamFileInfo(ushort nPort,ref uint dwTimeLength, ref uint dwFileLength,ref uint dwWidth,ref uint dwHeight);  //得到文件信息
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_Play(ushort nPort);                      //播放
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_FastPlay(ushort nPort,uint nValue);     //快速播放  dwValue 1---1000之间毫秒
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_FastPlayBack(ushort nPort,uint nValue); //快退
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_FrameGO(ushort nPort);                   //单帧进
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_FrameBack(ushort nPort);                 //单帧退
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_Pause(ushort nPort);                     //暂停
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_Resume(ushort nPort);                    //继续
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_Stop(ushort nPort);                      //停止

        [DllImport(dllname)]
        public static extern int YW7000PLAYER_GetPlayPosition(ushort nPort,ref uint dwPlayedTime);			//得到播放的时间
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_SetPlayPosition(ushort nPort,float fOffset);					//设置播放位置
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_SeekToSecond(ushort nPort,int nSec);							//移动播放指针到指定秒
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_SetPlayLoop(ushort nPort,bool bIsLoop);						//循环播放
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_RegPlayStatusMsg(ushort nPort,IntPtr hWnd,uint MessageID);	//注册播放状态消息(1.H5PLAYER_MSG_PLAY_END:文件播放结束	2.播放进度:0 ~ 文件时间长度<秒)


        public delegate int HHTalkCaptureData(IntPtr pBuffer, int nBufLen, uint dwContext, IntPtr pContext);

        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKInit(  IntPtr hWnd, out IntPtr hTalk);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKRegCaptureDataCB(IntPtr hTalk,HHTalkCaptureData pCBTalk,uint dwContext,IntPtr pContext);

        

        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKStart( IntPtr hTalk,ref WAVEFORMATEX pInFormat, ref WAVEFORMATEX pOutFormat);  
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKStop(  IntPtr hTalk);

        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKSendToPCData(IntPtr hTalk, IntPtr pBuffer, int nBufLen);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKSetVolume(IntPtr hTalk, int lVolume);
        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKGetVolume(IntPtr hTalk, out int lpVolume);

        [DllImport(dllname)]
        public static extern int YW7000PLAYER_TKRelease(IntPtr hTalk);

    }
}
