﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ParkingCommunication.CameraSDK.ZNYKT13
{
    public enum ENCODE_VIDEO_TYPE
    {
        EV_TYPE_NONE = 0xFFFF,
        EV_TYPE_PAL_D1 = 0x00,		//PAL制D1		704 * 576
        EV_TYPE_PAL_HD1 = 0x01,		//PAL制HalfD1	704 * 288
        EV_TYPE_PAL_CIF = 0x02,		//PAL制CIF		352 * 288
        EV_TYPE_VGA = 0x03,		//VGA			640 * 480
        EV_TYPE_HVGA = 0x04,		//HVGA			640 * 240
        EV_TYPE_CVGA = 0x05,		//CVGA			320 * 240
        EV_TYPE_PAL_QCIF = 0x06,		//PAL制QCIF		176 * 144
        EV_TYPE_QVGA = 0x07,		//QVGA			160 * 120
        EV_TYPE_NTSC_D1 = 0x08,		//N制D1			704 * 480
        EV_TYPE_NTSC_HD1 = 0x09,		//N制HalfD1		704 * 240
        EV_TYPE_NTSC_CIF = 0x0A,		//N制CIF		352 * 240
        EV_TYPE_NTSC_QCIF = 0x0E,		//N制QCIF		176 * 120

        //H.264
        EV_H264_PAL_D1 = 0x10,		//H264_2,PAL制D1		704 * 576
        EV_H264_PAL_HD1 = 0x11,		//H264_2,PAL制HalfD1	704 * 288
        EV_H264_PAL_CIF = 0x12,		//H264_2,PAL制CIF		352 * 288
        EV_H264_VGA = 0x13,		//H264_2,VGA			640 * 480
        EV_H264_HVGA = 0x14,		//H264_2,HVGA			640 * 240
        EV_H264_CVGA = 0x15,		//H264_2,CVGA			320 * 240
        EV_H264_PAL_QCIF = 0x16,		//H264_2,PAL制QCIF		176 * 144
        EV_H264_QVGA = 0x17,		//H264_2,QVGA			160 * 120
        EV_H264_NTSC_D1 = 0x18,		//H264_2,N制D1			704 * 480
        EV_H264_NTSC_HD1 = 0x19,		//H264_2,N制HalfD1		704 * 240
        EV_H264_NTSC_CIF = 0x1A,		//H264_2,N制CIF			352 * 240
        EV_H264_NTSC_QCIF = 0x1E,		//H264_2,N制QCIF		176 * 120

        //标准MPEG4
        EV_MPEG4_PAL_D1 = 0x20,		//PAL制D1				704 * 576
        EV_MPEG4_PAL_HD1 = 0x21,		//PAL制HalfD1			704 * 288
        EV_MPEG4_PAL_CIF = 0x22,		//PAL制CIF				352 * 288
        EV_MPEG4_VGA = 0x23,		//VGA					640 * 480
        EV_MPEG4_HVGA = 0x24,		//HVGA					640 * 240
        EV_MPEG4_CVGA = 0x25,		//CVGA					320 * 240
        EV_MPEG4_PAL_QCIF = 0x26,		//PAL制QCIF				176 * 144
        EV_MPEG4_QVGA = 0x27,		//QVGA					160 * 120
        EV_MPEG4_NTSC_D1 = 0x28,		//N制D1					704 * 480
        EV_MPEG4_NTSC_HD1 = 0x29,		//N制HalfD1				704 * 240
        EV_MPEG4_NTSC_CIF = 0x2A,		//N制CIF				352 * 240
        EV_MPEG4_NTSC_QCIF = 0x2E,		//N制QCIF				176 * 120

        //MJPEG
        EV_MJPEG_PAL_D1 = 0x30,     //MJPEG,PAL制D1        704 * 576
        EV_MJPEG_PAL_HD1 = 0x31,     //MJPEG,PAL制HalfD1    704 * 288
        EV_MJPEG_PAL_CIF = 0x32,     //MJPEG,PAL制CIF       352 * 288
        EV_MJPEG_VGA = 0x33,     //MJPEG,VGA            640 * 480
        EV_MJPEG_HVGA = 0x34,     //MJPEG,HVGA           640 * 240
        EV_MJPEG_CVGA = 0x35,     //MJPEG,CVGA           320 * 240
        EV_MJPEG_PAL_QCIF = 0x36,     //MJPEG,PAL制QCIF      176 * 144
        EV_MJPEG_QVGA = 0x37,     //MJPEG,QVGA           160 * 120
        EV_MJPEG_NTSC_D1 = 0x38,     //MJPEG,N制D1          704 * 480
        EV_MJPEG_NTSC_HD1 = 0x39,     //MJPEG,N制HalfD1      704 * 240
        EV_MJPEG_NTSC_CIF = 0x3A,     //MJPEG,N制CIF         352 * 240
        EV_MJPEG_NTSC_QCIF = 0x3E,     //MJPEG,N制QCIF        176 * 120

        //JPEG
        EV_JPEG_PAL_D1 = 0x40,     //JPEG,PAL制D1        704 * 576
        EV_JPEG_PAL_HD1 = 0x41,     //JPEG,PAL制HalfD1    704 * 288
        EV_JPEG_PAL_CIF = 0x42,     //JPEG,PAL制CIF       352 * 288
        EV_JPEG_VGA = 0x43,     //JPEG,VGA            640 * 480
        EV_JPEG_HVGA = 0x44,     //JPEG,HVGA           640 * 240
        EV_JPEG_CVGA = 0x45,     //JPEG,CVGA           320 * 240
        EV_JPEG_PAL_QCIF = 0x46,     //JPEG,PAL制QCIF      176 * 144
        EV_JPEG_QVGA = 0x47,     //JPEG,QVGA           160 * 120
        EV_JPEG_NTSC_D1 = 0x48,     //JPEG,N制D1          704 * 480
        EV_JPEG_NTSC_HD1 = 0x49,     //JPEG,N制HalfD1      704 * 240
        EV_JPEG_NTSC_CIF = 0x4A,     //JPEG,N制CIF         352 * 240
        EV_JPEG_NTSC_QCIF = 0x4E,     //JPEG,N制QCIF        176 * 120

        //
        EA_G722_S16B16C1 = 0x0100,	//音频，G722
        EA_G711A_S16B16C1 = 0x0200,	//音频，G711A
        EA_G711MU_S16B16C1 = 0x0300,	//音频，G711MU
        EA_ADPCM_S16B16C1 = 0x0400,	//音频，ADPCM
        EA_G726_S16B16C1 = 0x0500,	//音频，G726
        EA_BUTT_S16B16C1 = 0x0600,	//音频，BUTT
        EA_MPT_S16B16C1 = 0x0700,	//音频，MPT
    }

    public enum eFrameType
    {
        MY_FRAME_TYPE_A = 0x0d,				//音频帧
        MY_FRAME_TYPE_I = 0x0e,				//视频的I帧
        MY_FRAME_TYPE_P = 0x0b				//视频的P帧
    }

    public class YW7000AVDefine
    {
        const int HH_EXT_HEAD_FLAG = 0x06070809;
        const int HH_EXT_TAIL_FLAG = 0x0a0b0c0d;
        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HHAV_INFO
        {
            //视频参数
            public uint nVideoEncodeType;		//视频编码格式
            public uint nVideoHeight;			//视频图像高
            public uint nVideoWidth;			//视频图像宽
            //音频参数
            public uint nAudioEncodeType;		//音频编码格式
            public uint nAudioChannels;			//通道数
            public uint nAudioBits;				//位数
            public uint nAudioSamples;			//采样率
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct EXT_FRAME_VIDEO
        {
	        public ushort	nVideoEncodeType;	//视频编码算法
	        public ushort	nVideoWidth;		//视频图像宽
	        public ushort	nVideoHeight;		//视频图像高
	        public byte     cPal;               //制式
	        public byte     cTwoFeild;          //是否是两场编码（如果是两场编码，PC端解码需做deinterlace）
	        public uint     dwReserved1;
            public uint     dwReserved2;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct EXT_FRAME_AUDIO
        {
	        public ushort	nAudioEncodeType;	//音频编码算法
	        public ushort	nAudioChannels;		//通道数
	        public ushort	nAudioBits;			//位数
	        public ushort   wReserved;
	        public uint	    nAudioSamples;		//采样率 	
	        public uint     nAudioBitrate;		//音频编码码率
        }

        [StructLayoutAttribute(LayoutKind.Explicit)]
        public struct EXT_FRAME_TYPE
        {
            [FieldOffset(0)]
            public EXT_FRAME_VIDEO  szFrameVideo;
            [FieldOffset(0)]
            public EXT_FRAME_AUDIO  szFrameAudio;
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct EXT_FRAME_HEAD
        {
            public uint	    nStartFlag;			//扩展帧头起始标识
            public ushort	nVer;				//版本
            public ushort	nLength;			//扩展帧头长度
	        public EXT_FRAME_TYPE	szFrameInfo;		
	        public uint     nTimestamp;			//以毫秒为单位的时间戳
	        public uint	    nEndFlag;			//扩展帧头起始标识

	        public bool CheckExtFlag()
	        {
		        return (HH_EXT_HEAD_FLAG == nStartFlag && HH_EXT_TAIL_FLAG == nEndFlag ) ? true:false;
	        }
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HV_FRAME_HEAD
        {
	        public ushort	zeroFlag;				// 0
	        public byte     oneFlag;				// 1
	        public byte	    streamFlag;				// 数据帧标志 FRAME_FLAG_VP，FRAME_FLAG_VI，FRAME_FLAG_A
	
	        public uint	    nByteNum;				//数据帧大小
	        public uint	    nTimestamp;				//时间戳
        }
    }
}
