﻿using System;
using System.Runtime.InteropServices;

namespace ParkingCommunication.CameraSDK.ZNYKT13
{
    public enum eHHFrameType
    {
        eType_Frame_A = 0x0d,
        eType_Frame_I = 0x0e,
        eType_Frame_P = 0x0b
    }
    public enum eWriteFileStatus
    {
        eStatus_CreateFileSuccess = 1,
        eStatus_CloseFileSuccess = 2,
        eStatus_CreateFileError = -1,
        eStatus_WriteFileError = -2
    }
    public class HHReadWriter
    {
        public const string dllname = @"ZNYKTY13\HHReadWriterSDK.dll";
        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct HHFILEINFO
        {
            public uint dwFileSize;
            public uint dwPlayTime;
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 2, ArraySubType = UnmanagedType.U4)]
            public uint[] dwReserve;
        };

        public delegate int HHWriteFileCB(string strFileName,uint dwStatus,ref HHFILEINFO pFileInfo,IntPtr pContext);

        //初始化写
        [DllImport(dllname)]
         public static extern IntPtr HHFile_InitWriter();
        //释放
        [DllImport(dllname)]
         public static extern int HHFile_ReleaseWriter(IntPtr hWriter);
        //设置BUFFER大小
        [DllImport(dllname)]
        public static extern int HHFile_SetCacheBufferSize(IntPtr hWriter, int lBufferSize);
        //写
        [DllImport(dllname)]
        public static extern int HHFile_RegWriteFileCB(IntPtr hWriter, HHWriteFileCB pCBWriteFile, IntPtr pContext);
        //输入一帧
        [DllImport(dllname)]
        public static extern int HHFile_InputFrame(IntPtr hWriter, IntPtr pFrame, int lFrameSize, uint dwEncType);
        //开始写
        [DllImport(dllname)]
        public static extern int HHFile_StartWrite(IntPtr hWriter, string strFileName);
        //取得写信息
        [DllImport(dllname)]
        public static extern int HHFile_GetWriteInfo(IntPtr hWriter, ref HHFILEINFO xFileInfo);
        //停止写
        [DllImport(dllname)]
        public static extern int HHFile_StopWrite(IntPtr hWriter);

    }
}