﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingCommunication.CameraSDK.ZNYKT5
{
    public class VzSendPort
    {
        /// <summary>
        /// 语音发送
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public static byte[] LoadLsNoX2010znykt(byte JiHao, byte Order, byte SonOrder, string StrData)
        {
            int i;

            byte[] dateByte = GetArray(StrData);
            byte[] sendData = new byte[dateByte.Length + 8];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = JiHao;
            sendData[2] = JiHao;
            sendData[3] = Order;
            sendData[4] = Order;
            //                 if (Flag == 1 || Flag == 2|| Flag == 3)
            //                 {
            //                     sendData[5] = Convert.ToByte(sendData.Length + 1);
            //                     sendData[6] = Convert.ToByte(sendData.Length + 1);
            // 
            //                 }
            //                 else if (Flag == 0)
            //                 {
            sendData[5] = Convert.ToByte(dateByte.Length + 1);
            sendData[6] = Convert.ToByte(dateByte.Length + 1);
            // }
            sendData[7] = SonOrder;
            for (i = 8; i < dateByte.Length + 8; i++)//时间处理
            {
                sendData[i] = dateByte[i - 8];
            }
            return sendData;

        }

        /// <summary>
        /// 语音发送
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public static byte[] LoadLsNoX2010znykt(byte JiHao, byte Order, byte SonOrder, string StrData, int Flag)
        {
            int i;
            byte[] dateByte = GetArray(StrData);
            byte[] sendData = new byte[dateByte.Length + 8];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = JiHao;
            sendData[2] = JiHao;
            sendData[3] = Order;
            sendData[4] = Order;
            //                 if (Flag == 1 || Flag == 2|| Flag == 3)
            //                 {
            //                     sendData[5] = Convert.ToByte(sendData.Length + 1);
            //                     sendData[6] = Convert.ToByte(sendData.Length + 1);
            // 
            //                 }
            //                 else if (Flag == 0)
            //                 {
            sendData[5] = Convert.ToByte(dateByte.Length + 1);
            sendData[6] = Convert.ToByte(dateByte.Length + 1);
            // }
            sendData[7] = SonOrder;
            for (i = 8; i < dateByte.Length + 8; i++)//时间处理
            {
                sendData[i] = dateByte[i - 8];
            }

            return sendData;
        }

        /// <summary>
        /// 显示屏控制命令,一路顺风
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <param name="Flag">协议</param>
        /// <returns></returns>
        public static byte[] ShowLed55(int JiHao, string strData, int Flag)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            //byte[] dateByte = GetAsciiShow(strData);
            byte[] sendData = new byte[byteJihao.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = 1;
            sendData[byteJihao.Length + 4] = 1;
            sendData[byteJihao.Length + 5] = 0x55;

            return sendData;

        }


        /// <summary>
        /// 语音 
        /// 42：欢迎光临 
        /// 46：此卡过期  
        /// 48：此卡无效  
        /// 4C：此卡已入场 
        /// 4F：此卡禁止入场 
        /// 57：此卡已出场
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">指令</param>
        /// <returns></returns>
        public static byte[] VoiceLoad(int JiHao, string strData, int Flag)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetArray(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 5];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = 0x01;
            sendData[byteJihao.Length + 4] = 0x01;
            for (int i = byteJihao.Length + 5; i < byteJihao.Length + 5 + dateByte.Length; i++)
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 5)];
            }
            return sendData;
        }


        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="Ziling"></param>
        /// <param name="iZ"></param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public static byte[] SendCommand(int JiHao, int Ziling, int iZ, int Flag)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            byte[] byteZhiling = GetByteArray(Ziling);
            byte[] byteiZ = GetByteArray(iZ.ToString());
            byte[] sendData = new byte[byteJihao.Length + byteZhiling.Length + byteiZ.Length + 3];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x34;
            sendData[byteJihao.Length + 2] = 0x34;
            for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteZhiling.Length; i++)//时间处理
            {
                sendData[i] = byteZhiling[i - (byteJihao.Length + 3)];
            }
            for (int i = byteJihao.Length + 3 + byteZhiling.Length; i < byteJihao.Length + byteZhiling.Length + 3 + byteiZ.Length; i++)//时间处理
            {
                sendData[i] = byteiZ[i - (byteJihao.Length + 3 + byteZhiling.Length)];
            }
            return sendData;
        }
        /// <summary>
        /// 显示屏控制命令,报语音，可用日期XX日
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <returns></returns>
        public static byte[] SendFullCW(int JiHao, int strData, byte zhiling, int Flag)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetByteArray(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 5] = zhiling;
            for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 6)];
            }
            return sendData;
        }



        /// <summary>
        /// 显示屏控制命令,报语音，可用日期XX日
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <returns></returns>
        public static byte[] ShowLed(int JiHao, string strData, byte zhiling, int Flag)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetAsciiShow(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 5] = zhiling;
            for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 6)];
            }
            return sendData;
        }
        /// <summary>
        /// 显示屏控制命令,报语音“请交费XXXX元”
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <returns></returns>
        public static byte[] ShowLed(int JiHao, string strData, int Flag)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetAsciiShow(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 5] = 0x4A;
            for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 6)];
            }
            return sendData;
        }
        /// <summary>
        /// 控制机显示屏
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public static byte[] CtrlLedShow(byte JiHao, byte Order, byte SonOrder, string StrData, int Flag)
        {
            int i;

            byte[] dateByte = GetArray(StrData);
            byte[] sendData = new byte[dateByte.Length + 10];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = JiHao;
            sendData[2] = JiHao;
            sendData[3] = Order;
            sendData[4] = Order;
            sendData[5] = Convert.ToByte(dateByte.Length + 3);
            sendData[6] = Convert.ToByte(dateByte.Length + 3);
            sendData[7] = SonOrder;
            sendData[8] = Convert.ToByte(dateByte.Length);
            for (i = 9; i < dateByte.Length + 9; i++)//时间处理
            {
                sendData[i] = dateByte[i - 9];
            }
            sendData[dateByte.Length + 9] = YHXY(StrData);
            return sendData;
        }


        /// <summary>
        ///异或效验 
        /// </summary>
        /// <param name="strList"></param>
        /// <returns></returns>
        public static byte YHXY(string str)
        {
            string[] strList = Getstring(str);
            byte[] Hexbyte = new byte[strList.Length];
            byte check = 0;
            check = (byte)(Convert.ToByte(strList[0], 16) ^ Convert.ToByte(strList[1], 16));
            for (int i = 2; i < strList.Length; i++)
            {
                check = (byte)(check ^ Convert.ToByte(strList[i], 16));
            }
            string CheckSumHex = Convert.ToString(check, 16);
            if (CheckSumHex.Length == 1)
            {
                CheckSumHex = "0" + CheckSumHex;
            }
            return Convert.ToByte(CheckSumHex.ToUpper(), 16);
        }
        /// <summary>
        /// ASCII处理
        /// </summary>
        /// <param name="strAscii"></param>
        /// <returns></returns>
        public static byte[] GetAsciiShow(string strAscii)
        {

            byte[] byteDate = new byte[strAscii.Length];
            for (int i = 0; i < strAscii.Length; i++)
            {
                string sum = "";
                string strJihao = strAscii.Substring(i, 1);
                //int ac = Convert.ToInt32(strJihao, 16);
                // char chr = Convert.ToChar(ac);

                System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();

                byte[] aaa = asciiEncoding.GetBytes(strJihao);

                int intAsciiCode = (int)asciiEncoding.GetBytes(strJihao)[0];



                //return (intAsciiCode);

                //sum = chr.ToString();

                byteDate[i] = Convert.ToByte(Convert.ToString(intAsciiCode, 16), 16);
            }
            return byteDate;

        }
        /// <summary>
        /// 机号和扇区号处理
        /// </summary>
        /// <param name="number">int</param>
        /// <returns>返回byte[]类型</returns>
        public static byte[] GetByteArray(int number)
        {
            byte[] Nbtye = new byte[2];
            Nbtye[0] = Convert.ToByte(number.ToString());
            Nbtye[1] = Convert.ToByte(number.ToString());

            return Nbtye;
        }
        /// <summary>
        /// 机号和扇区号处理
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static byte[] GetByteArray(string number)
        {
            byte[] Nbtye = new byte[2];
            Nbtye[0] = Convert.ToByte(number.ToString(), 16);
            Nbtye[1] = Convert.ToByte(number.ToString(), 16);

            return Nbtye;
        }
        /// <summary>
        ///字符串转换为数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static byte[] GetArray(string str)
        {
            string[] HexStr = Getstring(str);
            byte[] Hexbyte = new byte[HexStr.Length];
            for (int j = 0; j < HexStr.Length; j++)
            {
                Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            }

            return Hexbyte;
        }

        public static string[] Getstring(string str)
        {
            List<String> al = new List<String>();
            for (int i = 0; i < str.Length / 2; i++)
            {
                string strJihao = str.Substring(i * 2, 2);
                al.Add(strJihao);
            }
            string s = string.Join(",", al.ToArray());
            string[] HexStr = s.Split(',');
            return HexStr;
        }
    }
}
