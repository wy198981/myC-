﻿using System;
using System.Runtime.InteropServices;

namespace ParkingCommunication.CameraSDK.ZNYKT11
{
    public class dvY
    {
        public const string dllname = @"ZNYKTY11\DVNetSDK.dll";

        //////////////////////////////////////////////////////////////////////////
        //  参数定义
        //////////////////////////////////////////////////////////////////////////
        public const Int32 DVERR_OK = 0;                    // 成功/无错误

        public const Int32 DV_IP_LEN = 128;                 // IP地址长度
        public const Int32 DV_NAME_LEN = 128;               // 名称长度

        public const Int32 DV_RESERVED_LEN = 64;            // 保留字段长度
        public const Int32 DV_MAX_PATH = 260;               // 最大文件路径长度
        public const Int32 DV_MAX_STREAM_COUNT = 4;         // 允许的设备最大流数目

        // [ 设备命令定义 ]
        public const Int32 DVCMD_OPEN_RELAY = 100;          // 打开继电器命令，详见：[ 打开/关闭继电器命令参数说明 ]
        public const Int32 DVCMD_CLOSE_RELAY = 101;         // 关闭继电器命令，详见：[ 打开/关闭继电器命令参数说明 ]
        public const Int32 DVCMD_OPEN_CLOSE_RELAY = 102;    // 脉动继电器命令，即：打开一段时间后自动关闭，详见：[ 脉动继电器命令参数说明 ]
        public const Int32 DVCMD_OPEN_GATE = 200;           // 开闸(门)操作，调用IO-F3(+/-)

        public const Int32 DV_PLT_TYPE_LEN = 256;           // 车牌类型长度
        public const Int32 DV_PLT_LEN = 32;                 // 车牌内容长度
        public const Int32 DV_PLT_CLR_LEN = 32;             // 车牌颜色长度

        // [ 打开/关闭继电器命令参数说明 ]
        // DV_Cmd:
        // 	nCmd   : DVCMD_OPEN_RELAY 或 DVCMD_CLOSE_RELAY
        // 	nParam : 继电器编号，从0开始

        // [ 脉动继电器命令参数说明 ]
        // DV_Cmd:
        // 	nCmd   : DVCMD_OPEN_CLOSE_RELAY
        // 	nParam : 继电器编号，从0开始
        // 	nParam2: 继电器保持时间，<= 0: 默认保持时间(500毫秒)，> 0: 实际保持时间，单位为毫秒

        // [ 解码帧格式定义 ]
        public const Int32 DV_FRAME_TYPE_AUDIO16 = 101;     // AUDIO16
        public const Int32 DV_FRAME_TYPE_AUDIO8 = 100;      // AUDIO8
        public const Int32 DV_FRAME_TYPE_UYVY = 1;          // UYVY
        public const Int32 DV_FRAME_TYPE_YV12 = 3;          // YV12
        public const Int32 DV_FRAME_TYPE_RGB32 = 7;         // RGB32

        // [ 抓拍模式定义 ]
        public const Int32 DV_SNAP_TO_CALLBACK = 0;         // 抓拍数据以回调函数返回
        public const Int32 DV_SNAP_TO_MEM = 1;              // 抓拍到内存
        public const Int32 DV_SNAP_TO_FILE = 2;             // 抓拍到文件


        // [ 网络参数模式定义 ]
        public const Int32 DV_NET_PARAM_SET = 0;            // 用户设定IP和DNS
        public const Int32 DV_NET_PARAM_AUTO = 1;           // 自动获取IP和DNS

        // [ 图片格式定义 ]
        public const Int32 DV_IMG_FMT_JPG = 0;              // JPG图片格式
        public const Int32 DV_IMG_FMT_BMP = 1;              // BMP图片格式

        // [ 车牌颜色定义 ]
        public const Int32 DV_PC_UNKNOWN = 0;               // 未知
        public const Int32 DV_PC_BLUE = 1;                  // 蓝底白字
        public const Int32 DV_PC_YELLOW = 2;                // 黄底黑字
        public const Int32 DV_PC_WHITE = 3;                 // 白底黑字
        public const Int32 DV_PC_BLACK = 4;                 // 黑底白字
        public const Int32 DV_PC_GREEN = 5;                 // 绿底白字

        // [ 车牌类型定义 ]
        public const Int32 DV_PT_UNKNOWN = 0;               // 不确定的
        public const Int32 DV_PT_BLUE = 1;                  // 蓝牌车
        public const Int32 DV_PT_YELLOW = 2;                // 单层黄牌车
        public const Int32 DV_PT_POLICE = 3;                // 警车
        public const Int32 DV_PT_WUJING = 4;                // 武警车辆
        public const Int32 DV_PT_DBYELLOW = 5;              // 双层黄牌
        public const Int32 DV_PT_MOTOR = 6;                 // 摩托车
        public const Int32 DV_PT_INSTRUCTIONCAR = 7;        // 教练车
        public const Int32 DV_PT_MILITARY = 8;              // 军车
        public const Int32 DV_PT_PERSONAL = 9;              // 个性化车
        public const Int32 DV_PT_GANGAO = 10;               // 港澳车
        public const Int32 DV_PT_EMBASSY = 11;              // 使馆车
        public const Int32 DV_PT_NONGLARE = 12;             // 老式车牌(不反光)

        // [ 智能模式触发类型定义 ]
        public const Int32 DV_SM_TRIGGER_NONE = 0;          // 空模式
        public const Int32 DV_SM_TRIGGER_SINGLEIO = 0x2;    // 卡口单IO触发
        public const Int32 DV_SM_TRIGGER_RS485 = 0x4;       // 卡口车检器触发
        public const Int32 DV_SM_TRIGGER_MPR = 0x40;        // 出入口视频触发

        // [ 日期时间格式化说明 ]
        // %d 每月的第几天             %f 毫秒数
        // %H 24小时制的小时           %I 12小时制的小时
        // %m 十进制表示的月份         %M 十时制表示的分钟数
        // %S 十进制的秒数             %t 水平制表符
        // %Y 带世纪部分的十制年份     %n 新行符
        // %% 百分号

        //////////////////////////////////////////////////////////////////////////
        //
        //  数据结构定义
        //
        //////////////////////////////////////////////////////////////////////////
        // 设备基本信息结构体
        public struct DV_DeviceGeneralInfo
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szIP;                             // 设备IP地址
            public int nPort;                               // 设备端口号

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_NAME_LEN)]
            public string szID;                             // 设备标识

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        };

        // 设备连接信息结构体
        public struct DV_DeviceCnnInfo
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szIP;                             // 设备IP地址
            public int nPort;                               // 设备端口号，如果小于等于0，使用默认：60000

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_NAME_LEN)]
            public string szUserName;                       // 登录用户名，如果为空，使用默认：admin
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_NAME_LEN)]
            public string szPassword;                       // 登录密码，如果为空，使用默认：admin
            public int nLoginTimeout;                       // 登录超时时间，单位为毫秒，如果小于等于0，使用默认：5000

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        };

        // 码流数据包结构体
        public struct DV_Packet
        {
            public int nDataType;                           // 数据类型,详见：[ 编码格式定义 ]

            public IntPtr pData;                            // 数据
            public int nDataLength;                         // 数据有效长度

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        };

        // 码流图像数据结构体
        public struct DV_Frame
        {
            public int nStamp;                              // 时标信息
            public int nType;                               // 数据类型，详见：[ 解码帧格式定义 ]

            public int nWidth;                              // 画面宽，单位为像素，如果是音频数据则为0
            public int nHeight;                             // 画面高，单位为像素，如果是音频数据则为0
            public IntPtr pData;                            // 数据
            public int nLength;                             // 数据长度

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        };

        // 设备控制命令结构体
        public struct DV_Cmd
        {
            public int nCmd;                                // 命令代码
            public int nParam;                              // 命令参数1
            public int nParam2;                             // 命令参数2

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        };

        // 解码器信息结构体
        public struct DV_DecoderInfo
        {
            public IntPtr hViewWnd;                         // 窗口句柄

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        };

        // 日期时间结构体
        public struct DV_DateTime
        {
            public int nYear;
            public int nMonth;
            public int nDay;
            public int nHour;
            public int nMinute;
            public int nSecond;
            public int nMilliseconds;
        };

        public struct DV_Date
        {
            public int nYear;
            public int nMonth;
            public int nDay;
        };

        public struct DV_Time
        {
            public int nHour;
            public int nMinute;
            public int nSecond;
            public int nMilliseconds;
        };

        // 卡口抓拍（全景图+单车牌）结构体
        public struct DV_CaptureInfo
        {
            public DV_DateTime time;                        // 抓拍发生时间

            public int bHasPlate;                           // 是否含有车牌 0: 无，1:有

            int nPlateType;                                 // 车牌类型
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_PLT_TYPE_LEN)]
            public string szPlateType;                      // 车牌类型名称

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_PLT_LEN)]
            public string szPlateText;                      // 车牌号码

            int nPlateColor;                                // 车牌颜色
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_PLT_CLR_LEN)]
            public string szPlateColor;                     // 车牌颜色名称

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public IntPtr[] pData;                          // 数据
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public int[] nLength;                           // 数据长度

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        } ;

        // 黑白名单子项结构体
        public struct DV_BWListItem
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_PLT_LEN)]
            public string szPlateText;                           // 车牌号码
            public DV_Date beginDate;                            // 有效期开始
            public DV_Date endDate;                              // 有效期结束
            public DV_Time dayBeginTime;                         // 每天有效开始时间
            public DV_Time dayEndTime;                           // 每天有效结束时间

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                          // 保留字段
        } ;
        //////////////////////////////////////////////////////////////////////////
        //
        // 回调函数定义
        //
        //////////////////////////////////////////////////////////////////////////
        // 功能: 返回码流原始数据包
        // 参数说明:
        //   hDevice        [IN] : 设备标识
        //   pPkt           [IN] : 码流数据包结构体指针
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无
        public delegate void DV_DataCallback(IntPtr hDevice, ref DV_Packet pPkt, IntPtr pUserData);

        // 功能: 返回解码后数据
        // 参数说明:
        //   hDevice        [IN] : 设备标识
        //   pFrame         [IN] : 解码后数据帧结构体指针
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无
        public delegate void DV_FrameCallback(IntPtr hDevice, ref DV_Frame pFrame, IntPtr pUserData);

        // 功能: 返回解码后数据
        // 参数说明:
        //   hDevice        [IN] : 设备标识
        //   pCaptureInfo   [IN] : 抓拍数据
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无

        public delegate void DV_CaptureCallback(IntPtr hDevice, ref DV_CaptureInfo pCaptureInfo, IntPtr pUserData);

        //////////////////////////////////////////////////////////////////////////
        //
        // 设备码流、抓拍、录像、命令等接口定义
        //
        //////////////////////////////////////////////////////////////////////////

        // 功能: 初始化SDK
        // 参数说明:
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_InitSDK();

        // 功能: 释放SDK
        // 参数说明:
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_ReleaseSDK();

        // 功能: 错误码文本消息获取接口
        // 参数说明:
        //   nErrCode       [IN] : 错误码
        //   pszMsgBuf      [OUT]: 消息缓存指针
        //   nMsgBufSize    [IN]:  消息缓存大小
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetErrorMessage(int nErrCode, IntPtr pszMsgBuf, int nMsgBufSize);

        // 功能: 根据设备IP和端口号等信息链接到设备，此接口在设备关闭前只允许执行一次
        // 参数说明:
        //   pCnnInfo       [IN] : 设备连接信息
        //   phDev          [OUT]: 输出设备句柄
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_OpenDevice(ref DV_DeviceCnnInfo pCnnInfo, ref IntPtr phDev);

        // 功能: 根据设备标识关闭已经打开的设备
        // 参数说明:
        //   hDev           [IN] : 设备标识
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_CloseDevice(IntPtr hDev);

        // 功能: 打开码流
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   nStreamID      [IN] : 码流编号
        //   hWnd           [IN] : 视频播放窗口句柄
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StartStream(IntPtr hDev, int nStreamID, IntPtr hWnd);

        // 功能: 关闭码流
        // 参数说明:
        //   hDev           [IN] : 设备标识
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StopStream(IntPtr hDev);

        // 功能: 设置数据回调
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pCbFun         [IN] : 回调函数
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetDataCallback(IntPtr hDev, DV_DataCallback pCbFun, IntPtr pUserData);

        // 功能: 设置解码数据回调
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pCbFun         [IN] : 解码数据回调
        //   pUserData      [IN] : 解码数据回调用户数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetFrameCallback(IntPtr hDev, DV_FrameCallback pCbFun, IntPtr pUserData);

        // 功能: 设置抓拍回调
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pCbFun         [IN] : 回调函数
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetCaptureCallback(IntPtr hDev, DV_CaptureCallback pCbFun, IntPtr pUserData);

        // 功能: 抓拍图片
        // 结果在回调函数中返回
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   nFormat        [IN] : 图片格式，
        //                  0：JPG，其他：暂不支持
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_Capture(IntPtr hDev, int nFormat);

        // 功能: 开始录像
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszFileName    [IN] : 录像文件名称
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StartRecording(IntPtr hDev, string pszFileName);

        // 功能: 开始自动录像
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszFileName    [IN] : 录像文件名称，带格式，详见：[ 日期时间格式化说明 ]
        //   nCycle         [IN] : 单个录像文件周期，
        //                  <= 0 : 表示录像文件无限长，
        //                  = 0  : 单个录像文件时间，单位为秒，SDK内部自动切换录像文件，
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StartAutoRecording(IntPtr hDev, string pszFileName, int nCycle);

        // 功能: 停止录像
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszFileName    [IN] : 录像文件名称
        //   nCycle         [IN] : 单个录像文件周期
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StopRecording(IntPtr hDev);

        // 功能: 设备控制
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pCmd           [IN] : 设备控制命令结构体指针，详见：[ 设备命令定义 ]
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_Exec(IntPtr hDev, ref DV_Cmd pCmd);

        // 功能: 获取新的卡口抓拍数据,
        // 原理:
        //   SDK内部有一个先进先出的抓拍图片队列，所有抓拍的图片都被缓存在此队列中的头部，
        //   队列大小默认为10，如果抓拍图片数量超过队列大小，SDK自动删除队尾的数据。
        //   每调用一次此接口，都会从队列中取出队尾的数据赋值给pInfo
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pInfo          [IN] : 卡口抓拍数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetNewGateCaptureInfo(IntPtr hDev, ref DV_CaptureInfo pInfo);

        // 功能: 重启设备
        // 参数说明:
        //   hDev           [IN] : 设备标识
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_Reboot(IntPtr hDev);
        //////////////////////////////////////////////////////////////////////////
        //
        // 黑白名单操作
        //
        //////////////////////////////////////////////////////////////////////////
        // 功能: 获取白名单子项数量
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pSize          [OUT]: 子项数量指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetWhiteListSize(IntPtr hDev, ref int pSize);

        // 功能: 获取白名单子项
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   nItem          [IN] : 子项编号(列表下标，从0开始)
        //   pItem          [OUT]: 子项数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetWhiteListItem(IntPtr hDev, int nItem, ref DV_BWListItem pItem);

        // 功能: 添加车牌到白名单
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pItem          [IN] : 名单子项数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_AddItemToWhiteList(IntPtr hDev, ref DV_BWListItem pItem);

        // 功能: 从白名单中删除数据
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszPlateText   [IN] : 车牌号码
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_DeleteFromWhiteListByPlate(IntPtr hDev, string pszPlateText);

        // 功能: 清空白名单
        // 参数说明:
        //   hDev           [IN] : 设备标识
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_ClearWhiteList(IntPtr hDev);

        //////////////////////////////////////////////////////////////////////////
        //
        // 工具接口定义
        //
        //////////////////////////////////////////////////////////////////////////

        // 功能: 格式化本地时间
        // 参数说明:
        //   pszFormat      [IN] : 带有时间格式的字符串，带格式，详见：[ 日期时间格式化说明 ]
        //   pszStrBuf      [OUT]: 输出字符串缓存指针
        //   nBufSize       [IN] : 输出字符串缓存大小
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_FormatLocalDateTime(string pszFormat, IntPtr pszStrBuf, int nBufSize);

        // 功能: 保存数据到文件
        // 参数说明:
        //   pszFileName    [IN] : 文件路径
        //   pData          [IN] : 数据缓存指针
        //   nDataSize      [IN] : 数据长度
        //   bFmtFileName   [IN] : 0: 不格式化文件名，1: 用本地时间格式化文件名，详见：[ 日期时间格式化说明 ]
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SaveDataToFile(string pszFileName, IntPtr pData, int nDataSize, int bFmtFileName);

        //////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// 获得日期
        /// </summary>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <param name="day"></param>
        /// <returns></returns>
        public static DV_Date GetDate(int year, int month, int day)
        {
            DV_Date d = new DV_Date();
            d.nYear = year;
            d.nMonth = month;
            d.nDay = day;

            return d;
        }

        /// <summary>
        /// 获得日期
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public static DV_Date GetDate(DateTime t)
        {
            DV_Date d = new DV_Date();
            d.nYear = t.Year;
            d.nMonth = t.Month;
            d.nDay = t.Day;

            return d;
        }
        /// <summary>
        /// 获得时间
        /// </summary>
        /// <param name="hour"></param>
        /// <param name="minute"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public static DV_Time GetTime(int hour, int minute, int second)
        {
            DV_Time t = new DV_Time();
            t.nHour = hour;
            t.nMinute = minute;
            t.nSecond = second;
            t.nMilliseconds = 0;

            return t;
        }

        /// <summary>
        /// 获得时间
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public static DV_Time GetTime(DateTime t)
        {
            DV_Time t2 = new DV_Time();
            t2.nHour = t.Hour;
            t2.nMinute = t.Minute;
            t2.nSecond = t.Second;
            t2.nMilliseconds = t.Millisecond;

            return t2;
        }

        /// <summary>
        /// 日期转换成字符串
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        public static string DateToString(DV_Date d)
        {
            return string.Format("{0}/{1}/{2}", d.nYear, d.nMonth, d.nDay);
        }

        /// <summary>
        /// 时间转换成字符串
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public static string TimeToString(DV_Time t)
        {
            return string.Format("{0}:{1}:{2}", t.nHour, t.nMinute, t.nSecond);
        }
    }
}