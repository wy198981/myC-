﻿using System;
using System.Runtime.InteropServices;

namespace ParkingCommunication.CameraSDK.ZNYKT11
{
    public class dv
    {
        public const string dllname = @"ZNYKTY11\DVNetSDK.dll";
     
        //////////////////////////////////////////////////////////////////////////
        //  参数定义
        //////////////////////////////////////////////////////////////////////////
        public const Int32 DVERR_OK                      = 0;      // 成功/无错误

        public const Int32 DV_IP_LEN                     = 128;    // IP地址长度
        public const Int32 DV_NAME_LEN                   = 128;    // 名称长度

        public const Int32 DV_RESERVED_LEN               = 64;     // 保留字段长度
        public const Int32 DV_MAX_PATH                   = 260;    // 最大文件路径长度
        public const Int32 DV_MAX_STREAM_COUNT           = 4;      // 允许的设备最大流数目

        // [ 设备命令定义 ]
        public const Int32 DVCMD_OPEN_RELAY              = 100;    // 打开继电器命令，详见：[ 打开/关闭继电器命令参数说明 ]
        public const Int32 DVCMD_CLOSE_RELAY             = 101;    // 关闭继电器命令，详见：[ 打开/关闭继电器命令参数说明 ]
        public const Int32 DVCMD_OPEN_CLOSE_RELAY        = 102;    // 脉动继电器命令，即：打开一段时间后自动关闭，详见：[ 脉动继电器命令参数说明 ]

        // [ 打开/关闭继电器命令参数说明 ]
        // DV_Cmd:
        // 	nCmd   : DVCMD_OPEN_RELAY 或 DVCMD_CLOSE_RELAY
        // 	nParam : 继电器编号，从0开始

        // [ 脉动继电器命令参数说明 ]
        // DV_Cmd:
        // 	nCmd   : DVCMD_OPEN_CLOSE_RELAY
        // 	nParam : 继电器编号，从0开始
        // 	nParam2: 继电器保持时间，<= 0: 默认保持时间(500毫秒)，> 0: 实际保持时间，单位为毫秒

        // [ 音视频编码格式定义 ]
        public const Int32 DV_ENC_TYPE_UNKNOWN           = 0;      // 未知编码
        public const Int32 DV_ENC_TYPE_H264              = 1;      // H264编码
        public const Int32 DV_ENC_TYPE_MJPEG             = 2;      // MJPEG编码
        public const Int32 DV_ENC_TYPE_H264_MAIN         = 3;      // H264 main profile
        public const Int32 DV_ENC_TYPE_H264_HIGH         = 4;      // H264 high profile
        public const Int32 DV_ENC_TYPE_G711_ALAW         = 5;      // G711A律编码
        public const Int32 DV_ENC_TYPE_G711_ULAW         = 6;      // G711U律编码
        public const Int32 DV_ENC_TYPE_RAW_PCM           = 7;      // PCM编码

        // [ 解码帧格式定义 ]
        public const Int32 DV_FRAME_TYPE_AUDIO16         = 1;      // 音频。采样率16khz，单声道，每个采样点16位表示
        public const Int32 DV_FRAME_TYPE_RGB32           = 2;      // RGB32	视频。每像素4字节，排列方式与位图相似，“BGR0” 第一个像素位于图像左下角
        public const Int32 DV_FRAME_TYPE_YV12            = 3;      // YV12	视频，yv12格式。排列顺序“Y0Y1……”、“V0V1……”、“U0-U1……”
        public const Int32 DV_FRAME_TYPE_UYVY            = 4;      // 视频，uyvy格式。排列顺序“U0Y0V0Y1U2Y2V2Y3 … …”，第一个像素位于图像左上角
        public const Int32 DV_FRAME_TYPE_YUV420          = 5;      // YUV420	视频，YUV420格式。排列顺序“Y0Y1……”、“U0-U1……”、“V0V1……”
        public const Int32 DV_FRAME_TYPE_YUY2_YUYV       = 6;      // yuy2、yuyv	视频，yuy2或yuyv格式。排列顺序“Y0 U0 Y1 V0 Y2 U2 Y3 V2… …”，第一个像素位于图像左上角
        public const Int32 DV_FRAME_TYPE_AUDIO8          = 7;      // 音频。采样率8khz，单声道，每个采样点16位表示。
        public const Int32 DV_FRAME_TYPE_RGB24           = 8;      // RGB24

        // [ 抓拍模式定义 ]
        public const Int32 DV_SNAP_TO_CALLBACK           = 0;      // 抓拍数据以回调函数返回
        public const Int32 DV_SNAP_TO_MEM                = 1;      // 抓拍到内存
        public const Int32 DV_SNAP_TO_FILE               = 2;      // 抓拍到文件

        // [ 镜像模式定义 ]
        public const Int32 DV_MIRROR_OFF                 = 0;      // 关闭           
        public const Int32 DV_MIRROR_HOR                 = 1;      // 水平镜像        
        public const Int32 DV_MIRROR_VER                 = 2;      // 垂直镜像        
        public const Int32 DV_MIRROR_BOTH                = 3;      // 水平-垂直镜像        

        // [ 码流控制类型定义 ]
        public const Int32 DV_BITRATE_CTRL_CBR           = 1;      // 固定码率
        public const Int32 DV_BITRATE_CTRL_VBR           = 2;      // 自动码率
        public const Int32 DV_BITRATE_CTRL_LBR           = 3;      // 固定帧长

        // [ 网络参数模式定义 ]
        public const Int32 DV_NET_PARAM_SET              = 0;      // 用户设定IP和DNS
        public const Int32 DV_NET_PARAM_AUTO             = 1;      // 自动获取IP和DNS

        // [ 图片格式定义 ]
        public const Int32 DV_IMG_FMT_JPG                = 0;      // JPG图片格式
        public const Int32 DV_IMG_FMT_BMP                = 1;      // BMP图片格式


        // [ 告警类型定义 ]
        public const Int32 DV_ALARM_VIDEO_COVER          = 1;      // 视频遮挡告警
        public const Int32 DV_ALARM_VIDEO_LOST           = 2;      // 视频丢失告警


        // [ 日期时间格式化说明 ]
        // %d 每月的第几天             %f 毫秒数
        // %H 24小时制的小时           %I 12小时制的小时
        // %m 十进制表示的月份         %M 十时制表示的分钟数
        // %S 十进制的秒数             %t 水平制表符
        // %Y 带世纪部分的十制年份     %n 新行符
        // %% 百分号

        //////////////////////////////////////////////////////////////////////////
        //
        //  数据结构定义
        //
        //////////////////////////////////////////////////////////////////////////
        // 告警数据结构体
        public struct DV_AlarmData
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szIP;                 // 设备IP地址
            public int nType;                            // 类型类型，详见：[ 告警类型定义 ]
            public int nState;                           // 告警状态，1：开始，0：停止
            public int nAlarmTime;                       // 告警时间

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 设备基本信息结构体
        public struct DV_DeviceGeneralInfo
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szIP;                          // 设备IP地址
            public int nPort;                            // 设备端口号

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_NAME_LEN)]
            public string szID;                          // 设备标识

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 设备连接信息结构体
        public struct DV_DeviceCnnInfo
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szIP;                          // 设备IP地址
            public int nPort;                            // 设备端口号，如果小于等于0，使用默认：60000

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_NAME_LEN)]
            public string szUserName;                    // 登录用户名，如果为空，使用默认：admin
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_NAME_LEN)]
            public string szPassword;                    // 登录密码，如果为空，使用默认：admin
            public int nLoginTimeout;                    // 登录超时时间，单位为毫秒，如果小于等于0，使用默认：5000

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 码流数据包结构体
        public struct DV_Packet
        {
            public int nStreamFormat;                    // 1表示原始流，2表示混合流
            public int nStreamType;                      // 原始流类型，1表示视频，2表示音频
            public int nEncoderType;                     // 编码格式,详见：[ 音视频编码格式定义 ]
            public int nFrameType;                       // 数据帧类型,1表示I帧, 2表示P帧, 0表示未知类型
            public int nFrameRate;                       // 帧率
            public int nBitRate;                         // 当前码率
            public Int64 nFrameID;                       // 数据帧序号
            public Int64 nTimeStamp;                     // 数据采集时间戳，单位为微秒

            public int nTimezone;                        // 时区
            public int nDaylightSavingTime;              // 夏令时

            public int nImageWidth;                      // 图像宽度
            public int nImageHeight;                     // 图像高度
            public int nDataLength;                      // 数据有效长度
            public IntPtr pData;                         // 数据

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 码流图像数据结构体
        public struct DV_Frame
        {
            public int nFrameRate;                       // 编码时产生的图像帧率
            public Int64 nTimeStamp;                     // 时标信息，单位为微秒
            public int nType;                            // 数据类型，详见：[ 解码帧格式定义 ]

            public int nWidth;                           // 画面宽，单位为像素，如果是音频数据则为0
            public int nHeight;                          // 画面高，单位为像素，如果是音频数据则为0
            public IntPtr pData;                         // 数据
            public int nLength;                          // 数据长度

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 设备控制命令结构体
        public struct DV_Cmd
        {
            public int nCmd;                             // 命令代码
            public int nParam;                           // 命令参数1
            public int nParam2;                          // 命令参数2

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 解码器信息结构体
        public struct DV_DecoderInfo
        {
            public IntPtr hViewWnd;                      // 窗口句柄

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 网络参数结构体
        public struct DV_NetParam
        {
            public int nNetParamMode;                    // 详见：[ 网络参数模式定义 ]

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szIP;                 // IP地址
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szMask;               // 子网掩码
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szGate;               // 网关
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szDNS1;               // 主DNS
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_IP_LEN)]
            public string szDNS2;               // 备用DNS

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 码流参数结构体
        public struct DV_StreamParam
        {
            public int nStreamId;                        // 码流编号
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DV_NAME_LEN)]
            public string szStreamName;                  // 码流名称
            public int nQuality;                         // 视频质量，[1-9]
            public int nVideoEncoderType;                // 视频编码类型，详见：[ 音视频编码格式定义 ]
            public int nAudioEncoderType;                // 音频编码类型，详见：[ 音视频编码格式定义 ]
            public int nBitRateType;                     // 码流控制类型，详见：[ 码流控制类型定义 ]
            public int nBitRate;                         // 码率，单位Kbps
            public int nGOP;                             // I帧间隔
            public int nFrameRate;                       // 帧率
            public int nImageWidth;                      // 分辨率-图像宽度
            public int nImageHeight;                     // 分辨率-图像高度

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 所有码流参数结构体
        public struct DV_AllStreamParams
        {
            public int nStreamCount;                     // 码流数量

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_MAX_STREAM_COUNT)]
            DV_StreamParam[] Params;                     // 参数列表

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        // 图像参数结构体
        public struct DV_ImageParam
        {
            public int nBrightness;                      // 亮度，  范围：[0-100]
            public int nSaturation;                      // 饱和度，范围：[0-100]
            public int nSharpness;                       // 锐度，  范围：[0-100]

            public int nMirrorMode;                      // 详见：[ 镜像模式定义 ]
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = DV_RESERVED_LEN)]
            public int[] Reserved;                       // 保留字段
        };

        //////////////////////////////////////////////////////////////////////////
        //
        // 回调函数定义
        //
        //////////////////////////////////////////////////////////////////////////

        // 功能: 返回设备搜索结果
        // 参数说明:
        //   hSearchEngine  [IN] : 搜索引擎标识
        //   pInfo          [IN] : 设备基本信息结构体指针
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无
        public delegate void DV_SearchCallback(IntPtr hSearchEngine, ref DV_DeviceGeneralInfo pInfo, IntPtr pUserData);

        // 功能: 返回告警信息
        // 参数说明:
        //   pAlarmData     [IN] : 告警数据结构体指针
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无
        public delegate void DV_AlarmCallback(ref DV_AlarmData pAlarmData, IntPtr pUserData);

        // 功能: 返回码流原始数据包
        // 参数说明:
        //   hDevice        [IN] : 设备标识
        //   pPkt           [IN] : 码流数据包结构体指针
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无
        public delegate void DV_DataCallback(IntPtr hDevice, ref DV_Packet pPkt, IntPtr pUserData);

        // 功能: 返回解码后数据
        // 参数说明:
        //   hDecoder       [IN] : 解码器标识
        //   pFrame         [IN] : 解码后数据帧结构体指针
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无
        public delegate void DV_DecoderDataCallback(IntPtr hDecoder, ref DV_Frame pFrame, IntPtr pUserData);

        // 功能: 返回解码后数据
        // 参数说明:
        //   hDevice        [IN] : 设备标识
        //   pImageData     [IN] : 图片数据指针
        //   nImageSize     [IN] : 图片数据大小
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          无
        public delegate void DV_CaptureCallback(IntPtr hDevice, IntPtr pImageData, int nImageSize, IntPtr pUserData);

        //////////////////////////////////////////////////////////////////////////
        //
        // 设备码流、抓拍、录像、命令等接口定义
        //
        //////////////////////////////////////////////////////////////////////////

        // 功能: 初始化SDK
        // 参数说明:
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_InitSDK();

        // 功能: 释放SDK
        // 参数说明:
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_ReleaseSDK();

        // 功能: 错误码文本消息获取接口
        // 参数说明:
        //   nErrCode       [IN] : 错误码
        //   pszMsgBuf      [OUT]: 消息缓存指针
        //   nMsgBufSize    [IN]:  消息缓存大小
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetErrorMessage(int nErrCode, IntPtr pszMsgBuf, int nMsgBufSize);

        // 功能: 创建搜索引擎
        // 参数说明:
        //   pSearchCbFun   [IN] : 搜索回调函数
        //   pUserData      [IN] : 搜索回调函数用户数据
        //   phEng          [OUT]: 搜索引擎指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int OpenSearchEngine(DV_SearchCallback pSearchCbFun, IntPtr pUserData, ref IntPtr phEng);

        // 功能: 关闭搜索引擎
        // 参数说明:
        //   hEng           [IN] : 搜索引擎句柄
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int CloseSearchEngine(IntPtr hEng);

        // 功能: 设置告警回调
        // 参数说明:
        //   pAlarmCbFun    [IN] : 告警回调函数
        //   pUserData      [IN] : 告警回调函数用户数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetAlarmCallback(DV_AlarmCallback pAlarmCbFun, IntPtr pUserData);

        // 功能: 根据设备IP和端口号等信息连接到设备，此接口在设备关闭前只允许执行一次
        // 参数说明:
        //   pCnnInfo       [IN] : 设备连接信息
        //   phDev          [OUT]: 输出设备句柄
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_OpenDevice(ref DV_DeviceCnnInfo pCnnInfo, ref IntPtr phDev);

        // 功能: 根据设备标识关闭已经打开的设备
        // 参数说明:
        //   hDev           [IN] : 设备标识
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_CloseDevice(IntPtr hDev);

        // 功能: 打开码流
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   nStreamID      [IN] : 码流编号
        //   hWnd           [IN] : 视频播放窗口句柄
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StartStream(IntPtr hDev, int nStreamID, IntPtr hWnd);

        // 功能: 关闭码流
        // 参数说明:
        //   hDev           [IN] : 设备标识
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StopStream(IntPtr hDev);

        // 功能: 设置数据回调
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pCbFun         [IN] : 回调函数
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetDataCallback(IntPtr hDev, DV_DataCallback pCbFun, IntPtr pUserData);

        // 功能: 设置抓拍回调
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pCbFun         [IN] : 回调函数
        //   pUserData      [IN] : 回调函数用户数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetCaptureCallback(IntPtr hDev, DV_CaptureCallback pCbFun, IntPtr pUserData);

        // 功能: 抓拍图片
        // 结果在回调函数中返回
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   nFormat        [IN] : 图片格式，
        //                  0：JPG，其他：详见：[ 图片格式定义 ]
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_Capture(IntPtr hDev, int nFormat);

        // 功能: 抓拍图片到文件
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszFileName    [IN] : 目标文件名称
        //   nFormat        [IN] : 图片格式，
        //                  0：JPG，其他：详见：[ 图片格式定义 ]
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_CaptureToFile(IntPtr hDev, string pszFileName, int nFormat);

        // 功能: 抓拍图片到内存
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pBuf           [OUT]: 缓存指针
        //   nBufSize       [IN] : 缓存大小
        //   pDataSize      [OUT]: 抓拍后图片数据内存中大小
        //   nFormat        [IN] : 图片格式，
        //                  0：JPG，其他：详见：[ 图片格式定义 ]
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_CaptureToMem(IntPtr hDev, IntPtr pBuf, int nBufSize, ref int pDataSize, int nFormat);

        // 功能: 开始录像
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszFileName    [IN] : 录像文件名称
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StartRecording(IntPtr hDev, string pszFileName);

        // 功能: 开始自动录像
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszFileName    [IN] : 录像文件名称，带格式，详见：[ 日期时间格式化说明 ]
        //   nCycle         [IN] : 单个录像文件周期，
        //                  <= 0 : 表示录像文件无限长，
        //                  = 0  : 单个录像文件时间，单位为秒，SDK内部自动切换录像文件，
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StartAutoRecording(IntPtr hDev, string pszFileName, int nCycle);

        // 功能: 停止录像
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pszFileName    [IN] : 录像文件名称
        //   nCycle         [IN] : 单个录像文件周期
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_StopRecording(IntPtr hDev);

        // 功能: 设备控制
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pCmd           [IN] : 设备控制命令结构体指针，详见：[ 设备命令定义 ]
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_Exec(IntPtr hDev, ref DV_Cmd pCmd);

        //////////////////////////////////////////////////////////////////////////
        //
        // 设备参数接口定义
        //
        //////////////////////////////////////////////////////////////////////////
        // 功能: 网络参数获取
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pNetParam      [OUT]: 网络参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetNetParam(IntPtr hDev, ref DV_NetParam pNetParam);

        // 功能: 网络参数设置
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pNetParam      [IN] : 网络参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetNetParam(IntPtr hDev, ref DV_NetParam pNetParam);

        // 功能: 码流参数获取
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   nStreamID      [IN] : 码流编号
        //   pStreamParam   [OUT]: 码流参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetStreamParam(IntPtr hDev, int nStreamID, ref DV_StreamParam pStreamParam);

        // 功能: 码流参数设置
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   nStreamID      [IN] : 码流编号
        //   pStreamParam   [IN] : 码流参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetStreamParam(IntPtr hDev, int nStreamID, ref DV_StreamParam pStreamParam);

        // 功能: 码流参数获取
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pStreamParams  [OUT]: 所有码流参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetAllStreamParams(IntPtr hDev, ref DV_AllStreamParams pStreamParams);

        // 功能: 码流参数设置
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pStreamParams  [IN] : 所有码流参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetAllStreamParams(IntPtr hDev, ref DV_AllStreamParams pStreamParams);


        // 功能: 图像参数获取
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pImageParam    [OUT]: 图像参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_GetImageParam(IntPtr hDev, ref DV_ImageParam pImageParam);

        // 功能: 图像参数设置
        // 参数说明:
        //   hDev           [IN] : 设备标识
        //   pImageParam    [IN] : 图像参数结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetImageParam(IntPtr hDev, ref DV_ImageParam pImageParam);

        //////////////////////////////////////////////////////////////////////////
        //
        // 解码器接口定义
        //
        //////////////////////////////////////////////////////////////////////////

        // 功能: 创建解码器
        // 参数说明:
        //   pDecInfo       [IN] : 解码器参数
        //   phDecoder      [OUT]: 输出解码器句柄
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_CreateDecoder(ref DV_DecoderInfo pDecInfo, ref IntPtr phDecoder);

        // 功能: 删除解码器
        // 参数说明:
        //   hDecoder       [IN] : 解码器标识
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_DeleteDecoder(IntPtr hDecoder);

        // 功能: 设置解码数据回调
        // 参数说明:
        //   hDecoder       [IN] : 解码器标识
        //   pCbFun         [IN] : 解码数据回调
        //   pUserData      [IN] : 解码数据回调用户数据
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SetDecoderDataCallback(IntPtr hDecoder, DV_DecoderDataCallback pCbFun, IntPtr pUserData);

        // 功能: 解码
        // 参数说明:
        //   hDecoder       [IN] : 解码器标识
        //   pPkt           [IN] : 码流数据包结构体指针
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_Decode(IntPtr hDecoder, ref DV_Packet pPkt);

        //////////////////////////////////////////////////////////////////////////
        //
        // 工具接口定义
        //
        //////////////////////////////////////////////////////////////////////////

        // 功能: 格式化本地时间
        // 参数说明:
        //   pszFormat      [IN] : 带有时间格式的字符串，带格式，详见：[ 日期时间格式化说明 ]
        //   pszStrBuf      [OUT]: 输出字符串缓存指针
        //   nBufSize       [IN] : 输出字符串缓存大小
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_FormatLocalDateTime(string pszFormat, IntPtr pszStrBuf, int nBufSize);

        // 功能: 保存数据到文件
        // 参数说明:
        //   pszFileName    [IN] : 文件路径
        //   pData          [IN] : 数据缓存指针
        //   nDataSize      [IN] : 数据长度
        //   bFmtFileName   [IN] : 0: 不格式化文件名，1: 用本地时间格式化文件名，详见：[ 日期时间格式化说明 ]
        // 返回值:          SDK错误码
        [DllImport(dllname)]
        public static extern int DV_SaveDataToFile(string pszFileName, IntPtr pData, int nDataSize, int bFmtFileName);

    }
}



