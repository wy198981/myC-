﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParkingModel;
using System.Runtime.InteropServices;
using ParkingInterface;
using ParkingCommunication.CameraSDK.ZNYKT14;
using ParkingCommunication.CameraSDK.ZNYKT13;
using ParkingCommunication.CameraSDK.ZNYKT5;
using System.Net;
using System.Threading;

namespace ParkingCommunication
{
    public enum VoiceType : uint
    {
        /// <summary>
        /// 系统禁止读卡（枚举值，车道编号）
        /// </summary>
        ProhibitInGate,
        /// <summary>
        /// 欢迎光临（枚举值，车道编号）
        /// </summary>
        Welcome,
        /// <summary>
        /// 已过期，请与管理处联系（枚举值，车道编号）
        /// </summary>
        BeOverdue,
        /// <summary>
        /// 未授权，请与管理处联系（枚举值，车道编号）
        /// </summary>
        CarInvalid,
        /// <summary>
        /// 已入场（枚举值，车道编号）
        /// </summary>
        AlreadyEntered,
        /// <summary>
        /// 已出场（枚举值，车道编号）
        /// </summary>
        AlreadyAppeared,
        /// <summary>
        /// 车位已满（枚举值，车道编号）
        /// </summary>
        ParkingFull,
        /// <summary>
        /// 储值车车位已满（枚举值，车道编号）
        /// </summary>
        StoredValueParkingFull,
        /// <summary>
        /// 临时车车位已满（枚举值，车道编号）
        /// </summary>
        TemporaryParkingFull,
        /// <summary>
        /// 月租车车位已满（枚举值，车道编号）
        /// </summary>
        MonthlyParkingFull,

        /// <summary>
        /// 解除车位已满（枚举值，车道编号）
        /// </summary>
        RelieveParkingFull,
        /// <summary>
        /// 解除储值车车位已满（枚举值，车道编号）
        /// </summary>
        RelieveStoredValueParkingFull,
        /// <summary>
        /// 解除临时车车位已满（枚举值，车道编号）
        /// </summary>
        RelieveTemporaryParkingFull,
        /// <summary>
        /// 解除月租车车位已满（枚举值，车道编号）
        /// </summary>
        RelieveMonthlyParkingFull,

        //2017-02-10
        Relieve,
        //2017-02-10

        /// <summary>
        /// 余额不足，请及时充值（枚举值，车道编号）
        /// </summary>
        BalanceInsufficient,
        /// <summary>
        /// 入场语音（枚举值，车道编号,车辆类型（“MthA”），车牌号码，剩余日期（免费车，月租车传正常值，临时车，储值车传‘0’)，车场车位（十六进制，默认传‘FFFF’），剩余车位，余额（储值车，默认传0）））
        /// </summary>
        InGateVoice,
        /// <summary>
        /// 出场语音（枚举值，车道编号,车辆类型（“MthA”），车牌号码，剩余日期（免费车，月租车传正常值，临时车，储值车传‘0’)，车场车位（十六进制，默认传‘FFFF’），剩余车位，余额（储值车，默认传0）））
        /// </summary>
        OutGateVoice,
        /// <summary>
        /// 出场确认开闸后播报一路顺风
        /// </summary>
        TempOutOpen,

    }

    public class VoiceSend
    {
        private Int32[] m_hLPRClient = new Int32[11];//登陆ID 使用于摄像机开闸
        private Int32[] m_nSerialHandle = new Int32[11]; //播放库ID  使用于摄像机开闸 
        public static int LPort = 0; //本机端口号
        public static int SPort = 0; //下位机端口号

        public VoiceSend(int Localport, int ServerPort)
        {
          
            if (Model.bAppEnable)
            {
                LPort = 9802;
                SPort = 9801;
            }
            else
            {
                LPort = Localport;
                SPort = ServerPort;
            }
        }

        public VoiceSend(Int32[] _m_hLPRClient, Int32[] _m_nSerialHandle, int Localport, int ServerPort)
        {
            m_hLPRClient = _m_hLPRClient;
            m_nSerialHandle = _m_nSerialHandle;
            LPort = Localport;
            SPort = ServerPort;

            if (Model.bAppEnable)
            {
                LPort = 9802;
                SPort = 9801;
            }
        }


        /// <summary>
        /// 处理开闸
        /// </summary>
        /// <param name="iGateNum">车道编号</param>
        /// <returns></returns>
        public string SendOpen(int iGateNum)
        {
            string strRst = "0";
            if (Model.bVideoCamera)//判断是否为摄像机开闸
            {
                if (Model.iVideoType == 0)
                {
                    CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SetIOOutputAuto(m_hLPRClient[iGateNum], 1, 1500);
                }

                if (Model.strVideoType == "ZNYKT14")
                {
                    CameraSDK.ZNYKT14.MyClass.T_ControlGate tControlGate = new CameraSDK.ZNYKT14.MyClass.T_ControlGate();
                    tControlGate.ucState = 1;
                    IntPtr ptControlGate = Marshal.AllocHGlobal(Marshal.SizeOf(tControlGate));
                    Marshal.StructureToPtr(tControlGate, ptControlGate, true);
                    int iRet = CameraSDK.ZNYKT14.MyClass.Net_GateSetup(m_hLPRClient[iGateNum], ptControlGate);
                }

                else if (Model.strVideoType == "ZNYKT13")
                {
                    CtrlOutput((IntPtr)m_hLPRClient[iGateNum], 0, 1);
                }
            }
            else
            {
                if (Model.Channels[iGateNum].iXieYi == 1)
                {
                    byte[] bSend = AllCommand.SendCommand(Model.Channels[iGateNum].iCtrlID, 0x0C, 5);// 生成发送指令
                    strRst = IsSuccess(UDPSend.Send(bSend, Model.Channels[iGateNum].sIP, LPort, SPort));// 返回值进行解析

                    ParkingInterface.Request request = new ParkingInterface.Request();
                    
                    if (strRst == "0")
                    {
                        OptLog opt = new OptLog();
                        opt.OptNO = Model.sUserCard;
                        opt.UserName = Model.sUserName;
                        opt.OptMenu = "开闸";
                        opt.OptContent = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        opt.OptTime = DateTime.Now;
                        opt.StationID = Model.stationID;
                        var addStr = ParkingInterface.JsonJoin.ModelToJson(opt);
                        int ret = request.AddData(Model.token, "tOptLog", addStr);
                    }
                }
            }
            return strRst;
        }

        /// <summary>
        /// 标准语音显示
        /// </summary>
        /// <param name="Type">语音类型</param>
        /// <param name="iGateNum">车道编号</param>
        /// <param name="strCarType">车辆类型（“MthA”）</param>
        /// <param name="strCPH">车牌号码</param>
        /// <param name="CYkDay">剩余日期（免费车，月租车传正常值，临时车，储值车传‘0’)</param>
        /// <param name="strCardCW">车场车位（十六进制，默认传‘FFFF’）</param>
        /// <param name="iSpaces">剩余车位</param>
        /// <param name="dStrYE">余额（储值车，默认传0）</param>
        /// <param name="dSFJE">收费金额</param>
        /// <param name="strStopCarTime">停车时间(默认值为FFFF)</param>
        /// <returns></returns>
        public string VoiceDisplay(VoiceType Type, int iGateNum, string strCarType = "MthA", string strCPH = "", int CYkDay = 0, string strCardCW = "", int iSpaces = 0, decimal dStrYE = 0, decimal dSFJE=0, string strStopCarTime="FFFFFFFF")
        {
            string strRst = "0";
            byte[] bSend;
            int iJiHao = Model.Channels[iGateNum].iCtrlID;//机号
            int iGateType = Model.Channels[iGateNum].iInOut;//车道类型
            int iXieYi = Model.Channels[iGateNum].iXieYi;//协议类型
            switch (Type)
            {

                case VoiceType.TempOutOpen:
                    bSend = AllCommand.ShowLed55(iJiHao, "FFFF");
                    break;
                case VoiceType.InGateVoice:
                    bSend = VoiceInGate(iJiHao, strCarType, strCPH, CYkDay, strCardCW, iSpaces, dStrYE);//入场播报语音
                    break;
                case VoiceType.OutGateVoice:
                    bSend = VoiceOutGate(iJiHao, strCarType, strCPH, CYkDay, strCardCW, iSpaces, dStrYE, dSFJE, strStopCarTime);//出场播报语音
                    break;
                case VoiceType.BalanceInsufficient:
                    bSend = AllCommand.ShowLed(iJiHao, "", 0x45);//余额不足，请先充值；
                    break;
                case VoiceType.ProhibitInGate:
                    bSend = AllCommand.VoiceLoad(iJiHao, "4F");//系统禁止读卡；
                    break;
                case VoiceType.Welcome:
                    bSend = AllCommand.VoiceLoad(iJiHao, "42");//欢迎光临；
                    break;
                case VoiceType.BeOverdue:
                    bSend = AllCommand.VoiceLoad(iJiHao, "46");//此车已过期；
                    break;
                case VoiceType.CarInvalid:
                    bSend = AllCommand.VoiceLoad(iJiHao, "48");//此车无效；
                    break;
                case VoiceType.AlreadyEntered:
                    bSend = AllCommand.VoiceLoad(iJiHao, "4C");//已入场；
                    break;
                case VoiceType.AlreadyAppeared:
                    bSend = AllCommand.VoiceLoad(iJiHao, "57");//已出场；
                    break;
                case VoiceType.ParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x73, 5);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x82, 5);// 车位已满
                    }
                    break;
                case VoiceType.StoredValueParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x73, 3);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x82, 3);// 储值车车位已满
                    }
                    break;
                case VoiceType.TemporaryParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x73, 2);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x82, 2);// 临时车车位已满
                    }
                    break;
                case VoiceType.MonthlyParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x73, 1);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x82, 1);// 月租车车位已满
                    }
                    break;

                case VoiceType.RelieveParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x72, 5);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x83, 5);// 解除车位已满
                    }
                    break;
                case VoiceType.RelieveStoredValueParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x72, 3);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x83, 3);// 解除储值车车位已满
                    }
                    break;
                case VoiceType.RelieveTemporaryParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x72, 2);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x83, 2);// 解除临时车车位已满
                    }
                    break;
                case VoiceType.RelieveMonthlyParkingFull:
                    if (Model.bOut485)//判断是否为摄像机开闸
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x72, 1);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x83, 1);// 解除月租车车位已满
                    }
                    break;

                case VoiceType.Relieve:
                    if (Model.bOut485)
                    {
                        bSend = AllCommand.SendFullCW(iJiHao, 0x72, 0);
                    }
                    else
                    {
                        bSend = AllCommand.SendCommand(iJiHao, 0x83, 0);
                    }
                    break;
                //2017-02-10 新增0

                default:
                    bSend = AllCommand.VoiceLoad(iJiHao, "42");//欢迎光临；
                    break;
            }

            if (Model.bOut485)//判断是否为摄像机开闸
            {
                if (Model.iVideoType == 0)//ZNYKTY5 摄像机通透485
                {
                    CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialSendbyte(m_nSerialHandle[iGateNum], bSend, bSend.Length);
                }
            }
            else
            {
                if (Model.Channels[iGateNum].iXieYi == 1)
                {
                    strRst = IsSuccess(UDPSend.Send(bSend, Model.Channels[iGateNum].sIP, LPort, SPort));// 返回值进行解析
                }
            }

            return strRst;
        }

        /// <summary>
        /// 出场语音解析
        /// </summary>
        /// <param name="iJiHao"></param>
        /// <param name="strCarType"></param>
        /// <param name="strCPH"></param>
        /// <param name="CYkDay"></param>
        /// <param name="strCardCW"></param>
        /// <param name="iSpaces"></param>
        /// <param name="dStrYE"></param>
        /// <returns></returns>
        private byte[] VoiceOutGate(int iJiHao, string strCarType, string strCPH, int CYkDay, string strCardCW, int iSpaces, decimal dStrYE, decimal dSFJE, string strStopCarTime = "FFFF0000")
        {
            byte[] bSend = null;
            strCardCW = strCardCW.PadLeft(4, '0');

            if (strCarType.Substring(0, 3) == "Fre" || strCarType.Substring(0, 3) == "Mth")//入场发送月租车和免费车语音
            {
                if (strCPH.Length != 7 || strCPH == "0000000" || strCPH == "6666666" || strCPH == "8888888" || strCPH == "京000000")
                {
                    if (strCPH.Length == 8 && strCPH.Substring(0, 2) == "WJ")
                    {
                    }
                    else
                    {
                        strCPH = "";
                    }

                }
                string strCYkDay = "";

                if (Model.iCtrlShowPlate == 1 || Model.iCtrlShowCW == 1)
                {
                    if (Model.iCtrlShowPlate == 0)
                    {
                        strCPH = "FFFF";
                    }

                    if (CYkDay > Model.iIDNoticeDay && Model.iIDNoticeDay > 0)
                    {
                        strCYkDay = "FFFF";
                    }
                    else
                    {
                        //X4
                        strCYkDay = CYkDay.ToString("0000");
                    }

                    if (Model.iCtrlShowCW == 0)
                    {
                        strCardCW = "FFFF";
                    }

                    if (strCPH.Length == 7)
                    {
                        if (((Model.iAutoColor == 3 || strCPH.Substring(6, 1) == "警" || strCPH.Substring(0, 2) == "WJ") && Model.iAutoColorSet == 1) || (strCPH.Substring(1, 1) == "0" && Model.iAuto0Set == 1))
                        {
                            strCYkDay = "FFFF";
                            strCardCW = "FFFF";
                        }
                    }

                    string sLoad = LedSound_New(0x6B, strCYkDay, strCardCW, "FFFF", strCPH);
                    bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x6B, sLoad);
                }
                
            }
            else if (strCarType.Substring(0, 3) == "Tmp" || strCarType.Substring(0, 3) == "Mtp") //入场发送临时车语音
            {
                if (strCPH.Length != 7 || strCPH == "0000000" || strCPH == "6666666" || strCPH == "8888888" || strCPH == "京000000")
                {
                    if (strCPH.Length == 8 && strCPH.Substring(0, 2) == "WJ")
                    {
                    }
                    else
                    {
                        strCPH = "";
                    }

                }

                string MyTempMoney = "";

                if (Model.iXsd == 0)
                {
                    if (Model.iChargeType == 3)
                    {
                        if (Model.iXsdNum == 1)
                        {
                            MyTempMoney = (Convert.ToInt32(dSFJE * 10)).ToString("X4");
                        }
                        else
                        {

                            if (Convert.ToDecimal(dSFJE) > 655)
                            {

                            }
                            MyTempMoney = (Convert.ToInt32(dSFJE * 100)).ToString("X4");

                        }
                    }
                    else
                    {
                        //四舍五入(非国际标准(国际标准遇偶逢六才进一，基数逢五进一))
                        MyTempMoney = Convert.ToInt32(Math.Round(dSFJE, 0, MidpointRounding.AwayFromZero)).ToString("X4");
                        //MyTempMoney = Convert.ToInt32(dSFJE).ToString("X4");
                    }
                }
                else
                {
                    //MyTempMoney = (Convert.ToInt32(dSFJE * 10)).ToString("X4");
                    MyTempMoney = Convert.ToInt32(Math.Round(dSFJE * 10, 0, MidpointRounding.AwayFromZero)).ToString("X4");
                }

                //if ((Model.iOutAutoOpenModel == 0 || Model.iAutoKZ == 1) && Model.iAutoPlateEn == 1)
                //{
                //    if (Model.iCtrlShowPlate == 0)
                //    {
                //        strCPH = "FFFF";
                //    }
                //    strCardCW = "FFFF";

                //    string sLoad = LedSound_New(0x6B, "FFFF", strCardCW, "FFFF", strCPH);
                //    bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x6B, sLoad);
                //}
                //else
                //{
                    if (Model.bSfDec)
                    {
                        bSend = AllCommand.ShowLed(iJiHao, MyTempMoney);
                    }
                    else
                    {
                        string sLoad = LedSound_New(0x69, MyTempMoney, "FFFF", strStopCarTime, strCPH);
                        bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x69, sLoad);
                    }
                //}

            }
            else if (strCarType.Substring(0, 3) == "Str")
            {
                if (strCPH.Length != 7 || strCPH == "0000000" || strCPH == "6666666" || strCPH == "8888888" || strCPH == "京000000")
                {
                    if (strCPH.Length == 8 && strCPH.Substring(0, 2) == "WJ")
                    {
                    }
                    else
                    {
                        strCPH = "";
                    }

                }
                string CCzkMoney = "";
                string LskMoney = "";
                if (Model.iCtrlShowPlate == 1 || Model.iCtrlShowStayTime == 1)
                {
                    if (Model.iXsd == 1 || (Model.iXsd == 0 && Model.iChargeType == 3))
                    {
                        if (Model.iChargeType == 3)
                        {
                            if (Model.iXsdNum == 1)
                            {
                                LskMoney = (Convert.ToInt32(dSFJE * 10)).ToString("X4");
                                CCzkMoney = (Convert.ToInt32(dStrYE * 10)).ToString("X4");
                            }
                            else
                            {
                                LskMoney = (Convert.ToInt32(dSFJE * 100)).ToString("X4");
                                CCzkMoney = (Convert.ToInt32(dStrYE * 100)).ToString("X4");
                            }
                        }
                        else
                        {
                            LskMoney = (Convert.ToInt32(dSFJE * 10)).ToString("X4");
                            CCzkMoney = (Convert.ToInt32(dStrYE * 10)).ToString("X4");
                        }
                    }
                    else
                    {
                        LskMoney = Convert.ToInt32(dSFJE).ToString("X4");
                        CCzkMoney = Convert.ToInt32(dStrYE).ToString("X4");
                    }


                    string sLoad = LedSound_New(0x6D, CCzkMoney, LskMoney, strStopCarTime, strCPH);
                    bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x6D, sLoad);
                }
            }
            else
            {
                bSend = new byte[1];
            }
            return bSend;
        }


        /// <summary>
        /// 入场语音解析
        /// </summary>
        /// <param name="iJiHao"></param>
        /// <param name="strCarType"></param>
        /// <param name="strCPH"></param>
        /// <param name="CYkDay"></param>
        /// <param name="strCardCW"></param>
        /// <param name="iSpaces"></param>
        /// <param name="dStrYE"></param>
        /// <returns></returns>
        private byte[] VoiceInGate(int iJiHao, string strCarType, string strCPH, int CYkDay, string strCardCW, int iSpaces, decimal dStrYE)
        {
            byte[] bSend = null;
            strCardCW = strCardCW.PadLeft(4, '0');
            if (Model.iCtrlShowRemainPos == 1)   //2015-10-22 入口显示剩余车位语音 都从这里发
            {
                if (strCPH.Length != 7 || strCPH == "0000000" || strCPH == "6666666" || strCPH == "8888888" || strCPH == "京000000")
                {
                    if (strCPH.Length == 8 && strCPH.Substring(0, 2) == "WJ")
                    {
                    }
                    else
                    {
                        strCPH = "";
                    }

                }
                string strSY = "";
                if (Model.iFreeCardNoInPlace == 1 && strCarType.Substring(0, 3) == "Fre")
                {
                    strSY = iSpaces.ToString("0000");
                }
                else
                {
                    strSY = (iSpaces - 1).ToString("0000");
                }


                if (Convert.ToInt32(strSY) < 0)
                {
                    strSY = "0000";
                }
                string strCardType = "FFFF";
                string strSendB = "FFFF";
                string CCzkMoney = "";
                if (strCarType.Substring(0, 3) == "Fre" || strCarType.Substring(0, 3) == "Mth")
                {
                    if (Model.iCtrlShowCW == 0)
                    {
                        strSendB = "FFFF";
                        strCardType = "4FFF";
                    }
                    else
                    {
                        strSendB = strCardCW;
                        strCardType = "4FFF";

                    }
                    if (CYkDay > Model.iIDNoticeDay && Model.iIDNoticeDay > 0)
                    {
                        strCardType = "1FFF";
                        strSendB = "FFFF";
                    }
                    else
                    {
                        strCardType = "1FFF";

                        strSendB = CYkDay.ToString("0000");
                        //strSendB = CYkDay.ToString("X4");
                    }

                    //2017-02-10
                    if (strCPH.Length >= 7)
                    {
                        if (((Model.iAutoColor == 3 || strCPH.Substring(6, 1) == "警" || strCPH.Substring(0, 2) == "WJ") && Model.iAutoColorSet == 1) || (strCPH.Substring(1, 1) == "0" && Model.iAuto0Set == 1))
                        {
                            strSendB = "FFFF";
                        }
                    }
                    //if (Model.iAuto0Set == 1)
                    //{
                    //    strSendB = "FFFF";
                    //}
                }
                else if (strCarType.Substring(0, 3) == "Tmp")
                {
                    strCardType = "0FFF";
                }
                else if (strCarType.Substring(0, 3) == "Str")
                {
                    if (Model.iXsd == 1 || (Model.iXsd == 0 && Model.iChargeType == 3))
                    {
                        if (Model.iChargeType == 3)
                        {
                            if (Model.iXsdNum == 1)
                            {
                                CCzkMoney = (Convert.ToInt32(dStrYE * 10)).ToString("X4");
                            }
                            else
                            {
                                CCzkMoney = (Convert.ToInt32(dStrYE * 100)).ToString("X4");
                            }
                        }
                        else
                        {
                            CCzkMoney = Convert.ToInt32(dStrYE * 10).ToString("X4");
                        }
                    }
                    else
                    {
                        CCzkMoney = Convert.ToInt32(dStrYE).ToString("X4");
                    }
                    strSendB = CCzkMoney;
                    strCardType = "2FFF";
                }
                else
                {
                    strCardType = "3FFF";
                }

                //处理月卡过期  不播报语音 th 2016-04-27
                if (strSendB == null)
                {
                    strSendB = "FFFF";
                }

                string sLoad = LedSound_New(0x90, strSY, strSendB, strCardType, strCPH);

                bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x90, sLoad);


            }
            else if (strCarType.Substring(0, 3) == "Fre" || strCarType.Substring(0, 3) == "Mth")//入场发送月租车和免费车语音
            {
                if (strCPH.Length != 7 || strCPH == "0000000" || strCPH == "6666666" || strCPH == "8888888" || strCPH == "京000000")
                {
                    if (strCPH.Length == 8 && strCPH.Substring(0, 2) == "WJ")
                    {
                    }
                    else
                    {
                        strCPH = "";
                    }

                }

                if (Model.iCtrlShowPlate == 1 || Model.iCtrlShowCW == 1)
                {
                    if (Model.iCtrlShowPlate == 0)
                    {
                        strCPH = "FFFF";
                    }

                    string strCYkDay = "";

                    if (CYkDay > Model.iIDNoticeDay && Model.iIDNoticeDay > 0)
                    {
                        strCYkDay = "FFFF";
                    }
                    else
                    {
                        //X4
                        strCYkDay = CYkDay.ToString("0000");
                    }
                    if (Model.iCtrlShowCW == 0)
                    {
                        strCardCW = "FFFF";

                    }
                    string sLoad = LedSound_New(0x6A, strCYkDay, strCardCW, "FFFF", strCPH);
                    bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x6A, sLoad);
                }


            }
            else if (strCarType.Substring(0, 3) == "Tmp" || strCarType.Substring(0, 3) == "Mtp") //入场发送临时车语音
            {
                if (strCPH.Length != 7 || strCPH == "0000000" || strCPH == "6666666" || strCPH == "8888888" || strCPH == "京000000")
                {
                    if (strCPH.Length == 8 && strCPH.Substring(0, 2) == "WJ")
                    {
                    }
                    else
                    {
                        strCPH = "";
                    }

                }

                if (Model.iCtrlShowPlate == 1 || Model.iCtrlShowCW == 1)
                {
                    if (Model.iCtrlShowPlate == 0)
                    {
                        strCPH = "FFFF";
                    }

                    string strCYkDay = "FFFF";
                    strCardCW = "FFFF";

                    string sLoad = LedSound_New(0x68, strCYkDay, strCardCW, "FFFF", strCPH);
                    bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x68, sLoad);
                }
            }
            else if (strCarType.Substring(0, 3) == "Str")
            {
                if (strCPH.Length != 7 || strCPH == "0000000" || strCPH == "6666666" || strCPH == "8888888" || strCPH == "京000000")
                {
                    if (strCPH.Length == 8 && strCPH.Substring(0, 2) == "WJ")
                    {
                    }
                    else
                    {
                        strCPH = "";
                    }

                }
                string CCzkMoney = "";
                if (Model.iXsd == 1 || (Model.iXsd == 0 && Model.iChargeType == 3))
                {
                    if (Model.iChargeType == 3)
                    {
                        if (Model.iXsdNum == 1)
                        {
                            CCzkMoney = (Convert.ToInt32(dStrYE * 10)).ToString("X4");
                        }
                        else
                        {
                            CCzkMoney = (Convert.ToInt32(dStrYE * 100)).ToString("X4");
                        }
                    }
                    else
                    {
                        CCzkMoney = (Convert.ToInt32(dStrYE * 10)).ToString("X4");
                    }
                }
                else
                {
                    CCzkMoney = Convert.ToInt32(dStrYE).ToString("X4");
                }
                string sLoad = LedSound_New(0x6C, CCzkMoney, "FFFF", "FFFF", strCPH);
                bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x6C, sLoad);

            }
            else
            {
                bSend = new byte[1];
            }
            return bSend;
        }


        /// <summary>
        /// 处理音频发送
        /// </summary>
        /// <returns></returns>
        public string LedSound_New(byte byteCmd, string str1, string str2, string str3, string strPlate)
        {
            byte[] MyStr = new byte[19];
            byte[] rtnMystr = new byte[20];
            for (int i = 0; i < 19; i++)
            {
                MyStr[i] = 0xFF;
            }

            if (str1 == "FFFF" || str1 == null)
            {

            }
            else
            {
                //2015-07-06
                if (str1.IndexOf('-') >= 0)
                {
                    str1 = "FFFF";
                }
                else
                {
                    MyStr[0] = Convert.ToByte(0x30 + Convert.ToByte(str1.Substring(0, 1), 16));
                    MyStr[1] = Convert.ToByte(0x30 + Convert.ToByte(str1.Substring(1, 1), 16));
                    MyStr[2] = Convert.ToByte(0x30 + Convert.ToByte(str1.Substring(2, 1), 16));
                    MyStr[3] = Convert.ToByte(0x30 + Convert.ToByte(str1.Substring(3, 1), 16));
                }
            }

            if (str2 == "FFFF")
            {

            }
            else
            {

                if (byteCmd == 0x6A || byteCmd == 0x6B)
                {
                    byte[] byte1 = StringToAsciiBytes(str2);
                    MyStr[4] = byte1[0];
                    MyStr[5] = byte1[1];
                    MyStr[6] = byte1[2];
                    MyStr[7] = byte1[3];
                }
                else
                {
                    MyStr[4] = Convert.ToByte(0x30 + Convert.ToByte(str2.Substring(0, 1), 16));
                    MyStr[5] = Convert.ToByte(0x30 + Convert.ToByte(str2.Substring(1, 1), 16));
                    MyStr[6] = Convert.ToByte(0x30 + Convert.ToByte(str2.Substring(2, 1), 16));
                    MyStr[7] = Convert.ToByte(0x30 + Convert.ToByte(str2.Substring(3, 1), 16));
                }
            }

            //2015-07-06 如果时间有负数，则不报时间
            if (null != str3 && str3 != "" && str3.IndexOf('-') >= 0)
            {
                str3 = "FFFF";
            }

            if (str3 == "FFFF")
            {

            }
            else
            {
                if (byteCmd == 0x69)
                {
                    MyStr[8] = Convert.ToByte(str3.Substring(0, 2), 16);
                    MyStr[9] = Convert.ToByte(str3.Substring(2, 2), 16);
                    MyStr[10] = Convert.ToByte(str3.Substring(4, 2), 16);
                    MyStr[11] = Convert.ToByte(str3.Substring(6, 2), 16);
                }
                else if (byteCmd == 0x6D)
                {
                    MyStr[8] = Convert.ToByte(str3.Substring(0, 2), 16);
                    MyStr[9] = Convert.ToByte(str3.Substring(2, 2), 16);
                    MyStr[10] = Convert.ToByte(str3.Substring(4, 2), 16);
                    MyStr[11] = Convert.ToByte(str3.Substring(6, 2), 16);

                }
                else
                {
                    MyStr[8] = Convert.ToByte(0x30 + Convert.ToByte(str3.Substring(0, 1), 16));
                    MyStr[9] = Convert.ToByte(0x30 + Convert.ToByte(str3.Substring(1, 1), 16));
                    MyStr[10] = Convert.ToByte(0x30 + Convert.ToByte(str3.Substring(2, 1), 16));
                    MyStr[11] = Convert.ToByte(0x30 + Convert.ToByte(str3.Substring(3, 1), 16));
                }
            }
            if (strPlate.Length == 7 || (strPlate.Length == 8 && strPlate.Substring(0, 2) == "WJ"))
            {
                string CPH = GetCphToHex(strPlate);
                byte[] byteCPH = GetByteArray(CPH);
                int iLength = byteCPH.Length;
                if (iLength > 7)
                {
                    iLength = 7;
                }
                for (int j = 0; j < iLength; j++)
                {
                    MyStr[12 + j] = byteCPH[j];
                }
            }
            else
            {

            }
            string strDate = ByteToHexString(MyStr);
            byte yhxy = YHXY(strDate);

            for (int i = 0; i < MyStr.Length; i++)
            {
                rtnMystr[i] = MyStr[i];
            }
            rtnMystr[19] = yhxy;

            return ByteToHexString(rtnMystr);
        }

        /// <summary>
        /// btye数组转换为字符串
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public string ByteToHexString(byte[] bytes)
        {
            string str = string.Empty;
            if (bytes != null)
            {
                for (int i = 0; i < bytes.Length; i++)
                {
                    str += bytes[i].ToString("X2");
                }
            }
            return str;
        }
        /// <summary>
        ///异或效验 
        /// </summary>
        /// <param name="strList"></param>
        /// <returns></returns>
        public byte YHXY(string str)
        {
            string[] strList = GetStringArray(str);
            byte[] Hexbyte = new byte[strList.Length];
            byte check = 0;

            //2015-08-15
            //if (strList.Length == 1)
            //{
            //    return Convert.ToByte(strList[0], 16);
            //}

            check = (byte)(Convert.ToByte(strList[0], 16) ^ Convert.ToByte(strList[1], 16));
            for (int i = 2; i < strList.Length; i++)
            {
                check = (byte)(check ^ Convert.ToByte(strList[i], 16));
            }
            string CheckSumHex = Convert.ToString(check, 16);
            if (CheckSumHex.Length == 1)
            {
                CheckSumHex = "0" + CheckSumHex;
            }
            return Convert.ToByte(CheckSumHex.ToUpper(), 16);
        }

        /// <summary>
        /// 字符串转换为字符串数组
        /// 如12345678,每取两位转换为12 34 56 78的四个数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public string[] GetStringArray(string str)
        {
            List<String> al = new List<String>();
            for (int i = 0; i < str.Length / 2; i++)
            {
                string strJihao = str.Substring(i * 2, 2);
                al.Add(strJihao);
            }
            string s = string.Join(",", al.ToArray());
            string[] HexStr = s.Split(',');
            return HexStr;
        }
        /// <summary>
        /// 返回字符串的ASCII数组
        /// </summary>
        /// <param name="strAscii"></param>
        /// <returns></returns>
        public byte[] StringToAsciiBytes(string strAscii)
        {

            byte[] byteDate;

            System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();

            byteDate = asciiEncoding.GetBytes(strAscii);

            return byteDate;

        }

        /// <summary>
        /// 车牌号转换为16进制
        /// </summary>
        /// <param name="CPH"></param>
        /// <returns></returns>
        public string GetCphToHex(string CPH)
        {

            string strSum = "";
            string diqu = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警军空海北沈兰济南广成甲乙丙午未申庚巳辛壬临武使ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string diqu1 = "京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼渝川贵云藏陕甘青宁新港澳台警使武领学";
            if (CPH.Length == 8 && CPH.Substring(0, 2) == "WJ")
            {
                CPH = "武" + CPH.Substring(2);

                string str2 = CPH.Substring(0, 1);
                string strNum = "";
                for (int i = 0; i < diqu.Length; i++)
                {
                    if (diqu.Substring(i, 1) == str2)
                    {
                        strNum = i.ToString("X2");
                    }
                }
                string str3 = CPH.Substring(1, 1);
                string strNum1 = "";
                for (int i = 0; i < diqu1.Length; i++)
                {
                    if (diqu1.Substring(i, 1) == str3)
                    {
                        strNum1 = i.ToString("X2");
                    }
                }
                string sum = "";
                for (int i = 0; i < CPH.Substring(2, 5).Length; i++)
                {
                    string strJihao = CPH.Substring(2, 5).Substring(i, 1);

                    char chr = Convert.ToChar(strJihao);
                    //int aaaa = (int)chr;

                    sum += ((int)chr).ToString("X2");
                }
                strSum = strNum + strNum1 + sum;
            }
            else if (diqu1.Contains(CPH.Substring(CPH.Length - 1, 1)))
            {
                string str2 = CPH.Substring(0, 1);
                string strNum = "";
                for (int i = 0; i < diqu.Length; i++)
                {
                    if (diqu.Substring(i, 1) == str2)
                    {
                        strNum = i.ToString("X2");
                    }
                }

                string sum = "";
                for (int i = 0; i < CPH.Substring(1, 5).Length; i++)
                {
                    string strJihao = CPH.Substring(1, 5).Substring(i, 1);

                    char chr = Convert.ToChar(strJihao);
                    //int aaaa = (int)chr;

                    sum += ((int)chr).ToString("X2");
                }

                string str3 = CPH.Substring(CPH.Length - 1, 1);
                string strNum1 = "";
                for (int i = 0; i < diqu1.Length; i++)
                {
                    if (diqu1.Substring(i, 1) == str3)
                    {
                        strNum1 = i.ToString("X2");
                    }
                }

                strSum = strNum + sum + strNum1;
            }
            else
            {
                string str1 = CPH.Substring(0, 1);

                string strNum = "";
                for (int i = 0; i < diqu.Length; i++)
                {
                    if (diqu.Substring(i, 1) == str1)
                    {
                        strNum = i.ToString("X2");
                        break;
                    }
                }
                string sum = "";
                for (int i = 0; i < CPH.Substring(1, 6).Length; i++)
                {
                    string strJihao = CPH.Substring(1, 6).Substring(i, 1);
                    if (diqu1.Contains(strJihao))
                    {
                        for (int j = 0; j < diqu1.Length; j++)
                        {
                            if (diqu1.Substring(j, 1) == strJihao)
                            {
                                sum += j.ToString("X2");
                                break;
                            }
                        }
                    }
                    else
                    {
                        char chr = Convert.ToChar(strJihao);
                        sum += ((int)chr).ToString("X2");
                    }

                    //int aaaa = (int)chr;


                }
                strSum = strNum + sum;
            }


            return strSum;
        }

        /// <summary>
        /// 十六进制字符串转换为Byte数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public byte[] GetByteArray(string str)
        {
            string[] HexStr = GetStringArray(str);
            byte[] Hexbyte = new byte[HexStr.Length];
            for (int j = 0; j < HexStr.Length; j++)
            {
                Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            }

            return Hexbyte;
        }


        /// <summary>
        /// 组合语音发送
        /// </summary>
        /// <param name="iGateNum">车道编号</param>
        /// <param name="strData">语音编号</param>
        /// <returns></returns>
        public string LoadLsNoX2010znykt(int iGateNum, string strData)
        {
            string strRst = "0";
            byte[] bSend;
            int iJiHao = Model.Channels[iGateNum].iCtrlID;//机号
            int iGateType = Model.Channels[iGateNum].iInOut;//车道类型
            int iXieYi = Model.Channels[iGateNum].iXieYi;//协议类型

            int iLenY = (strData.Length / 2);
            strData += AllCommand.YHXY(strData).ToString("X2");
            strData = iLenY.ToString("X2") + strData;

            bSend = AllCommand.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), 0x3D, 0x72, strData);

            if (Model.bOut485)//判断是否为摄像机开闸
            {
                if (Model.iVideoType == 0)//ZNYKTY5 摄像机通透485
                {
                    CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialSendbyte(m_nSerialHandle[iGateNum], bSend, bSend.Length);
                }
            }
            else
            {
                if (Model.Channels[iGateNum].iXieYi == 1)
                {
                    strRst = IsSuccess(UDPSend.Send(bSend, Model.Channels[iGateNum].sIP, LPort, SPort));// 返回值进行解析
                }
            }
            return strRst;
        }


        /// <summary>
        /// 返回值进行解析  判断指令是否发送成功
        /// </summary>
        /// <param name="strRst"></param>
        /// <returns></returns>
        private string IsSuccess(string strRst)
        {
            if (strRst.Length > 1)
            {
                if (strRst.Substring(strRst.Length - 4, 4) == "3030")
                {
                    return "0";
                }
                else
                {
                    return "1";
                }
            }
            else
            {
                return strRst;
            }
        }

        /// <summary>
        /// 显示屏控制命令,报语音“请交费XXXX元”
        /// </summary>
        /// <param name="ax"></param>
        /// <param name="iJiHao"></param>
        /// <param name="strIP"></param>
        /// <param name="strData"></param>
        /// <param name="iHandle"></param>
        /// <param name="iXieYi"></param>
        public void LedShow2010znykt(int iGateNum, string strData)
        {
            byte[] bVZSend = AllCommand.ShowLed(Model.Channels[iGateNum].iCtrlID, strData);

            if (Model.bOut485)
            {
                if (Model.iVideoType == 0)//ZNYKTY5 摄像机通透485
                {
                    int ret = CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialSendbyte(m_nSerialHandle[iGateNum], bVZSend, bVZSend.Length);
                }
            }
            else
            {
                if (Model.Channels[iGateNum].iXieYi == 1)
                {
                    //GCR.SedBll sendbll = new GCR.SedBll(strIP, 1007, 1005);
                    //sendbll.ShowLed(iJiHao, strData, iXieYi);

                    IsSuccess(UDPSend.Send(bVZSend, Model.Channels[iGateNum].sIP, LPort, SPort));// 返回值进行解析
                }
            }
        }


        public void LoadTime(int iJiHao, string strIP, int iHandle, int iXieYi)
        {
            if (Model.bOut485)
            {
                byte[] bVZSend = AllCommand.LoadTime(iJiHao, DateTime.Now);
                if (Model.strVideoType == "ZNYKT5")
                {
                    int ret = CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialSendbyte(iHandle, bVZSend, bVZSend.Length);
                }
                else if (Model.strVideoType == "ZNYKT14")
                {
                    int iRst = CameraSDK.ZNYKT14.MyClass.Net_TransRS485Data(iHandle, Model.i485TT, bVZSend, Convert.ToByte(bVZSend.Length));
                }
                else if (Model.strVideoType == "ZNYKT13")
                {
                    CameraSDK.ZNYKT13.YW7000NetClient.Sen485((IntPtr)iHandle, bVZSend);
                }
            }
            else
            {
                if (iXieYi == 1)
                {
                    SedBll senbll = new SedBll(strIP, 1007, 1005);
                    string strRetun = senbll.LoadTime(iJiHao, DateTime.Now, iXieYi);
                }
            }
        }


        private static void CtrlOutput(IntPtr iLogon, byte nOutputNo, byte nStatus)
        {
            CameraSDK.ZNYKT13.YW7000NetClient.OUTPUT_CTRL OutputCtrl = new CameraSDK.ZNYKT13.YW7000NetClient.OUTPUT_CTRL();
            OutputCtrl.ChannelNo = nOutputNo;
            OutputCtrl.Status = nStatus;
            IntPtr pConfigBuf = Marshal.AllocHGlobal(Marshal.SizeOf(OutputCtrl));
            Marshal.StructureToPtr(OutputCtrl, pConfigBuf, false);
            CameraSDK.ZNYKT13.HHERR_CODE errCode = CameraSDK.ZNYKT13.YW7000NetClient.YW7000NET_SetServerConfig(iLogon, CameraSDK.ZNYKT13.HHCMD_NET.HHCMD_SET_OUTPUT_CTRL,
                pConfigBuf, (uint)Marshal.SizeOf(OutputCtrl), 0);
            Marshal.FreeHGlobal(pConfigBuf);
        }


        private Hid usbHid = new Hid();

        public struct VIDEO_WND
        {
            public string m_DevName, m_DevUrl, m_DevUser, m_DevPasswd;
            public int m_nPort;
            public IntPtr m_hOpenVideo, m_hLogon, m_hOpenImg, m_hTalk, m_hPlayTalk, m_hRecord;
            public ushort m_VideoWidth, m_VideoHeight;
            public int m_CurrPosY;
            public object m_mutexRecord;
            public System.Windows.Forms.Label DisplayWnd;
            public bool m_bSlave, m_bListen, m_bCheckLine, m_bCarRect;
            public byte[] m_bOut;
            public AutoResetEvent LoginEvent;
            public Task m_ReLoginThread;
            public AutoResetEvent ChannelEvent;
            public Task m_ReOpenChThread;
            public AutoResetEvent PictureEvent;
            public Task m_ReOpenPicThread;
        }

        VIDEO_WND[] VideoInfo = new VIDEO_WND[11];

        private VzClientSDK.VZDEV_SERIAL_RECV_DATA_CALLBACK serialRECV = null;

        int m_nSelIndex = 0;

        GetServiceData gsd = new GetServiceData();

        public void LoadParameter()
        {
            try
            {
                string[] strTmp = new string[2];

                string strRetun = "";
                for (int y = 0; y < Model.iChannelCount; y++)
                {
                    #region ---带控制板加载控制板参数
                    if (Model.bIsKZB)
                    {
                        SedBll sendbll = new SedBll(Model.Channels[y].sIP, 1007, 1005);
                        //固定卡有效期剩余xx天提示
                        byte[] BSend = CR.GetByteArray(Model.iIDNoticeDay.ToString("00") + Model.iIDNoticeDay.ToString("00"));

                        if (Model.Channels[y].iXieYi == 1 || Model.Channels[y].iXieYi == 3)
                        {
                            sendbll.SetUsbType(ref usbHid, Model.Channels[y].iXieYi);
                            strRetun = sendbll.DisplayCmdX1(Convert.ToByte(Model.Channels[y].iCtrlID), 0x84, BSend, Model.Channels[y].iXieYi);
                        }

                        System.Threading.Thread.Sleep(100);
                        if (strRetun == "2")
                        {
                            //MessageBox.Show("控制机【" + Model.Channels[y].iCtrlID.ToString() + "】通讯不通", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                            continue;
                        }

                        //设置语音播报方式
                        switch (Model.iCtrlVoiceMode)
                        {
                            case 0:// '欢迎光临/一路顺风:
                                strTmp[0] = "55";
                                strTmp[1] = "55";
                                break;
                            case 1:// '您好/一路平安
                                strTmp[0] = "AA";
                                strTmp[1] = "AA";
                                break;
                            case 2:// '欢迎光临/一路平安
                                strTmp[0] = "55";
                                strTmp[1] = "AA";
                                break;
                            case 3:// '您好/一路顺风
                                strTmp[0] = "AA";
                                strTmp[1] = "55";
                                break;
                        }

                        if (Model.Channels[y].iXieYi == 1 || Model.Channels[y].iXieYi == 3)
                        {
                            sendbll.SetUsbType(ref usbHid, Model.Channels[y].iXieYi);
                            strRetun = sendbll.LoadLsNoX2010znykt(Convert.ToByte(Model.Channels[y].iCtrlID), 0x3D, 0x60, strTmp[0] + strTmp[0] + strTmp[1] + strTmp[1], Model.Channels[y].iXieYi);
                        }

                        System.Threading.Thread.Sleep(100);
                        if (strRetun == "2")
                        {
                            //MessageBox.Show("与控制机通讯不通", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        //设置语音播报版本
                        switch (Model.iCtrlVoiceLedVersion)
                        {
                            case 0:// '3.0语音/显示屏
                                strTmp[0] = "AA";
                                break;
                            case 1:// 4.1语音/显示屏
                                strTmp[0] = "55";
                                break;
                        }

                        if (Model.iCtrlShowPlate == 1)
                        {
                            strTmp[0] = "55";
                        }
                        else
                        {
                            strTmp[0] = "AA";
                        }
                        if (Model.iCtrlShowStayTime == 1)
                        {
                            strTmp[1] = "55";
                        }
                        else
                        {
                            strTmp[1] = "AA";
                        }
                        if (Model.Channels[y].iXieYi == 1 || Model.Channels[y].iXieYi == 3)
                        {
                            sendbll.SetUsbType(ref usbHid, Model.Channels[y].iXieYi);
                            strRetun = sendbll.LoadLsNoX2010znykt(Convert.ToByte(Model.Channels[y].iCtrlID), 0x3D, 0x71, strTmp[0] + strTmp[0] + strTmp[1] + strTmp[1], Model.Channels[y].iXieYi);
                        }

                        System.Threading.Thread.Sleep(100);
                        if (strRetun == "2")
                        {
                            //MessageBox.Show("与控制机通讯不通", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                        //判断带小数点
                        if (Model.iXsd == 1)
                        {
                            strTmp[0] = "AA";
                        }
                        else
                        {
                            if (Model.iChargeType == 3)
                            {
                                if (Model.iXsdNum == 1)
                                {
                                    strTmp[0] = "AA";
                                }
                                else
                                {
                                    strTmp[0] = "BB";
                                }
                            }
                            else
                            {
                                strTmp[0] = "55";
                            }
                        }
                        if (Model.Channels[y].iXieYi == 1 || Model.Channels[y].iXieYi == 3)
                        {
                            sendbll.SetUsbType(ref usbHid, Model.Channels[y].iXieYi);
                            strRetun = sendbll.LoadLsNoX2010znykt(Convert.ToByte(Model.Channels[y].iCtrlID), 0x3D, 0x6F, strTmp[0] + strTmp[0] + "00" + "00", Model.Channels[y].iXieYi);
                        }

                        if (strRetun == "2")
                        {
                            //MessageBox.Show("与控制机通讯不通", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        //加载过期多少天后禁止入场 2016-06-23 th
                        if (Model.iYKOverTimeCharge == 2)
                        {
                            if (Model.Channels[y].iXieYi == 1)
                            {
                                sendbll.SendCommand(Model.Channels[y].iCtrlID, 0x85, Model.iMothOverDay, Model.Channels[y].iXieYi);//开闸
                            }
                        }
                        else
                        {
                            if (Model.Channels[y].iXieYi == 1)
                            {
                                sendbll.SendCommand(Model.Channels[y].iCtrlID, 0x85, 0, Model.Channels[y].iXieYi);//开闸
                            }
                        }


                        Dictionary<string, object> dic = new Dictionary<string, object>();
                        dic = gsd.GetDeviceParameter(Model.Channels[y].iCtrlID, Model.Channels[y].sIP);
                        if (dic != null && dic.Count > 0)
                        {
                            //2017-02-15
                            string str1 = DataSourceToOx1String(Model.Channels[y].sIP, Model.Channels[y].iCtrlID, Model.Channels[y].iXieYi, dic);
                            string str2 = DataSourceToOx2String(Model.Channels[y].sIP, Model.Channels[y].iCtrlID, Model.Channels[y].iXieYi, dic);
                            string rtnStr = sendbll.DisplayCmdX2(Convert.ToByte(Model.Channels[y].iCtrlID), 0x43, CR.GetByteArray(str1), 1);
                            string strRsts = sendbll.LoadDinnerPriceSet(Convert.ToByte(Model.Channels[y].iCtrlID), str2, Model.Channels[y].iXieYi, Model.Channels[y].sIP);
                            if (strRsts == "2")
                            {
                                //MessageBox.Show("与控制机通讯不通", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                                return;
                            }
                        }
                        else
                        {

                            //脱机车牌识别专用 车牌识别在线下位机月卡不开闸
                            string strData = sendbll.LoadOffLineSet(Convert.ToByte(Model.Channels[y].iCtrlID), Model.Channels[y].iXieYi, Model.Channels[y].sIP);

                            if (Model.iMorePaingCar == 1 || Model.iIDOneInOneOut == 1)
                            {
                                if (strData.Length > 1)
                                {
                                    string str1 = Convert.ToInt32(Convert.ToString(Convert.ToInt32(strData.Substring(17, 1), 16), 2)).ToString("0000");

                                    str1 = "0" + str1.Substring(1);


                                    string strSend = Convert.ToString(Convert.ToInt32(str1, 2), 16).ToUpper();

                                    strSend = strData.Substring(0, 17) + strSend + strData.Substring(18);

                                    string strRsts = sendbll.LoadDinnerPriceSet(Convert.ToByte(Model.Channels[y].iCtrlID), strSend, Model.Channels[y].iXieYi, Model.Channels[y].sIP);
                                    if (strRsts == "2")
                                    {
                                        //MessageBox.Show("与控制机通讯不通", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                                        return;
                                    }
                                }
                            }
                            else
                            {
                                if (strData.Length > 1)
                                {
                                    string str1 = Convert.ToInt32(Convert.ToString(Convert.ToInt32(strData.Substring(17, 1), 16), 2)).ToString("0000");

                                    str1 = "1" + str1.Substring(1);


                                    string strSend = Convert.ToString(Convert.ToInt32(str1, 2), 16).ToUpper();

                                    strSend = strData.Substring(0, 17) + strSend + strData.Substring(18);

                                    string strRsts = sendbll.LoadDinnerPriceSet(Convert.ToByte(Model.Channels[y].iCtrlID), strSend, Model.Channels[y].iXieYi, Model.Channels[y].sIP);

                                    if (strRsts == "2")
                                    {
                                        //MessageBox.Show("与控制机通讯不通", "提示", MessageBoxButton.OK, MessageBoxImage.Error);
                                        return;
                                    }
                                }
                            }

                        }



                        List<CheDaoSet> lstCDO = gsd.GetCheDaoOffline();
                        int N = 0;
                        string sIP = "";
                        
                        string strRstOK = "";
                        string strRstZOK = "";
                        string strMsg = "";
                        for (int i = 0; i < lstCDO.Count; i++)
                        {
                            if (lstCDO[i].SendSignal == true)
                            {
                                sendbll = new SedBll(lstCDO[i].IP, 1007, 1005);
                                string strIP = lstCDO[i].IP;
                                int iCount = 0;
                                if (lstCDO[i].XieYi == 1)
                                {
                                    if (N == 0)
                                    {
                                        sIP = strIP;
                                    }
                                    else
                                    {
                                        //前3段不一样，则不是同一网段
                                        if (sIP.Substring(0, sIP.LastIndexOf(".")) != strIP.Substring(0, strIP.LastIndexOf(".")))
                                        {

                                            return;
                                        }
                                    }
                                    N++;

                                    bool bOK = false;
                                    for (int j = 0; j < lstCDO.Count; j++)
                                    {
                                        if (lstCDO[j].InOut == 1)
                                        {
                                            if (lstCDO[j].RecieveSignal == true)
                                            {
                                                strRstOK += "1";
                                                string strIP1 = lstCDO[j].IP;
                                                string SendIP = "";

                                                if (lstCDO[j].XieYi == 1)
                                                {
                                                    string[] r = strIP1.Split('.');
                                                    foreach (string s in r)
                                                    {
                                                        SendIP += Convert.ToInt32(s).ToString("X2");
                                                    }
                                                    string strSend = "54" + iCount.ToString("X2") + SendIP + "FFFFFFFF";
                                                    strRetun = sendbll.SetOffLineIP(lstCDO[i].CtrlNumber, strSend, lstCDO[i].XieYi);
                                                    if (strRetun == "0")
                                                    {
                                                        strRstOK += "1";
                                                    }
                                                    else
                                                    {
                                                        strMsg += "【" + lstCDO[i].CtrlNumber + "】";
                                                        bOK = true;
                                                        break;
                                                    }
                                                    iCount++;
                                                }
                                                else
                                                {
                                                    continue;
                                                }
                                            }
                                            else
                                            {
                                                continue;
                                            }
                                        }
                                        else
                                        {
                                            continue;
                                        }
                                    }

                                    for (int j = iCount; j < 16; j++)
                                    {
                                        if (bOK)
                                        {
                                            break;
                                        }
                                        strRstOK += "1";
                                        string strSend = "54" + iCount.ToString("X2") + "FFFFFFFFFFFFFFFF";
                                        strRetun = sendbll.SetOffLineIP(lstCDO[i].CtrlNumber, strSend, lstCDO[i].XieYi);
                                        if (strRetun == "0")
                                        {
                                            strRstZOK += "1";
                                        }
                                        else
                                        {
                                            strMsg += "【" + lstCDO[i].CtrlNumber + "】";
                                            break;
                                        }
                                        iCount++;
                                    }
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }

                        if (strRstOK == strRstZOK)
                        {

                        }
                        else
                        { 
                        
                        }
                    }
                    #endregion


                    #region -----摄像机加载显示屏
                    else
                    {
                        List<NetCameraSet> lstNCS = gsd.SelectVideo(Model.Channels[y].sIDAddress);
                        if (lstNCS.Count > 0)
                        {
                            string strVideoType = lstNCS[0].VideoType.ToString();
                            if (strVideoType == "ZNYKTY5" || strVideoType == "ZNYKTY14" || strVideoType == "ZNYKTY13")
                            {

                                int m_nSerialHandle = 0;
                                int m_hLPRClient = 0;
                                if (strVideoType == "ZNYKTY5")
                                {
                                    m_hLPRClient = ParkingCommunication.CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_Open(lstNCS[0].VideoIP, ushort.Parse(lstNCS[0].VideoPort), lstNCS[0].VideoUserName, lstNCS[0].VideoPassWord);
                                    if (m_hLPRClient == 0)
                                    {
                                        //MessageBox.Show("与摄像机链接【" + lstNCS[0].VideoIP + "】失败！");
                                        break;
                                    }

                                    m_nSerialHandle = ParkingCommunication.CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialStart(m_hLPRClient, 1, serialRECV, IntPtr.Zero);
                                }
                                else if (strVideoType == "ZNYKTY14")
                                {
                                    int nCamId = MyClass.Net_AddCamera(lstNCS[0].VideoIP.ToString());
                                    m_nSerialHandle = nCamId;
                                    int iRet = MyClass.Net_ConnCamera(nCamId, 30000, 10);
                                    if (iRet != 0)
                                    {
                                        //MessageBox.Show("与摄像机链接【" + lstNCS[0].VideoIP.ToString() + "】失败！");
                                        break;
                                    }
                                }
                                else if (strVideoType == "ZNYKTY13")
                                {
                                    //HHERR_CODE errCode = YW7000NetClient.YW7000NET_LogonServer(Videodt.Rows[0]["VideoIP"].ToString(), ushort.Parse(Videodt.Rows[0]["VideoPort"].ToString()), "", Videodt.Rows[0]["VideoUserName"].ToString(), Videodt.Rows[0]["VideoPassWord"].ToString(), (uint)0, out VideoInfo[0].m_hLogon, IntPtr.Zero);
                                    //if (errCode != HHERR_CODE.HHERR_SUCCESS)
                                    //{
                                    //    MessageBox.Show("连接相机【" + txtIP.Text + "】失败!", "提示");
                                    //    break;
                                    //}
                                }


                                if (Model.iCtrlShowPlate == 1)
                                {
                                    strTmp[0] = "55";
                                }
                                else
                                {
                                    strTmp[0] = "AA";
                                }
                                if (Model.iCtrlShowStayTime == 1)
                                {
                                    strTmp[1] = "55";
                                }
                                else
                                {
                                    strTmp[1] = "AA";
                                }


                                byte[] bVZSend = ParkingCommunication.AllCommand.LoadLsNoX2010znykt(0, 0x3D, 0x71, strTmp[0] + strTmp[0] + strTmp[1] + strTmp[1], 0); ;


                                if (strVideoType == "ZNYKTY5")
                                {
                                    int ret0 = ParkingCommunication.CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialSendbyte(m_nSerialHandle, bVZSend, bVZSend.Length);
                                }
                                else if (strVideoType == "ZNYKTY14")
                                {
                                    int iRst = MyClass.Net_TransRS485Data(m_nSerialHandle, Model.i485TT, bVZSend, Convert.ToByte(bVZSend.Length));
                                }
                                else if (strVideoType == "ZNYKTYY13")
                                {
                                    YW7000NetClient.Sen485(VideoInfo[0].m_hLogon, bVZSend);
                                }

                                System.Threading.Thread.Sleep(100);


                                //设置语音播报方式
                                switch (Model.iCtrlVoiceMode)
                                {
                                    case 0:// '欢迎光临/一路顺风:
                                        strTmp[0] = "55";
                                        strTmp[1] = "55";
                                        break;
                                    case 1:// '您好/一路平安
                                        strTmp[0] = "AA";
                                        strTmp[1] = "AA";
                                        break;
                                    case 2:// '欢迎光临/一路平安
                                        strTmp[0] = "55";
                                        strTmp[1] = "AA";
                                        break;
                                    case 3:// '您好/一路顺风
                                        strTmp[0] = "AA";
                                        strTmp[1] = "55";
                                        break;
                                }

                                byte[] bVZSend2 = ParkingCommunication.AllCommand.LoadLsNoX2010znykt(0, 0x3D, 0x60, strTmp[0] + strTmp[0] + strTmp[1] + strTmp[1], 0); ;


                                if (strVideoType == "ZNYKTY5")
                                {
                                    int ret0 = ParkingCommunication.CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialSendbyte(m_nSerialHandle, bVZSend2, bVZSend2.Length);
                                }
                                else if (strVideoType == "ZNYKTY14")
                                {
                                    int iRst = MyClass.Net_TransRS485Data(m_nSerialHandle, Model.i485TT, bVZSend2, Convert.ToByte(bVZSend2.Length));
                                }
                                else if (strVideoType == "ZNYKTY13")
                                {
                                    YW7000NetClient.Sen485(VideoInfo[0].m_hLogon, bVZSend2);
                                }
                                System.Threading.Thread.Sleep(100);
                                //判断带小数点
                                if (Model.iXsd == 1)
                                {
                                    strTmp[0] = "AA";
                                }
                                else
                                {
                                    if (Model.iChargeType == 3)
                                    {
                                        if (Model.iXsdNum == 1)
                                        {
                                            strTmp[0] = "AA";
                                        }
                                        else
                                        {
                                            strTmp[0] = "BB";
                                        }
                                    }
                                    else
                                    {
                                        strTmp[0] = "55";
                                    }
                                }

                                byte[] bVZSend1 = ParkingCommunication.AllCommand.LoadLsNoX2010znykt(0, 0x3D, 0x6F, strTmp[0] + strTmp[0] + strTmp[1] + strTmp[1], 0); ;

                                if (strVideoType == "ZNYKTY5")
                                {
                                    int ret = VzClientSDK.VzLPRClient_SerialSendbyte(m_nSerialHandle, bVZSend1, bVZSend1.Length);
                                }
                                else if (strVideoType == "ZNYKTY14")
                                {
                                    int iRst = MyClass.Net_TransRS485Data(m_nSerialHandle, Model.i485TT, bVZSend1, Convert.ToByte(bVZSend1.Length));
                                }
                                else if (strVideoType == "ZNYKTY13")
                                {
                                    YW7000NetClient.Sen485(VideoInfo[0].m_hLogon, bVZSend1);
                                }

                                if (strVideoType == "ZNYKTY5")
                                {
                                    if (m_hLPRClient > 0)
                                    {
                                        ParkingCommunication.CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_Close(m_hLPRClient);
                                        m_hLPRClient = 0;
                                    }
                                }
                                else if (strVideoType == "ZNYKTY14")
                                {
                                    MyClass.Net_DisConnCamera(m_nSerialHandle);
                                    MyClass.Net_DelCamera(m_nSerialHandle);
                                }
                                else if (strVideoType == "ZNYKTY13")
                                {
                                    if (VideoInfo[0].m_hLogon != IntPtr.Zero)
                                    {
                                        YW7000NetClient.YW7000NET_LogoffServer(VideoInfo[0].m_hLogon);
                                        VideoInfo[m_nSelIndex].m_hLogon = IntPtr.Zero;
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    #region 加载收费标准
                    LoadChargeStandard();
                    #endregion

                }
            }
            catch (Exception ex)
            {
                gsd.AddLog("LoadParameter:", ex.Message + "\r\n" + ex.StackTrace);
            }
        }


        /// <summary>
        /// 读取并加载收费标准
        /// </summary>
        public void LoadChargeStandard()
        {
            List<CheDaoSet> cds = gsd.GetCtrName(Model.stationID);
            List<CardTypeDef> ctd = gsd.GetChargeCarType();

            for (int i = 0; i < cds.Count; i++)
            {
                if (cds[i].InOut == 1)
                {
                    for (int j = 0; j < ctd.Count; j++)
                    {
                        List<ChargeRules> lstCR = gsd.GetChargeRules(ctd[j].Identifying);
                        if (lstCR == null || lstCR.Count <= 0)
                        {
                            continue;
                        }

                        CardTypeChargeRules ChargeRule = new CardTypeChargeRules(lstCR);
                        DeviceCommander cmder = DeviceCommander.GetCommander(cds[i]);
                        int ret = cmder.SetChargeRule(ChargeRule);
                    }
                }
            }
        }


        public string DataSourceToOx1String(string sIP, int ctrlNumber, int xieYi, Dictionary<string, object> dic)
        {
            try
            {
                string SStr1 = "";
                string SStr2 = "";
                string SStr3 = "";
                string SStr4 = "";
                if (xieYi != 1)
                {
                    SStr1 = "11111111";
                    SStr2 = "11111111";
                    SStr3 = "11111111";
                    SStr4 = "11111111";
                }
                else
                {
                    SedBll sendbll = new SedBll(sIP, 1007, 1005);
                    string rtnStr = sendbll.ReadSystem(Convert.ToByte(ctrlNumber), 1);

                    string strSum = "";
                    foreach (char c in rtnStr)
                    {
                        strSum += CR.ConvertToBin(c);
                    }

                    string str1 = strSum.Substring(0, 8);
                    string str2 = strSum.Substring(8, 8);
                    string str3 = strSum.Substring(16, 8);
                    string str4 = strSum.Substring(24, 8);
                }


    
                SStr1 = CR.ReplaceAppointString(SStr1, SStr1.Substring(7, 1), dic.ContainsKey("IsExit") ? (dic["IsExit"].ToString() == "1" ? "0" : "1") : "1", 7);
                SStr1 = CR.ReplaceAppointString(SStr1, SStr1.Substring(1, 1), dic.ContainsKey("SmallPark") ? (dic["SmallPark"].ToString() == "1" ? "0" : "1") : "1", 1);

                SStr2 = CR.ReplaceAppointString(SStr2, SStr2.Substring(7, 1), dic.ContainsKey("ICTempConfirmCutOff") ? (dic["ICTempConfirmCutOff"].ToString() == "1" ? "0" : "1") : "1", 7);
                SStr2 = CR.ReplaceAppointString(SStr2, SStr2.Substring(4, 1), dic.ContainsKey("ICMonthConfirmCutOff") ? (dic["ICMonthConfirmCutOff"].ToString() == "1" ? "0" : "1") : "1", 4);

                SStr3 = CR.ReplaceAppointString(SStr3, SStr3.Substring(6, 1), dic.ContainsKey("BarrierShutInPalce") ? (dic["BarrierShutInPalce"].ToString() == "1" ? "0" : "1") : "1", 6);
                SStr3 = CR.ReplaceAppointString(SStr3, SStr3.Substring(3, 1), dic.ContainsKey("IllegalCutOffRecord") ? (dic["IllegalCutOffRecord"].ToString() == "1" ? "0" : "1") : "1", 3);

                SStr4 = CR.ReplaceAppointString(SStr4, SStr4.Substring(4, 1), dic.ContainsKey("UDiskClearAllCardInfo") ? (dic["UDiskClearAllCardInfo"].ToString() == "1" ? "0" : "1") : "1", 4);


                string strSum1 = string.Format("{0:X}", Convert.ToInt32(SStr1.Substring(0, 4), 2));
                strSum1 += string.Format("{0:X}", Convert.ToInt32(SStr1.Substring(4, 4), 2));
                string strSum2 = string.Format("{0:X}", Convert.ToInt32(SStr2.Substring(0, 4), 2));
                strSum2 += string.Format("{0:X}", Convert.ToInt32(SStr2.Substring(4, 4), 2));
                string strSum3 = string.Format("{0:X}", Convert.ToInt32(SStr3.Substring(0, 4), 2));
                strSum3 += string.Format("{0:X}", Convert.ToInt32(SStr3.Substring(4, 4), 2));
                string strSum4 = string.Format("{0:X}", Convert.ToInt32(SStr4.Substring(0, 4), 2));
                strSum4 += string.Format("{0:X}", Convert.ToInt32(SStr4.Substring(4, 4), 2));
                return strSum1 + strSum2 + strSum3 + strSum4;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message + "\r\n" + ex.StackTrace);
            }
        }

        public string DataSourceToOx2String(string sIP, int ctrlNumber, int xieYi, Dictionary<string, object> dic)
        {
            try
            {
                string str = "";
                if (xieYi != 1)
                {
                    str = "FFFFFFFFFFFFFFFFFF00000000";
                }
                else
                {
                    SedBll sendbll = new SedBll(sIP, 1007, 1005);
                    str = sendbll.LoadOffLineSet(Convert.ToByte(ctrlNumber), 1, sIP); 
                }

                string str1 = Convert.ToInt32(Convert.ToString(Convert.ToInt32(str.Substring(17, 1), 16), 2)).ToString("0000");
                string str2 = Convert.ToInt32(Convert.ToString(Convert.ToInt32(str.Substring(16, 1), 16), 2)).ToString("0000");
                string str3 = Convert.ToInt32(Convert.ToString(Convert.ToInt32(str.Substring(13, 1), 16), 2)).ToString("0000");

                str3 = str3.Substring(0, 3) + (dic.ContainsKey("ZeroCPHAutoCutOff") ? (dic["ZeroCPHAutoCutOff"].ToString() == "1" ? "0" : "1") : "1");

                if (Model.iMorePaingCar == 1 || Model.iIDOneInOneOut == 1)
                {
                    dic["MonthOnLineCutOff"] = 1;
                }

                str1 = (dic.ContainsKey("MonthOnLineCutOff") ? (dic["MonthOnLineCutOff"].ToString() == "1" ? "0" : "1") : "1") +
                    (dic.ContainsKey("TempVisibleSinogram") ? (dic["TempVisibleSinogram"].ToString() == "1" ? "0" : "1") : "1") +
                    (dic.ContainsKey("IsEnableTempOffline") ? (dic["IsEnableTempOffline"].ToString() == "1" ? "0" : "1") : "1") +
                    (dic.ContainsKey("WhiteCPHAutoCutOff") ? (dic["WhiteCPHAutoCutOff"].ToString() == "1" ? "0" : "1") : "1");

                str2 = (dic.ContainsKey("CancelChargeCameraOffline") ? (dic["CancelChargeCameraOffline"].ToString() == "1" ? "0" : "1") : "1") + str2.Substring(1);


                string strSend = Convert.ToString(Convert.ToInt32(str1, 2), 16).ToUpper();

                string strSend1 = Convert.ToString(Convert.ToInt32(str2, 2), 16).ToUpper();

                string strSend2 = Convert.ToString(Convert.ToInt32(str3, 2), 16).ToUpper();

                strSend = str.Substring(0, 13) + strSend2 + str.Substring(14, 3) + strSend + str.Substring(18);

                return strSend;

            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message + "\r\n" + ex.StackTrace);
            }
        }

       

        /// <summary>
        /// 语音发送一路顺风
        /// </summary>
        /// <param name="ax"></param>
        /// <param name="iJiHao"></param>
        /// <param name="strIP"></param>
        /// <param name="sloadCmd"></param>
        /// <param name="ssssLoadZiLing"></param>
        /// <param name="strsLoad"></param>
        /// <param name="iHandle"></param>
        /// <param name="iXieYi"></param>
        //public void ShowLed55(int iJiHao, string strIP, int iHandle, int iXieYi)
        //{
        //    if (Model.bOut485)
        //    {
        //        byte[] bVZSend = AllCommand.ShowLed55(iJiHao, "FFFF");
        //        //byte[] bVZSend = VzSendPort.LoadLsNoX2010znykt(Convert.ToByte(iJiHao), Convert.ToByte(sloadCmd), Convert.ToByte(ssssLoadZiLing), strsLoad, iXieYi);
        //        if (Model.strVideoType == "ZNYKT5")
        //        {
        //            int ret = CameraSDK.ZNYKT5.VzClientSDK.VzLPRClient_SerialSendbyte(iHandle, bVZSend, bVZSend.Length);
        //        }
        //        else if (Model.strVideoType == "ZNYKT14")
        //        {
        //            int iRst = CameraSDK.ZNYKT14.MyClass.Net_TransRS485Data(iHandle, Model.i485TT, bVZSend, Convert.ToByte(bVZSend.Length));
        //        }
        //        else if (Model.strVideoType == "ZNYKT13")
        //        {
        //            CameraSDK.ZNYKT13.YW7000NetClient.Sen485((IntPtr)iHandle, bVZSend);
        //        }
        //    }
        //    else
        //    {
        //        SedBll sendbll = new SedBll(strIP, 1007, 1005);
        //        sendbll.ShowLed55(iJiHao, "FFFF", iXieYi);//一路顺风
        //    }
        //}
    }
}
