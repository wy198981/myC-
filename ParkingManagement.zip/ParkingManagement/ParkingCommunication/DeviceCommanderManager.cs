﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingCommunication
{
    public class DeviceCommanderManager
    {
        static readonly object objLock = new object();
        static readonly Dictionary<string, DeviceCommander> dicDevFlag_DevCmder = new Dictionary<string, DeviceCommander>();

        public static DeviceCommander GetCommander(ParkingModel.CheDaoSet channel, int localPort = 1007, int serverPort = 1005)
        {
            string Flag;
            DeviceCommander cmder;

            if (null == channel)
            {
                return null;
            }

            Flag = string.Format("{0}_{1}", channel.CtrlNumber, channel.IP);    //以机号和IP组成标识

            lock (objLock)
            {
                if (dicDevFlag_DevCmder.ContainsKey(Flag))
                {
                    cmder = dicDevFlag_DevCmder[Flag];
                }
                else
                {
                    cmder = new DeviceCommander(channel, serverPort, localPort);
                    dicDevFlag_DevCmder.Add(Flag, cmder);
                }
            }

            return cmder;
        }

        public static DeviceCommander GetCommander(int modulus, int localPort = 1007, int serverPort = 1005)
        {
            string Flag;
            DeviceCommander cmder;
            ParkingModel.CheDaoSet channel;

            if (modulus < 0 || modulus >= ParkingModel.Model.Channels.Length)
            {
                throw new ArgumentOutOfRangeException("modulus");
            }

            Flag = string.Format("{0}_{1}", ParkingModel.Model.Channels[modulus].iCtrlID, ParkingModel.Model.Channels[modulus].sIP);    //以机号和IP组成标识

            lock (objLock)
            {
                if (dicDevFlag_DevCmder.ContainsKey(Flag))
                {
                    cmder = dicDevFlag_DevCmder[Flag];
                }
                else
                {
                    int value;

                    channel = new ParkingModel.CheDaoSet();
                    channel.BigSmall = ParkingModel.Model.Channels[modulus].iBigSmall;
                    channel.CameraIP = ParkingModel.Model.Channels[modulus].sCarVideo;
                    //channel.CarChannel = ParkingModel.Model.Channels[modulus].;
                    channel.CheckPortID = ParkingModel.Model.Channels[modulus].iCheckPortID;
                    channel.CtrlNumber = ParkingModel.Model.Channels[modulus].iCtrlID;
                    channel.HasOutCard = ParkingModel.Model.Channels[modulus].iOutCard;
                    //channel.ID = ParkingModel.Model.Channels[modulus].;
                    channel.InOut = ParkingModel.Model.Channels[modulus].iInOut;
                    channel.InOutName = ParkingModel.Model.Channels[modulus].sInOutName;
                    channel.IP = ParkingModel.Model.Channels[modulus].sIP;
                    channel.OnLine = ParkingModel.Model.Channels[modulus].iOnLine;
                    channel.OpenID = ParkingModel.Model.Channels[modulus].iOpenID;
                    channel.OpenType = ParkingModel.Model.Channels[modulus].iOpenType;
                    //channel.PersonVideo = ParkingModel.Model.Channels[modulus].sPersonVideo;
                    if (int.TryParse(ParkingModel.Model.Channels[modulus].sPersonVideo,out value))
                    {
                        channel.PersonVideo = value;
                    }
                    //channel.StationID = ParkingModel.Model.Channels[modulus].;
                    channel.SubJH = ParkingModel.Model.Channels[modulus].sSubJH;
                    //channel.Temp1 = ParkingModel.Model.Channels[modulus].;
                    //channel.Temp2 = ParkingModel.Model.Channels[modulus].;
                    //channel.Temp3 = ParkingModel.Model.Channels[modulus].;
                    channel.TempOut = ParkingModel.Model.Channels[modulus].iTempOut;
                    channel.XieYi = ParkingModel.Model.Channels[modulus].iXieYi;

                    cmder = GetCommander(channel, localPort, serverPort);
                }
            }

            return cmder;
        }

        public static void UpdateCommander(ParkingModel.CheDaoSet channel)
        {
            string Flag;

            if (null == channel)
            {
                return;
            }

            Flag = string.Format("{0}_{1}", channel.CtrlNumber, channel.IP);    //以机号和IP组成标识

            lock (objLock)
            {
                if (dicDevFlag_DevCmder.ContainsKey(Flag))
                {
                    dicDevFlag_DevCmder[Flag] = new DeviceCommander(channel);
                }
            }
        }

        public static void DeleteCommander(ParkingModel.CheDaoSet channel)
        {
            if (null == channel)
            {
                return;
            }

            DeleteCommander(channel.CtrlNumber, channel.IP);
        }

        public static void DeleteCommander(int CtrlNumber, string IP)
        {
            string Flag;

            Flag = string.Format("{0}_{1}", CtrlNumber, IP);    //以机号和IP组成标识

            lock (objLock)
            {
                if (dicDevFlag_DevCmder.ContainsKey(Flag))
                {
                    dicDevFlag_DevCmder.Remove(Flag);
                }
            }
        }
    }
}