﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ParkingCommunication
{
    /// <summary>
    /// 生成指令数组并返回
    /// </summary>
    public class AllCommand
    {
        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="Ziling"></param>
        /// <param name="iZ"></param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public static byte[] SendCommand(int JiHao, int Ziling, int iZ)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            byte[] byteZhiling = GetByteArray(Ziling);
            byte[] byteiZ = GetByteArray(iZ.ToString());
            byte[] sendData = new byte[byteJihao.Length + byteZhiling.Length + byteiZ.Length + 3];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x34;
            sendData[byteJihao.Length + 2] = 0x34;
            for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteZhiling.Length; i++)//时间处理
            {
                sendData[i] = byteZhiling[i - (byteJihao.Length + 3)];
            }
            for (int i = byteJihao.Length + 3 + byteZhiling.Length; i < byteJihao.Length + byteZhiling.Length + 3 + byteiZ.Length; i++)//时间处理
            {
                sendData[i] = byteiZ[i - (byteJihao.Length + 3 + byteZhiling.Length)];
            }
            return sendData;
        }

        /// <summary>
        /// 语音发送
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public static byte[] LoadLsNoX2010znykt(byte JiHao, byte Order, byte SonOrder, string StrData)
        {
            int i;

            byte[] dateByte = GetArray(StrData);
            byte[] sendData = new byte[dateByte.Length + 8];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = JiHao;
            sendData[2] = JiHao;
            sendData[3] = Order;
            sendData[4] = Order;
            sendData[5] = Convert.ToByte(dateByte.Length + 1);
            sendData[6] = Convert.ToByte(dateByte.Length + 1);
            // }
            sendData[7] = SonOrder;
            for (i = 8; i < dateByte.Length + 8; i++)//时间处理
            {
                sendData[i] = dateByte[i - 8];
            }
            return sendData;

        }

        /// <summary>
        /// 语音发送
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public static byte[] LoadLsNoX2010znykt(byte JiHao, byte Order, byte SonOrder, string StrData, int Flag)
        {
            int i;
            byte[] dateByte = GetArray(StrData);
            byte[] sendData = new byte[dateByte.Length + 8];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = JiHao;
            sendData[2] = JiHao;
            sendData[3] = Order;
            sendData[4] = Order;
            //                 if (Flag == 1 || Flag == 2|| Flag == 3)
            //                 {
            //                     sendData[5] = Convert.ToByte(sendData.Length + 1);
            //                     sendData[6] = Convert.ToByte(sendData.Length + 1);
            // 
            //                 }
            //                 else if (Flag == 0)
            //                 {
            sendData[5] = Convert.ToByte(dateByte.Length + 1);
            sendData[6] = Convert.ToByte(dateByte.Length + 1);
            // }
            sendData[7] = SonOrder;
            for (i = 8; i < dateByte.Length + 8; i++)//时间处理
            {
                sendData[i] = dateByte[i - 8];
            }

            return sendData;
        }

        /// <summary>
        /// 显示屏控制命令,一路顺风
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <param name="Flag">协议</param>
        /// <returns></returns>
        public static byte[] ShowLed55(int JiHao, string strData)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            //byte[] dateByte = GetAsciiShow(strData);
            byte[] sendData = new byte[byteJihao.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = 1;
            sendData[byteJihao.Length + 4] = 1;
            sendData[byteJihao.Length + 5] = 0x55;

            return sendData;

        }


        /// <summary>
        /// 语音 
        /// 42：欢迎光临 
        /// 46：此卡过期  
        /// 48：此卡无效  
        /// 4C：此卡已入场 
        /// 4F：此卡禁止入场 
        /// 57：此卡已出场
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">指令</param>
        /// <returns></returns>
        public static byte[] VoiceLoad(int JiHao, string strData)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetArray(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 5];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = 0x01;
            sendData[byteJihao.Length + 4] = 0x01;
            for (int i = byteJihao.Length + 5; i < byteJihao.Length + 5 + dateByte.Length; i++)
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 5)];
            }
            return sendData;
        }


        /// <summary>
        /// 发送指令
        /// </summary>
        /// <param name="JiHao"></param>
        /// <param name="Ziling"></param>
        /// <param name="iZ"></param>
        /// <returns>0;表示成功 1：发送失败 2：表示超时 3：本方法报错</returns>
        public static byte[] SendCommand(int JiHao, int Ziling, int iZ, int Flag)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            byte[] byteZhiling = GetByteArray(Ziling);
            byte[] byteiZ = GetByteArray(iZ.ToString());
            byte[] sendData = new byte[byteJihao.Length + byteZhiling.Length + byteiZ.Length + 3];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x34;
            sendData[byteJihao.Length + 2] = 0x34;
            for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteZhiling.Length; i++)//时间处理
            {
                sendData[i] = byteZhiling[i - (byteJihao.Length + 3)];
            }
            for (int i = byteJihao.Length + 3 + byteZhiling.Length; i < byteJihao.Length + byteZhiling.Length + 3 + byteiZ.Length; i++)//时间处理
            {
                sendData[i] = byteiZ[i - (byteJihao.Length + 3 + byteZhiling.Length)];
            }
            return sendData;
        }
        /// <summary>
        /// 显示屏控制命令,报语音，可用日期XX日
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <returns></returns>
        public static byte[] SendFullCW(int JiHao, byte zhiling, int strData)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetByteArray(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 5] = zhiling;
            for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 6)];
            }
            return sendData;
        }



        /// <summary>
        /// 显示屏控制命令,报语音，可用日期XX日
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <returns></returns>
        public static byte[] ShowLed(int JiHao, string strData, byte zhiling)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetAsciiShow(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 5] = zhiling;
            for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 6)];
            }
            return sendData;
        }
        /// <summary>
        /// 显示屏控制命令,报语音“请交费XXXX元”
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="strData">费用必须为4位</param>
        /// <returns></returns>
        public static byte[] ShowLed(int JiHao, string strData)
        {

            byte[] byteJihao = GetByteArray(JiHao);
            byte[] dateByte = GetAsciiShow(strData);
            byte[] sendData = new byte[byteJihao.Length + dateByte.Length + 6];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3D;
            sendData[byteJihao.Length + 2] = 0x3D;
            sendData[byteJihao.Length + 3] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 4] = Convert.ToByte(dateByte.Length + 1);
            sendData[byteJihao.Length + 5] = 0x4A;
            for (int i = byteJihao.Length + 6; i < byteJihao.Length + 6 + dateByte.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 6)];
            }
            return sendData;
        }
        /// <summary>
        /// 控制机显示屏
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public static byte[] CtrlLedShow(byte JiHao, byte Order, byte SonOrder, string StrData, int Flag)
        {
            int i;

            byte[] dateByte = GetArray(StrData);
            byte[] sendData = new byte[dateByte.Length + 10];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = JiHao;
            sendData[2] = JiHao;
            sendData[3] = Order;
            sendData[4] = Order;
            sendData[5] = Convert.ToByte(dateByte.Length + 3);
            sendData[6] = Convert.ToByte(dateByte.Length + 3);
            sendData[7] = SonOrder;
            sendData[8] = Convert.ToByte(dateByte.Length);
            for (i = 9; i < dateByte.Length + 9; i++)//时间处理
            {
                sendData[i] = dateByte[i - 9];
            }
            sendData[dateByte.Length + 9] = YHXY(StrData);
            return sendData;
        }


        /// <summary>
        ///异或效验 
        /// </summary>
        /// <param name="strList"></param>
        /// <returns></returns>
        public static byte YHXY(string str)
        {
            string[] strList = Getstring(str);
            byte[] Hexbyte = new byte[strList.Length];
            byte check = 0;

            //2015-08-15
            if (strList.Length == 1)
            {
                return Convert.ToByte(strList[0], 16);
            }

            check = (byte)(Convert.ToByte(strList[0], 16) ^ Convert.ToByte(strList[1], 16));
            for (int i = 2; i < strList.Length; i++)
            {
                check = (byte)(check ^ Convert.ToByte(strList[i], 16));
            }
            string CheckSumHex = Convert.ToString(check, 16);
            if (CheckSumHex.Length == 1)
            {
                CheckSumHex = "0" + CheckSumHex;
            }
            return Convert.ToByte(CheckSumHex.ToUpper(), 16);
        }
        /// <summary>
        /// ASCII处理
        /// </summary>
        /// <param name="strAscii"></param>
        /// <returns></returns>
        public static byte[] GetAsciiShow(string strAscii)
        {

            byte[] byteDate = new byte[strAscii.Length];
            for (int i = 0; i < strAscii.Length; i++)
            {
                string sum = "";
                string strJihao = strAscii.Substring(i, 1);
                //int ac = Convert.ToInt32(strJihao, 16);
                // char chr = Convert.ToChar(ac);

                System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();

                byte[] aaa = asciiEncoding.GetBytes(strJihao);

                int intAsciiCode = (int)asciiEncoding.GetBytes(strJihao)[0];



                //return (intAsciiCode);

                //sum = chr.ToString();

                byteDate[i] = Convert.ToByte(Convert.ToString(intAsciiCode, 16), 16);
            }
            return byteDate;

        }
        /// <summary>
        /// 机号和扇区号处理
        /// </summary>
        /// <param name="number">int</param>
        /// <returns>返回byte[]类型</returns>
        public static byte[] GetByteArray(int number)
        {
            byte[] Nbtye = new byte[2];
            Nbtye[0] = Convert.ToByte(number.ToString());
            Nbtye[1] = Convert.ToByte(number.ToString());

            return Nbtye;
        }
        /// <summary>
        /// 机号和扇区号处理
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static byte[] GetByteArray(string number)
        {
            byte[] Nbtye = new byte[2];
            Nbtye[0] = Convert.ToByte(number.ToString(), 16);
            Nbtye[1] = Convert.ToByte(number.ToString(), 16);

            return Nbtye;
        }
        /// <summary>
        ///字符串转换为数组
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static byte[] GetArray(string str)
        {
            string[] HexStr = Getstring(str);
            byte[] Hexbyte = new byte[HexStr.Length];
            for (int j = 0; j < HexStr.Length; j++)
            {
                Hexbyte[j] = Convert.ToByte(HexStr[j], 16);
            }

            return Hexbyte;
        }

        public static string[] Getstring(string str)
        {
            List<String> al = new List<String>();
            for (int i = 0; i < str.Length / 2; i++)
            {
                string strJihao = str.Substring(i * 2, 2);
                al.Add(strJihao);
            }
            string s = string.Join(",", al.ToArray());
            string[] HexStr = s.Split(',');
            return HexStr;
        }


        /// <summary>
        /// 读取时间指令
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <returns>返回指令数组</returns>
        public static byte[] ReadTime(int JiHao)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] sendData = new byte[byteJihao.Length + 3];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 3 - 2] = 0x32;
            sendData[byteJihao.Length + 3 - 1] = 0x32;

            return sendData;

        }


        /// <summary>
        /// 强制脱机指令        
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <returns>返回指令数组</returns>
        public static byte[] ForceOffLine(int JiHao)
        {
            byte[] strList = GetByteArray(JiHao);

            byte[] sendData = new byte[12];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = strList[0];
            sendData[2] = strList[1];
            sendData[3] = 0xBC;
            sendData[4] = 0xBC;
            for (int i = 5; i < 11; i++)//时间处理
            {
                sendData[i] = 0xAA;
            }
            sendData[11] = 0x0;  //XOR

            return sendData;

        }


        /// <summary>
        /// 加载收费标准
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="CardType">卡类</param>
        /// <param name="strData">指令</param>
        /// <returns></returns>
        public static byte[] LoadCharge(int JiHao, string CardType, string strData)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] byteSectorMode = GetByteArray(CardType);
            byte[] dateByte = GetArray(strData);
            byte dateJY = YHXY(strData);

            byte[] sendData = new byte[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 4];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x36;
            sendData[byteJihao.Length + 2] = 0x36;
            for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteSectorMode.Length; i++)//时间处理
            {
                sendData[i] = byteSectorMode[i - (byteJihao.Length + 3)];
            }
            for (int i = byteJihao.Length + 3 + byteSectorMode.Length; i < byteJihao.Length + dateByte.Length + 3 + byteSectorMode.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 3 + byteSectorMode.Length)];
            }
            sendData[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 3] = dateJY;//验证处理
            return sendData;
        }


        /// <summary>
        /// 读取收费标准
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <returns>返回指令数组</returns>
        public static byte[] ReadCharge(int JiHao, string CardType)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] byteCardType = GetByteArray(CardType);

            byte[] sendData = new byte[byteJihao.Length + byteCardType.Length + 3];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x37;
            sendData[byteJihao.Length + 2] = 0x37;
            for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteCardType.Length; i++)//时间处理
            {
                sendData[i] = byteCardType[i - (byteJihao.Length + 3)];
            }

            return sendData;
        }

        /// <summary>
        /// 写卡(写卡前必须先把下位机转换成发行模式)
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="SectorMode">扇区号</param>
        /// <param name="strData">命令</param>
        /// <returns></returns>
        public static byte[] WriteCard(int JiHao, int SectorMode, string strData)
        {
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] byteSectorMode = GetByteArray(SectorMode);
            byte[] dateByte = GetArray(strData);
            byte dateJY = YHXY(strData);

            byte[] sendData = new byte[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 4];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x3E;
            sendData[byteJihao.Length + 2] = 0x3E;
            for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteSectorMode.Length; i++)//时间处理
            {
                sendData[i] = byteSectorMode[i - (byteJihao.Length + 3)];
            }
            for (int i = byteJihao.Length + 3 + byteSectorMode.Length; i < byteJihao.Length + dateByte.Length + 3 + byteSectorMode.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (byteJihao.Length + 3 + byteSectorMode.Length)];
            }
            sendData[byteJihao.Length + byteSectorMode.Length + dateByte.Length + 3] = dateJY;//验证处理

            return sendData;
        }


        /// <summary>
        /// 转换模式
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Mode">模式:0为正常工作模式   1为发卡模式</param>
        /// <returns>返回指令数组</returns>
        public static byte[] SelectMode(int JiHao, int Mode)
        {
            int sMode = 0;
            if (Mode == 1)
            {
                sMode = 49;
            }
            else
            {
                sMode = 48;
            }
            byte[] byteJihao = GetByteArray(JiHao);
            byte[] byteMode = GetByteArray(sMode);

            byte[] sendData = new byte[byteJihao.Length + byteMode.Length + 3];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= byteJihao.Length; i++)
            {
                sendData[i] = byteJihao[i - 1];
            }
            sendData[byteJihao.Length + 1] = 0x33;
            sendData[byteJihao.Length + 2] = 0x33;
            for (int i = byteJihao.Length + 3; i < byteJihao.Length + 3 + byteMode.Length; i++)//时间处理
            {
                sendData[i] = byteMode[i - (byteJihao.Length + 3)];
            }

            return sendData;

        }

        /// <summary>
        /// 加载时间指令
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="dt">当前时间</param>
        /// <returns>返回指令数组</returns>
        public static byte[] LoadTime(int JiHao, DateTime dt)
        {

            byte[] strList = GetByteArray(JiHao);

            byte[] dateByte = GetArray(strDates(dt));
            byte dateJY = YHXY(strDates(dt));

            byte[] sendData = new byte[strList.Length + dateByte.Length + 4];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            for (int i = 1; i <= strList.Length; i++)//机号处理
            {
                sendData[i] = strList[i - 1];
            }
            sendData[strList.Length + 1] = 0x31;
            sendData[strList.Length + 2] = 0x31;
            for (int i = strList.Length + 3; i < strList.Length + 3 + dateByte.Length; i++)//时间处理
            {
                sendData[i] = dateByte[i - (strList.Length + 3)];
            }
            sendData[strList.Length + dateByte.Length + 3] = dateJY;//验证处理

            return sendData;

        }

        public static string strDates(DateTime dt)
        {
            #region  时间转换
            string year = dt.Year.ToString().Substring(2, 2);
            string month = "";
            if (dt.Month < 10)
            {
                month = "0" + dt.Month.ToString();
            }
            else
            {
                month = dt.Month.ToString();
            }
            string day = "";
            if (dt.Day < 10)
            {
                day = "0" + dt.Day.ToString();
            }
            else
            {
                day = dt.Day.ToString();
            }
            string hour = "";
            if (dt.Hour < 10)
            {
                hour = "0" + dt.Hour.ToString();
            }
            else
            {
                hour = dt.Hour.ToString();
            }
            string minute = "";
            if (dt.Minute < 10)
            {
                minute = "0" + dt.Minute.ToString();
            }
            else
            {
                minute = dt.Minute.ToString();
            }
            string second = "";
            if (dt.Second < 10)
            {
                second = "0" + dt.Second.ToString();
            }
            else
            {
                second = dt.Second.ToString();
            }

            #endregion

            int week = (int)dt.DayOfWeek;

            string strDate;

            if (week == 0)
            {
                strDate = year + month + day + hour + minute + second + "07";
            }
            else
            {
                strDate = year + month + day + hour + minute + second + "0" + week.ToString();
            }
            return strDate;
        }


        /// <summary>
        /// 语音发送
        /// </summary>
        /// <param name="JiHao">机号</param>
        /// <param name="Order">命令</param>
        /// <param name="SonOrder">子命令</param>
        /// <param name="StrData">发送数组</param>
        /// <returns></returns>
        public static byte[] LoadLsNoX2010znyktXor(byte JiHao, byte Order, byte SonOrder, string StrData)
        {
            int i = 0;
            byte[] dateByte = GetArray(StrData);
            byte[] sendData = new byte[dateByte.Length + 9];
            sendData[0] = Config.byteHead[Config.HeadIndex];
            sendData[1] = JiHao;
            sendData[2] = JiHao;
            sendData[3] = Order;
            sendData[4] = Order;

            sendData[5] = Convert.ToByte(dateByte.Length + 1);
            sendData[6] = Convert.ToByte(dateByte.Length + 1);

            sendData[7] = SonOrder;
            for (i = 8; i < dateByte.Length + 8; i++)//时间处理
            {
                sendData[i] = dateByte[i - 8];
            }
            sendData[dateByte.Length + 8] = YHXY(StrData);

            return sendData;

        }
    }
}
