﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.IO;
using Microsoft.Win32.SafeHandles;
using System.Windows;
using System.Threading;
using System.Text;
using System.Windows.Forms;

namespace ParkingCommunication
{
   public class report : EventArgs
    {
        public readonly byte reportID;
        public readonly byte[] reportBuff;
        public report(byte id, byte[] arrayBuff)
        {
            reportID = id;
            reportBuff = arrayBuff;
        }
    }
   public class Hid : object
   {
       protected const Int32 WAIT_TIMEOUT = 0X102;
       protected const Int32 WAIT_OBJECT_0 = 0;
       protected static string strDevicePath = "";


       public UInt16 VID = 0x9083;

       public UInt16 PID = 0x9750;//产品编号

       private IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);
       private const int MAX_USB_DEVICES = 64;
       public bool deviceOpened = false;
       private FileStream hidDevice = null;

       int outputReportLength;//输出报告长度,包刮一个字节的报告ID
       public int OutputReportLength { get { return outputReportLength; } }
       int inputReportLength;//输入报告长度,包刮一个字节的报告ID   
       public int InputReportLength { get { return inputReportLength; } }

       private Guid device_class;
       private IntPtr usb_event_handle;
       private IntPtr handle;
       private SafeFileHandle device;

       private int HidHandle = -1;

       public Hid(UInt16 pid)
       {
           PID = pid;
           device_class = HIDGuid;
       }
       public Hid()
       {

           device_class = HIDGuid;
       }
       /// <summary>
       /// Provides details about a single USB device
       /// </summary>
       [StructLayout(LayoutKind.Sequential, Pack = 1)]
       protected struct DeviceInterfaceData
       {
           public int Size;
           public Guid InterfaceClassGuid;
           public int Flags;
           public IntPtr Reserved; // should correspond to ULONG_PTR but was an int
       }
       private static string GetDevicePath(IntPtr hInfoSet, ref DeviceInterfaceData oInterface)
       {
           DeviceInterfaceDetailData oDetail = new DeviceInterfaceDetailData();
           // Size workaround
           if (IntPtr.Size == 8)
               oDetail.Size = 8;
           else
               oDetail.Size = 5;
           //Console.WriteLine("Size of struct: {0}", Marshal.SizeOf(oDetail)); // 4 + 256 = 260

           uint nRequiredSize = 0;

           // Error 0
           if (!SetupDiGetDeviceInterfaceDetail(hInfoSet, ref oInterface, IntPtr.Zero, 0, ref nRequiredSize, IntPtr.Zero))
               // Error 122 - ERROR_INSUFFICIENT_BUFFER (not a problem, just used to set nRequiredSize)
               if (SetupDiGetDeviceInterfaceDetail(hInfoSet, ref oInterface, ref oDetail, nRequiredSize, ref nRequiredSize, IntPtr.Zero))
                   return oDetail.DevicePath;
           // Error 1784 - ERROR_INVALID_USER_BUFFER (unless size=5 on 32bit, size=8 on 64bit)
           return null;
       }

       /// <summary>
       /// 打开指定信息的设备
       /// </summary>
       /// <param name="vID">设备的vID</param>
       /// <param name="pID">设备的pID</param>
       /// <param name="serial">设备的serial</param>,string serial
       /// <returns></returns>

       public HID_RETURN OpenDevice(UInt16 vID, UInt16 pID)
       {
           try
           {

               // IntPtr hInfoSet = SetupDiGetClassDevs(ref gHid, null, IntPtr.Zero, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);
               if (deviceOpened == false)
               {
                   //获取连接的HID列表
                   List<string> deviceList = new List<string>();
                   GetHidDeviceList(ref deviceList);

                   //WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " GetHidDeviceList");   //2015-08-21 test

                   if (deviceList.Count == 0)
                       return HID_RETURN.NO_DEVICE_CONECTED;
                   for (int i = 0; i < deviceList.Count; i++)
                   {
                       //device = CreateFile(deviceList[i], DESIREDACCESS.GENERIC_READ | DESIREDACCESS.GENERIC_WRITE, 0, 0, CREATIONDISPOSITION.OPEN_EXISTING, FLAGSANDATTRIBUTES.FILE_FLAG_OVERLAPPED, 0);
                       device = CreateFile(deviceList[i], DESIREDACCESS.GENERIC_READ | DESIREDACCESS.GENERIC_WRITE, 0, 0, CREATIONDISPOSITION.OPEN_EXISTING, 0, 0);

                       //WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " CreateFile"); //2015-08-21 test

                       if (!device.IsInvalid)
                       { // strDevicePath = GetDevicePath(hInfoSet, ref oInterface);
                           HIDD_ATTRIBUTES attributes;
                           //IntPtr serialBuff = Marshal.AllocHGlobal(512);
                           HidD_GetAttributes(device, out attributes);
                           //HidD_GetSerialNumberString(device, serialBuff, 512);
                           //string deviceStr = Marshal.PtrToStringAuto(serialBuff);
                           //Marshal.FreeHGlobal(serialBuff);
                           if (attributes.VendorID == vID && attributes.ProductID == pID)   // && deviceStr == serial
                           {
                               WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 已找到USB设备"); //2015-08-21 test

                               IntPtr preparseData;
                               HIDP_CAPS caps;
                               HidD_GetPreparsedData(device, out preparseData);
                               HidP_GetCaps(preparseData, out caps);
                               HidD_FreePreparsedData(preparseData);
                               outputReportLength = caps.OutputReportByteLength;
                               inputReportLength = caps.InputReportByteLength;

                               hidDevice = new FileStream(device, FileAccess.ReadWrite, inputReportLength, false);   //false同步 ,true异步
                               deviceOpened = true;
                               //BeginAsyncRead();
                               Guid gHid = HIDGuid;
                               IntPtr hInfoSet = SetupDiGetClassDevs(ref gHid, null, IntPtr.Zero, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);
                               DeviceInterfaceData oInterface = new DeviceInterfaceData();
                               strDevicePath = GetDevicePath(hInfoSet, ref oInterface);
                               return HID_RETURN.SUCCESS;
                           }
                           else
                           {
                               device.Close();
                               //CloseHandle(device);
                           }
                       }
                   }
                   //return HID_RETURN.SUCCESS;
                   return HID_RETURN.DEVICE_NOT_FIND;
               }
               else
                   return HID_RETURN.DEVICE_OPENED;
           }
           catch (System.Exception ex)
           {
               return HID_RETURN.DEVICE_NOT_FIND;
           }
       }

       /// <summary>
       /// 关闭打开的设备
       /// </summary>
       public void CloseDevice()
       {
           try
           {
               if (deviceOpened == true)
               {
                   //CloseHandle(device);   //2015-08-21                    
                   hidDevice.Close();
                   hidDevice.Dispose();
                   device.Close();
                   device.Dispose();
                   deviceOpened = false;

                   WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 关闭设备");  //2015-08-21 test
               }
           }
           catch (System.Exception ex)
           {
               WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 关闭设备出错:" + ex.Message);  //2015-08-21 test
           }
       }

       /// <summary>
       /// 开始一次异步读
       /// </summary>
       private void BeginAsyncRead()
       {
           byte[] inputBuff = new byte[InputReportLength];
           hidDevice.BeginRead(inputBuff, 0, InputReportLength, new AsyncCallback(ReadCompleted), inputBuff);
       }
       /// <summary>
       /// 异步读取结束,发出有数据到达事件
       /// </summary>
       /// <param name="iResult">这里是输入报告的数组</param>
       private void ReadCompleted(IAsyncResult iResult)
       {
           byte[] readBuff = (byte[])(iResult.AsyncState);
           try
           {
               hidDevice.EndRead(iResult);//读取结束,如果读取错误就会产生一个异常
               byte[] reportData = new byte[readBuff.Length - 1];
               for (int i = 1; i < readBuff.Length; i++)
                   reportData[i - 1] = readBuff[i];
               report e = new report(readBuff[0], reportData);
               OnDataReceived(e); //发出数据到达消息
               BeginAsyncRead();//启动下一次读操作
           }
           catch (IOException e)//读写错误,设备已经被移除
           {
               EventArgs ex = new EventArgs();
               OnDeviceRemoved(ex);//发出设备移除消息
               CloseDevice();

           }
       }

       /// <summary>
       /// 事件:数据到达,处理此事件以接收输入数据
       /// </summary>
       public event EventHandler<report> DataReceived;
       protected virtual void OnDataReceived(report e)
       {
           if (DataReceived != null) DataReceived(this, e);
       }

       /// <summary>
       /// 事件：设置连接
       /// </summary>
       public event EventHandler DeviceArrived;
       protected virtual void OnDeviceArrived(EventArgs e)
       {
           if (DeviceArrived != null) DeviceArrived(this, e);
       }

       /// <summary>
       /// 事件:设备断开
       /// </summary>
       public event EventHandler DeviceRemoved;
       protected virtual void OnDeviceRemoved(EventArgs e)
       {
           if (DeviceRemoved != null) DeviceRemoved(this, e);
       }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="buffer"></param>
       /// <returns></returns>
       public string Write(report r)
       {
           byte[] buffer = null;
           if (deviceOpened)
           {
               try
               {
                   buffer = new byte[outputReportLength];
                   buffer[0] = r.reportID;
                   int maxBufferLength = 0;
                   if (r.reportBuff.Length < outputReportLength - 1)
                       maxBufferLength = r.reportBuff.Length;
                   else
                       maxBufferLength = outputReportLength - 1;
                   for (int i = 1; i < maxBufferLength; i++)
                       buffer[i] = r.reportBuff[i - 1];
                   hidDevice.Write(buffer, 0, OutputReportLength);

                   ////////////////////////////////////////////////
                   int numberOfBytesRead = 0;  //读取的字节数
                   byte[] BufBytes = new byte[outputReportLength];  //读取BUF                                   
                   Thread.Sleep(50);
                   numberOfBytesRead = hidDevice.Read(BufBytes, 0, BufBytes.Length);   //读取
                   if (numberOfBytesRead == outputReportLength)
                   {
                       //Console.WriteLine("hidDevice.Read 成功");
                       return ByteToHexString(BufBytes).ToString();
                   }
                   else
                   {
                       return "";
                   }
                   ///////////////////////////////////////////////

                   //////bool bSuccess = false;
                   //////buffer = DataRead(ref bSuccess);

                   //////if (bSuccess)  //读取成功
                   //////{
                   //////    return ByteToHexString(buffer).ToString();
                   //////}
                   //////else
                   //////{
                   //////    return "";
                   //////}
               }
               catch (Exception e)
               {
                   WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Write 出错:" + e.Message);  //2015-08-21 test
                   //EventArgs ex = new EventArgs();
                   //OnDeviceRemoved(ex);//发出设备移除消息
                   CloseDevice();
                   return "设备关闭";
               }

           }
           else
           {
               WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Write 时设备处于关闭状态");  //2015-08-21 test
               return "设备关闭";
           }
       }


       /// <summary>
       /// 
       /// </summary>
       /// <param name="buffer"></param>
       /// <returns></returns>
       //public string ParkingReadWrite(report r)
       //{
       //    byte[] buffer = null;
       //    if (deviceOpened)
       //    {
       //        try
       //        {
       //            buffer = new byte[outputReportLength];
       //            buffer[0] = r.reportID;
       //            int maxBufferLength = 0;
       //            if (r.reportBuff.Length < outputReportLength - 1)
       //                maxBufferLength = r.reportBuff.Length;
       //            else
       //                maxBufferLength = outputReportLength - 1;
       //            for (int i = 1; i < maxBufferLength; i++)
       //                buffer[i] = r.reportBuff[i - 1];
       //            hidDevice.Write(buffer, 0, OutputReportLength);


       //            ////////////////////////////////////////////////
       //            int numberOfBytesRead = 0;  //读取的字节数
       //            byte[] BufBytes = new byte[outputReportLength];  //读取BUF                                   
       //            Thread.Sleep(50);
       //            numberOfBytesRead = hidDevice.Read(BufBytes, 0, BufBytes.Length);   //读取
       //            if (numberOfBytesRead == outputReportLength)
       //            {
       //                Console.WriteLine("hidDevice.Read 成功");
       //                return ByteToHexString(BufBytes).ToString();
       //            }
       //            else
       //            {
       //                return "";
       //            }
       //            ////////////////////////////////////////////////


       //            //bool bSuccess = false;
       //            //buffer = DataRead(ref bSuccess);

       //            //if (bSuccess)  //读取成功
       //            //{
       //            //    return ByteToHexString(buffer).ToString();
       //            //}
       //            //else
       //            //{
       //            //    return "";
       //            //}
       //        }
       //        catch (Exception e)
       //        {
       //            WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " ParkingReadWrite 出错:" + e.Message);  //2015-08-21 test

       //            //EventArgs ex = new EventArgs();
       //            // OnDeviceRemoved(ex);//发出设备移除消息
       //            //deviceOpened = false;
       //            //CloseDevice();
       //            return "设备关闭";
       //        }

       //    }
       //    else
       //    {
       //        WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " ParkingReadWrite 时设备处于关闭状态");  //2015-08-21 test
       //        return "设备关闭";
       //    }
       //}

       private byte[] DataRead(ref Boolean success)
       {
           try
           {
               InputReportViaInterruptTransfer report = new InputReportViaInterruptTransfer();

               bool foundMyDevice = false;
               bool result = false;
               byte[] readBuffer = new Byte[OutputReportLength];

               byte[] recvData = report.Read(device, ref foundMyDevice, ref readBuffer, ref result);

               success = result;

               return recvData;
           }
           catch (Exception ex)
           {
               WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " DataRead 出错:" + ex.Message);  //2015-08-21 test
               return null;
           }
       }
       internal class InputReportViaInterruptTransfer : ReportIn
       {
           internal Boolean readyForOverlappedTransfer; //  initialize to false

           ///  <summary>
           ///  closes open handles to a device.
           ///  </summary>
           ///  
           ///  <param name="hidHandle"> the handle for learning about the device and exchanging Feature reports. </param>
           ///  <param name="readHandle"> the handle for reading Input reports from the device. </param>
           ///  <param name="writeHandle"> the handle for writing Output reports to the device. </param>

           internal void CancelTransfer(SafeFileHandle hidHandle, SafeFileHandle readHandle, SafeFileHandle writeHandle, IntPtr eventObject)
           {
               try
               {


                   CancelIo(readHandle);


                   if ((!(hidHandle.IsInvalid)))
                   {
                       hidHandle.Close();
                   }

                   if ((!(readHandle.IsInvalid)))
                   {
                       readHandle.Close();
                   }

                   if ((!(writeHandle.IsInvalid)))
                   {
                       writeHandle.Close();
                   }
               }
               catch (Exception ex)
               {
                   //DisplayException(MODULE_NAME, ex);
                   throw;
               }
           }


           internal void PrepareForOverlappedTransfer(ref NativeOverlapped hidOverlapped, ref IntPtr eventObject)
           {
               try
               {

                   eventObject = CreateEvent(IntPtr.Zero, false, false, "");
                   hidOverlapped.OffsetLow = 0;
                   hidOverlapped.OffsetHigh = 0;
                   hidOverlapped.EventHandle = eventObject;
                   readyForOverlappedTransfer = true;
               }
               catch (Exception ex)
               {
                   //DisplayException(MODULE_NAME, ex);
                   throw;
               }
           }



           ///  <summary>
           ///  reads an Input report from the device using interrupt transfers.
           ///  </summary>
           ///  
           ///  <param name="hidHandle"> the handle for learning about the device and exchanging Feature reports. </param>
           ///  <param name="readHandle"> the handle for reading Input reports from the device. </param>
           ///  <param name="writeHandle"> the handle for writing Output reports to the device. </param>
           ///  <param name="myDeviceDetected"> tells whether the device is currently attached. </param>
           ///  <param name="inputReportBuffer"> contains the requested report. </param>
           ///  <param name="success"> read success </param>
           ///  

           //////private NativeOverlapped HidOverlapped = new NativeOverlapped();                       

           internal override byte[] Read(SafeFileHandle readHandle, ref Boolean myDeviceDetected, ref  Byte[] inputReportBuffer, ref Boolean success)
           {
               try
               {

                   byte[] BufBytes;   //读取BUF
                   byte[] OutBytes;   //返回BUF
                   BufBytes = new byte[64];

                   //////IntPtr eventObject = CreateEvent(IntPtr.Zero, false, false, "");  //IntPtr.Zero;
                   //////HidOverlapped = new NativeOverlapped();

                   // NativeOverlapped HidOverlapped = Pack(myDeviceDetected);
                   Int32 numberOfBytesRead = 0;
                   Int32 result = 0;

                   //////if (readyForOverlappedTransfer == false)
                   //////{
                   //////    PrepareForOverlappedTransfer(ref HidOverlapped, ref eventObject);
                   //////}
                   // success = ReadFile(readHandle, inputReportBuffer, inputReportBuffer.Length, ref numberOfBytesRead, ref HidOverlapped);
                   //System.IntPtr HidOverlappe = HidOverlapped.InternalLow;

                   Thread.Sleep(50);
                   //success = ReadFile(readHandle, inputReportBuffer, inputReportBuffer.Length, ref numberOfBytesRead, ref HidOverlapped);
                   success = ReadFile(readHandle, inputReportBuffer, inputReportBuffer.Length, ref numberOfBytesRead, 0);
                   if (!success)
                   {
                       //Console.WriteLine("waiting for ReadFile");

                       success = false;
                       myDeviceDetected = false;
                       return new byte[0];


                       ////result = WaitForSingleObject(eventObject, 50); //eventObject

                       //////result = GetOverlappedResult(readHandle.DangerousGetHandle(), ref HidOverlapped, ref numberOfBytesRead, false);
                       //////if (result != 0)
                       //////    success = true;


                       //////  Find out if ReadFile completed or timeout.
                       //////ResetEvent(eventObject);

                       ////switch (result)
                       ////{
                       ////    case (System.Int32)WAIT_OBJECT_0:

                       ////        //  ReadFile has completed

                       ////        if (numberOfBytesRead >= 64)
                       ////        {
                       ////            numberOfBytesRead = 64;
                       ////            success = true;

                       ////            Console.WriteLine("WaitForSingleObject 成功.");
                       ////            WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " WaitForSingleObject 成功 ");
                       ////            OutBytes = new byte[numberOfBytesRead];
                       ////            Array.Copy(inputReportBuffer, OutBytes, numberOfBytesRead);
                       ////            return OutBytes;
                       ////        }
                       ////        else
                       ////        {
                       ////            success = false;
                       ////            myDeviceDetected = false;
                       ////            return new byte[0];
                       ////        }

                       ////        break;
                       ////    case WAIT_TIMEOUT:

                       ////        //  Cancel the operation on timeout
                       ////        //CancelIo(readHandle);

                       ////        //CancelTransfer(hidHandle, readHandle, writeHandle, eventObject);
                       ////        //Console.WriteLine("Readfile timeout");
                       ////        success = false;
                       ////        myDeviceDetected = false;
                       ////        return new byte[0];
                       ////        break;
                       ////    default:

                       ////        //  Cancel the operation on other error.
                       ////        //CancelIo(readHandle);
                       ////        //CancelTransfer(hidHandle, readHandle, writeHandle, eventObject);
                       ////        //Console.WriteLine("Readfile undefined error");
                       ////        success = false;
                       ////        myDeviceDetected = false;
                       ////        return new byte[0];
                       ////        break;
                       ////}
                   }

                   //ResetEvent(eventObject);

                   Console.WriteLine("ReadFile 成功.");

                   if (numberOfBytesRead >= 64)
                   {
                       numberOfBytesRead = 64;
                       success = true;
                       OutBytes = new byte[numberOfBytesRead];
                       Array.Copy(inputReportBuffer, OutBytes, numberOfBytesRead);
                       return OutBytes;
                   }
                   else
                   {
                       success = false;
                       myDeviceDetected = false;
                       return new byte[0];
                   }

               }
               catch (System.Exception ex)
               {
                   WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Read 出错:" + ex.Message);  //2015-08-21 test
                   success = false;
                   myDeviceDetected = false;
                   return new byte[0];
               }
           }



           //internal override void Read( SafeFileHandle readHandle, ref Boolean myDeviceDetected, ref  Byte[] inputReportBuffer, ref Boolean success )
           //{
           //    try
           //    {

           //        IntPtr eventObject = CreateEvent(IntPtr.Zero, false, false, "");  //IntPtr.Zero;
           //        HidOverlapped = new NativeOverlapped();

           //        // NativeOverlapped HidOverlapped = Pack(myDeviceDetected);
           //        Int32 numberOfBytesRead = 0;
           //        Int32 result = 0;

           //        if (readyForOverlappedTransfer == false)
           //        {
           //            PrepareForOverlappedTransfer(ref  HidOverlapped, ref eventObject);
           //        }
           //        // success = ReadFile(readHandle, inputReportBuffer, inputReportBuffer.Length, ref numberOfBytesRead, ref HidOverlapped);

           //        System.IntPtr HidOverlappe = HidOverlapped.InternalLow;
           //        success = ReadFile(readHandle, inputReportBuffer, inputReportBuffer.Length, ref numberOfBytesRead, ref HidOverlapped);
           //        if (!success)
           //        {
           //            //Console.WriteLine("waiting for ReadFile");


           //            result = WaitForSingleObject(eventObject, 1000); //eventObject

           //            //result = GetOverlappedResult(readHandle.DangerousGetHandle(), ref HidOverlapped, ref numberOfBytesRead, false);
           //            //if (result != 0)
           //            //    success = true;


           //            //  Find out if ReadFile completed or timeout.

           //            switch (result)
           //            {
           //                case (System.Int32)WAIT_OBJECT_0:

           //                    //  ReadFile has completed

           //                    success = true;
           //                    //Console.WriteLine("ReadFile completed successfully.");
           //                    break;
           //                case WAIT_TIMEOUT:

           //                    //  Cancel the operation on timeout
           //                    CancelIo(readHandle);

           //                    //CancelTransfer(hidHandle, readHandle, writeHandle, eventObject);
           //                    //Console.WriteLine("Readfile timeout");
           //                    success = false;
           //                    myDeviceDetected = false;
           //                    break;
           //                default:

           //                    //  Cancel the operation on other error.
           //                    CancelIo(readHandle);
           //                    //CancelTransfer(hidHandle, readHandle, writeHandle, eventObject);
           //                    //Console.WriteLine("Readfile undefined error");
           //                    success = false;
           //                    myDeviceDetected = false;
           //                    break;
           //            }
           //        }

           //        ResetEvent(eventObject);

           //    }
           //    catch (System.Exception ex)
           //    {
           //        WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Read 出错:" + ex.Message);  //2015-08-21 test
           //    }
           //}


           //////internal override byte[] Read(SafeFileHandle readHandle, ref Boolean myDeviceDetected, ref  Byte[] inputReportBuffer, ref Boolean success)
           //////{
           //////    try
           //////    {
           //////        byte[] BufBytes;   //读取BUF
           //////        byte[] OutBytes;   //返回BUF
           //////        BufBytes = new byte[64];

           //////        Int32 numberOfBytesRead = 0;

           //////        IntPtr eventObject = CreateEvent(IntPtr.Zero, false, false, "");

           //////        NativeOverlapped HidOverlapped = new NativeOverlapped();

           //////        PrepareForOverlappedTransfer(ref HidOverlapped, ref eventObject);
           //////        Thread.Sleep(100);
           //////        success = ReadFile(readHandle, inputReportBuffer, inputReportBuffer.Length, ref numberOfBytesRead, ref HidOverlapped);
           //////        if (!success)  //没读成功
           //////        {
           //////            //  Console.WriteLine("waiting for ReadFile");
           //////            //Console.WriteLine("GetOverlappedResult 读取");
           //////            WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " ReadFile 失败");
           //////            ResetEvent(eventObject);
           //////            success = false;
           //////            return new byte[0];

           //////            //////bool bResult = GetOverlappedResult(readHandle, ref HidOverlapped, ref numberOfBytesRead, false);
           //////            //////int iReCount = 0;
           //////            //////uint start = GetTickCount();
           //////            //////while (!bResult && GetTickCount() - start < 50)
           //////            //////{
           //////            //////    Thread.Sleep(5);
           //////            //////    bResult = GetOverlappedResult(readHandle, ref HidOverlapped, ref numberOfBytesRead, false);
           //////            //////    iReCount++;
           //////            //////    if (bResult)
           //////            //////    {
           //////            //////        //Console.WriteLine("GetOverlappedResult 成功 " + iReCount.ToString() + "  耗时：" + (GetTickCount() - start).ToString());
           //////            //////        break;
           //////            //////    }
           //////            //////}

           //////            //////ResetEvent(eventObject);


           //////            //////if (bResult && numberOfBytesRead > 0)
           //////            //////{
           //////            //////    if (numberOfBytesRead > 64)
           //////            //////    {
           //////            //////        numberOfBytesRead = 64;
           //////            //////    }
           //////            //////    success = true;
           //////            //////    OutBytes = new byte[numberOfBytesRead];
           //////            //////    Array.Copy(inputReportBuffer, OutBytes, numberOfBytesRead);
           //////            //////    return OutBytes;
           //////            //////}
           //////            //////else
           //////            //////{
           //////            //////    success = false;
           //////            //////    return new byte[0];
           //////            //////}
           //////        }
           //////        else  //读取成功
           //////        {
           //////            ResetEvent(eventObject);
           //////            //Console.WriteLine("ReadFile 成功");
           //////            if (numberOfBytesRead > 64)
           //////            {
           //////                numberOfBytesRead = 64;
           //////            }
           //////            OutBytes = new byte[numberOfBytesRead];
           //////            Array.Copy(inputReportBuffer, OutBytes, numberOfBytesRead);
           //////            return OutBytes;
           //////        }
           //////    }
           //////    catch (System.Exception ex)
           //////    {
           //////        WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Read 出错:" + ex.Message);  //2015-08-21 test
           //////        success = false;
           //////        return new byte[0];
           //////    }
           //////}
       }
       internal abstract class ReportIn
       {
           ///  <summary>
           ///  Each class that handles reading reports defines a Read method for reading 
           ///  a type of report. Read is declared as a Sub rather
           ///  than as a Function because asynchronous reads use a callback method 
           ///  that can access parameters passed by ByRef but not Function return values.
           ///  </summary>

           internal abstract byte[] Read(SafeFileHandle readHandle, ref Boolean myDeviceDetected, ref Byte[] readBuffer, ref Boolean success);
       }


       /// <summary>
       /// 获取所有连接的hid的设备路径
       /// </summary>
       /// <returns>包含每个设备路径的字符串数组</returns>
       public void GetHidDeviceList(ref List<string> deviceList)
       {
           Guid hUSB = Guid.Empty;
           uint index = 0;

           deviceList.Clear();
           // 取得hid设备全局id
           HidD_GetHidGuid(ref hUSB);
           //取得一个包含所有HID接口信息集合的句柄
           IntPtr hidInfoSet = SetupDiGetClassDevs(ref hUSB, 0, IntPtr.Zero, DIGCF.DIGCF_PRESENT | DIGCF.DIGCF_DEVICEINTERFACE);
           if (hidInfoSet != IntPtr.Zero)
           {
               SP_DEVICE_INTERFACE_DATA interfaceInfo = new SP_DEVICE_INTERFACE_DATA();
               interfaceInfo.cbSize = Marshal.SizeOf(interfaceInfo);
               //查询集合中每一个接口
               for (index = 0; index < MAX_USB_DEVICES; index++)
               {
                   //得到第index个接口信息
                   if (SetupDiEnumDeviceInterfaces(hidInfoSet, IntPtr.Zero, ref hUSB, index, ref interfaceInfo))
                   {
                       int buffsize = 0;
                       // 取得接口详细信息:第一次读取错误,但可以取得信息缓冲区的大小
                       SetupDiGetDeviceInterfaceDetail(hidInfoSet, ref interfaceInfo, IntPtr.Zero, buffsize, ref buffsize, null);
                       //构建接收缓冲
                       IntPtr pDetail = Marshal.AllocHGlobal(buffsize);
                       SP_DEVICE_INTERFACE_DETAIL_DATA detail = new SP_DEVICE_INTERFACE_DETAIL_DATA();
                       detail.cbSize = Marshal.SizeOf(typeof(SP_DEVICE_INTERFACE_DETAIL_DATA));
                       Marshal.StructureToPtr(detail, pDetail, false);
                       if (SetupDiGetDeviceInterfaceDetail(hidInfoSet, ref interfaceInfo, pDetail, buffsize, ref buffsize, null))
                       {
                           deviceList.Add(Marshal.PtrToStringAuto((IntPtr)((int)pDetail + 4)));
                       }
                       Marshal.FreeHGlobal(pDetail);
                   }
               }
           }
           SetupDiDestroyDeviceInfoList(hidInfoSet);
           //return deviceList.ToArray();
       }

       public void ParseMessages(ref Message m)
       {
           if (m.Msg == DEVICE_FLAG.WM_DEVICECHANGE)	// we got a device change message! A USB device was inserted or removed
           {
               switch (m.WParam.ToInt32())	// Check the W parameter to see if a device was inserted or removed
               {
                   case DEVICE_FLAG.DEVICE_ARRIVAL:	// inserted
                       Console.WriteLine("ParseMessages 设备连接");
                       if (DeviceArrived != null)
                       {
                           DeviceArrived(this, new EventArgs());
                       }
                       CheckDevicePresent();
                       break;
                   case DEVICE_FLAG.DEVICE_REMOVECOMPLETE:	// removed
                       Console.WriteLine("ParseMessages 设备拔除");
                       if (DeviceRemoved != null)
                       {
                           DeviceRemoved(this, new EventArgs());
                       }
                       CheckDevicePresent();
                       break;
               }
           }
       }

       public void RegisterHandle(IntPtr Handle)
       {
           usb_event_handle = RegisterForUsbEvents(Handle, device_class);
           this.handle = Handle;
           //Check if the device is already present.
           CheckDevicePresent();
       }

       public bool CheckDevicePresent()
       {
           HID_RETURN hid_ret;
           string sSerial = "";

           if (deviceOpened == false)
           {
               hid_ret = OpenDevice(VID, PID);
               if (hid_ret == HID_RETURN.SUCCESS)
               {
                   Console.WriteLine("打开设备成功");
                   WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 打开设备成功");  //2015-08-21 test
                   return true;
               }
               else
               {
                   Console.WriteLine("打开设备失败");
                   WriteToTxtFile(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 打开设备失败");  //2015-08-21 test
                   return false;
               }
           }
           return true;
       }

       /// <summary>
       /// Helper to get the HID guid.
       /// </summary>
       public Guid HIDGuid
       {
           get
           {
               Guid gHid = Guid.Empty;
               HidD_GetHidGuid(ref gHid);
               return gHid;
               //return new Guid("A5DCBF10-6530-11D2-901F-00C04FB951ED"); //gHid;
           }
       }

       /// <summary>
       /// btye数组转换为字符串
       /// </summary>
       /// <param name="bytes"></param>
       /// <returns></returns>
       public StringBuilder ByteToHexString(byte[] bytes)
       {
           StringBuilder str = new StringBuilder();
           if (bytes != null)
           {
               for (int i = 0; i < bytes.Length; i++)
               {
                   str.Append(bytes[i].ToString("X2"));
               }
           }
           return str;
       }

       /// <summary>
       /// Registers a window to receive windows messages when a device is inserted/removed. Need to call this
       /// from a form when its handle has been created, not in the form constructor. Use form's OnHandleCreated override.
       /// </summary>
       /// <param name="hWnd">Handle to window that will receive messages</param>
       /// <param name="gClass">Class of devices to get messages for</param>
       /// <returns>A handle used when unregistering</returns>
       public IntPtr RegisterForUsbEvents(IntPtr hWnd, Guid gClass)
       {
           DeviceBroadcastInterface oInterfaceIn = new DeviceBroadcastInterface();
           oInterfaceIn.Size = Marshal.SizeOf(oInterfaceIn);
           oInterfaceIn.ClassGuid = gClass;
           oInterfaceIn.DeviceType = DEVICE_FLAG.DEVTYP_DEVICEINTERFACE;
           oInterfaceIn.Reserved = 0;
           return RegisterDeviceNotification(hWnd, oInterfaceIn, DEVICE_FLAG.DEVICE_NOTIFY_WINDOW_HANDLE);
       }
       /// <summary>
       /// Unregisters notifications. Can be used in form dispose
       /// </summary>
       /// <param name="hHandle">Handle returned from RegisterForUSBEvents</param>
       /// <returns>True if successful</returns>
       public bool UnregisterForUsbEvents(IntPtr hHandle)
       {
           return UnregisterDeviceNotification(hHandle);
       }

       public enum HID_RETURN
       {
           SUCCESS = 0,
           NO_DEVICE_CONECTED,
           DEVICE_NOT_FIND,
           DEVICE_OPENED,
           WRITE_FAILD,
           READ_FAILD

       }


       // 以下是调用windows的API的函数
       [DllImport("kernel32.dll")]
       private static extern uint GetTickCount();

       /// <summary>
       /// The HidD_GetHidGuid routine returns the device interface GUID for HIDClass devices.
       /// </summary>
       /// <param name="HidGuid">a caller-allocated GUID buffer that the routine uses to return the device interface GUID for HIDClass devices.</param>
       [DllImport("hid.dll")]
       private static extern void HidD_GetHidGuid(ref Guid HidGuid);

       /// <summary>
       /// The SetupDiGetClassDevs function returns a handle to a device information set that contains requested device information elements for a local machine. 
       /// </summary>
       /// <param name="ClassGuid">GUID for a device setup class or a device interface class. </param>
       /// <param name="Enumerator">A pointer to a NULL-terminated string that supplies the name of a PnP enumerator or a PnP device instance identifier. </param>
       /// <param name="HwndParent">A handle of the top-level window to be used for a user interface</param>
       /// <param name="Flags">A variable  that specifies control options that filter the device information elements that are added to the device information set. </param>
       /// <returns>a handle to a device information set </returns>
       [DllImport("setupapi.dll", SetLastError = true)]
       private static extern IntPtr SetupDiGetClassDevs(ref Guid ClassGuid, uint Enumerator, IntPtr HwndParent, DIGCF Flags);
       [DllImport("setupapi.dll", SetLastError = true)]
       protected static extern IntPtr SetupDiGetClassDevs(ref Guid gClass, [MarshalAs(UnmanagedType.LPStr)] string strEnumerator, IntPtr hParent, uint nFlags);
       /// <summary>
       /// <summary>
       /// The SetupDiDestroyDeviceInfoList function deletes a device information set and frees all associated memory.
       /// </summary>
       /// <param name="DeviceInfoSet">A handle to the device information set to delete.</param>
       /// <returns>returns TRUE if it is successful. Otherwise, it returns FALSE </returns>
       [DllImport("setupapi.dll", CharSet = CharSet.Auto, SetLastError = true)]
       private static extern Boolean SetupDiDestroyDeviceInfoList(IntPtr deviceInfoSet);

       /// <summary>
       /// The SetupDiEnumDeviceInterfaces function enumerates the device interfaces that are contained in a device information set. 
       /// </summary>
       /// <param name="deviceInfoSet">A pointer to a device information set that contains the device interfaces for which to return information</param>
       /// <param name="deviceInfoData">A pointer to an SP_DEVINFO_DATA structure that specifies a device information element in DeviceInfoSet</param>
       /// <param name="interfaceClassGuid">a GUID that specifies the device interface class for the requested interface</param>
       /// <param name="memberIndex">A zero-based index into the list of interfaces in the device information set</param>
       /// <param name="deviceInterfaceData">a caller-allocated buffer that contains a completed SP_DEVICE_INTERFACE_DATA structure that identifies an interface that meets the search parameters</param>
       /// <returns></returns>
       [DllImport("setupapi.dll", CharSet = CharSet.Auto, SetLastError = true)]
       private static extern Boolean SetupDiEnumDeviceInterfaces(IntPtr deviceInfoSet, IntPtr deviceInfoData, ref Guid interfaceClassGuid, UInt32 memberIndex, ref SP_DEVICE_INTERFACE_DATA deviceInterfaceData);

       /// <summary>
       /// The SetupDiGetDeviceInterfaceDetail function returns details about a device interface.
       /// </summary>
       /// <param name="deviceInfoSet">A pointer to the device information set that contains the interface for which to retrieve details</param>
       /// <param name="deviceInterfaceData">A pointer to an SP_DEVICE_INTERFACE_DATA structure that specifies the interface in DeviceInfoSet for which to retrieve details</param>
       /// <param name="deviceInterfaceDetailData">A pointer to an SP_DEVICE_INTERFACE_DETAIL_DATA structure to receive information about the specified interface</param>
       /// <param name="deviceInterfaceDetailDataSize">The size of the DeviceInterfaceDetailData buffer</param>
       /// <param name="requiredSize">A pointer to a variable that receives the required size of the DeviceInterfaceDetailData buffer</param>
       /// <param name="deviceInfoData">A pointer buffer to receive information about the device that supports the requested interface</param>
       /// <returns></returns>
       [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Auto)]
       private static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr deviceInfoSet, ref SP_DEVICE_INTERFACE_DATA deviceInterfaceData, IntPtr deviceInterfaceDetailData, int deviceInterfaceDetailDataSize, ref int requiredSize, SP_DEVINFO_DATA deviceInfoData);

       /// <summary>
       /// The HidD_GetAttributes routine returns the attributes of a specified top-level collection.
       /// </summary>
       /// <param name="HidDeviceObject">Specifies an open handle to a top-level collection</param>
       /// <param name="Attributes">a caller-allocated HIDD_ATTRIBUTES structure that returns the attributes of the collection specified by HidDeviceObject</param>
       /// <returns></returns>
       [DllImport("hid.dll")]
       private static extern Boolean HidD_GetAttributes(SafeFileHandle hidDeviceObject, out HIDD_ATTRIBUTES attributes);
       /// <summary>
       /// The HidD_GetSerialNumberString routine returns the embedded string of a top-level collection that identifies the serial number of the collection's physical device.
       /// </summary>
       /// <param name="HidDeviceObject">Specifies an open handle to a top-level collection</param>
       /// <param name="Buffer">a caller-allocated buffer that the routine uses to return the requested serial number string</param>
       /// <param name="BufferLength">Specifies the length, in bytes, of a caller-allocated buffer provided at Buffer</param>
       /// <returns></returns>
       [DllImport("hid.dll")]
       private static extern Boolean HidD_GetSerialNumberString(IntPtr hidDeviceObject, IntPtr buffer, int bufferLength);

       /// <summary>
       /// The HidD_GetPreparsedData routine returns a top-level collection's preparsed data.
       /// </summary>
       /// <param name="hidDeviceObject">Specifies an open handle to a top-level collection. </param>
       /// <param name="PreparsedData">Pointer to the address of a routine-allocated buffer that contains a collection's preparsed data in a _HIDP_PREPARSED_DATA structure.</param>
       /// <returns>HidD_GetPreparsedData returns TRUE if it succeeds; otherwise, it returns FALSE.</returns>
       [DllImport("hid.dll")]
       private static extern Boolean HidD_GetPreparsedData(SafeFileHandle hidDeviceObject, out IntPtr PreparsedData);

       [DllImport("hid.dll")]
       private static extern Boolean HidD_FreePreparsedData(IntPtr PreparsedData);

       [DllImport("hid.dll")]
       private static extern uint HidP_GetCaps(IntPtr PreparsedData, out HIDP_CAPS Capabilities);

       [DllImport("kernel32.dll", SetLastError = true)]
       protected static extern Int32 WaitForSingleObject(IntPtr hHandle, Int32 dwMilliseconds);

       /// <summary>
       /// This function creates, opens, or truncates a file, COM port, device, service, or console. 
       /// </summary>
       /// <param name="fileName">a null-terminated string that specifies the name of the object</param>
       /// <param name="desiredAccess">Type of access to the object</param>
       /// <param name="shareMode">Share mode for object</param>
       /// <param name="securityAttributes">Ignored; set to NULL</param>
       /// <param name="creationDisposition">Action to take on files that exist, and which action to take when files do not exist</param>
       /// <param name="flagsAndAttributes">File attributes and flags for the file</param>
       /// <param name="templateFile">Ignored</param>
       /// <returns>An open handle to the specified file indicates success</returns>

       [DllImport("kernel32.dll", SetLastError = true)]
       protected static extern SafeFileHandle CreateFile(string strName, uint nAccess, uint nShareMode, uint lpSecurity, uint nCreationFlags, uint nAttributes, uint lpTemplate);

       //[DllImport("kernel32.dll", SetLastError = true)]
       //private static extern IntPtr CreateFile(string fileName, uint desiredAccess, uint shareMode, uint securityAttributes, uint creationDisposition, uint flagsAndAttributes, uint templateFile);


       [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
       protected static extern IntPtr CreateEvent(IntPtr SecurityAttributes, Boolean bManualReset, Boolean bInitialState, String lpName);

       [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
       protected static extern IntPtr ResetEvent(IntPtr hEvent);

       /// <summary>
       /// This function closes an open object handle.
       /// </summary>
       /// <param name="hObject">Handle to an open object</param>
       /// <returns></returns>
       [DllImport("kernel32.dll")]
       private static extern int CloseHandle(SafeFileHandle hObject);

       /// <summary>
       /// This function reads data from a file, starting at the position indicated by the file pointer.
       /// </summary>
       /// <param name="file">Handle to the file to be read</param>
       /// <param name="buffer">Pointer to the buffer that receives the data read from the file </param>
       /// <param name="numberOfBytesToRead">Number of bytes to be read from the file</param>
       /// <param name="numberOfBytesRead">Pointer to the number of bytes read</param>
       /// <param name="lpOverlapped">Unsupported; set to NULL</param>
       /// <returns></returns>
       /// 
       //[DllImport("Kernel32.dll", SetLastError = true)]
       //private static extern bool ReadFile( IntPtr file, byte[] buffer, uint numberOfBytesToRead, out uint numberOfBytesRead, IntPtr lpOverlapped );

       //[DllImport("kernel32.dll", SetLastError = true)]
       //protected static extern Boolean    ReadFile( SafeFileHandle hFile, Byte[] lpBuffer, Int32 nNumberOfBytesToRead, ref Int32 lpNumberOfBytesRead, ref NativeOverlapped lpOverlapped );

       [DllImport("kernel32.dll", SetLastError = true)]
       //protected static extern bool ReadFile(SafeFileHandle hFile, Byte[] lpBuffer, Int32 nNumberOfBytesToRead, ref Int32 lpNumberOfBytesRead, ref NativeOverlapped lpOverlapped);
       protected static extern bool ReadFile(SafeFileHandle hFile, Byte[] lpBuffer, Int32 nNumberOfBytesToRead, ref Int32 lpNumberOfBytesRead, int lpOverlapped);


       //[DllImport("kernel32.dll", SetLastError = true)]
       //private static extern bool ReadFile(IntPtr hFile,  byte[] lpBuffer,uint nNumberOfBytesToRead, out uint lpNumberOfBytesRead, IntPtr lpOverlapped);

       //[DllImport("kernel32.dll", SetLastError = true)]
       //protected static extern bool ReadFile(SafeFileHandle hFile, Byte[] lpBuffer, Int32 nNumberOfBytesToRead, ref Int32 lpNumberOfBytesRead, ref NativeOverlapped lpOverlapped);

       //[DllImport(@"kernel32.dll", SetLastError = true)]
       //static extern bool ReadFile(
       //    SafeFileHandle hFile,      // handle to file
       //    byte* pBuffer,        // data buffer, should be fixed
       //    int NumberOfBytesToRead,  // number of bytes to read
       //    IntPtr pNumberOfBytesRead,  // number of bytes read, provide IntPtr.Zero here
       //    NativeOverlapped* lpOverlapped // should be fixed, if not IntPtr.Zero
       //);

       [DllImport("kernel32.dll", SetLastError = true)]
       protected static extern bool GetOverlappedResult(SafeFileHandle hFile, ref NativeOverlapped lpOverlapped, ref Int32 lpNumberOfBytesTransferred, bool bWait);

       [DllImport("kernel32.dll", SetLastError = true)]
       protected static extern Int32 CancelIo(SafeFileHandle hFile);
       /// <summary>
       ///  This function writes data to a file
       /// </summary>
       /// <param name="file">Handle to the file to be written to</param>
       /// <param name="buffer">Pointer to the buffer containing the data to write to the file</param>
       /// <param name="numberOfBytesToWrite">Number of bytes to write to the file</param>
       /// <param name="numberOfBytesWritten">Pointer to the number of bytes written by this function call</param>
       /// <param name="lpOverlapped">Unsupported; set to NULL</param>
       /// <returns></returns>
       [DllImport("Kernel32.dll", SetLastError = true)]
       private static extern bool WriteFile(IntPtr file, byte[] buffer, uint numberOfBytesToWrite, out uint numberOfBytesWritten, IntPtr lpOverlapped);

       /// <summary>
       /// Registers the device or type of device for which a window will receive notifications
       /// </summary>
       /// <param name="recipient">A handle to the window or service that will receive device events for the devices specified in the NotificationFilter parameter</param>
       /// <param name="notificationFilter">A pointer to a block of data that specifies the type of device for which notifications should be sent</param>
       /// <param name="flags">A Flags that specify the handle type</param>
       /// <returns>If the function succeeds, the return value is a device notification handle</returns>
       [DllImport("User32.dll", SetLastError = true)]
       private static extern IntPtr RegisterDeviceNotification(IntPtr hwnd, DeviceBroadcastInterface oInterface, uint nFlags);

       /// <summary>
       /// Closes the specified device notification handle.
       /// </summary>
       /// <param name="handle">Device notification handle returned by the RegisterDeviceNotification function</param>
       /// <returns></returns>
       [DllImport("user32.dll", SetLastError = true)]
       private static extern bool UnregisterDeviceNotification(IntPtr handle);

       [DllImport("setupapi.dll", SetLastError = true)]
       protected static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr lpDeviceInfoSet, ref DeviceInterfaceData oInterfaceData, IntPtr lpDeviceInterfaceDetailData, uint nDeviceInterfaceDetailDataSize, ref uint nRequiredSize, IntPtr lpDeviceInfoData);

       [DllImport("setupapi.dll", SetLastError = true)]
       protected static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr lpDeviceInfoSet, ref DeviceInterfaceData oInterfaceData, ref DeviceInterfaceDetailData oDetailData, uint nDeviceInterfaceDetailDataSize, ref uint nRequiredSize, IntPtr lpDeviceInfoData);
       protected const uint GENERIC_READ = 0x80000000;
       /// <summary>CreateFile : file share for read</summary>
       protected const uint FILE_SHARE_READ = 0x1;
       /// <summary>CreateFile : file share for write</summary>
       protected const uint FILE_SHARE_WRITE = 0x2;
       /// <summary>CreateFile : Resource to be "created" must exist</summary>
       protected const uint OPEN_EXISTING = 3;

       /// <summary>CreateFile : Open handle for overlapped operations</summary>
       protected const uint FILE_FLAG_OVERLAPPED = 0x40000000;
       protected const int DIGCF_DEVICEINTERFACE = 0x10;
       protected const int DIGCF_PRESENT = 0x02;


       #region
       /// <summary>
       /// SP_DEVICE_INTERFACE_DATA structure defines a device interface in a device information set.
       /// </summary>
       public struct SP_DEVICE_INTERFACE_DATA
       {
           public int cbSize;
           public Guid interfaceClassGuid;
           public int flags;
           public int reserved;
       }

       /// <summary>
       /// SP_DEVICE_INTERFACE_DETAIL_DATA structure contains the path for a device interface.
       /// </summary>
       [StructLayout(LayoutKind.Sequential, Pack = 2)]
       internal struct SP_DEVICE_INTERFACE_DETAIL_DATA
       {
           internal int cbSize;
           internal short devicePath;
       }

       /// <summary>
       /// SP_DEVINFO_DATA structure defines a device instance that is a member of a device information set.
       /// </summary>
       [StructLayout(LayoutKind.Sequential)]
       public class SP_DEVINFO_DATA
       {
           public int cbSize = Marshal.SizeOf(typeof(SP_DEVINFO_DATA));
           public Guid classGuid = Guid.Empty; // temp
           public int devInst = 0; // dumy
           public int reserved = 0;
       }
       /// <summary>
       /// Flags controlling what is included in the device information set built by SetupDiGetClassDevs
       /// </summary>
       public enum DIGCF
       {
           DIGCF_DEFAULT = 0x00000001, // only valid with DIGCF_DEVICEINTERFACE                 
           DIGCF_PRESENT = 0x00000002,
           DIGCF_ALLCLASSES = 0x00000004,
           DIGCF_PROFILE = 0x00000008,
           DIGCF_DEVICEINTERFACE = 0x00000010
       }
       /// <summary>
       /// The HIDD_ATTRIBUTES structure contains vendor information about a HIDClass device
       /// </summary>
       public struct HIDD_ATTRIBUTES
       {
           public int Size;
           public ushort VendorID;
           public ushort ProductID;
           public ushort VersionNumber;
       }

       public struct HIDP_CAPS
       {
           public ushort Usage;
           public ushort UsagePage;
           public ushort InputReportByteLength;
           public ushort OutputReportByteLength;
           [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)]
           public ushort[] Reserved;
           public ushort NumberLinkCollectionNodes;
           public ushort NumberInputButtonCaps;
           public ushort NumberInputValueCaps;
           public ushort NumberInputDataIndices;
           public ushort NumberOutputButtonCaps;
           public ushort NumberOutputValueCaps;
           public ushort NumberOutputDataIndices;
           public ushort NumberFeatureButtonCaps;
           public ushort NumberFeatureValueCaps;
           public ushort NumberFeatureDataIndices;
       }
       /// <summary>
       /// Type of access to the object. 
       ///</summary>
       static class DESIREDACCESS
       {
           public const uint GENERIC_READ = 0x80000000;
           public const uint GENERIC_WRITE = 0x40000000;
           public const uint GENERIC_EXECUTE = 0x20000000;
           public const uint GENERIC_ALL = 0x10000000;
       }
       /// <summary>
       /// Action to take on files that exist, and which action to take when files do not exist. 
       /// </summary>
       static class CREATIONDISPOSITION
       {
           public const uint CREATE_NEW = 1;
           public const uint CREATE_ALWAYS = 2;

           public const uint OPEN_EXISTING = 3;

           public const uint OPEN_ALWAYS = 4;
           public const uint TRUNCATE_EXISTING = 5;
       }
       /// <summary>
       /// File attributes and flags for the file. 
       /// </summary>
       static class FLAGSANDATTRIBUTES
       {
           public const uint FILE_FLAG_WRITE_THROUGH = 0x80000000;
           public const uint FILE_FLAG_OVERLAPPED = 0x40000000;
           public const uint FILE_FLAG_NO_BUFFERING = 0x20000000;
           public const uint FILE_FLAG_RANDOM_ACCESS = 0x10000000;
           public const uint FILE_FLAG_SEQUENTIAL_SCAN = 0x08000000;
           public const uint FILE_FLAG_DELETE_ON_CLOSE = 0x04000000;
           public const uint FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;
           public const uint FILE_FLAG_POSIX_SEMANTICS = 0x01000000;
           public const uint FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000;
           public const uint FILE_FLAG_OPEN_NO_RECALL = 0x00100000;
           public const uint FILE_FLAG_FIRST_PIPE_INSTANCE = 0x00080000;
       }
       /// <summary>
       /// Serves as a standard header for information related to a device event reported through the WM_DEVICECHANGE message.
       /// </summary>
       [StructLayout(LayoutKind.Sequential)]
       public struct DEV_BROADCAST_HDR
       {
           public int dbcc_size;
           public int dbcc_devicetype;
           public int dbcc_reserved;
       }
       /// <summary>
       /// Contains information about a class of devices
       /// </summary>
       [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
       public struct DEV_BROADCAST_DEVICEINTERFACE
       {
           public int dbcc_size;
           public int dbcc_devicetype;
           public int dbcc_reserved;
           public Guid dbcc_classguid;
           [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 255)]
           public string dbcc_name;
       }

       static class DEVICE_FLAG
       {
           /// <summary>Windows message sent when a device is inserted or removed</summary>
           public const int WM_DEVICECHANGE = 0x0219;
           /// <summary>WParam for above : A device was inserted</summary>
           public const int DEVICE_ARRIVAL = 0x8000;
           /// <summary>WParam for above : A device was removed</summary>
           public const int DEVICE_REMOVECOMPLETE = 0x8004;
           /// <summary>Used when registering for device insert/remove messages : specifies the type of device</summary>
           public const int DEVTYP_DEVICEINTERFACE = 0x05;
           /// <summary>Used when registering for device insert/remove messages : we're giving the API call a window handle</summary>
           public const int DEVICE_NOTIFY_WINDOW_HANDLE = 0;
       }

       /// <summary>
       /// Access to the path for a device
       /// </summary>
       [StructLayout(LayoutKind.Sequential, Pack = 1)]
       public struct DeviceInterfaceDetailData
       {
           public int Size;
           [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
           public string DevicePath;
       }
       /// <summary>
       /// Used when registering a window to receive messages about devices added or removed from the system.
       /// </summary>
       [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
       public class DeviceBroadcastInterface
       {
           public int Size;
           public int DeviceType;
           public int Reserved;
           public Guid ClassGuid;
           [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
           public string Name;
       }


       #endregion

       public static void WriteToTxtFile(string text)
       {
           try
           {
               string filePath = System.Windows.Forms.Application.StartupPath;

               FileStream fs = new FileStream(filePath + "\\LogList.txt", FileMode.Append);

               if (fs.Length > 1048576)
               {
                   fs.Close();
                   File.Move(filePath + "\\LogList.txt", filePath + "\\LogList-" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt");
                   fs = new FileStream(filePath + "\\LogList.txt", FileMode.Append);
               }

               StreamWriter sw = new StreamWriter(fs, Encoding.Default);
               sw.Write(text + "\r\n");
               sw.Close();
               fs.Close();
           }
           catch (System.Exception ex)
           {

           }
       }
   }
}
