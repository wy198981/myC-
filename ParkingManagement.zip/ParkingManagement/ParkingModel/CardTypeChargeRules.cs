﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class CardTypeChargeRules
    {
        /// <summary>
        /// 把数据库中的结构转换为类结构，以便访问
        /// </summary>
        /// <param name="lstRule">某类卡的收费标准。必须只传一类卡的标准，否则会造成数据混乱。</param>
        public CardTypeChargeRules(List<ChargeRules> lstRule)
        {
            if (null == lstRule || lstRule.Count <= 0)
            {
                _HoursRule = new HoursChargeRule(lstRule);
                return;
            }

            _TopSF = lstRule[0].TopSF;
            _ParkID = lstRule[0].ParkID;
            _CardType = lstRule[0].CardType;
            _FreeMinutes = lstRule[0].FreeMinute;

            //停车时间超过免费时间后，免费时间是否计入总停车时间中进行计费。用Hours为30的JE表示，JE大于0不计费
            var nocharge = from rule in lstRule where rule.Hours == 30 select rule;
            if (null != nocharge && nocharge.Count() > 0)
            {
                _FreeMinutesNoCharge = nocharge.ElementAt(0).JE > 0;
            }

            //计费模式。用Hours为40的JE表示，JE为0是按小时为单位计费，1为分白天夜间段计费，2为按设定时间计费，3为按次计费。
            var mode = from rule in lstRule where rule.Hours == 40 select rule;
            if (null != mode && mode.Count() > 0)
            {
                _ChargeMode = (int)mode.ElementAt(0).JE;
            }

            switch (ChargeMode)
            {
                case 1:
                    _DayNightRule = new DayNightChargeRule(lstRule);
                    break;
                case 2:
                    _TimeUnitRule = new TimeUnitChargeRule(lstRule);
                    break;
                case 3:
                    break;
                default:
                    _HoursRule = new HoursChargeRule(lstRule);
                    break;
            }
        }

        protected string _CardType;
        protected int _TopSF;
        protected int _ParkID;
        protected int _FreeMinutes;
        protected bool _FreeMinutesNoCharge;
        protected int _ChargeMode;
        protected HoursChargeRule _HoursRule;
        protected DayNightChargeRule _DayNightRule;
        protected TimeUnitChargeRule _TimeUnitRule;

        /// <summary>
        /// 卡类型
        /// </summary>
        public string CardType { get { return _CardType; } set { _CardType = value; } }
        /// <summary>
        /// 最高收费
        /// </summary>
        public int TopSF { get { return _TopSF; } set { _TopSF = value; } }
        /// <summary>
        /// 免费时间(分钟)
        /// </summary>
        public int FreeMinutes { get { return _FreeMinutes; } set { _FreeMinutes = value; } }
        /// <summary>
        /// 免费时间不计时
        /// </summary>
        public bool FreeMinutesNoCharge { get { return _FreeMinutesNoCharge; } set { _FreeMinutesNoCharge = value; } }
        /// <summary>
        /// 计费模式。0为按小时为单位计费，1为分白天夜间段计费，2为按设定时间计费，3为按次计费。
        /// </summary>
        public int ChargeMode { get { return _ChargeMode; } set { ChangeChargeMode(value); } }

        public int ParkID { get { return _ParkID; } set { _ParkID = value; } }

        /// <summary>
        /// 当ChargeMode为0时，在此对象中保存收费规则
        /// </summary>
        public HoursChargeRule HoursRule { get { return _HoursRule; } }
        /// <summary>
        /// 当ChargeMode为1时，在此对象中保存收费规则
        /// </summary>
        public DayNightChargeRule DayNightRule { get { return _DayNightRule; } }
        /// <summary>
        /// 当ChargeMode为2时，在此对象中保存收费规则
        /// </summary>
        public TimeUnitChargeRule TimeUnitRule { get { return _TimeUnitRule; } }

        public List<ChargeRules> ToRuleList()
        {
            ChargeRules rule;
            ChargeRules rulNew;
            List<ChargeRules> lst;

            lst = new List<ChargeRules>();

            rule = new ChargeRules();
            rule.CardType = CardType;
            rule.TopSF = TopSF;
            rule.FreeMinute = FreeMinutes;
            rule.ParkID = _ParkID;

            //免费时间是否计费
            rulNew = rule.Copy<ChargeRules>();
            rulNew.Hours = 30;
            rulNew.JE = (FreeMinutesNoCharge ? 1 : 0);
            lst.Add(rulNew);

            //计费模式。用Hours为40的JE表示，JE为0是按小时为单位计费，1为分白天夜间段计费，2为按设定时间计费，3为按次计费。
            rulNew = rule.Copy<ChargeRules>();
            rulNew.Hours = 40;
            rulNew.JE = ChargeMode;
            lst.Add(rulNew);

            switch (ChargeMode)
            {
                case 1:
                    lst.AddRange(DayNightRule.ToRuleList(rule));
                    break;
                case 2:
                    lst.AddRange(TimeUnitRule.ToRuleList(rule));
                    break;
                case 3:
                    break;
                default:
                    lst.AddRange(HoursRule.ToRuleList(rule));
                    break;
            }

            return lst;
        }

        /// <summary>
        /// 更改收费模式。
        /// </summary>
        /// <param name="NewMode">0是按小时为单位计费，1为分白天夜间段计费，2为按设定时间计费，3为按次计费</param>
        public void ChangeChargeMode(int NewMode)
        {
            switch (NewMode)
            {
                case 1:
                    _DayNightRule = _DayNightRule ?? new DayNightChargeRule(null);
                    break;
                case 2:
                    _TimeUnitRule = _TimeUnitRule ?? new TimeUnitChargeRule(null);
                    break;
                case 3:
                    break;
                default:
                    _HoursRule = _HoursRule ?? new HoursChargeRule(null);
                    break;
            }

            _ChargeMode = NewMode;
        }
    }

    /// <summary>
    /// 默认24小时制收费模式
    /// </summary>
    public class HoursChargeRule
    {
        public HoursChargeRule(List<ChargeRules> lstRule)
        {
            if (null == lstRule || lstRule.Count <= 0)
            {
                return;
            }

            foreach (ChargeRules rule in lstRule)
            {
                switch (rule.Hours)
                {
                    case 1:
                        _Hour1Money = rule.JE ?? 0;
                        break;
                    case 2:
                        _Hour2Money = rule.JE ?? 0;
                        break;
                    case 3:
                        _Hour3Money = rule.JE ?? 0;
                        break;
                    case 4:
                        _Hour4Money = rule.JE ?? 0;
                        break;
                    case 5:
                        _Hour5Money = rule.JE ?? 0;
                        break;
                    case 6:
                        _Hour6Money = rule.JE ?? 0;
                        break;
                    case 7:
                        _Hour7Money = rule.JE ?? 0;
                        break;
                    case 8:
                        _Hour8Money = rule.JE ?? 0;
                        break;
                    case 9:
                        _Hour9Money = rule.JE ?? 0;
                        break;
                    case 10:
                        _Hour10Money = rule.JE ?? 0;
                        break;
                    case 11:
                        _Hour11Money = rule.JE ?? 0;
                        break;
                    case 12:
                        _Hour12Money = rule.JE ?? 0;
                        break;
                    case 13:
                        _Hour13Money = rule.JE ?? 0;
                        break;
                    case 14:
                        _Hour14Money = rule.JE ?? 0;
                        break;
                    case 15:
                        _Hour15Money = rule.JE ?? 0;
                        break;
                    case 16:
                        _Hour16Money = rule.JE ?? 0;
                        break;
                    case 17:
                        _Hour17Money = rule.JE ?? 0;
                        break;
                    case 18:
                        _Hour18Money = rule.JE ?? 0;
                        break;
                    case 19:
                        _Hour19Money = rule.JE ?? 0;
                        break;
                    case 20:
                        _Hour20Money = rule.JE ?? 0;
                        break;
                    case 21:
                        _Hour21Money = rule.JE ?? 0;
                        break;
                    case 22:
                        _Hour22Money = rule.JE ?? 0;
                        break;
                    case 23:
                        _Hour23Money = rule.JE ?? 0;
                        break;
                    case 24:
                        _Hour24Money = rule.JE ?? 0;
                        break;
                    case 80:
                        _OverNightCharge = rule.JE ?? 0;
                        break;
                }
            }
        }

        protected decimal _Hour1Money;
        protected decimal _Hour2Money;
        protected decimal _Hour3Money;
        protected decimal _Hour4Money;
        protected decimal _Hour5Money;
        protected decimal _Hour6Money;
        protected decimal _Hour7Money;
        protected decimal _Hour8Money;
        protected decimal _Hour9Money;
        protected decimal _Hour10Money;
        protected decimal _Hour11Money;
        protected decimal _Hour12Money;
        protected decimal _Hour13Money;
        protected decimal _Hour14Money;
        protected decimal _Hour15Money;
        protected decimal _Hour16Money;
        protected decimal _Hour17Money;
        protected decimal _Hour18Money;
        protected decimal _Hour19Money;
        protected decimal _Hour20Money;
        protected decimal _Hour21Money;
        protected decimal _Hour22Money;
        protected decimal _Hour23Money;
        protected decimal _Hour24Money;
        protected decimal _OverNightCharge;

        public decimal Hour1Money { get { return _Hour1Money; } set { _Hour1Money = value; } }
        public decimal Hour2Money { get { return _Hour2Money; } set { _Hour2Money = value; } }
        public decimal Hour3Money { get { return _Hour3Money; } set { _Hour3Money = value; } }
        public decimal Hour4Money { get { return _Hour4Money; } set { _Hour4Money = value; } }
        public decimal Hour5Money { get { return _Hour5Money; } set { _Hour5Money = value; } }
        public decimal Hour6Money { get { return _Hour6Money; } set { _Hour6Money = value; } }
        public decimal Hour7Money { get { return _Hour7Money; } set { _Hour7Money = value; } }
        public decimal Hour8Money { get { return _Hour8Money; } set { _Hour8Money = value; } }
        public decimal Hour9Money { get { return _Hour9Money; } set { _Hour9Money = value; } }
        public decimal Hour10Money { get { return _Hour10Money; } set { _Hour10Money = value; } }
        public decimal Hour11Money { get { return _Hour11Money; } set { _Hour11Money = value; } }
        public decimal Hour12Money { get { return _Hour12Money; } set { _Hour12Money = value; } }
        public decimal Hour13Money { get { return _Hour13Money; } set { _Hour13Money = value; } }
        public decimal Hour14Money { get { return _Hour14Money; } set { _Hour14Money = value; } }
        public decimal Hour15Money { get { return _Hour15Money; } set { _Hour15Money = value; } }
        public decimal Hour16Money { get { return _Hour16Money; } set { _Hour16Money = value; } }
        public decimal Hour17Money { get { return _Hour17Money; } set { _Hour17Money = value; } }
        public decimal Hour18Money { get { return _Hour18Money; } set { _Hour18Money = value; } }
        public decimal Hour19Money { get { return _Hour19Money; } set { _Hour19Money = value; } }
        public decimal Hour20Money { get { return _Hour20Money; } set { _Hour20Money = value; } }
        public decimal Hour21Money { get { return _Hour21Money; } set { _Hour21Money = value; } }
        public decimal Hour22Money { get { return _Hour22Money; } set { _Hour22Money = value; } }
        public decimal Hour23Money { get { return _Hour23Money; } set { _Hour23Money = value; } }
        public decimal Hour24Money { get { return _Hour24Money; } set { _Hour24Money = value; } }
        /// <summary>
        /// 过0点加收费用
        /// </summary>
        public decimal OverNightCharge { get { return _OverNightCharge; } set { _OverNightCharge = value; } }

        public List<ChargeRules> ToRuleList(ChargeRules ruleBase)
        {
            ChargeRules rulNew;
            List<ChargeRules> lst;

            lst = new List<ChargeRules>();

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 1;
            rulNew.JE = Hour1Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 2;
            rulNew.JE = Hour2Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 3;
            rulNew.JE = Hour3Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 4;
            rulNew.JE = Hour4Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 5;
            rulNew.JE = Hour5Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 6;
            rulNew.JE = Hour6Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 7;
            rulNew.JE = Hour7Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 8;
            rulNew.JE = Hour8Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 9;
            rulNew.JE = Hour9Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 10;
            rulNew.JE = Hour10Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 11;
            rulNew.JE = Hour11Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 12;
            rulNew.JE = Hour12Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 13;
            rulNew.JE = Hour13Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 14;
            rulNew.JE = Hour14Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 15;
            rulNew.JE = Hour15Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 16;
            rulNew.JE = Hour16Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 17;
            rulNew.JE = Hour17Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 18;
            rulNew.JE = Hour18Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 19;
            rulNew.JE = Hour19Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 20;
            rulNew.JE = Hour20Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 21;
            rulNew.JE = Hour21Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 22;
            rulNew.JE = Hour22Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 23;
            rulNew.JE = Hour23Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 24;
            rulNew.JE = Hour24Money;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 80;
            rulNew.JE = OverNightCharge;
            lst.Add(rulNew);

            return lst;
        }
    }

    /// <summary>
    /// 分白天夜间段收费模式
    /// </summary>
    public class DayNightChargeRule
    {
        public DayNightChargeRule(List<ChargeRules> lstRule)
        {
            if (null == lstRule || lstRule.Count <= 0)
            {
                return;
            }

            foreach (ChargeRules rule in lstRule)
            {
                switch (rule.Hours)
                {
                    case 31:
                        _DayBeginHour = rule.JE ?? 0;
                        break;
                    case 32:
                        _NightBeginHour = rule.JE ?? 0;
                        break;
                    case 41:
                        _DayBeginMinute = rule.JE ?? 0;
                        break;
                    case 42:
                        _NightBeginMinute = rule.JE ?? 0;
                        break;
                    case 51:
                        _DayHourUnit = rule.JE ?? 0;
                        break;
                    case 52:
                        _NightHourUnit = rule.JE ?? 0;
                        break;
                    case 61:
                        _DayMinuteUnit = rule.JE ?? 0;
                        break;
                    case 62:
                        _NightMinuteUnit = rule.JE ?? 0;
                        break;
                    case 71:
                        _DayUnitMoney = rule.JE ?? 0;
                        break;
                    case 72:
                        _NightUnitMoney = rule.JE ?? 0;
                        break;
                    case 81:
                        _DayMaxMoney = rule.JE ?? 0;
                        break;
                    case 82:
                        _NightMaxMoney = rule.JE ?? 0;
                        break;
                    case 91:
                        _DayMinMoney = rule.JE ?? 0;
                        break;
                    case 92:
                        _NightMinMoney = rule.JE ?? 0;
                        break;
                    case 101:
                        _DayFirstUnitMoney = rule.JE ?? 0;
                        break;
                    case 102:
                        _NightFirstUnitMoney = rule.JE ?? 0;
                        break;
                    case 111:
                        _DayFirstUnitHour = rule.JE ?? 0;
                        break;
                    case 112:
                        _NightFirstUnitHour = rule.JE ?? 0;
                        break;
                    case 121:
                        _DayFirstUnitMinute = rule.JE ?? 0;
                        break;
                    case 122:
                        _NightFirstUnitMinute = rule.JE ?? 0;
                        break;
                    case 131:
                        _DayCutAtTheNextStartPoint = rule.JE > 0;
                        break;
                    case 132:
                        _NightCutAtTheNextStartPoint = rule.JE > 0;
                        break;
                }
            }
        }

        protected decimal _DayBeginHour;
        protected decimal _DayBeginMinute;
        protected decimal _DayHourUnit;
        protected decimal _DayMinuteUnit;
        protected decimal _DayUnitMoney;
        protected decimal _DayMaxMoney;
        protected decimal _DayMinMoney;
        protected decimal _DayFirstUnitMoney;
        protected decimal _DayFirstUnitHour;
        protected decimal _DayFirstUnitMinute;
        protected bool _DayCutAtTheNextStartPoint;
        protected decimal _NightBeginHour;
        protected decimal _NightBeginMinute;
        protected decimal _NightHourUnit;
        protected decimal _NightMinuteUnit;
        protected decimal _NightUnitMoney;
        protected decimal _NightMaxMoney;
        protected decimal _NightMinMoney;
        protected decimal _NightFirstUnitMoney;
        protected decimal _NightFirstUnitHour;
        protected decimal _NightFirstUnitMinute;
        protected bool _NightCutAtTheNextStartPoint;

        public decimal DayBeginHour { get { return _DayBeginHour; } set { _DayBeginHour = value; } }
        public decimal DayBeginMinute { get { return _DayBeginMinute; } set { _DayBeginMinute = value; } }
        public decimal DayHourUnit { get { return _DayHourUnit; } set { _DayHourUnit = value; } }
        public decimal DayMinuteUnit { get { return _DayMinuteUnit; } set { _DayMinuteUnit = value; } }
        public decimal DayUnitMoney { get { return _DayUnitMoney; } set { _DayUnitMoney = value; } }
        public decimal DayMaxMoney { get { return _DayMaxMoney; } set { _DayMaxMoney = value; } }
        //public decimal DayMinMoney { get { return _DayMinMoney; } set { _DayMinMoney = value; } }   //没有使用
        public decimal DayFirstUnitMoney { get { return _DayFirstUnitMoney; } set { _DayFirstUnitMoney = value; } }
        public decimal DayFirstUnitHour { get { return _DayFirstUnitHour; } set { _DayFirstUnitHour = value; } }
        public decimal DayFirstUnitMinute { get { return _DayFirstUnitMinute; } set { _DayFirstUnitMinute = value; } }
        public bool DayCutAtTheNextStartPoint { get { return _DayCutAtTheNextStartPoint; } set { _DayCutAtTheNextStartPoint = value; } }

        public decimal NightBeginHour { get { return _NightBeginHour; } set { _NightBeginHour = value; } }
        public decimal NightBeginMinute { get { return _NightBeginMinute; } set { _NightBeginMinute = value; } }
        public decimal NightHourUnit { get { return _NightHourUnit; } set { _NightHourUnit = value; } }
        public decimal NightMinuteUnit { get { return _NightMinuteUnit; } set { _NightMinuteUnit = value; } }
        public decimal NightUnitMoney { get { return _NightUnitMoney; } set { _NightUnitMoney = value; } }
        public decimal NightMaxMoney { get { return _NightMaxMoney; } set { _NightMaxMoney = value; } }
        //public decimal NightMinMoney { get { return _NightMinMoney; } set { _NightMinMoney = value; } }   //没有使用
        public decimal NightFirstUnitMoney { get { return _NightFirstUnitMoney; } set { _NightFirstUnitMoney = value; } }
        public decimal NightFirstUnitHour { get { return _NightFirstUnitHour; } set { _NightFirstUnitHour = value; } }
        public decimal NightFirstUnitMinute { get { return _NightFirstUnitMinute; } set { _NightFirstUnitMinute = value; } }
        public bool NightCutAtTheNextStartPoint { get { return _NightCutAtTheNextStartPoint; } set { _NightCutAtTheNextStartPoint = value; } }

        public List<ChargeRules> ToRuleList(ChargeRules ruleBase)
        {
            ChargeRules rulNew;
            List<ChargeRules> lst;

            lst = new List<ChargeRules>();

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 31;
            rulNew.JE = DayBeginHour;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 32;
            rulNew.JE = NightBeginHour;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 41;
            rulNew.JE = DayBeginMinute;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 42;
            rulNew.JE = NightBeginMinute;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 51;
            rulNew.JE = DayHourUnit;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 52;
            rulNew.JE = NightHourUnit;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 61;
            rulNew.JE = DayMinuteUnit;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 62;
            rulNew.JE = NightMinuteUnit;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 71;
            rulNew.JE = DayUnitMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 72;
            rulNew.JE = NightUnitMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 81;
            rulNew.JE = DayMaxMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 82;
            rulNew.JE = NightMaxMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 91;
            rulNew.JE = _DayMinMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 92;
            rulNew.JE = _NightMinMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 101;
            rulNew.JE = DayFirstUnitMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 102;
            rulNew.JE = NightFirstUnitMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 111;
            rulNew.JE = DayFirstUnitHour;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 112;
            rulNew.JE = NightFirstUnitHour;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 121;
            rulNew.JE = DayFirstUnitMinute;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 122;
            rulNew.JE = NightFirstUnitMinute;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 131;
            rulNew.JE = DayCutAtTheNextStartPoint ? 1 : 0;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 132;
            rulNew.JE = NightCutAtTheNextStartPoint ? 1 : 0;
            lst.Add(rulNew);

            return lst;
        }
    }

    /// <summary>
    /// 按设定时间收费模式
    /// </summary>
    public class TimeUnitChargeRule
    {
        public TimeUnitChargeRule(List<ChargeRules> lstRule)
        {
            if (null == lstRule || lstRule.Count <= 0)
            {
                return;
            }

            foreach (ChargeRules rule in lstRule)
            {
                switch (rule.Hours)
                {
                    case 61:
                        _TimeUnit = rule.JE ?? 0;
                        break;
                    case 71:
                        _UnitMoney = rule.JE ?? 0;
                        break;
                    case 80:
                        _OverNightCharge = rule.JE ?? 0;
                        break;
                    case 101:
                        _FirstUnitMoney = rule.JE ?? 0;
                        break;
                    case 121:
                        _FirstUnit = rule.JE ?? 0;
                        break;
                }
            }
        }

        protected decimal _TimeUnit;
        protected decimal _UnitMoney;
        protected decimal _FirstUnit;
        protected decimal _FirstUnitMoney;
        protected decimal _OverNightCharge;

        /// <summary>
        /// 计时单位(分钟)
        /// </summary>
        public decimal TimeUnit { get { return _TimeUnit; } set { _TimeUnit = value; } }
        /// <summary>
        /// 每计时单位收费额(元)
        /// </summary>
        public decimal UnitMoney { get { return _UnitMoney; } set { _UnitMoney = value; } }
        /// <summary>
        /// 首计时单位(分钟)
        /// </summary>
        public decimal FirstUnit { get { return _FirstUnit; } set { _FirstUnit = value; } }
        /// <summary>
        /// 首计时单位收费额(元)
        /// </summary>
        public decimal FirstUnitMoney { get { return _FirstUnitMoney; } set { _FirstUnitMoney = value; } }
        /// <summary>
        /// 过0点加收费用(元)
        /// </summary>
        public decimal OverNightCharge { get { return _OverNightCharge; } set { _OverNightCharge = value; } }

        public List<ChargeRules> ToRuleList(ChargeRules ruleBase)
        {
            ChargeRules rulNew;
            List<ChargeRules> lst;

            lst = new List<ChargeRules>();

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 61;
            rulNew.JE = TimeUnit;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 71;
            rulNew.JE = UnitMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 80;
            rulNew.JE = OverNightCharge;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 101;
            rulNew.JE = FirstUnitMoney;
            lst.Add(rulNew);

            rulNew = ruleBase.Copy<ChargeRules>();
            rulNew.Hours = 121;
            rulNew.JE = FirstUnit;
            lst.Add(rulNew);

            return lst;
        }
    }
}