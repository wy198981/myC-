﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tRightsItem
    public class RightsItem
    {

        /// <summary>
        /// 自增ID
        /// </summary>		
        private long _id;
        public long ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 窗体名或页面名
        /// </summary>		
        private string _formname;
        public string FormName
        {
            get { return _formname; }
            set { _formname = value; }
        }
        /// <summary>
        /// 控件名称
        /// </summary>		
        private string _itemname;
        public string ItemName
        {
            get { return _itemname; }
            set { _itemname = value; }
        }
        /// <summary>
        /// 所属分组
        /// </summary>		
        private string _category;
        public string Category
        {
            get { return _category; }
            set { _category = value; }
        }
        /// <summary>
        /// 上级控件ID。顶级控件此值填0
        /// </summary>		
        private long _pid;
        public long PID
        {
            get { return _pid; }
            set { _pid = value; }
        }
        /// <summary>
        /// 简短的说明
        /// </summary>		
        private string _description;
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        /// <summary>
        /// 排列顺序
        /// </summary>		
        private string _orders;
        public string Orders
        {
            get { return _orders; }
            set { _orders = value; }
        }

    }
}

