﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tSysSetting
		public class SysSetting
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 工作站编号
        /// </summary>		
		private int _stationid;
        public int StationID
        {
            get{ return _stationid; }
            set{ _stationid = value; }
        }        
		/// <summary>
		/// 设置名称
        /// </summary>		
		private string _setname;
        public string SetName
        {
            get{ return _setname; }
            set{ _setname = value; }
        }        
		/// <summary>
		/// 设置中文名
        /// </summary>		
		private string _chinesename;
        public string ChineseName
        {
            get{ return _chinesename; }
            set{ _chinesename = value; }
        }        
		/// <summary>
		/// 设置值
        /// </summary>		
		private string _setvalue;
        public string SetValue
        {
            get{ return _setvalue; }
            set{ _setvalue = value; }
        }

        public SysSetting()
        { 
        
        }

        public SysSetting(int stationid, string name, object value, string cname)
        {
            _stationid = stationid;
            _setname = name;
            _setvalue = value.ToString();
            _chinesename = cname;
        }
		   
	}
}

