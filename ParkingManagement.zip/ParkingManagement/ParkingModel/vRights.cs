﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
    //vRights
    public class vRights
    {

        /// <summary>
        /// FormName
        /// </summary>		
        private string _formname;
        public string FormName
        {
            get { return _formname; }
            set { _formname = value; }
        }
        /// <summary>
        /// ItemName
        /// </summary>		
        private string _itemname;
        public string ItemName
        {
            get { return _itemname; }
            set { _itemname = value; }
        }
        /// <summary>
        /// Category
        /// </summary>		
        private string _category;
        public string Category
        {
            get { return _category; }
            set { _category = value; }
        }
        /// <summary>
        /// PID
        /// </summary>		
        private int _pid;
        public int PID
        {
            get { return _pid; }
            set { _pid = value; }
        }
        /// <summary>
        /// ID
        /// </summary>		
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// GroupNO
        /// </summary>		
        private int _groupno;
        public int GroupNO
        {
            get { return _groupno; }
            set { _groupno = value; }
        }
        /// <summary>
        /// RightsItemID
        /// </summary>		
        private int _rightsitemid;
        public int RightsItemID
        {
            get { return _rightsitemid; }
            set { _rightsitemid = value; }
        }
        /// <summary>
        /// CanView
        /// </summary>		
        private bool _canview;
        public bool CanView
        {
            get { return _canview; }
            set { _canview = value; }
        }
        /// <summary>
        /// CanOperate
        /// </summary>		
        private bool _canoperate;
        public bool CanOperate
        {
            get { return _canoperate; }
            set { _canoperate = value; }
        }
        /// <summary>
        /// GroupName
        /// </summary>		
        private string _groupname;
        public string GroupName
        {
            get { return _groupname; }
            set { _groupname = value; }
        }
        /// <summary>
        /// Description
        /// </summary>		
        private string _description;
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        /// <summary>
        /// Orders
        /// </summary>		
        private string _orders;
        public string Orders
        {
            get { return _orders; }
            set { _orders = value; }
        }

    }


    /// <summary>
    /// 节点类，基础类
    /// </summary>
    [Serializable]
    public class JieDian
    {
        public vRights Model = new vRights();
        public JieDian[] Childs = null;
    }
}

