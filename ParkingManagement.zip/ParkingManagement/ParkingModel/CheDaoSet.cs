﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
using System.ComponentModel;

namespace ParkingModel
{

    public enum OpenTypeOpt { 临时卡确定开闸, 全部确定开闸, 全部自动开闸, 临免确定开闸, 确定开闸并吞卡, 自动开闸并吞卡, 自动吞卡确定开闸, 读卡或识别开闸, 读卡加识别开闸 };
    
    
	 	//tCheDaoSet
    public class CheDaoSet:INotifyPropertyChanged 
	{
   		public event PropertyChangedEventHandler PropertyChanged;   


      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 工作站编号
        /// </summary>		
		private int _stationid;
        public int StationID
        {
            get{ return _stationid; }
            set{ _stationid = value; }
        }        
		/// <summary>
		/// 车道
        /// </summary>		
		private int _carchannel;
        public int CarChannel
        {
            get { return _carchannel; }
            set { _carchannel = value; }
        }

        //public InOutOpt InOut
        //{ 
        //    get;set;
        //}
        

		/// <summary>
		/// 入出类型
        /// </summary>		
		private int _inout;
        public int InOut
        {
            get { return _inout; }
            set { _inout = value; }

            // set  
            //{
            //    _inout = value;  
            //    if (PropertyChanged != null)//有改变  
            //    {
            //        PropertyChanged(this, new PropertyChangedEventArgs("InOut"));//对Name进行监听  
            //    }  
            //}  
            //get  
            //{  
            //    return _inout;  
            //} 
        }        
		/// <summary>
		/// 车道名称
        /// </summary>		
		private string _inoutname;
        public string InOutName
        {
            //get{ return _inoutname; }
            //set{ _inoutname = value; }

            set  
            {  
                _inoutname = value;  
                if (PropertyChanged != null)//有改变  
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("InOutName"));//对Name进行监听  
                }  
            }  
            get  
            {  
                return _inoutname;  
            } 
        }        
		/// <summary>
		/// 机号
        /// </summary>		
		private int _ctrlnumber;
        public int CtrlNumber
        {
            get { return _ctrlnumber; }
            set { _ctrlnumber = value; }

            //set  
            //{
            //    _ctrlnumber = value;  
            //    if (PropertyChanged != null)//有改变  
            //    {
            //        PropertyChanged(this, new PropertyChangedEventArgs("CtrlNumber"));//对Name进行监听  
            //    }  
            //}  
            //get  
            //{
            //    return _ctrlnumber;  
            //} 

        }        
		/// <summary>
		/// 开闸机号
        /// </summary>		
		private int _openid;
        public int OpenID
        {
            get{ return _openid; }
            set{ _openid = value; }
        }        
		/// <summary>
		/// 开闸方式
        /// </summary>		
		private int _opentype;
        public int OpenType
        {
            get { return _opentype; }
            set { _opentype = value; }
        }


        //public OpenTypeOpt OpenType
        //{
        //    get;
        //    set;
        //}

		/// <summary>
		/// 人相视频
        /// </summary>		
		private int _personvideo;
        public int PersonVideo
        {
            get{ return _personvideo; }
            set{ _personvideo = value; }
        }        
		/// <summary>
		/// 大小车场
        /// </summary>		
		private int _bigsmall;
        public int BigSmall
        {
            get { return _bigsmall; }
            set { _bigsmall = value; }
        }        

        //public BigSmallOpt BigSmall
        //{
        //    get;
        //    set;
        //}

		/// <summary>
		/// 检测口
        /// </summary>		
		private int _checkportid;
        public int CheckPortID
        {
            get{ return _checkportid; }
            set{ _checkportid = value; }
        }        
		/// <summary>
		/// 是否在线
        /// </summary>		
		private int _online;
        public int OnLine
        {
            get{ return _online; }
            set{ _online = value; }
        }        
		/// <summary>
		/// 临时出口
        /// </summary>		
		private int _tempout;
        public int TempOut
        {
            get{ return _tempout; }
            set{ _tempout = value; }
        }        
		/// <summary>
		/// 出卡机
        /// </summary>		
		private int _hasoutcard;
        public int HasOutCard
        {
            get{ return _hasoutcard; }
            set{ _hasoutcard = value; }
        }        
		/// <summary>
		/// 子机号
        /// </summary>		
		private string _subjh;
        public string SubJH
        {
            get{ return _subjh; }
            set{ _subjh = value; }
        }        
		/// <summary>
		/// 协议
        /// </summary>		
		private int _xieyi;
        public int XieYi
        {
            get{ return _xieyi; }
            set{ _xieyi = value; }
        }        
		/// <summary>
		/// IP地址
        /// </summary>		
		private string _ip;
        public string IP
        {
            get
            { return _ip; }
            set
            {
                _ip = value;
                if (PropertyChanged != null)//有改变  
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("IP"));//对Name进行监听  
                }
            }
        }
        
		/// <summary>
		/// 相机IP
        /// </summary>		
		private string _cameraip;
        public string CameraIP
        {
            get{ return _cameraip; }
            set{ _cameraip = value; }
        }        
		/// <summary>
		/// 备用
        /// </summary>		
		private int _temp1;
        public int Temp1
        {
            get{ return _temp1; }
            set{ _temp1 = value; }
        }        
		/// <summary>
		/// 备用
        /// </summary>		
		private int _temp2;
        public int Temp2
        {
            get{ return _temp2; }
            set{ _temp2 = value; }
        }        
		/// <summary>
		/// 备用
        /// </summary>		
		private int _temp3;
        public int Temp3
        {
            get{ return _temp3; }
            set{ _temp3 = value; }
        }

        public bool SendSignal { get; set; }
        public bool RecieveSignal { get; set; }
	}
}

