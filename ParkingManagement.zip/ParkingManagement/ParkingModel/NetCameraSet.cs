﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
using System.ComponentModel;
namespace ParkingModel
{
	 	//tNetCameraSet
    public class NetCameraSet : INotifyPropertyChanged
	{
        public event PropertyChangedEventHandler PropertyChanged;   
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 工作站编号
        /// </summary>		
		private int _stationid;
        public int StationID
        {
            get{ return _stationid; }
            set{ _stationid = value; }
        }        
		/// <summary>
		/// 相机IP
        /// </summary>		
		private string _videoip;
        public string VideoIP
        {
            get{ return _videoip; }
            set{ _videoip = value; }
        }        
		/// <summary>
		/// 端口
        /// </summary>		
		private string _videoport;
        public string VideoPort
        {
            get{ return _videoport; }
            set{ 
                _videoport = value;
                if (PropertyChanged != null)//有改变  
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("VideoPort"));//对Name进行监听  
                } 
            }
        }        
		/// <summary>
		/// 用户名
        /// </summary>		
		private string _videousername;
        public string VideoUserName
        {
            get{ return _videousername; }
            set{ _videousername = value; }
        }        
		/// <summary>
		/// 登录密码
        /// </summary>		
		private string _videopassword;
        public string VideoPassWord
        {
            get{ return _videopassword; }
            set
            {
                _videopassword = value;
                if (PropertyChanged != null)//有改变  
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("VideoPassWord"));//对Name进行监听  
                }
            }
        }        
		/// <summary>
		/// VideoType
        /// </summary>		
		private string _videotype;
        public string VideoType
        {
            get{ return _videotype; }
            set{ _videotype = value; }
        }        
		   
	}
}

