﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tNoRecordCPH
		public class NoRecordCPH
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// CPH
        /// </summary>		
		private string _cph;
        public string CPH
        {
            get{ return _cph; }
            set{ _cph = value; }
        }        
		   
	}
}

