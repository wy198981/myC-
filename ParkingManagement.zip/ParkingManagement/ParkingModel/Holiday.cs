﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tHoliday
		public class Holiday
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 日期
        /// </summary>		
		private DateTime _dates;
        public DateTime Dates
        {
            get{ return _dates; }
            set{ _dates = value; }
        }        
		/// <summary>
		/// 类型（假日或工作日）
        /// </summary>		
		private string _types;
        public string Types
        {
            get{ return _types; }
            set{ _types = value; }
        }        
		   
	}
}

