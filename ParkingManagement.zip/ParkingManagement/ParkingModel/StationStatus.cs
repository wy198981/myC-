﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tStationStatus
		public class StationStatus
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 工作站编号
        /// </summary>		
		private int _stationid;
        public int StationID
        {
            get{ return _stationid; }
            set{ _stationid = value; }
        }        
		/// <summary>
		/// 是否在线
        /// </summary>		
		private int _online;
        public int Online
        {
            get{ return _online; }
            set{ _online = value; }
        }        
		   
	}
}

