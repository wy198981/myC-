﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tDeviceSettingsBakeup
		public class DeviceSettingsBakeup
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// CtrlNumber
        /// </summary>		
		private int _ctrlnumber;
        public int CtrlNumber
        {
            get{ return _ctrlnumber; }
            set{ _ctrlnumber = value; }
        }        
		/// <summary>
		/// Instruct
        /// </summary>		
		private string _instruct;
        public string Instruct
        {
            get{ return _instruct; }
            set{ _instruct = value; }
        }        
		/// <summary>
		/// Flag
        /// </summary>		
		private string _flag;
        public string Flag
        {
            get{ return _flag; }
            set{ _flag = value; }
        }        
		   
	}
}

