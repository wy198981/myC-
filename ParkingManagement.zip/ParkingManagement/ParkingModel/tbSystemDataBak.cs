﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tbSystemDataBak
		public class tbSystemDataBak
	{
   		     
      	/// <summary>
		/// id
        /// </summary>		
		private int _id;
        public int id
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// IsEnld
        /// </summary>		
		private bool _isenld;
        public bool IsEnld
        {
            get{ return _isenld; }
            set{ _isenld = value; }
        }        
		/// <summary>
		/// LoadRoute
        /// </summary>		
		private string _loadroute;
        public string LoadRoute
        {
            get{ return _loadroute; }
            set{ _loadroute = value; }
        }        
		/// <summary>
		/// BakTime
        /// </summary>		
		private string _baktime;
        public string BakTime
        {
            get{ return _baktime; }
            set{ _baktime = value; }
        }        
		   
	}
}

