﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class QueryConditionGroup
    {
        public QueryConditionGroup()
        {
            _Combinator = "and";
        }

        protected string _Combinator;
        protected readonly List<QueryCondition> lst = new List<QueryCondition>();

        /// <summary>
        /// 条件列表
        /// </summary>
        public List<QueryCondition> Conditions { get { return lst; } }

        /// <summary>
        /// 逻辑连接符(or 或 and)
        /// </summary>
        public string Combinator
        {
            get
            {
                return null == _Combinator || "" == _Combinator.Trim() ? "and" : _Combinator.Trim();
            }
            set
            {
                _Combinator = value;
            }
        }

        public void Add(string fieldName, string oprator, object value, string combinator = "and")
        {
            QueryCondition condition;

            condition = new QueryCondition(fieldName, oprator, value, combinator);

            lst.Add(condition);
        }
    }
}
