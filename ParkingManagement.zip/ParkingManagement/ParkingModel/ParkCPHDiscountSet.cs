﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tParkCPHDiscountSet
    public class ParkCPHDiscountSet
    {

        /// <summary>
        /// ID
        /// </summary>		
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 部门Id。
        /// </summary>
        public long DeptId { get; set; }
        /// <summary>
        /// 部门名称
        /// </summary>
        public string DeptName { get; set; }
        /// <summary>
        /// 车牌号
        /// </summary>
        public string CPH { get; set; }
        /// <summary>
        /// 优惠场所
        /// </summary>

        public string Address { get; set; }
        /// <summary>
        /// 优惠的数量
        /// </summary>

        public decimal? Favorable { get; set; }
        /// <summary>
        /// 优惠方式（小时或元）
        /// </summary>

        public string Manner { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public decimal? OutHour { get; set; }
        /// <summary>
        /// 
        /// </summary>

        public decimal? OutDayNo { get; set; }
        /// <summary>
        /// 状态。0为新增，1为已优惠，2为因互斥优惠生效而失效，3为因删除而失效
        /// </summary>
        public byte Status { get; set; }
        /// <summary>
        /// 操作时间
        /// </summary>

        public DateTime? OptTime { get; set; }
        /// <summary>
        /// 操作员
        /// </summary>

        public string OperatorName { get; set; }
        /// <summary>
        /// 过期时间。为空表示永不过期。
        /// </summary>

        public DateTime? ValidEndTime { get; set; }
    }
}