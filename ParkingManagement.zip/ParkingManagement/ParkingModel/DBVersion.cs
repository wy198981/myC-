﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tDBVersion
		public class DBVersion
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// DBVer
        /// </summary>		
		private int _dbver;
        public int DBVer
        {
            get{ return _dbver; }
            set{ _dbver = value; }
        }        
		/// <summary>
		/// upd_Time
        /// </summary>		
		private DateTime _upd_time;
        public DateTime upd_Time
        {
            get{ return _upd_time; }
            set{ _upd_time = value; }
        }        
		   
	}
}

