﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tSummaryReport
		public class SummaryReport
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// CARDSNO
        /// </summary>		
		private string _cardsno;
        public string CARDSNO
        {
            get{ return _cardsno; }
            set{ _cardsno = value; }
        }        
		/// <summary>
		/// IMONTHA
        /// </summary>		
		private int _imontha;
        public int IMONTHA
        {
            get{ return _imontha; }
            set{ _imontha = value; }
        }        
		/// <summary>
		/// IMONTHB
        /// </summary>		
		private int _imonthb;
        public int IMONTHB
        {
            get{ return _imonthb; }
            set{ _imonthb = value; }
        }        
		/// <summary>
		/// IMONTHC
        /// </summary>		
		private int _imonthc;
        public int IMONTHC
        {
            get{ return _imonthc; }
            set{ _imonthc = value; }
        }        
		/// <summary>
		/// IMONTHD
        /// </summary>		
		private int _imonthd;
        public int IMONTHD
        {
            get{ return _imonthd; }
            set{ _imonthd = value; }
        }        
		/// <summary>
		/// ISUMMONTH
        /// </summary>		
		private int _isummonth;
        public int ISUMMONTH
        {
            get{ return _isummonth; }
            set{ _isummonth = value; }
        }        
		/// <summary>
		/// IFREEA
        /// </summary>		
		private int _ifreea;
        public int IFREEA
        {
            get{ return _ifreea; }
            set{ _ifreea = value; }
        }        
		/// <summary>
		/// IFREEB
        /// </summary>		
		private int _ifreeb;
        public int IFREEB
        {
            get{ return _ifreeb; }
            set{ _ifreeb = value; }
        }        
		/// <summary>
		/// ISUMFREE
        /// </summary>		
		private int _isumfree;
        public int ISUMFREE
        {
            get{ return _isumfree; }
            set{ _isumfree = value; }
        }        
		/// <summary>
		/// ITEMPA
        /// </summary>		
		private int _itempa;
        public int ITEMPA
        {
            get{ return _itempa; }
            set{ _itempa = value; }
        }        
		/// <summary>
		/// ITEMPB
        /// </summary>		
		private int _itempb;
        public int ITEMPB
        {
            get{ return _itempb; }
            set{ _itempb = value; }
        }        
		/// <summary>
		/// ITEMPC
        /// </summary>		
		private int _itempc;
        public int ITEMPC
        {
            get{ return _itempc; }
            set{ _itempc = value; }
        }        
		/// <summary>
		/// ITEMPD
        /// </summary>		
		private int _itempd;
        public int ITEMPD
        {
            get{ return _itempd; }
            set{ _itempd = value; }
        }        
		/// <summary>
		/// ITEMPE
        /// </summary>		
		private int _itempe;
        public int ITEMPE
        {
            get{ return _itempe; }
            set{ _itempe = value; }
        }        
		/// <summary>
		/// ITEMPF
        /// </summary>		
		private int _itempf;
        public int ITEMPF
        {
            get{ return _itempf; }
            set{ _itempf = value; }
        }        
		/// <summary>
		/// ITEMPG
        /// </summary>		
		private int _itempg;
        public int ITEMPG
        {
            get{ return _itempg; }
            set{ _itempg = value; }
        }        
		/// <summary>
		/// ITEMPH
        /// </summary>		
		private int _itemph;
        public int ITEMPH
        {
            get{ return _itemph; }
            set{ _itemph = value; }
        }        
		/// <summary>
		/// ISUMTEMP
        /// </summary>		
		private int _isumtemp;
        public int ISUMTEMP
        {
            get{ return _isumtemp; }
            set{ _isumtemp = value; }
        }        
		/// <summary>
		/// IMONEYA
        /// </summary>		
		private int _imoneya;
        public int IMONEYA
        {
            get{ return _imoneya; }
            set{ _imoneya = value; }
        }        
		/// <summary>
		/// IMONEYB
        /// </summary>		
		private int _imoneyb;
        public int IMONEYB
        {
            get{ return _imoneyb; }
            set{ _imoneyb = value; }
        }        
		/// <summary>
		/// IMONEYC
        /// </summary>		
		private int _imoneyc;
        public int IMONEYC
        {
            get{ return _imoneyc; }
            set{ _imoneyc = value; }
        }        
		/// <summary>
		/// IMONEYD
        /// </summary>		
		private int _imoneyd;
        public int IMONEYD
        {
            get{ return _imoneyd; }
            set{ _imoneyd = value; }
        }        
		/// <summary>
		/// ISUMMONEY
        /// </summary>		
		private int _isummoney;
        public int ISUMMONEY
        {
            get{ return _isummoney; }
            set{ _isummoney = value; }
        }        
		/// <summary>
		/// IMONEY
        /// </summary>		
		private decimal _imoney;
        public decimal IMONEY
        {
            get{ return _imoney; }
            set{ _imoney = value; }
        }        
		/// <summary>
		/// ZSUMCAR
        /// </summary>		
		private int _zsumcar;
        public int ZSUMCAR
        {
            get{ return _zsumcar; }
            set{ _zsumcar = value; }
        }        
		/// <summary>
		/// ZSUMMONEY
        /// </summary>		
		private decimal _zsummoney;
        public decimal ZSUMMONEY
        {
            get{ return _zsummoney; }
            set{ _zsummoney = value; }
        }        
		/// <summary>
		/// ITEMPFREE
        /// </summary>		
		private int _itempfree;
        public int ITEMPFREE
        {
            get{ return _itempfree; }
            set{ _itempfree = value; }
        }        
		/// <summary>
		/// ITEMPMONEY
        /// </summary>		
		private int _itempmoney;
        public int ITEMPMONEY
        {
            get{ return _itempmoney; }
            set{ _itempmoney = value; }
        }        
		/// <summary>
		/// IMONTHE
        /// </summary>		
		private int _imonthe;
        public int IMONTHE
        {
            get{ return _imonthe; }
            set{ _imonthe = value; }
        }        
		/// <summary>
		/// IMONTHF
        /// </summary>		
		private int _imonthf;
        public int IMONTHF
        {
            get{ return _imonthf; }
            set{ _imonthf = value; }
        }        
		/// <summary>
		/// IMONTHG
        /// </summary>		
		private int _imonthg;
        public int IMONTHG
        {
            get{ return _imonthg; }
            set{ _imonthg = value; }
        }        
		/// <summary>
		/// IMONTHH
        /// </summary>		
		private int _imonthh;
        public int IMONTHH
        {
            get{ return _imonthh; }
            set{ _imonthh = value; }
        }        
		   
	}
}

