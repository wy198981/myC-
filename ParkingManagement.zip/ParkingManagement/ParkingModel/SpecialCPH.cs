﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class SpecialCPH
    {
        public int ID { get; set; }
        public int Type { get; set; }
        public string CPH { get; set; }
        public string Mode { get; set; }
        public string Show { get; set; }
    }
}
