﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tParkDiscountJHSet
		public class ParkDiscountJHSet
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 打折机机号
        /// </summary>		
		private int _ctrlnumber;
        public int CtrlNumber
        {
            get{ return _ctrlnumber; }
            set{ _ctrlnumber = value; }
        }        
		/// <summary>
		/// 优惠场所
        /// </summary>		
		private string _address;
        public string Address
        {
            get{ return _address; }
            set{ _address = value; }
        }        
		/// <summary>
		/// 优惠金额或小时
        /// </summary>		
		private decimal _favorable;
        public decimal Favorable
        {
            get{ return _favorable; }
            set{ _favorable = value; }
        }        
		/// <summary>
		/// 优惠方式
        /// </summary>		
		private string _manner;
        public string Manner
        {
            get{ return _manner; }
            set{ _manner = value; }
        }        
		/// <summary>
		/// OutHour
        /// </summary>		
		private decimal _outhour;
        public decimal OutHour
        {
            get{ return _outhour; }
            set{ _outhour = value; }
        }        
		/// <summary>
		/// OutDayNo
        /// </summary>		
		private decimal _outdayno;
        public decimal OutDayNo
        {
            get{ return _outdayno; }
            set{ _outdayno = value; }
        }        
		   
	}
}

