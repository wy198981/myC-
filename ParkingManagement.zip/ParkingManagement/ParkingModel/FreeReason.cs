﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tFreeReason
		public class FreeReason
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// ItemID
        /// </summary>		
		private int _itemid;
        public int ItemID
        {
            get{ return _itemid; }
            set{ _itemid = value; }
        }        
		/// <summary>
		/// ItemDetail
        /// </summary>		
		private string _itemdetail;
        public string ItemDetail
        {
            get{ return _itemdetail; }
            set{ _itemdetail = value; }
        }        
		   
	}
}

