﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tDepartment
		public class Department
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 部门编号
        /// </summary>		
		private string _deptno;
        public string DeptNO
        {
            get{ return _deptno; }
            set{ _deptno = value; }
        }        
		/// <summary>
		/// 部门名称
        /// </summary>		
		private string _deptname;
        public string DeptName
        {
            get{ return _deptname; }
            set{ _deptname = value; }
        }        
		/// <summary>
		/// 部门标志
        /// </summary>		
		private string _deptsymbol;
        public string DeptSymbol
        {
            get{ return _deptsymbol; }
            set{ _deptsymbol = value; }
        }        
		/// <summary>
		/// PID
        /// </summary>		
		private int _pid;
        public int PID
        {
            get{ return _pid; }
            set{ _pid = value; }
        }        
		   
	}
}

