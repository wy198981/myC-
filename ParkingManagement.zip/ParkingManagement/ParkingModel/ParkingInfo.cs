﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParkingModel
{
    public class ParkingInfo
    {
        public Decimal TotalDiscount { get; set; }
        public Decimal TotalCharge { get; set; }
        public int ManualOpenCarCount { get; set; }
        public int TotalCarCountInPark { get; set; }
        public int MonthCarCountInPark { get; set; }
        public int TempCarCountInPark { get; set; }
        public int PrepaidCarCountInPark { get; set; }
        public int FreeCarCountInPark { get; set; }
    }
}
