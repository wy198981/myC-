﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tOperators
		public class Operators
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 卡号
        /// </summary>		
		private string _cardno;
        public string CardNO
        {
            get{ return _cardno; }
            set{ _cardno = value; }
        }        
		/// <summary>
		/// 卡类
        /// </summary>		
		private string _cardtype;
        public string CardType
        {
            get{ return _cardtype; }
            set{ _cardtype = value; }
        }        
		/// <summary>
		/// 人员编号
        /// </summary>		
		private string _userno;
        public string UserNO
        {
            get{ return _userno; }
            set{ _userno = value; }
        }        
		/// <summary>
		/// 人员姓名
        /// </summary>		
		private string _username;
        public string UserName
        {
            get{ return _username; }
            set{ _username = value; }
        }        
		/// <summary>
		/// 部门
        /// </summary>		
		private string _deptname;
        public string DeptName
        {
            get{ return _deptname; }
            set{ _deptname = value; }
        }        
		/// <summary>
		/// 密码
        /// </summary>		
		private string _pwd;
        public string Pwd
        {
            get{ return _pwd; }
            set{ _pwd = value; }
        }        
		/// <summary>
		/// 卡状态
        /// </summary>		
		private int _cardstate;
        public int CardState
        {
            get{ return _cardstate; }
            set{ _cardstate = value; }
        }        
		/// <summary>
		/// 权限组
        /// </summary>		
		private int _userlevel;
        public int UserLevel
        {
            get{ return _userlevel; }
            set{ _userlevel = value; }
        }        
		   
	}
}

