﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tUserInfo
		public class UserInfo
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 人员编号
        /// </summary>		
		private string _userno;
        public string UserNO
        {
            get{ return _userno; }
            set{ _userno = value; }
        }        
		/// <summary>
		/// 人员姓名
        /// </summary>		
		private string _username;
        public string UserName
        {
            get{ return _username; }
            set{ _username = value; }
        }        
		/// <summary>
		/// 性别
        /// </summary>		
		private string _sex;
        public string Sex
        {
            get{ return _sex; }
            set{ _sex = value; }
        }        
		/// <summary>
		/// 家庭住址
        /// </summary>		
		private string _homeaddress;
        public string HomeAddress
        {
            get{ return _homeaddress; }
            set{ _homeaddress = value; }
        }

        private int _deptid;
        public int DeptID
        {
            get { return _deptid; }
            set { _deptid = value; }
        }

		/// <summary>
		/// 部门名称
        /// </summary>		
		private string _deptname;
        public string DeptName
        {
            get{ return _deptname; }
            set{ _deptname = value; }
        }        
		/// <summary>
		/// 职业
        /// </summary>		
		private string _job;
        public string Job
        {
            get{ return _job; }
            set{ _job = value; }
        }        
		/// <summary>
		/// 工作时间
        /// </summary>		
		private DateTime? _worktime;
        public DateTime? WorkTime
        {
            get{ return _worktime; }
            set{ _worktime = value; }
        }        
		/// <summary>
		/// 出生日期
        /// </summary>		
		private DateTime? _birthdate;
        public DateTime? BirthDate
        {
            get{ return _birthdate; }
            set{ _birthdate = value; }
        }        
		/// <summary>
		/// 身份证号
        /// </summary>		
		private string _idcard;
        public string IDCard
        {
            get{ return _idcard; }
            set{ _idcard = value; }
        }        
		/// <summary>
		/// 婚姻状态
        /// </summary>		
		private string _maritalstatus;
        public string MaritalStatus
        {
            get{ return _maritalstatus; }
            set{ _maritalstatus = value; }
        }        
		/// <summary>
		/// 最高学历
        /// </summary>		
		private string _highestdegree;
        public string HighestDegree
        {
            get{ return _highestdegree; }
            set{ _highestdegree = value; }
        }        
		/// <summary>
		/// 政治面貌
        /// </summary>		
		private string _politicalstatus;
        public string PoliticalStatus
        {
            get{ return _politicalstatus; }
            set{ _politicalstatus = value; }
        }        
		/// <summary>
		/// 学校名称
        /// </summary>		
		private string _school;
        public string School
        {
            get{ return _school; }
            set{ _school = value; }
        }        
		/// <summary>
		/// 专长
        /// </summary>		
		private string _speciality;
        public string Speciality
        {
            get{ return _speciality; }
            set{ _speciality = value; }
        }        
		/// <summary>
		/// 外语
        /// </summary>		
		private string _foreignlanguage;
        public string ForeignLanguage
        {
            get{ return _foreignlanguage; }
            set{ _foreignlanguage = value; }
        }        
		/// <summary>
		/// 技能
        /// </summary>		
		private string _skill;
        public string Skill
        {
            get{ return _skill; }
            set{ _skill = value; }
        }        
		/// <summary>
		/// 电话
        /// </summary>		
		private string _telnumber;
        public string TelNumber
        {
            get{ return _telnumber; }
            set{ _telnumber = value; }
        }        
		/// <summary>
		/// 手机
        /// </summary>		
		private string _mobnumber;
        public string MobNumber
        {
            get{ return _mobnumber; }
            set{ _mobnumber = value; }
        }        
		/// <summary>
		/// 邮编
        /// </summary>		
		private string _zipcode;
        public string ZipCode
        {
            get{ return _zipcode; }
            set{ _zipcode = value; }
        }        
		/// <summary>
		/// 籍贯
        /// </summary>		
		private string _nativeplace;
        public string NativePlace
        {
            get{ return _nativeplace; }
            set{ _nativeplace = value; }
        }        
		/// <summary>
		/// 车位数量
        /// </summary>		
		private int _carplaceno;
        public int CarPlaceNo
        {
            get{ return _carplaceno; }
            set{ _carplaceno = value; }
        }        
		   
	}
}

