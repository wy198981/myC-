﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tBillPrintSet
		public class BillPrintSet
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// Title
        /// </summary>		
		private string _title;
        public string Title
        {
            get{ return _title; }
            set{ _title = value; }
        }        
		/// <summary>
		/// FTitle
        /// </summary>		
		private string _ftitle;
        public string FTitle
        {
            get{ return _ftitle; }
            set{ _ftitle = value; }
        }        
		/// <summary>
		/// Footer
        /// </summary>		
		private string _footer;
        public string Footer
        {
            get{ return _footer; }
            set{ _footer = value; }
        }        
		   
	}
}

