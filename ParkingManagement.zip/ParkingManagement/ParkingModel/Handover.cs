﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class Handover
    {
        /// <summary>
        /// 车场编号
        /// </summary>
        public int CarparkNO { get; set; }
        /// <summary>
        /// 交班操作员名称
        /// </summary>
        public string OffDutyOperatorNO { get; set; }
        /// <summary>
        /// 接班操作员名称
        /// </summary>
        public string TakeOverOperatorNO { get; set; }

        public string TakeOverOperatorName { get; set; }

        public string OffDutyOperatorName { get; set; }

        /// <summary>
        /// 交班操作员上一次接班时间
        /// </summary>
        public DateTime LastTakeOverTime { get; set; }
        /// <summary>
        /// 本次换班时间
        /// </summary>
        public DateTime ThisTakeOverTime { get; set; }
        /// <summary>
        /// 两次换班期间出场的总应收金额
        /// </summary>

        public decimal TotalCharge { get; set; }
        /// <summary>
        /// 两次换班期间出场的总收费金额
        /// </summary>

        public decimal TotalPaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的储值卡收费金额
        /// </summary>

        public decimal StrPaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的临时车收费金额
        /// </summary>

        public decimal TmpPaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的月临车收费金额
        /// </summary>

        public decimal MtpPaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的A类车收费金额
        /// </summary>

        public decimal ATypePaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的B类车收费金额
        /// </summary>

        public decimal BTypePaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的C类车收费金额
        /// </summary>

        public decimal CTypePaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的D类车收费金额
        /// </summary>

        public decimal DTypePaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的E类车收费金额
        /// </summary>

        public decimal ETypePaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的F类车收费金额
        /// </summary>

        public decimal FTypePaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的G类车收费金额
        /// </summary>

        public decimal GTypePaid { get; set; }
        /// <summary>
        /// 两次换班期间出场的H类车收费金额
        /// </summary>

        public decimal HTypePaid { get; set; }
        /// <summary>
        /// 当前场内临时车数量
        /// </summary>

        public int InTmpNum { get; set; }
        /// <summary>
        /// 当前场内月租车数量
        /// </summary>

        public int InMthNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的临时车车次
        /// </summary>

        public int OutTmpNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的临免车车次
        /// </summary>

        public int OutTfrNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的月租车车次
        /// </summary>

        public int OutMthNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的月临车车次
        /// </summary>

        public int OutMtpNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的免费车车次
        /// </summary>

        public int OutFreNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的人工开闸车次
        /// </summary>

        public int OutPerOpen { get; set; }
        /// <summary>
        /// 两次换班期间进入过车场的临时车总车次
        /// </summary>

        public int TotalInTmpNum { get; set; }
        /// <summary>
        /// 两次换班期间进入过车场的总车次
        /// </summary>

        public int TotalInNumber { get; set; }
        /// <summary>
        /// 两次换班期间已出场的总车次
        /// </summary>

        public int TotalOutNumber { get; set; }
        /// <summary>
        /// 两次换班期间出场的A类车总车次
        /// </summary>

        public int ATypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的B类车总车次
        /// </summary>

        public int BTypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的C类车总车次
        /// </summary>

        public int CTypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的D类车总车次
        /// </summary>

        public int DTypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的E类车总车次
        /// </summary>

        public int ETypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的F类车总车次
        /// </summary>

        public int FTypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的G类车总车次
        /// </summary>

        public int GTypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的H类车总车次
        /// </summary>

        public int HTypeCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的收费车车次
        /// </summary>

        public int PaidCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的免费车车次
        /// </summary>

        public int FreCarNum { get; set; }
        /// <summary>
        /// 两次换班期间出场的未交费车车次
        /// </summary>

        public int NotPaidCarNum { get; set; }
        /// <summary>
        /// 备注
        /// </summary>

        public string Remarks { get; set; }


    }
}
