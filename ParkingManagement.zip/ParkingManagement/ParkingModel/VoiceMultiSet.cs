﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tVoiceMultiSet
		public class VoiceMultiSet
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 机号
        /// </summary>		
		private int _number;
        public int Number
        {
            get{ return _number; }
            set{ _number = value; }
        }        
		/// <summary>
		/// 卡号
        /// </summary>		
		private string _cardno;
        public string CardNO
        {
            get{ return _cardno; }
            set{ _cardno = value; }
        }        
		/// <summary>
		/// 开始时间
        /// </summary>		
		private DateTime _starttime;
        public DateTime StartTime
        {
            get{ return _starttime; }
            set{ _starttime = value; }
        }        
		/// <summary>
		/// 结束时间
        /// </summary>		
		private DateTime _endtime;
        public DateTime EndTime
        {
            get{ return _endtime; }
            set{ _endtime = value; }
        }        
		/// <summary>
		/// 入场语音
        /// </summary>		
		private string _invoice;
        public string InVoice
        {
            get{ return _invoice; }
            set{ _invoice = value; }
        }        
		/// <summary>
		/// 出场语音
        /// </summary>		
		private string _outvoice;
        public string OutVoice
        {
            get{ return _outvoice; }
            set{ _outvoice = value; }
        }

        /// <summary>
        /// 人员编号
        /// </summary>
        private string _userNO;
        public string UserNO
        {
            get { return _userNO; }
            set { _userNO = value; }
        }

        /// <summary>
        /// 人员姓名
        /// </summary>
        private string _userName;
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

	}
}

