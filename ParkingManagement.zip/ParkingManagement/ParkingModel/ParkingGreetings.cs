﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tParkingGreetings
		public class ParkingGreetings
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 机号
        /// </summary>		
		private int _ctrlnumber;
        public int CtrlNumber
        {
            get{ return _ctrlnumber; }
            set{ _ctrlnumber = value; }
        }        
		/// <summary>
		/// 语音字符串
        /// </summary>		
		private string _voice;
        public string Voice
        {
            get{ return _voice; }
            set{ _voice = value; }
        }        
		/// <summary>
		/// 开始时间
        /// </summary>		
		private DateTime _starttime;
        public DateTime StartTime
        {
            get{ return _starttime; }
            set{ _starttime = value; }
        }        
		/// <summary>
		/// 结束时间
        /// </summary>		
		private DateTime _endtime;
        public DateTime EndTime
        {
            get{ return _endtime; }
            set{ _endtime = value; }
        }        
		/// <summary>
		/// 是否启用多功能语音
        /// </summary>		
		private bool _dredgevoice;
        public bool DredgeVoice
        {
            get{ return _dredgevoice; }
            set{ _dredgevoice = value; }
        }        
		   
	}
}

