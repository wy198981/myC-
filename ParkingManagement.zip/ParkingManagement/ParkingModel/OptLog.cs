﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tOptLog
		public class OptLog
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 工作站编号
        /// </summary>		
		private int _stationid;
        public int StationID
        {
            get{ return _stationid; }
            set{ _stationid = value; }
        }        
		/// <summary>
		/// 操作员编号
        /// </summary>		
		private string _optno;
        public string OptNO
        {
            get{ return _optno; }
            set{ _optno = value; }
        }        
		/// <summary>
		/// 操作员
        /// </summary>		
		private string _username;
        public string UserName
        {
            get{ return _username; }
            set{ _username = value; }
        }        
		/// <summary>
		/// 操作菜单
        /// </summary>		
		private string _optmenu;
        public string OptMenu
        {
            get{ return _optmenu; }
            set{ _optmenu = value; }
        }        
		/// <summary>
		/// 操作内容
        /// </summary>		
		private string _optcontent;
        public string OptContent
        {
            get{ return _optcontent; }
            set{ _optcontent = value; }
        }        
		/// <summary>
		/// 操作时间
        /// </summary>		
		private DateTime? _opttime;
        public DateTime? OptTime
        {
            get{ return _opttime; }
            set{ _opttime = value; }
        }        
		/// <summary>
		/// 电脑名
        /// </summary>		
		private string _pcname;
        public string PCName
        {
            get{ return _pcname; }
            set{ _pcname = value; }
        }
        public int CarparkNO { get; set; }      
		   
	}
}

