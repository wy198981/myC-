﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tQueryScheme
		public class QueryScheme
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// QueryTable
        /// </summary>		
		private string _querytable;
        public string QueryTable
        {
            get{ return _querytable; }
            set{ _querytable = value; }
        }        
		/// <summary>
		/// SchId
        /// </summary>		
		private int _schid;
        public int SchId
        {
            get{ return _schid; }
            set{ _schid = value; }
        }        
		/// <summary>
		/// SchName
        /// </summary>		
		private string _schname;
        public string SchName
        {
            get{ return _schname; }
            set{ _schname = value; }
        }        
		/// <summary>
		/// FieldName
        /// </summary>		
		private string _fieldname;
        public string FieldName
        {
            get{ return _fieldname; }
            set{ _fieldname = value; }
        }        
		/// <summary>
		/// Operators
        /// </summary>		
		private string _operators;
        public string Operators
        {
            get{ return _operators; }
            set{ _operators = value; }
        }        
		/// <summary>
		/// Selectvalues
        /// </summary>		
		private string _selectvalues;
        public string Selectvalues
        {
            get{ return _selectvalues; }
            set{ _selectvalues = value; }
        }        
		/// <summary>
		/// startime
        /// </summary>		
		private string _startime;
        public string startime
        {
            get{ return _startime; }
            set{ _startime = value; }
        }        
		/// <summary>
		/// endtime
        /// </summary>		
		private string _endtime;
        public string endtime
        {
            get{ return _endtime; }
            set{ _endtime = value; }
        }        
		   
	}
}

