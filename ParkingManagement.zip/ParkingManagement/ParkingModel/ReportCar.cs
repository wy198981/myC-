﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class ReportCar
    {
        public int MthCount { get; set; }
        public int MtpCount { get; set; }
        public int TmpCount { get; set; }
        public int TfcCount { get; set; }
        public int StrCount { get; set; }
        public int FreCount { get; set; }
        public int OptCount { get; set; }
        public int PerCount { get; set; }
        public int TotalCount { get; set; }
        public Decimal TotalSFJE { get;set;}
        public Decimal TotalYSJE { get; set; }
        public Decimal TotalDiscount { get; set; }
        public Decimal TotalCash { get; set; }
        public Decimal TotalOTSFJE { get; set; }
        public Decimal TotalAliPay { get; set; }
        public Decimal TotalWeChat { get; set; }
        public Decimal ATypeTotalSFJE { get; set; }
        public Decimal BTypeTotalSFJE { get; set; }
        public Decimal CTypeTotalSFJE { get; set; }
        public Decimal DTypeTotalSFJE { get; set; }
        public Decimal ETypeTotalSFJE { get; set; }
        public Decimal FTypeTotalSFJE { get; set; }
        public Decimal GTypeTotalSFJE { get; set; }
        public Decimal HTypeTotalSFJE { get; set; }

    }
}
