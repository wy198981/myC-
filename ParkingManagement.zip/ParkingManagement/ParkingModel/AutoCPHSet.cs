﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
    //tAutoCPHSet
    public class AutoCPHSet
    {
        /// <summary>
        /// ID
        /// </summary>		
        private long _id;
        public long ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// AutoPlateEn
        /// </summary>		
        private bool _autoplateen;
        public bool AutoPlateEn
        {
            get { return _autoplateen; }
            set { _autoplateen = value; }
        }
        /// <summary>
        /// AutoPlateDBJD
        /// </summary>		
        private int _autoplatedbjd;
        public int AutoPlateDBJD
        {
            get { return _autoplatedbjd; }
            set { _autoplatedbjd = value; }
        }
        /// <summary>
        /// InAutoOpenModel
        /// </summary>		
        private int _inautoopenmodel;
        public int InAutoOpenModel
        {
            get { return _inautoopenmodel; }
            set { _inautoopenmodel = value; }
        }
        /// <summary>
        /// OutAutoOpenModel
        /// </summary>		
        private int _outautoopenmodel;
        public int OutAutoOpenModel
        {
            get { return _outautoopenmodel; }
            set { _outautoopenmodel = value; }
        }
        /// <summary>
        /// CphDelay
        /// </summary>		
        private string _cphdelay;
        public string CphDelay
        {
            get { return _cphdelay; }
            set { _cphdelay = value; }
        }
        /// <summary>
        /// SameCphDelay
        /// </summary>		
        private string _samecphdelay;
        public string SameCphDelay
        {
            get { return _samecphdelay; }
            set { _samecphdelay = value; }
        }
        /// <summary>
        /// AutoSetMinutes
        /// </summary>		
        private int? _autosetminutes;
        public int? AutoSetMinutes
        {
            get { return _autosetminutes; }
            set { _autosetminutes = value; }
        }
        /// <summary>
        /// AutoMinutes
        /// </summary>		
        private bool? _autominutes;
        public bool? AutoMinutes
        {
            get { return _autominutes; }
            set { _autominutes = value; }
        }
        /// <summary>
        /// AutoColorSet
        /// </summary>		
        private int? _autocolorset;
        public int? AutoColorSet
        {
            get { return _autocolorset; }
            set { _autocolorset = value; }
        }
        /// <summary>
        /// AutoDeleteImg
        /// </summary>		
        private int? _autodeleteimg;
        public int? AutoDeleteImg
        {
            get { return _autodeleteimg; }
            set { _autodeleteimg = value; }
        }
        /// <summary>
        /// AutoPattern
        /// </summary>		
        private int? _autopattern;
        public int? AutoPattern
        {
            get { return _autopattern; }
            set { _autopattern = value; }
        }
        /// <summary>
        /// AutoKZ
        /// </summary>		
        private bool? _autokz;
        public bool? AutoKZ
        {
            get { return _autokz; }
            set { _autokz = value; }
        }
        /// <summary>
        /// AutoYTime
        /// </summary>		
        private int? _autoytime;
        public int? AutoYTime
        {
            get { return _autoytime; }
            set { _autoytime = value; }
        }
        /// <summary>
        /// ReadCardTime
        /// </summary>		
        private int? _readcardtime;
        public int? ReadCardTime
        {
            get { return _readcardtime; }
            set { _readcardtime = value; }
        }
        /// <summary>
        /// MaxPlateWidth
        /// </summary>		
        private int? _maxplatewidth;
        public int? MaxPlateWidth
        {
            get { return _maxplatewidth; }
            set { _maxplatewidth = value; }
        }
        /// <summary>
        /// MinPlateWidth
        /// </summary>		
        private int? _minplatewidth;
        public int? MinPlateWidth
        {
            get { return _minplatewidth; }
            set { _minplatewidth = value; }
        }
        /// <summary>
        /// OnlyLocation
        /// </summary>		
        private bool? _onlylocation;
        public bool? OnlyLocation
        {
            get { return _onlylocation; }
            set { _onlylocation = value; }
        }
        /// <summary>
        /// Darmpolice
        /// </summary>		
        private bool? _darmpolice;
        public bool? Darmpolice
        {
            get { return _darmpolice; }
            set { _darmpolice = value; }
        }
        /// <summary>
        /// Embassy
        /// </summary>		
        private bool? _embassy;
        public bool? Embassy
        {
            get { return _embassy; }
            set { _embassy = value; }
        }
        /// <summary>
        /// OnlyDyellow
        /// </summary>		
        private bool? _onlydyellow;
        public bool? OnlyDyellow
        {
            get { return _onlydyellow; }
            set { _onlydyellow = value; }
        }
        /// <summary>
        /// Tractor
        /// </summary>		
        private bool? _tractor;
        public bool? Tractor
        {
            get { return _tractor; }
            set { _tractor = value; }
        }
        /// <summary>
        /// Army2
        /// </summary>		
        private bool? _army2;
        public bool? Army2
        {
            get { return _army2; }
            set { _army2 = value; }
        }
        /// <summary>
        /// ArmPol
        /// </summary>		
        private bool? _armpol;
        public bool? ArmPol
        {
            get { return _armpol; }
            set { _armpol = value; }
        }
        /// <summary>
        /// Indivi
        /// </summary>		
        private bool? _indivi;
        public bool? Indivi
        {
            get { return _indivi; }
            set { _indivi = value; }
        }
        /// <summary>
        /// Yellow2
        /// </summary>		
        private bool? _yellow2;
        public bool? Yellow2
        {
            get { return _yellow2; }
            set { _yellow2 = value; }
        }
        /// <summary>
        /// PCName
        /// </summary>		
        //private string _pcname;
        //public string PCName
        //{
        //    get{ return _pcname; }
        //    set{ _pcname = value; }
        //}

        private int _stationID;
        public int StationID
        {
            get { return _stationID; }
            set { _stationID = value; }
        }

        /// <summary>
        /// LocalProvince
        /// </summary>		
        private string _localprovince;
        public string LocalProvince
        {
            get { return _localprovince; }
            set { _localprovince = value; }
        }
        /// <summary>
        /// YImageSave
        /// </summary>		
        private string _yimagesave;
        public string YImageSave
        {
            get { return _yimagesave; }
            set { _yimagesave = value; }
        }
        /// <summary>
        /// Night
        /// </summary>		
        private bool? _night;
        public bool? Night
        {
            get { return _night; }
            set { _night = value; }
        }
        /// <summary>
        /// InMothOpenModel
        /// </summary>		
        private int? _inmothopenmodel;
        public int? InMothOpenModel
        {
            get { return _inmothopenmodel; }
            set { _inmothopenmodel = value; }
        }
        /// <summary>
        /// OutMothOpenModel
        /// </summary>		
        private int? _outmothopenmodel;
        public int? OutMothOpenModel
        {
            get { return _outmothopenmodel; }
            set { _outmothopenmodel = value; }
        }
        /// <summary>
        /// InOutConfirm
        /// </summary>		
        private bool? _inoutconfirm;
        public bool? InOutConfirm
        {
            get { return _inoutconfirm; }
            set { _inoutconfirm = value; }
        }
        /// <summary>
        /// OutConfirm
        /// </summary>		
        private bool? _outconfirm;
        public bool? OutConfirm
        {
            get { return _outconfirm; }
            set { _outconfirm = value; }
        }

        public int CarparkNO { get; set; }
    }
}

