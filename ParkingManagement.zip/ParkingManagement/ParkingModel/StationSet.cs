﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class StationSet
    {
        public long ID { get; set; }
        public short StationId { get; set; }
        public string StationName { get; set; }
        public int CarparkNO { get; set; }
    }
}