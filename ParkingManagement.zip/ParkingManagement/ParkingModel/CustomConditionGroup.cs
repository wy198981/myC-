﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class CustomConditionGroup : CustomConditionGroupBase
    {
        public CustomConditionGroup()
        {
            _Version = 1;
        }

        protected List<CustomCondition> lstCon = new List<CustomCondition>();

        public List<CustomCondition> Conditions { get { return lstCon; } }

        public CustomCondition.ConditionCombinator Combinator { get; set; }

        public void AddCondition(ParkingModel.CustomCondition.CustomConditionType type, string field, ParkingModel.CustomCondition.ConditionComparator comparator, string value, ParkingModel.CustomCondition.ConditionCombinator combinator)
        {
            lstCon.Add(new CustomCondition(type, field, comparator, value, combinator));
        }
    }
}
