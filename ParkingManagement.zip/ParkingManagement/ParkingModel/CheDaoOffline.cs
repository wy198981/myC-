﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class CheDaoOffline
    {
        public long ID { get; set; }
        public int StationID { get; set; }
        public int CtrlNumber { get; set; }
        public string IP { get; set; }
        public bool SendSignal { get; set; }
        public bool RecieveSignal { get; set; }
        public int InOut { get; set; }
        public int InOutName { get; set; }
        public int BigSmall { get; set; }
        public string StationName { get; set; }
        public int CarparkNO { get; set; }
    }
}
