﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tMoney
		public class Money
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 卡号
        /// </summary>		
		private string _cardno;
        public string CardNO
        {
            get{ return _cardno; }
            set{ _cardno = value; }
        }        
		/// <summary>
		/// 人员编号
        /// </summary>		
		private string _userno;
        public string UserNO
        {
            get{ return _userno; }
            set{ _userno = value; }
        }        
		/// <summary>
		/// 车牌号
        /// </summary>		
		private string _cph;
        public string CPH
        {
            get{ return _cph; }
            set{ _cph = value; }
        }        
		/// <summary>
		/// 操作时间
        /// </summary>		
		private DateTime _optdate;
        public DateTime OptDate
        {
            get{ return _optdate; }
            set{ _optdate = value; }
        }        
		/// <summary>
		/// 收费金额
        /// </summary>		
		private decimal _sfje;
        public decimal SFJE
        {
            get{ return _sfje; }
            set{ _sfje = value; }
        }        
		/// <summary>
		/// 余额
        /// </summary>		
		private decimal _balance;
        public decimal Balance
        {
            get{ return _balance; }
            set{ _balance = value; }
        }        
		/// <summary>
		/// 操作员编号
        /// </summary>		
		private string _operatorno;
        public string OperatorNO
        {
            get{ return _operatorno; }
            set{ _operatorno = value; }
        }        
		/// <summary>
		/// 操作类型
        /// </summary>		
		private string _opttype;
        public string OptType
        {
            get{ return _opttype; }
            set{ _opttype = value; }
        }        
		/// <summary>
		/// 新开始日期
        /// </summary>		
		private DateTime _newstartdate;
        public DateTime NewStartDate
        {
            get{ return _newstartdate; }
            set{ _newstartdate = value; }
        }        
		/// <summary>
		/// 新结束日期
        /// </summary>		
		private DateTime _newenddate;
        public DateTime NewEndDate
        {
            get{ return _newenddate; }
            set{ _newenddate = value; }
        }        
		/// <summary>
		/// 上次结束日期
        /// </summary>		
		private DateTime _lastenddate;
        public DateTime LastEndDate
        {
            get{ return _lastenddate; }
            set{ _lastenddate = value; }
        }        
		
        #region 发行
        public string CarCardType { get; set; }
        public string CardState { get; set; }
        public double CardYJ { get; set; }
        public string SubSystem { get; set; }
        public DateTime CarIssueDate { get; set; }
        public string CarIssueUserCard { get; set; }
        //public double Balance { get; set; }
        public DateTime CarValidStartDate { get; set; }
        public DateTime CarValidEndDate { get; set; }
        //public string CPH { get; set; }
        public string CarColor { get; set; }
        public string CarType { get; set; }
        public string CarPlace { get; set; }
        public DateTime CarWithdrawCardDate { get; set; }
        public string CarWithdrawOptCard { get; set; }
        public string CarValidMachine { get; set; }
        public string CarValidZone { get; set; }
        public string CarMemo { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime WithdrawDate { get; set; }
        public string IssueUserCard { get; set; }
        public string WithdrawUserCard { get; set; }
        public DateTime LossregDate { get; set; }
        public string LossregUserCard { get; set; }
        public string CardIDNO { get; set; }
        public int Tempnumber { get; set; }
        public string TimeTeam { get; set; }
        public string HolidayLimited { get; set; }
        public string UserInfo { get; set; }
        public string BackCardNum { get; set; }
        public string CardIdLossState { get; set; }
        public string CardIdUnLossState { get; set; }
        public DateTime UnLossDate { get; set; }
        public string UnLossUer { get; set; }
        public string CarFailID { get; set; }
        public string CaRFailOKNO { get; set; }
        public string CardLossMachine { get; set; }
        public string DownLoadState { get; set; }
        public string DownloadSignal { get; set; }
        public string CPHDownloadSignal { get; set; }
        public string Res1 { get; set; }
        public string Res2 { get; set; }
        public int MonthType { get; set; }
        #endregion

        #region  人员
        public string UserName { get; set; }
        public string Sex { get; set; }
        public string HomeAddress { get; set; }
        public string DeptName { get; set; }
        public string Job { get; set; }
        public DateTime WorkTime { get; set; }
        public DateTime BirthDate { get; set; }
        public string IDCard { get; set; }
        public string MaritalStatus { get; set; }
        public string HighestDegree { get; set; }
        public string PoliticalStatus { get; set; }
        public string School { get; set; }
        public string Speciality { get; set; }
        public string ForeignLanguage { get; set; }
        public string Skill { get; set; }
        public string TelNumber { get; set; }
        public string MobNumber { get; set; }
        public string ZipCode { get; set; }
        public string NativePlace { get; set; }
        public int CarPlaceNo { get; set; }
        #endregion
    }
}

