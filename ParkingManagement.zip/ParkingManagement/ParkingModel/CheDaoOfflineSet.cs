﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class CheDaoOfflineSet
    {
        /// <summary>
        /// 白牌车和0牌车自动开闸
        /// </summary>
        public bool IsAutoOpenGateWithWhiteOrZeroPlate { get; set; }
        /// <summary>
        /// 入口临时车脱机自动开闸
        /// </summary>
        public bool IsAutoOPenGeteWithTmpCarAtInGate { get; set; }
        /// <summary>
        /// 临时车显示播报汉字
        /// </summary>
        public bool IsTmpCarReadChinese { get; set; }
        /// <summary>
        /// 月卡车在线不开闸
        /// </summary>
        public bool IsOnlineMthCarDonotOpenGate { get; set; }
        /// <summary>
        /// 取消计费型相机脱机计费功能
        /// </summary>
        public bool IsOfflineCameraCannotInCharge { get; set; }
    }
}
