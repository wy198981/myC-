﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParkingModel
{
    public class SpecialDayVoice
    {
        /// <summary>
        /// ID
        /// </summary>		
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        private DateTime _specialDay;
        public DateTime SpecialDay
        {
            get { return _specialDay; }
            set { _specialDay = value; }
        }

        private string _voice;
        public string Voice
        {
            get { return _voice; }
            set { _voice = value; }
        }
    }
}
