﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tRights
    public class Rights
    {

        /// <summary>
        /// 自增主键
        /// </summary>		
        private long _id;
        public long ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 权限组编号
        /// </summary>		
        private long _groupid;
        public long GroupID
        {
            get { return _groupid; }
            set { _groupid = value; }
        }
        /// <summary>
        /// 权限项目ID
        /// </summary>		
        private long _rightsitemid;
        public long RightsItemID
        {
            get { return _rightsitemid; }
            set { _rightsitemid = value; }
        }
        /// <summary>
        /// CanView
        /// </summary>		
        private bool _canview;
        public bool CanView
        {
            get { return _canview; }
            set { _canview = value; }
        }
        /// <summary>
        /// CanOperate
        /// </summary>		
        private bool _canoperate;
        public bool CanOperate
        {
            get { return _canoperate; }
            set { _canoperate = value; }
        }

        public long PID { get; set; }

        public string Category { get; set; }
        public string FormName { get; set; }
        public string ItemName { get; set; }
        public string GroupName { get; set; }
        public string Description { get; set; }
        public string Orders { get; set; }
    }
}

