﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tUserInfoFieldSet
		public class UserInfoFieldSet
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// EN_Name
        /// </summary>		
		private string _en_name;
        public string EN_Name
        {
            get{ return _en_name; }
            set{ _en_name = value; }
        }        
		/// <summary>
		/// CH_Name
        /// </summary>		
		private string _ch_name;
        public string CH_Name
        {
            get{ return _ch_name; }
            set{ _ch_name = value; }
        }        
		/// <summary>
		/// Type
        /// </summary>		
		private string _type;
        public string Type
        {
            get{ return _type; }
            set{ _type = value; }
        }        
		   
	}
}

