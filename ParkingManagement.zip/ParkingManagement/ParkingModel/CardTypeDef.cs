﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tCardTypeDef
    public class CardTypeDef
    {

        /// <summary>
        /// ID
        /// </summary>		
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 中文卡类
        /// </summary>		
        private string _cardtype;
        public string CardType
        {
            get { return _cardtype; }
            set { _cardtype = value; }
        }
        /// <summary>
        /// 实际卡类
        /// </summary>		
        private string _identifying;
        public string Identifying
        {
            get { return _identifying; }
            set { _identifying = value; }
        }
        /// <summary>
        /// 是否启用
        /// </summary>		
        private bool _enabled;
        public bool Enabled
        {
            get { return _enabled; }
            set { _enabled = value; }
        }
        /// <summary>
        /// 英文卡类
        /// </summary>		
        private string _reamrks;
        public string Reamrks
        {
            get { return _reamrks; }
            set { _reamrks = value; }
        }

        //private int _freeMinute;
        //public int FreeMinute
        //{
        //    get { return _freeMinute; }
        //    set { _freeMinute = value; }
        //}

        //private int _topSF;
        //public int TopSF
        //{
        //    get { return _topSF; }
        //    set { _topSF = value; }
        //}


    }
}

