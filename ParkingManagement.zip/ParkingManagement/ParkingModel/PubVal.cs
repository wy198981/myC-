﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class PubVal
    {
        /// <summary>
        /// 登录时服务器分配的Token
        /// </summary>
        public static string Token { get; set; }
        /// <summary>
        /// 登录的工作站
        /// </summary>
        public static int StationId { get; set; }
        /// <summary>
        /// 登录的车场
        /// </summary>
        public static int ParkId { get; set; }
        /// <summary>
        /// 设备通讯的协议号
        /// </summary>
        public static int DeviceProtocol { get; set; }
    }
}