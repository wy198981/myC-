﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    //用于保存界面控件的值
    public class MonitorModel
    {
        /// <summary>
        /// lblPersonNo (用户编号)
        /// </summary>
        public string PersonNo { get; set; }

        /// <summary>
        /// lblPersonName (用户名)
        /// </summary>
        public string PersonName { get; set; }

        /// <summary>
        /// lblDeptName (部门名称)
        /// </summary>
        public string DeptName { get; set; }

        /// <summary>
        /// lblCardNo (卡片号码)
        /// </summary>
        public string CardNo { get; set; }

        /// <summary>
        /// lblCardType (卡片类型)
        /// </summary>
        public string CardType { get; set; }

        /// <summary> (入场时间)
        /// lblInTime
        /// </summary>
        public DateTime InTime { get; set; }

        /// <summary>
        /// lblOutTime (出场时间)
        /// </summary>
        public DateTime OutTime { get; set; }

        /// <summary>
        /// lblCharge  (消费金额)
        /// </summary>
        public decimal Charge { get; set; }

        /// <summary>
        /// 应收金额
        /// </summary>
        public decimal AmountReceivable { get; set; }

        /// <summary>
        /// lblBalance  (剩余金额)
        /// </summary>
        public decimal Balance { get; set; }

        /// <summary>
        /// txbOperatorInfo  (操作提示信息)
        /// </summary>
        public string OperatorInfo { get; set; }

        /// <summary>
        /// txbCharge 
        /// </summary>
        public string TCharge { get; set; }

       
        /// <summary>
        /// lblCarNo  (车牌号码)
        /// </summary>
        public string CarNo { get; set; }

       
    }

    public enum OpenWay { AutoCutOff = 0, ConfirmCutOff, NoCutOff }
    public enum PlateColor { Blue = 0, Yellow, White, Black, Unknown }


    /// <summary>
    ///进场记录
    /// </summary>
    public class ApproachRecord
    {
        public OpenWay OpenMode { get; set; }
        //public OpenWay OpenMode { get; set; }
        public string CardNO { get; set; }
        public string CardType { get; set; }
        public string ImageName { get; set; }
        public string ImagePath { get; set; }
        public string CPH { get; set; }
        public DateTime InTime { get; set; }
        public string UserNO { get; set; }
        public string UserName { get; set; }
        public string DeptName { get; set; }
        public decimal Balance { get; set; }
        public DateTime CarValidEndDate { get; set; }
        public string CarPlace { get; set; }
        public int RemainingDays { get; set; }
        public int RemainingPlaceCount { get; set; }
        public int CtrlNumber { get; set; }
        public string InOutName { get; set; }
        public string BlackReason { get; set; }
    }

    /// <summary>
    /// 出场记录
    /// </summary>
    public class AppearanceRecord
    {
        public OpenWay OpenMode { get; set; }
        public string CardNO { get; set; }
        public string CardType { get; set; }
        public string ImageName { get; set; }
        public string ImagePath { get; set; }
        public string CPH { get; set; }
        public DateTime? InTime { get; set; }
        public DateTime OutTime { get; set; }
        public decimal SFJE { get; set; }
        public decimal YSJE { get; set; }
        public string UserNO { get; set; }
        public string UserName { get; set; }
        public string DeptName { get; set; }
        public decimal Balance { get; set; }
        public DateTime CarValidEndDate { get; set; }
        public string CarPlace { get; set; }
        public int RemainingDays { get; set; }
        public Object DiscountSet { get; set; }
        public int RemainingPlaceCount { get; set; }
        public int CtrlNumber { get; set; }
        public string InOutName { get; set; }
        public string BlackReason { get; set; }
        public string StayTime { get; set; }
        public ApproachRecord[] SimilarCPHInPark { get; set; }
        public string[] SimilarCPHIssued { get; set; }
    }

    public struct ImageInfo
    {
        public bool isEntrance;
        public string networkPath;
        public string localPath;
        public System.Windows.Forms.PictureBox picShow;
    }

    public class Summary
    {
        /// <summary>
        /// txbSurplusCarCount (剩余车位)
        /// </summary>
        public int SurplusCarCount { get; set; }

        /// <summary>
        /// lblMthCount  (记录场内固定车总数)
        /// </summary>
        public int MthCount { get; set; }

        /// <summary>
        /// lblTmpCount (记录场内临时车总数)
        /// </summary>
        public int TmpCount { get; set; }

        /// <summary>
        ///lblFreCount (记录场内免费车总数)
        /// </summary>
        public int FreCount { get; set; }

        /// <summary>
        /// lblStrCount（记录场内储值车总数）
        /// </summary>
        public int StrCount { get; set; }

        /// <summary>
        /// lblOutCount (记录场内派出车数)
        /// </summary>
        public int OutCount { get; set; }

        /// <summary>
        /// lblOpenCount  (手动开闸数)
        /// </summary>
        public int OpenCount { get; set; }

        /// <summary>
        /// lblFreMoney  (免费金额)
        /// </summary>
        public decimal FreMoney { get; set; }

        /// <summary>
        /// lblMoneyCount  (总收费金额)
        /// </summary>
        public decimal MoneyCount { get; set; }
    }
}
