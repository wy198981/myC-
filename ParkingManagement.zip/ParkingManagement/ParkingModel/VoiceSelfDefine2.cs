﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tVoiceSelfDefine2
		public class VoiceSelfDefine2
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// CtrlNumber
        /// </summary>		
		private int _ctrlnumber;
        public int CtrlNumber
        {
            get{ return _ctrlnumber; }
            set{ _ctrlnumber = value; }
        }        
		/// <summary>
		/// Voice
        /// </summary>		
		private string _voice;
        public string Voice
        {
            get{ return _voice; }
            set{ _voice = value; }
        }        
		   
	}
}

