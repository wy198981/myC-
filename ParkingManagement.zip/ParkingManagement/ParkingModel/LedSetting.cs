﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tLedSetting
		public class LedSetting
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 工作站编号
        /// </summary>		
		private int _stationid;
        public int StationID
        {
            get{ return _stationid; }
            set{ _stationid = value; }
        }        
		/// <summary>
		/// 主板机号
        /// </summary>		
		private int _ctrid;
        public int CtrID
        {
            get{ return _ctrid; }
            set{ _ctrid = value; }
        }        
		/// <summary>
		/// LED屏机号
        /// </summary>		
		private string _surplusid;
        public string SurplusID
        {
            get{ return _surplusid; }
            set{ _surplusid = value; }
        }        
		/// <summary>
		/// 移动速度
        /// </summary>		
		private string _speed;
        public string Speed
        {
            get{ return _speed; }
            set{ _speed = value; }
        }        
		/// <summary>
		/// 停止时间
        /// </summary>		
		private string _stoptime;
        public string StopTime
        {
            get{ return _stoptime; }
            set{ _stoptime = value; }
        }        
		/// <summary>
		/// 颜色
        /// </summary>		
		private string _color;
        public string Color
        {
            get{ return _color; }
            set{ _color = value; }
        }        
		/// <summary>
		/// 显示时间
        /// </summary>		
		private string _sumtime;
        public string SumTime
        {
            get{ return _sumtime; }
            set{ _sumtime = value; }
        }        
		/// <summary>
		/// 车牌后缀
        /// </summary>		
		private string _cphendstr;
        public string CPHEndStr
        {
            get{ return _cphendstr; }
            set{ _cphendstr = value; }
        }        
		/// <summary>
		/// 显示方式
        /// </summary>		
		private string _showway;
        public string ShowWay
        {
            get{ return _showway; }
            set{ _showway = value; }
        }        
		/// <summary>
		/// 移动方式
        /// </summary>		
		private string _move;
        public string Move
        {
            get{ return _move; }
            set{ _move = value; }
        }        
		/// <summary>
		/// 模式（字数）
        /// </summary>		
		private string _pattern;
        public string Pattern
        {
            get{ return _pattern; }
            set{ _pattern = value; }
        }        
		   
	}
}

