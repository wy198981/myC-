﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tRawRecord
    public class RawRecord
    {

        /// <summary>
        /// ID
        /// </summary>		
        private long _id;
        public long ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// CardNO
        /// </summary>		
        private string _cardno;
        public string CardNO
        {
            get { return _cardno; }
            set { _cardno = value; }
        }
        /// <summary>
        /// CPH
        /// </summary>		
        private string _cph;
        public string CPH
        {
            get { return _cph; }
            set { _cph = value; }
        }
        /// <summary>
        /// CardType
        /// </summary>		
        private string _cardtype;
        public string CardType
        {
            get { return _cardtype; }
            set { _cardtype = value; }
        }
        /// <summary>
        /// InTime
        /// </summary>		
        private DateTime _intime;
        public DateTime InTime
        {
            get { return _intime; }
            set { _intime = value; }
        }
        /// <summary>
        /// OutTime
        /// </summary>		
        private DateTime _outtime;
        public DateTime OutTime
        {
            get { return _outtime; }
            set { _outtime = value; }
        }
        /// <summary>
        /// InGateName
        /// </summary>		
        private string _ingatename;
        public string InGateName
        {
            get { return _ingatename; }
            set { _ingatename = value; }
        }
        /// <summary>
        /// OutGateName
        /// </summary>		
        private string _outgatename;
        public string OutGateName
        {
            get { return _outgatename; }
            set { _outgatename = value; }
        }
        /// <summary>
        /// InOperatorCard
        /// </summary>		
        private string _inoperatorcard;
        public string InOperatorCard
        {
            get { return _inoperatorcard; }
            set { _inoperatorcard = value; }
        }
        /// <summary>
        /// OutOperatorCard
        /// </summary>		
        private string _outoperatorcard;
        public string OutOperatorCard
        {
            get { return _outoperatorcard; }
            set { _outoperatorcard = value; }
        }
        /// <summary>
        /// InOperator
        /// </summary>		
        private string _inoperator;
        public string InOperator
        {
            get { return _inoperator; }
            set { _inoperator = value; }
        }
        /// <summary>
        /// OutOperator
        /// </summary>		
        private string _outoperator;
        public string OutOperator
        {
            get { return _outoperator; }
            set { _outoperator = value; }
        }
        /// <summary>
        /// InPic
        /// </summary>		
        private string _inpic;
        public string InPic
        {
            get { return _inpic; }
            set { _inpic = value; }
        }
        /// <summary>
        /// InUser
        /// </summary>		
        private string _inuser;
        public string InUser
        {
            get { return _inuser; }
            set { _inuser = value; }
        }
        /// <summary>
        /// OutPic
        /// </summary>		
        private string _outpic;
        public string OutPic
        {
            get { return _outpic; }
            set { _outpic = value; }
        }
        /// <summary>
        /// OutUser
        /// </summary>		
        private string _outuser;
        public string OutUser
        {
            get { return _outuser; }
            set { _outuser = value; }
        }
        /// <summary>
        /// ZJPic
        /// </summary>		
        private string _zjpic;
        public string ZJPic
        {
            get { return _zjpic; }
            set { _zjpic = value; }
        }
        /// <summary>
        /// SFJE
        /// </summary>		
        private decimal? _sfje;
        public decimal? SFJE
        {
            get { return _sfje; }
            set { _sfje = value; }
        }
        /// <summary>
        /// Balance
        /// </summary>		
        private decimal? _balance;
        public decimal? Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }
        /// <summary>
        /// YSJE
        /// </summary>		
        private decimal? _ysje;
        public decimal? YSJE
        {
            get { return _ysje; }
            set { _ysje = value; }
        }
        /// <summary>
        /// SFTime
        /// </summary>		
        private DateTime? _sftime;
        public DateTime? SFTime
        {
            get { return _sftime; }
            set { _sftime = value; }
        }
        /// <summary>
        /// SFOperator
        /// </summary>		
        private string _sfoperator;
        public string SFOperator
        {
            get { return _sfoperator; }
            set { _sfoperator = value; }
        }
        /// <summary>
        /// SFOperatorCard
        /// </summary>		
        private string _sfoperatorcard;
        public string SFOperatorCard
        {
            get { return _sfoperatorcard; }
            set { _sfoperatorcard = value; }
        }
        /// <summary>
        /// SFGate
        /// </summary>		
        private string _sfgate;
        public string SFGate
        {
            get { return _sfgate; }
            set { _sfgate = value; }
        }
        /// <summary>
        /// OvertimeSymbol
        /// </summary>		
        private string _overtimesymbol;
        public string OvertimeSymbol
        {
            get { return _overtimesymbol; }
            set { _overtimesymbol = value; }
        }
        /// <summary>
        /// OvertimeSFTime
        /// </summary>		
        private DateTime? _overtimesftime;
        public DateTime? OvertimeSFTime
        {
            get { return _overtimesftime; }
            set { _overtimesftime = value; }
        }
        /// <summary>
        /// OvertimeSFJE
        /// </summary>		
        private decimal? _overtimesfje;
        public decimal? OvertimeSFJE
        {
            get { return _overtimesfje; }
            set { _overtimesfje = value; }
        }
        /// <summary>
        /// CarparkNO
        /// </summary>		
        private int? _carparkno;
        public int? CarparkNO
        {
            get { return _carparkno; }
            set { _carparkno = value; }
        }
        /// <summary>
        /// BigSmall
        /// </summary>		
        private int? _bigsmall;
        public int? BigSmall
        {
            get { return _bigsmall; }
            set { _bigsmall = value; }
        }
        /// <summary>
        /// FreeReason
        /// </summary>		
        private string _freereason;
        public string FreeReason
        {
            get { return _freereason; }
            set { _freereason = value; }
        }
        /// <summary>
        /// StayTime
        /// </summary>		
        private string _staytime;
        public string StayTime
        {
            get { return _staytime; }
            set { _staytime = value; }
        }
        /// <summary>
        /// StationID
        /// </summary>		
        private int _stationid;
        public int StationID
        {
            get { return _stationid; }
            set { _stationid = value; }
        }
        /// <summary>
        /// YHAddress
        /// </summary>		
        private string _yhaddress;
        public string YHAddress
        {
            get { return _yhaddress; }
            set { _yhaddress = value; }
        }
        /// <summary>
        /// YHType
        /// </summary>		
        private string _yhtype;
        public string YHType
        {
            get { return _yhtype; }
            set { _yhtype = value; }
        }
        /// <summary>
        /// YHJE
        /// </summary>		
        private decimal _yhje;
        public decimal YHJE
        {
            get { return _yhje; }
            set { _yhje = value; }
        }
        /// <summary>
        /// Temp1
        /// </summary>		
        private string _temp1;
        public string Temp1
        {
            get { return _temp1; }
            set { _temp1 = value; }
        }
        /// <summary>
        /// Temp2
        /// </summary>		
        private string _temp2;
        public string Temp2
        {
            get { return _temp2; }
            set { _temp2 = value; }
        }
        /// <summary>
        /// Temp3
        /// </summary>		
        private string _temp3;
        public string Temp3
        {
            get { return _temp3; }
            set { _temp3 = value; }
        }
        /// <summary>
        /// Temp4
        /// </summary>		
        private string _temp4;
        public string Temp4
        {
            get { return _temp4; }
            set { _temp4 = value; }
        }
        /// <summary>
        /// Temp5
        /// </summary>		
        private string _temp5;
        public string Temp5
        {
            get { return _temp5; }
            set { _temp5 = value; }
        }
        /// <summary>
        /// 入场记录在线状态。0或空为在线记录，1为在线获取到的离线记录，2为通过U盘获取到的离线记录
        /// </summary>
        public byte OnlineState_In { get; set; }
        /// <summary>
        /// 出场记录在线状态。0或空为在线记录，1为在线获取到的离线记录，2为通过U盘获取到的离线记录
        /// </summary>
        public byte OnlineState_Out { get; set; }

    }
}

