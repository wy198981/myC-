﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tCarOut
    public class CarOut
    {
        public CarOut Copy()
        {
            return (CarOut)base.MemberwiseClone();
        }

        /// <summary>
        /// ID
        /// </summary>
        private long _id;
        public long ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 入场ID
        /// </summary>
        private long _inid;
        public long InID
        {
            get { return _inid; }
            set { _inid = value; }
        }
        /// <summary>
        /// 卡号
        /// </summary>
        private string _cardno;
        public string CardNO
        {
            get { return _cardno; }
            set { _cardno = value; }
        }
        /// <summary>
        /// 车牌
        /// </summary>
        private string _cph;
        public string CPH
        {
            get { return _cph; }
            set { _cph = value; }
        }
        /// <summary>
        /// 0为蓝色，1为黄色，2为白色，3为黑色，4为未识别
        /// </summary>
        private int _cpcolor;
        public int CPColor
        {
            get { return _cpcolor; }
            set { _cpcolor = value; }
        }
        /// <summary>
        /// 卡类
        /// </summary>
        private string _cardtype;
        public string CardType
        {
            get { return _cardtype; }
            set { _cardtype = value; }
        }
        /// <summary>
        /// 入场时间
        /// </summary>
        private DateTime _intime;
        public DateTime InTime
        {
            get { return _intime; }
            set { _intime = value; }
        }
        /// <summary>
        /// 出场时间
        /// </summary>
        private DateTime _outtime;
        public DateTime OutTime
        {
            get { return _outtime; }
            set { _outtime = value; }
        }
        /// <summary>
        /// 入场名称
        /// </summary>
        private string _ingatename;
        public string InGateName
        {
            get { return _ingatename; }
            set { _ingatename = value; }
        }
        /// <summary>
        /// 出场名称
        /// </summary>
        private string _outgatename;
        public string OutGateName
        {
            get { return _outgatename; }
            set { _outgatename = value; }
        }
        /// <summary>
        /// 入场操作员卡号
        /// </summary>
        private string _inoperatorcard;
        public string InOperatorCard
        {
            get { return _inoperatorcard; }
            set { _inoperatorcard = value; }
        }
        /// <summary>
        /// 出场操作员卡号
        /// </summary>
        private string _outoperatorcard;
        public string OutOperatorCard
        {
            get { return _outoperatorcard; }
            set { _outoperatorcard = value; }
        }
        /// <summary>
        /// 入场操作员
        /// </summary>
        private string _inoperator;
        public string InOperator
        {
            get { return _inoperator; }
            set { _inoperator = value; }
        }
        /// <summary>
        /// 出场操作员
        /// </summary>
        private string _outoperator;
        public string OutOperator
        {
            get { return _outoperator; }
            set { _outoperator = value; }
        }
        /// <summary>
        /// 入场车辆图片
        /// </summary>
        private string _inpic;
        public string InPic
        {
            get { return _inpic; }
            set { _inpic = value; }
        }
        /// <summary>
        /// 入场人相图片
        /// </summary>
        private string _inuser;
        public string InUser
        {
            get { return _inuser; }
            set { _inuser = value; }
        }
        /// <summary>
        /// 出场车辆图片
        /// </summary>
        private string _outpic;
        public string OutPic
        {
            get { return _outpic; }
            set { _outpic = value; }
        }
        /// <summary>
        /// 出场人相图片
        /// </summary>
        private string _outuser;
        public string OutUser
        {
            get { return _outuser; }
            set { _outuser = value; }
        }
        /// <summary>
        /// 证件图片
        /// </summary>
        private string _zjpic;
        public string ZJPic
        {
            get { return _zjpic; }
            set { _zjpic = value; }
        }
        /// <summary>
        /// 收费金额
        /// </summary>
        private decimal _sfje;
        public decimal SFJE
        {
            get { return _sfje; }
            set { _sfje = value; }
        }
        /// <summary>
        /// 余额
        /// </summary>
        private decimal _balance;
        public decimal Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }
        /// <summary>
        /// 应收金额
        /// </summary>
        private decimal _ysje;
        public decimal YSJE
        {
            get { return _ysje; }
            set { _ysje = value; }
        }
        /// <summary>
        /// 中央收费时间
        /// </summary>
        private DateTime _sftime;
        public DateTime SFTime
        {
            get { return _sftime; }
            set { _sftime = value; }
        }
        /// <summary>
        /// 中央收费操作员
        /// </summary>
        private string _sfoperator;
        public string SFOperator
        {
            get { return _sfoperator; }
            set { _sfoperator = value; }
        }
        /// <summary>
        /// 中央收费操作员卡号
        /// </summary>
        private string _sfoperatorcard;
        public string SFOperatorCard
        {
            get { return _sfoperatorcard; }
            set { _sfoperatorcard = value; }
        }
        /// <summary>
        /// 中央收费口名
        /// </summary>
        private string _sfgate;
        public string SFGate
        {
            get { return _sfgate; }
            set { _sfgate = value; }
        }
        /// <summary>
        /// 超时标志
        /// </summary>
        private string _overtimesymbol;
        public string OvertimeSymbol
        {
            get { return _overtimesymbol; }
            set { _overtimesymbol = value; }
        }
        /// <summary>
        /// 超时时间
        /// </summary>
        private DateTime _overtimesftime;
        public DateTime OvertimeSFTime
        {
            get { return _overtimesftime; }
            set { _overtimesftime = value; }
        }
        /// <summary>
        /// 超时金额
        /// </summary>
        private decimal _overtimesfje;
        public decimal OvertimeSFJE
        {
            get { return _overtimesfje; }
            set { _overtimesfje = value; }
        }
        /// <summary>
        /// 车场编号
        /// </summary>
        private int _carparkno;
        public int CarparkNO
        {
            get { return _carparkno; }
            set { _carparkno = value; }
        }
        /// <summary>
        /// 大小标志
        /// </summary>
        private int _bigsmall;
        public int BigSmall
        {
            get { return _bigsmall; }
            set { _bigsmall = value; }
        }
        /// <summary>
        /// 免费原因
        /// </summary>
        private string _freereason;
        public string FreeReason
        {
            get { return _freereason; }
            set { _freereason = value; }
        }
        /// <summary>
        /// 停车时间
        /// </summary>
        private string _staytime;
        public string StayTime
        {
            get { return _staytime; }
            set { _staytime = value; }
        }
        /// <summary>
        /// 工作站编号
        /// </summary>
        private int _stationid;
        public int StationID
        {
            get { return _stationid; }
            set { _stationid = value; }
        }
        /// <summary>
        /// 优惠场所
        /// </summary>
        private string _yhaddress;
        public string YHAddress
        {
            get { return _yhaddress; }
            set { _yhaddress = value; }
        }
        /// <summary>
        /// 优惠方式
        /// </summary>
        private string _yhtype;
        public string YHType
        {
            get { return _yhtype; }
            set { _yhtype = value; }
        }
        /// <summary>
        /// 优惠金额
        /// </summary>
        private decimal _yhje;
        public decimal YHJE
        {
            get { return _yhje; }
            set { _yhje = value; }
        }
        /// <summary>
        /// 备用
        /// </summary>
        private string _temp1;
        public string Temp1
        {
            get { return _temp1; }
            set { _temp1 = value; }
        }
        /// <summary>
        /// 备用
        /// </summary>
        private string _temp2;
        public string Temp2
        {
            get { return _temp2; }
            set { _temp2 = value; }
        }
        /// <summary>
        /// 备用
        /// </summary>
        private string _temp3;
        public string Temp3
        {
            get { return _temp3; }
            set { _temp3 = value; }
        }
        /// <summary>
        /// 备用
        /// </summary>
        private string _temp4;
        public string Temp4
        {
            get { return _temp4; }
            set { _temp4 = value; }
        }
        /// <summary>
        /// 备用
        /// </summary>
        private string _temp5;
        public string Temp5
        {
            get { return _temp5; }
            set { _temp5 = value; }
        }
        /// <summary>
        /// 支付方式。0 现金；1 微信；2 支付宝
        /// </summary>
        private int _paytype;
        public int PayType
        {
            get { return _paytype; }
            set { _paytype = value; }
        }

        private string _userNO;
        public string UserNO
        {
            get { return _userNO; }
            set { _userNO = value; }
        }

        private string _userName;
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        private string _deptName;
        public string DeptName
        {
            get { return _deptName; }
            set { _deptName = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string _chineseName;
        public string ChineseName
        {
            get { return _chineseName; }
            set { _chineseName = value; }
        }
        /// <summary>
        /// 入场记录在线状态。0或空为在线记录，1为在线获取到的离线记录，2为通过U盘获取到的离线记录
        /// </summary>
        public byte OnlineState_In { get; set; }
        /// <summary>
        /// 出场记录在线状态。0或空为在线记录，1为在线获取到的离线记录，2为通过U盘获取到的离线记录
        /// </summary>
        public byte OnlineState_Out { get; set; }
	}
}

