﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class CustomCondition
    {
        public enum CustomConditionType
        {
            #region 时间相关条件
            TotalTimeInPark = 0,
            TotalTimeInBigPark,
            TotalTimeInSmallPark,
            TimeInSmallPark,
            TimeInBigPark,
            CurrentTime,
            CurrentDate,
            CurrentDateTime,
            #endregion

            #region 字段值相关条件
            FieldValue = 50,
            #endregion
        }
        public enum ConditionComparator
        {
            Equal = 0,
            GreaterThan,
            LessThan,
            GreaterOrEqual,
            LessOrEqual,
            StartWith,
            EndWith,
            IsNullOrEmpty,
            IsNotNullOrEmpty,
        }
        public enum ConditionCombinator
        {
            And = 0,
            Or
        }

        public CustomConditionType ConditionType { get; set; }
        public string FieldName { get; set; }
        public ConditionComparator Comparator { get; set; }
        public string FieldValue { get; set; }
        public ConditionCombinator Combinator { get; set; }

        public CustomCondition()
        {
        }

        public CustomCondition(CustomConditionType type, string field, ConditionComparator comparator, string value, ConditionCombinator combinator)
        {
            ConditionType = type;
            FieldName = field;
            Comparator = comparator;
            FieldValue = value;
            Combinator = combinator;
        }
    }
}
