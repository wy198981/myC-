﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tVoiceSelfDefine
		public class VoiceSelfDefine
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// VoiceCardNO
        /// </summary>		
		private string _voicecardno;
        public string VoiceCardNO
        {
            get{ return _voicecardno; }
            set{ _voicecardno = value; }
        }        
		/// <summary>
		/// CtrlNumber
        /// </summary>		
		private int _ctrlnumber;
        public int CtrlNumber
        {
            get{ return _ctrlnumber; }
            set{ _ctrlnumber = value; }
        }

        private string _voice;
        public string Voice
        {
            get { return _voice; }
            set { _voice = value; }
        }


        /// <summary>
        /// 人员编号
        /// </summary>
        private string _userNO;
        public string UserNO
        {
            get { return _userNO; }
            set { _userNO = value; }
        }

        /// <summary>
        /// 人员姓名
        /// </summary>
        private string _userName;
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }
	}
}

