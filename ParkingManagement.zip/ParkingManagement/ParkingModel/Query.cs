﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tQuery
		public class Query
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 窗口的Name
        /// </summary>		
		private string _window;
        public string Window
        {
            get{ return _window; }
            set{ _window = value; }
        }        
		/// <summary>
		/// 保存的搜索名
        /// </summary>		
		private string _savename;
        public string SaveName
        {
            get{ return _savename; }
            set{ _savename = value; }
        }        
		/// <summary>
		/// 字段中文名
        /// </summary>		
		private string _showfield_cn;
        public string ShowField_CN
        {
            get{ return _showfield_cn; }
            set{ _showfield_cn = value; }
        }        
		/// <summary>
		/// 字段英文名
        /// </summary>		
		private string _showfield_en;
        public string ShowField_EN
        {
            get{ return _showfield_en; }
            set{ _showfield_en = value; }
        }        
		/// <summary>
		/// 真实字段名
        /// </summary>		
		private string _realfield;
        public string RealField
        {
            get{ return _realfield; }
            set{ _realfield = value; }
        }        
		/// <summary>
		/// 操作符
        /// </summary>		
		private string _op;
        public string OP
        {
            get{ return _op; }
            set{ _op = value; }
        }        
		/// <summary>
		/// 搜索的值
        /// </summary>		
		private string _searchvalue;
        public string SearchValue
        {
            get{ return _searchvalue; }
            set{ _searchvalue = value; }
        }        
		/// <summary>
		/// 数据类型
        /// </summary>		
		private string _datatype;
        public string DataType
        {
            get{ return _datatype; }
            set{ _datatype = value; }
        }        
		/// <summary>
		/// 是否勾选
        /// </summary>		
		private int _selected;
        public int Selected
        {
            get{ return _selected; }
            set{ _selected = value; }
        }        
		/// <summary>
		/// 查询保存的值
        /// </summary>		
		private int _currentshow;
        public int CurrentShow
        {
            get{ return _currentshow; }
            set{ _currentshow = value; }
        }        
		   
	}
}

