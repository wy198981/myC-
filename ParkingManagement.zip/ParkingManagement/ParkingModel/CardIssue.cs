﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tCardIssue
    public class CardIssue
    {
        public CardIssue Copy()
        {
            return (CardIssue)base.MemberwiseClone();
        }

        /// <summary>
        /// ID
        /// </summary>		
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 卡号
        /// </summary>		
        private string _cardno;
        public string CardNO
        {
            get { return _cardno; }
            set { _cardno = value; }
        }
        /// <summary>
        /// 人员编号
        /// </summary>		
        private string _userno;
        public string UserNO
        {
            get { return _userno; }
            set { _userno = value; }
        }
        /// <summary>
        /// 卡片状态。0正常，1挂失指令，2挂失完毕，3解挂指令，4挂失退款，5退卡完毕，6补卡完毕，其它状态未知
        /// </summary>		
        private string _cardstate;
        public string CardState
        {
            get { return _cardstate; }
            set { _cardstate = value; }
        }
        /// <summary>
        /// 卡片押金
        /// </summary>		
        private decimal _cardyj;
        public decimal CardYJ
        {
            get { return _cardyj; }
            set { _cardyj = value; }
        }
        /// <summary>
        /// 开通子系统。Bit位形式的字符串，第1位表示车场，第二位表示门禁，值1表示开通，值0表示不开通。
        /// </summary>		
        private string _subsystem;
        public string SubSystem
        {
            get { return _subsystem; }
            set { _subsystem = value; }
        }
        /// <summary>
        /// 车场卡类。MthA、MthB、TmpA、TmpB等。
        /// </summary>		
        private string _carcardtype;
        public string CarCardType
        {
            get { return _carcardtype; }
            set { _carcardtype = value; }
        }
        /// <summary>
        /// 车场发行日期
        /// </summary>		
        private DateTime _carissuedate;
        public DateTime CarIssueDate
        {
            get { return _carissuedate; }
            set { _carissuedate = value; }
        }
        /// <summary>
        /// 车场发行人卡号
        /// </summary>		
        private string _carissueusercard;
        public string CarIssueUserCard
        {
            get { return _carissueusercard; }
            set { _carissueusercard = value; }
        }
        /// <summary>
        /// 余额
        /// </summary>		
        private decimal _balance;
        public decimal Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }
        /// <summary>
        /// 车场有效起日
        /// </summary>		
        private DateTime _carvalidstartdate;
        public DateTime CarValidStartDate
        {
            get { return _carvalidstartdate; }
            set { _carvalidstartdate = value; }
        }
        /// <summary>
        /// 车场有效止日
        /// </summary>		
        private DateTime _carvalidenddate;
        public DateTime CarValidEndDate
        {
            get { return _carvalidenddate; }
            set { _carvalidenddate = value; }
        }
        /// <summary>
        /// 车牌号码
        /// </summary>		
        private string _cph;
        public string CPH
        {
            get { return _cph; }
            set { _cph = value; }
        }
        /// <summary>
        /// 车颜色。RGB表示法，使用6位十六进制数表示。
        /// </summary>		
        private string _carcolor;
        public string CarColor
        {
            get { return _carcolor; }
            set { _carcolor = value; }
        }
        /// <summary>
        /// 车型。如奔驰、宝马等
        /// </summary>		
        private string _cartype;
        public string CarType
        {
            get { return _cartype; }
            set { _cartype = value; }
        }
        /// <summary>
        /// 车位位置。
        /// </summary>		
        private string _carplace;
        public string CarPlace
        {
            get { return _carplace; }
            set { _carplace = value; }
        }
        /// <summary>
        /// 车场退卡时间
        /// </summary>		
        private DateTime _carwithdrawcarddate;
        public DateTime CarWithdrawCardDate
        {
            get { return _carwithdrawcarddate; }
            set { _carwithdrawcarddate = value; }
        }
        /// <summary>
        /// 车场退卡操作员
        /// </summary>		
        private string _carwithdrawoptcard;
        public string CarWithdrawOptCard
        {
            get { return _carwithdrawoptcard; }
            set { _carwithdrawoptcard = value; }
        }
        /// <summary>
        /// 车场有效机号。十六进制形式。实际上按比特位表示可在哪个设备上通过，比特位为0表示可通过。如7F7F表示在1号机和9号机可通过。
        /// </summary>		
        private string _carvalidmachine;
        public string CarValidMachine
        {
            get { return _carvalidmachine; }
            set { _carvalidmachine = value; }
        }
        /// <summary>
        /// 车场已下载的工作站
        /// </summary>		
        private string _carvalidzone;
        public string CarValidZone
        {
            get { return _carvalidzone; }
            set { _carvalidzone = value; }
        }
        /// <summary>
        /// 车场备注
        /// </summary>		
        private string _carmemo;
        public string CarMemo
        {
            get { return _carmemo; }
            set { _carmemo = value; }
        }
        /// <summary>
        /// 发行日期
        /// </summary>		
        private DateTime _issuedate;
        public DateTime IssueDate
        {
            get { return _issuedate; }
            set { _issuedate = value; }
        }
        /// <summary>
        /// 退卡日期
        /// </summary>		
        private DateTime _withdrawdate;
        public DateTime WithdrawDate
        {
            get { return _withdrawdate; }
            set { _withdrawdate = value; }
        }
        /// <summary>
        /// 发行操作员
        /// </summary>		
        private string _issueusercard;
        public string IssueUserCard
        {
            get { return _issueusercard; }
            set { _issueusercard = value; }
        }
        /// <summary>
        /// 退卡操作员
        /// </summary>		
        private string _withdrawusercard;
        public string WithdrawUserCard
        {
            get { return _withdrawusercard; }
            set { _withdrawusercard = value; }
        }
        /// <summary>
        /// 挂失日期
        /// </summary>		
        private DateTime _lossregdate;
        public DateTime LossregDate
        {
            get { return _lossregdate; }
            set { _lossregdate = value; }
        }
        /// <summary>
        /// 挂失操作员
        /// </summary>		
        private string _lossregusercard;
        public string LossregUserCard
        {
            get { return _lossregusercard; }
            set { _lossregusercard = value; }
        }
        /// <summary>
        /// 物理卡号
        /// </summary>		
        private string _cardidno;
        public string CardIDNO
        {
            get { return _cardidno; }
            set { _cardidno = value; }
        }
        /// <summary>
        /// 下载标志
        /// </summary>		
        private string _CardSyncFlag;
        public string DownloadSignal
        {
            get { return _CardSyncFlag; }
            set { _CardSyncFlag = value; }
        }
        /// <summary>
        /// Tempnumber
        /// </summary>		
        private int _tempnumber;
        public int Tempnumber
        {
            get { return _tempnumber; }
            set { _tempnumber = value; }
        }
        /// <summary>
        /// TimeTeam
        /// </summary>		
        private string _timeteam;
        public string TimeTeam
        {
            get { return _timeteam; }
            set { _timeteam = value; }
        }
        /// <summary>
        /// HolidayLimited
        /// </summary>		
        private string _holidaylimited;
        public string HolidayLimited
        {
            get { return _holidaylimited; }
            set { _holidaylimited = value; }
        }
        /// <summary>
        /// 用户信息
        /// </summary>		
        private string _userinfo;
        public string UserInfo
        {
            get { return _userinfo; }
            set { _userinfo = value; }
        }
        /// <summary>
        /// BackCardNum
        /// </summary>		
        private string _backcardnum;
        public string BackCardNum
        {
            get { return _backcardnum; }
            set { _backcardnum = value; }
        }
        /// <summary>
        /// CardIdLossState
        /// </summary>		
        private string _cardidlossstate;
        public string CardIdLossState
        {
            get { return _cardidlossstate; }
            set { _cardidlossstate = value; }
        }
        /// <summary>
        /// CardIdUnLossState
        /// </summary>		
        private string _cardidunlossstate;
        public string CardIdUnLossState
        {
            get { return _cardidunlossstate; }
            set { _cardidunlossstate = value; }
        }
        /// <summary>
        /// UnLossDate
        /// </summary>		
        private DateTime _unlossdate;
        public DateTime UnLossDate
        {
            get { return _unlossdate; }
            set { _unlossdate = value; }
        }
        /// <summary>
        /// UnLossUer
        /// </summary>		
        private string _unlossuer;
        public string UnLossUer
        {
            get { return _unlossuer; }
            set { _unlossuer = value; }
        }
        /// <summary>
        /// CarFailID
        /// </summary>		
        private string _carfailid;
        public string CarFailID
        {
            get { return _carfailid; }
            set { _carfailid = value; }
        }
        /// <summary>
        /// CaRFailOKNO
        /// </summary>		
        private string _carfailokno;
        public string CaRFailOKNO
        {
            get { return _carfailokno; }
            set { _carfailokno = value; }
        }
        /// <summary>
        /// 下载状态。0失败，1成功。
        /// </summary>		
        private string _downloadstate;
        public string DownLoadState
        {
            get { return _downloadstate; }
            set { _downloadstate = value; }
        }
        /// <summary>
        /// 卡片挂失机号
        /// </summary>		
        private string _cardlossmachine;
        public string CardLossMachine
        {
            get { return _cardlossmachine; }
            set { _cardlossmachine = value; }
        }
        /// <summary>
        /// 车牌下载标记。
        /// </summary>		
        private string _CPHSyncFlag;
        public string CPHDownloadSignal
        {
            get { return _CPHSyncFlag; }
            set { _CPHSyncFlag = value; }
        }
        /// <summary>
        /// Res1
        /// </summary>		
        private string _res1;
        public string Res1
        {
            get { return _res1; }
            set { _res1 = value; }
        }
        /// <summary>
        /// Res2
        /// </summary>		
        private string _res2;
        public string Res2
        {
            get { return _res2; }
            set { _res2 = value; }
        }
        /// <summary>
        /// 月卡类型(全包、包白天、包晚上)
        /// </summary>		
        private int _monthtype;
        public int MonthType
        {
            get { return _monthtype; }
            set { _monthtype = value; }
        }

        #region 人员model
        public string UserName { get; set; }
        public string Sex { get; set; }
        public string HomeAddress { get; set; }
        public string DeptName { get; set; }
        public string Job { get; set; }
        public DateTime? WorkTime { get; set; }
        public DateTime? BirthDate { get; set; }
        public string IDCard { get; set; }
        public string MaritalStatus { get; set; }
        public string HighestDegree { get; set; }
        public string PoliticalStatus { get; set; }
        public string School { get; set; }
        public string Speciality { get; set; }
        public string ForeignLanguage { get; set; }
        public string Skill { get; set; }
        public string TelNumber { get; set; }
        public string MobNumber { get; set; }
        public string ZipCode { get; set; }
        public string NativePlace { get; set; }
        public int CarPlaceNo { get; set; }
        #endregion

        public string CardType { get; set; }

        /// <summary>
        /// 剩余天数
        /// </summary>
        public long SurplusDays { get; set; }
    }
}

