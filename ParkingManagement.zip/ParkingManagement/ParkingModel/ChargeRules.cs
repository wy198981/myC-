﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
namespace ParkingModel
{
    //tChargeRules
    public class ChargeRules
    {

        /// <summary>
        /// ID
        /// </summary>		
        private long _id;
        public long ID
        {
            get { return _id; }
            set { _id = value; }
        }
        /// <summary>
        /// 车场编号
        /// </summary>		
        private int _parkid;
        public int ParkID
        {
            get { return _parkid; }
            set { _parkid = value; }
        }
        /// <summary>
        /// 卡类
        /// </summary>		
        private string _cardtype;
        public string CardType
        {
            get { return _cardtype; }
            set { _cardtype = value; }
        }
        /// <summary>
        /// 免费分钟
        /// </summary>		
        private int _freeminute;
        public int FreeMinute
        {
            get { return _freeminute; }
            set { _freeminute = value; }
        }
        /// <summary>
        /// 最高收费
        /// </summary>		
        private int _topsf;
        public int TopSF
        {
            get { return _topsf; }
            set { _topsf = value; }
        }
        /// <summary>
        /// 小时
        /// </summary>		
        private int? _hours;
        public int? Hours
        {
            get { return _hours; }
            set { _hours = value; }
        }
        /// <summary>
        /// 收费
        /// </summary>		
        private decimal? _je;
        public decimal? JE
        {
            get { return _je; }
            set { _je = value; }
        }

        public T Copy<T>()
        {
            return (T)MemberwiseClone();
        }
    }
}

