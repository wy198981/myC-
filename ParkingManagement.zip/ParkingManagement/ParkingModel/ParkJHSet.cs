﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tParkJHSet
		public class ParkJHSet
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 机号
        /// </summary>		
		private int _ctrlnumber;
        public int CtrlNumber
        {
            get{ return _ctrlnumber; }
            set{ _ctrlnumber = value; }
        }        
		/// <summary>
		/// 名称
        /// </summary>		
		private string _location;
        public string Location
        {
            get{ return _location; }
            set{ _location = value; }
        }        
		   
	}
}

