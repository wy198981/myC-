﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tLost
		public class Lost
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 卡号
        /// </summary>		
		private string _cardno;
        public string CardNO
        {
            get{ return _cardno; }
            set{ _cardno = value; }
        }        
		/// <summary>
		/// 人员编号
        /// </summary>		
		private string _userno;
        public string UserNO
        {
            get{ return _userno; }
            set{ _userno = value; }
        }        
		/// <summary>
		/// CPH
        /// </summary>		
		private string _cph;
        public string CPH
        {
            get{ return _cph; }
            set{ _cph = value; }
        }        
		/// <summary>
		/// 挂失日期
        /// </summary>		
		private DateTime _lossregdate;
        public DateTime LossregDate
        {
            get{ return _lossregdate; }
            set{ _lossregdate = value; }
        }        
		/// <summary>
		/// 操作员编号
        /// </summary>		
		private string _operatorno;
        public string OperatorNO
        {
            get{ return _operatorno; }
            set{ _operatorno = value; }
        }        
		/// <summary>
		/// 卡片状态
        /// </summary>		
		private string _cardstate;
        public string CardState
        {
            get{ return _cardstate; }
            set{ _cardstate = value; }
        }        
		/// <summary>
		/// 车场挂失成功机号
        /// </summary>		
		private string _carlostokid;
        public string CarLostOKID
        {
            get{ return _carlostokid; }
            set{ _carlostokid = value; }
        }        
		/// <summary>
		/// 车场挂失成功标识
        /// </summary>		
		private bool? _carlostokno;
        public bool? CarLostOKNO
        {
            get{ return _carlostokno; }
            set{ _carlostokno = value; }
        }        
		/// <summary>
		/// 车场解挂成功标识
        /// </summary>		
		private bool? _carunlostokno;
        public bool? CarUnLostOKNO
        {
            get{ return _carunlostokno; }
            set{ _carunlostokno = value; }
        }        
		   
	}
}

