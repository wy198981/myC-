﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tConstant
		public class Constant
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// Types
        /// </summary>		
		private string _types;
        public string Types
        {
            get{ return _types; }
            set{ _types = value; }
        }        
		/// <summary>
		/// OrderNO
        /// </summary>		
		private int _orderno;
        public int OrderNO
        {
            get{ return _orderno; }
            set{ _orderno = value; }
        }        
		/// <summary>
		/// Keys
        /// </summary>		
		private string _keys;
        public string Keys
        {
            get{ return _keys; }
            set{ _keys = value; }
        }        
		/// <summary>
		/// Value
        /// </summary>		
		private string _value;
        public string Value
        {
            get{ return _value; }
            set{ _value = value; }
        }        
		/// <summary>
		/// Flag
        /// </summary>		
		private int _flag;
        public int Flag
        {
            get{ return _flag; }
            set{ _flag = value; }
        }        
		   
	}
}

