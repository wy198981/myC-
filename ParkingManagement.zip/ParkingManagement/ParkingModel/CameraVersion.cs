﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class CameraVersion
    {
        public string Version { get; set; }
        public string ReleaseTime { get; set; }
        public string VersionName { get; set; }
        public bool IsOfflineChargeSupported { get; set; }
    }
}
