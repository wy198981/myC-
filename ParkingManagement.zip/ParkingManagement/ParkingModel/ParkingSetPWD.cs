﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tParkingSetPWD
		public class ParkingSetPWD
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 工作站编号
        /// </summary>		
		private int _stationid;
        public int StationID
        {
            get{ return _stationid; }
            set{ _stationid = value; }
        }        
		/// <summary>
		/// 密码
        /// </summary>		
		private string _pwd;
        public string Pwd
        {
            get{ return _pwd; }
            set{ _pwd = value; }
        }        
		/// <summary>
		/// BakeupTime
        /// </summary>		
		private DateTime _bakeuptime;
        public DateTime BakeupTime
        {
            get{ return _bakeuptime; }
            set{ _bakeuptime = value; }
        }        
		   
	}
}

