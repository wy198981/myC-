﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class CaclMoneyResult
    {
        public decimal YSJE { get; set; }
        public decimal SFJE { get; set; }
        public ParkCPHDiscountSet DiscountSet { get; set; }
        public DateTime InTime { get; set; }
        public DateTime OutTime { get; set; }
        public string CardType { get; set; }
        public string CPH { get; set; }
        public int RemainingPlaceCount { get; set; }
    }
}