﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tRightSet
		public class RightSet
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 模块名称
        /// </summary>		
		private string _formname;
        public string FormName
        {
            get{ return _formname; }
            set{ _formname = value; }
        }        
		/// <summary>
		/// 菜单名
        /// </summary>		
		private string _menuname;
        public string MenuName
        {
            get{ return _menuname; }
            set{ _menuname = value; }
        }        
		/// <summary>
		/// 菜单显示名
        /// </summary>		
		private string _menutext;
        public string MenuText
        {
            get{ return _menutext; }
            set{ _menutext = value; }
        }        
		/// <summary>
		/// ValidMark
        /// </summary>		
		private string _validmark;
        public string ValidMark
        {
            get{ return _validmark; }
            set{ _validmark = value; }
        }        
		/// <summary>
		/// KEYVALUE
        /// </summary>		
		private string _keyvalue;
        public string KEYVALUE
        {
            get{ return _keyvalue; }
            set{ _keyvalue = value; }
        }        
		   
	}
}

