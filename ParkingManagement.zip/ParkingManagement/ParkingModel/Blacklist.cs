﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tBlacklist
		public class Blacklist
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// CPH
        /// </summary>		
		private string _cph;
        public string CPH
        {
            get{ return _cph; }
            set{ _cph = value; }
        }        
		/// <summary>
		/// StartTime
        /// </summary>		
		private DateTime _starttime;
        public DateTime StartTime
        {
            get{ return _starttime; }
            set{ _starttime = value; }
        }        
		/// <summary>
		/// EndTime
        /// </summary>		
		private DateTime _endtime;
        public DateTime EndTime
        {
            get{ return _endtime; }
            set{ _endtime = value; }
        }        
		/// <summary>
		/// Reason
        /// </summary>		
		private string _reason;
        public string Reason
        {
            get{ return _reason; }
            set{ _reason = value; }
        }        
		/// <summary>
		/// DownloadSignal
        /// </summary>		
		private string _downloadsignal;
        public string DownloadSignal
        {
            get{ return _downloadsignal; }
            set{ _downloadsignal = value; }
        }        
		/// <summary>
		/// AddDelete
        /// </summary>		
		private int _adddelete;
        public int AddDelete
        {
            get{ return _adddelete; }
            set{ _adddelete = value; }
        }        
		   
	}
}

