﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tAutoTempDownLoad
		public class AutoTempDownLoad
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private int _id;
        public int ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// CPH
        /// </summary>		
		private string _cph;
        public string CPH
        {
            get{ return _cph; }
            set{ _cph = value; }
        }        
		/// <summary>
		/// InTime
        /// </summary>		
		private DateTime _intime;
        public DateTime InTime
        {
            get{ return _intime; }
            set{ _intime = value; }
        }        
		/// <summary>
		/// DownloadSignal
        /// </summary>		
		private string _downloadsignal;
        public string DownloadSignal
        {
            get{ return _downloadsignal; }
            set{ _downloadsignal = value; }
        }        
		/// <summary>
		/// InOut
        /// </summary>		
		private int _inout;
        public int InOut
        {
            get{ return _inout; }
            set{ _inout = value; }
        }        
		   
	}
}

