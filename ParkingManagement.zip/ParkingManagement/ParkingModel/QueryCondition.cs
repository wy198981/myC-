﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class QueryCondition
    {
        public QueryCondition()
        {
            _Combinator = "and";
        }

        public QueryCondition(string fieldName, string oprator, object value, string combinator = "and")
        {
            if (null == fieldName || "" == fieldName.Trim())
            {
                throw new ArgumentNullException("FieldName can't be empty in condition.");
            }
            if (null == oprator || "" == oprator.Trim())
            {
                throw new ArgumentNullException("Operator can't be empty in condition.");
            }
            if (!IsSupportedOperator(oprator))
            {
                throw new NotSupportedException(string.Format("Not supported operator: {0}", oprator));
            }

            FieldName = fieldName;
            Operator = oprator;
            FieldValue = value;
            Combinator = combinator;
        }

        protected string _Combinator;

        /// <summary>
        /// 字段名
        /// </summary>
        public string FieldName { get; set; }
        /// <summary>
        /// 运算符(支持<、>、=、<>、>=、<=、like、not like、null、not null)
        /// </summary>
        public string Operator { get; set; }
        /// <summary>
        /// 字段值
        /// </summary>
        public object FieldValue { get; set; }
        /// <summary>
        /// 逻辑连接符(or 或 and)
        /// </summary>
        public string Combinator
        {
            get
            {
                return null == _Combinator || "" == _Combinator.Trim() ? "and" : _Combinator.Trim();
            }
            set
            {
                _Combinator = value;
            }
        }

        #region 静态成员
        protected static readonly Dictionary<string, string> dicOperator_Operator = new Dictionary<string, string>();

        protected static void LoadDic()
        {
            if (dicOperator_Operator.Count <= 0)
            {
                dicOperator_Operator.Add("<", "<");
                dicOperator_Operator.Add(">", ">");
                dicOperator_Operator.Add("=", "=");
                dicOperator_Operator.Add("<>", "<>");
                dicOperator_Operator.Add("!=", "<>");
                dicOperator_Operator.Add("<=", "<=");
                dicOperator_Operator.Add(">=", ">=");
                dicOperator_Operator.Add("like", "like");
                dicOperator_Operator.Add("notlike", "not like");
                dicOperator_Operator.Add("not like", "not like");
                dicOperator_Operator.Add("null", "is null");
                dicOperator_Operator.Add("isnull", "is null");
                dicOperator_Operator.Add("is null", "is null");
                dicOperator_Operator.Add("notnull", "is not null");
                dicOperator_Operator.Add("not null", "is not null");
                dicOperator_Operator.Add("isnotnull", "is not null");
                dicOperator_Operator.Add("is notnull", "is not null");
                dicOperator_Operator.Add("isnot null", "is not null");
            }
        }

        /// <summary>
        /// 检查运算符是否为支持的符号
        /// </summary>
        /// <param name="op"></param>
        /// <returns></returns>
        public static bool IsSupportedOperator(string op)
        {
            if (null == op || "" == op.Trim())
            {
                return false;
            }

            LoadDic();
            return dicOperator_Operator.ContainsKey(op.Trim().ToLower());
        }

        public static bool IsSupportedCombinator(string op)
        {
            if (null == op || "" == op.Trim())
            {
                return false;
            }

            switch (op.Trim().ToLower())
            {
                case "or":
                case "and":
                    return true;
                default:
                    return false;
            }
        }

        public static string GetOperatorString(string op)
        {
            if (!IsSupportedOperator(op))
            {
                throw new NotSupportedException(string.Format("Not supported operator: {0}", op));
            }

            return dicOperator_Operator[op.Trim().ToLower()];
        }
        #endregion
    }
}
