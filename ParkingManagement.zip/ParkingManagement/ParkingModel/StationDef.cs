﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingModel
{
    public class StationDef
    {
        public int ID { get; set; }
        public int StationId { get; set; }
        public string StationName{get;set;}
    }
}
