﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tOffLineCphDownloadSet
		public class OffLineCphDownloadSet
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// CardNO
        /// </summary>		
		private string _cardno;
        public string CardNO
        {
            get{ return _cardno; }
            set{ _cardno = value; }
        }        
		/// <summary>
		/// CPHCardNO
        /// </summary>		
		private string _cphcardno;
        public string CPHCardNO
        {
            get{ return _cphcardno; }
            set{ _cphcardno = value; }
        }        
		/// <summary>
		/// DownLoadTime
        /// </summary>		
		private DateTime _downloadtime;
        public DateTime DownLoadTime
        {
            get{ return _downloadtime; }
            set{ _downloadtime = value; }
        }        
		/// <summary>
		/// State
        /// </summary>		
		private int _state;
        public int State
        {
            get{ return _state; }
            set{ _state = value; }
        }        
		   
	}
}

