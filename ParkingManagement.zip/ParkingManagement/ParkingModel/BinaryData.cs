﻿using System; 
using System.Text;
using System.Collections.Generic; 
using System.Data;
namespace ParkingModel
{
	 	//tBinaryData
		public class BinaryData
	{
   		     
      	/// <summary>
		/// ID
        /// </summary>		
		private long _id;
        public long ID
        {
            get{ return _id; }
            set{ _id = value; }
        }        
		/// <summary>
		/// 分类。如车场，门禁
        /// </summary>		
		private string _category;
        public string Category
        {
            get{ return _category; }
            set{ _category = value; }
        }        
		/// <summary>
		/// 表名
        /// </summary>		
		private string _tablename;
        public string TableName
        {
            get{ return _tablename; }
            set{ _tablename = value; }
        }        
		/// <summary>
		/// 记录ID
        /// </summary>		
		private long _rowid;
        public long RowID
        {
            get{ return _rowid; }
            set{ _rowid = value; }
        }        
		/// <summary>
		/// 数据标识。有可能一条记录对应多个数据（如出场记录有入场照片和出场照片），用一个标识区分。
        /// </summary>		
		private string _dataindex;
        public string DataIndex
        {
            get{ return _dataindex; }
            set{ _dataindex = value; }
        }        
		/// <summary>
		/// 记录对应的数据
        /// </summary>		
		private byte[] _data;
        public byte[] Data
        {
            get{ return _data; }
            set{ _data = value; }
        }        
		   
	}
}

